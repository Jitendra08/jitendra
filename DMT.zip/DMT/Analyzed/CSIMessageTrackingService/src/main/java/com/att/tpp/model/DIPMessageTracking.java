package com.att.tpp.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Lob;
import javax.persistence.NamedQuery;
import javax.persistence.Table;

@Entity
@Table(name="DIP_MESSAGE_TRACKING")
@NamedQuery(name="DIPMessageTracking.findAll", query="SELECT d FROM DIPMessageTracking d")
public class DIPMessageTracking {
	
	private static final long serialVersionUID = 1L;
	
	@Id
    @Column(name="MESSAGEID", nullable=false)
	private String messageId;

	@Column(name="DIP_MESSAGEID")
	private String dipMessageId;

	@Column(name="EVENT_NAME")
	private String eventName;
	
	@Column(name="MESSAGE_TYPE")
	private String messageType;
	
	@Column(name="CONVID")
	private String convid;

	@Column(name="RESPONSE_CODE")
	private String responseCode;

	@Column(name="RESPONSE_DESC")
	private String responseDesc;

	@Column(name="DB_TIMESTAMP")
	private java.sql.Timestamp dbTimestamp;
	
	@Column(name="REQUEST_TIME")
	private java.sql.Timestamp requestTime;
	
	@Lob
	@Column(name="INPUT_XML")
	private String inputXml;

	public String getMessageId() {
		return messageId;
	}

	public void setMessageId(String messageId) {
		this.messageId = messageId;
	}

	public String getDipMessageId() {
		return dipMessageId;
	}

	public void setDipMessageId(String dipMessageId) {
		this.dipMessageId = dipMessageId;
	}

	public String getEventName() {
		return eventName;
	}

	public void setEventName(String eventName) {
		this.eventName = eventName;
	}

	public String getMessageType() {
		return messageType;
	}

	public void setMessageType(String messageType) {
		this.messageType = messageType;
	}

	public String getConvid() {
		return convid;
	}

	public void setConvid(String convid) {
		this.convid = convid;
	}

	public String getResponseCode() {
		return responseCode;
	}

	public void setResponseCode(String responseCode) {
		this.responseCode = responseCode;
	}

	public String getResponseDesc() {
		return responseDesc;
	}

	public void setResponseDesc(String responseDesc) {
		this.responseDesc = responseDesc;
	}

	public java.sql.Timestamp getDbTimestamp() {
		return dbTimestamp;
	}

	public void setDbTimestamp(java.sql.Timestamp dbTimestamp) {
		this.dbTimestamp = dbTimestamp;
	}

	public java.sql.Timestamp getRequestTime() {
		return requestTime;
	}

	public void setRequestTime(java.sql.Timestamp requestTime) {
		this.requestTime = requestTime;
	}

	public String getInputXml() {
		return inputXml;
	}

	public void setInputXml(String inputXml) {
		this.inputXml = inputXml;
	}
	

}
