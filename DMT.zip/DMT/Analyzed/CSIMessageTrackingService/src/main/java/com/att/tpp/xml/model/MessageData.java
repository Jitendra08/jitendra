package com.att.tpp.xml.model;

public class MessageData {
	
	private String messageId;
	private String dipMessageId;
	private String eventName;
	private String messageType;
	private String convid;
	private String responseCode;
	private String responseDesc;
	private String dbTimestamp;
	private String requestTime;
	private String inputXml;
	
	public MessageData(){
		
	}
	
	public MessageData(String messageId, String dipMessageId, String eventName,
			String messageType, String convid, String responseCode,
			String responseDesc, String dbTimestamp, String requestTime,
			String inputXml) {
		super();
		this.messageId = messageId;
		this.dipMessageId = dipMessageId;
		this.eventName = eventName;
		this.messageType = messageType;
		this.convid = convid;
		this.responseCode = responseCode;
		this.responseDesc = responseDesc;
		this.dbTimestamp = dbTimestamp;
		this.requestTime = requestTime;
		this.inputXml = inputXml;
	}
	
	public String getMessageId() {
		return messageId;
	}
	public void setMessageId(String messageId) {
		this.messageId = messageId;
	}
	public String getDipMessageId() {
		return dipMessageId;
	}
	public void setDipMessageId(String dipMessageId) {
		this.dipMessageId = dipMessageId;
	}
	public String getEventName() {
		return eventName;
	}
	public void setEventName(String eventName) {
		this.eventName = eventName;
	}
	public String getMessageType() {
		return messageType;
	}
	public void setMessageType(String messageType) {
		this.messageType = messageType;
	}
	public String getConvid() {
		return convid;
	}
	public void setConvid(String convid) {
		this.convid = convid;
	}
	public String getResponseCode() {
		return responseCode;
	}
	public void setResponseCode(String responseCode) {
		this.responseCode = responseCode;
	}
	public String getResponseDesc() {
		return responseDesc;
	}
	public void setResponseDesc(String responseDesc) {
		this.responseDesc = responseDesc;
	}
	public String getDbTimestamp() {
		return dbTimestamp;
	}
	public void setDbTimestamp(String dbTimestamp) {
		this.dbTimestamp = dbTimestamp;
	}
	public String getRequestTime() {
		return requestTime;
	}
	public void setRequestTime(String requestTime) {
		this.requestTime = requestTime;
	}
	public String getInputXml() {
		return inputXml;
	}
	public void setInputXml(String inputXml) {
		this.inputXml = inputXml;
	}
	

}
