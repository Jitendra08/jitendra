
package com.att.tpp.jms.listener;

import javax.jms.JMSException;
import javax.jms.Message;
import javax.jms.MessageListener;
//import javax.jms.ObjectMessage;
import javax.jms.TextMessage;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;






import com.att.tpp.controller.CSIMessageTrackingController;

/**
 * Class handles  CSI DIP messages
 */
@Service
public class CSIMessageTrackingListener implements MessageListener
{
	private static final Logger csiMessageTrackingListenerLog = Logger.getLogger(CSIMessageTrackingListener.class);
	
	@Autowired
	private CSIMessageTrackingController csiMessageTrackingController;
	
	/**
	 * Method implements JMS onMessage and acts as the entry
	 * point for messages consumed by Springs DefaultMessageListenerContainer.
	 * When DefaultMessageListenerContainer picks a message from the queue it
	 * invokes this method with the message csiDIPMsg.
	 */
	public void onMessage(Message csiDIPMsg)
	{
		csiMessageTrackingListenerLog.debug("Received message from Request Queue [" + csiDIPMsg +"]");

		/* The message must be of type TextMessage */
		if (csiDIPMsg instanceof TextMessage)
		{
			try
			{
				String csiDipMsg = ((TextMessage) csiDIPMsg).getText();
				csiMessageTrackingListenerLog.info("CSIMessageTrackingListener Message received: " + csiDipMsg);
				String msgType = csiDIPMsg.getStringProperty("TYPE");
				if(csiDipMsg!=null){
									
					boolean postSuccess = csiMessageTrackingController.processRequest(csiDipMsg, msgType);
				
				}else{
					csiMessageTrackingListenerLog.info("csiDIPMsg is empty, no action to be taken in the CSIMessageTracking service");
				}
			}
			catch (JMSException jmsExc)
			{
				String errMsg = "An error occurred extracting message";
				csiMessageTrackingListenerLog.error(errMsg, jmsExc);
			} catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		else
		{
			String errMsg = "Message is not of expected type TextMessage";
			csiMessageTrackingListenerLog.error(errMsg);
			throw new RuntimeException(errMsg);
		}
	}

	
}