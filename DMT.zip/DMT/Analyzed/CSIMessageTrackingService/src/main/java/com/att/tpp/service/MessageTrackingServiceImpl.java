package com.att.tpp.service;

import java.io.IOException;
import java.sql.Timestamp;
import java.util.Date;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.att.tpp.dao.MessageTrackingDao;
import com.att.tpp.model.DIPMessageTracking;
import com.att.tpp.utils.MessageTrackingParser;
import com.att.tpp.xml.model.MessageData;



@Service("msgTrackingService")
public class MessageTrackingServiceImpl implements MessageTrackingService {
	
	@Autowired
	private MessageTrackingDao messageTrackingDao;	
	
	private static Logger messageTrackingServiceImplLog = Logger.getLogger(MessageTrackingServiceImpl.class);
	@Override
	public boolean parseDIPMessage(String csiDipMsg, String msgType)throws IOException, Exception {
		
		MessageData messageData = new MessageData();
		
		MessageTrackingParser msgTrackingParser = new MessageTrackingParser();
		messageData = msgTrackingParser.parseDIPMessage(csiDipMsg, msgType);
		
		DIPMessageTracking dipMsg = new DIPMessageTracking();
		Date date = new Date();
		
		dipMsg.setMessageId(messageData.getMessageId());
		dipMsg.setDipMessageId(messageData.getDipMessageId());
		dipMsg.setEventName(messageData.getEventName());
		dipMsg.setMessageType(messageData.getMessageType());
		dipMsg.setConvid(messageData.getConvid());
		dipMsg.setResponseCode(messageData.getResponseCode());
		dipMsg.setResponseDesc(messageData.getResponseDesc());
		dipMsg.setDbTimestamp(new Timestamp(date.getTime()));
		dipMsg.setRequestTime(new Timestamp(date.getTime()));
		dipMsg.setInputXml(messageData.getInputXml());
		
		boolean insertMsg = messageTrackingDao.insertMessageDetails(dipMsg);
		
		return insertMsg;
	}
}
