package com.att.tpp.controller;

import java.io.IOException;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.att.tpp.service.MessageTrackingService;

@Service("csiMessageTrackingController")
public class CSIMessageTrackingController {
	
	@Autowired
	private MessageTrackingService msgTrackingService;
	
	private static final Logger csiMessageTrackingControllerLog = Logger.getLogger(CSIMessageTrackingController.class);
	
	public boolean processRequest(String csiDipMsg, String msgType) throws IOException, Exception{
		boolean postSuccess = false;
		postSuccess = msgTrackingService.parseDIPMessage(csiDipMsg, msgType);
		csiMessageTrackingControllerLog.info("postSuccess = " + postSuccess);
		return postSuccess;
	}
}
	

