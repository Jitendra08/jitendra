package com.att.tpp.dao;

import com.att.tpp.model.DIPMessageTracking;

public interface MessageTrackingDao {
	
	public boolean insertMessageDetails(DIPMessageTracking msgData);

}
