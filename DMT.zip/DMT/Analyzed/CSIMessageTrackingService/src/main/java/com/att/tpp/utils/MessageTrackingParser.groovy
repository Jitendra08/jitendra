package com.att.tpp.utils
import com.att.tpp.xml.model.MessageData;

import groovy.util.logging.*

@Log4j
public class MessageTrackingParser {
	
	def MessageData parseDIPMessage(String csiDIPXML, String messageType){
		def strSoapXML = new XmlSlurper().parseText(csiDIPXML);
		def messageHeader = strSoapXML.Header.MessageHeader.TrackingMessageHeader;
		def parsedConId = null;
		def messageId = null;
		def dipMessageId = null;
		def eventName = null;
		
		def reqTime = new Date().toString();
		
		
		dipMessageId=messageHeader?.messageId?.toString();
		if(dipMessageId != null){
			messageId=dipMessageId.substring(dipMessageId.indexOf("_")+1,dipMessageId.length());
			eventName=dipMessageId.substring(0,dipMessageId.indexOf("_"));
		}
		
		def strException = null;
		def strResponse = null;
		if(messageType != null && messageType.equalsIgnoreCase("RESPONSE")){
			parsedConId=messageHeader?.conversationId?.toString();
			if(eventName != null && eventName.equalsIgnoreCase("IAP")){
				strResponse = strSoapXML.Body?.InquireAccountProfileResponse?.Response;
			}else if(eventName != null && eventName.equalsIgnoreCase("IFP")){
				strResponse = strSoapXML.Body?.InquireFanProfileResponse ?.Response;
			}else if(eventName != null && eventName.equalsIgnoreCase("ICIF")){
				strResponse = strSoapXML.Body?.InquireCustomerInformationFormResponse?.Response;
			}else if(eventName != null && eventName.equalsIgnoreCase("IPCP")){
				strResponse = strSoapXML.Body?.InquireSubscriberParentalControlsResponse?.Response;
			}
			
			if(strResponse.size() <= 0){
				strResponse = strSoapXML.Body?.Fault?.detail?.CSIApplicationException?.Response;
			}
		}
		
		log.info("messageId ---> " + messageId);
		log.info("dipMessageId ---> " + dipMessageId);
		log.info("parsedConId ---> " + parsedConId);
		
		def errorCode = null;
		def errorDesc = null;
		errorCode = strResponse?.code?.toString();
		errorDesc = strResponse?.description?.toString();
		return new  MessageData(messageId,dipMessageId,eventName,messageType,parsedConId,errorCode,errorDesc,reqTime,reqTime,csiDIPXML);
	}
	
	static main(args) {
		MessageTrackingParser mtp = new MessageTrackingParser()
		def com.att.tpp.xml.model.MessageData temp = mtp.parseDIPMessage(new File("C:\\TestXML\\soapRes1.xml").text,"RESPONSE");
	}

}
