package com.att.tpp.dao;

import org.apache.log4j.Logger;
import org.hibernate.HibernateException;
import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.att.tpp.model.DIPMessageTracking;

@Repository("messageTrackingDao")
public class MessageTrackingDaoImpl implements MessageTrackingDao{
	
	private static final Logger messageTrackingDaoImpl = Logger.getLogger(MessageTrackingDaoImpl.class);
	
	@Autowired
	private SessionFactory sessionFactoryArchive;
	
	@Transactional
	public boolean insertMessageDetails(DIPMessageTracking dipMessageTracking) {
		messageTrackingDaoImpl.debug("Inside MessageTrackingDaoImpl insertMessageDetails method");
		try {
			sessionFactoryArchive.getCurrentSession().save(dipMessageTracking);		
			sessionFactoryArchive.getCurrentSession().flush();
			return true;
		}catch (HibernateException e) {
			messageTrackingDaoImpl.error("Exception occured in the MessageTrackingDaoImpl insertMessageDetails method :"+e.getMessage());
			return false;
		}
	}

}
