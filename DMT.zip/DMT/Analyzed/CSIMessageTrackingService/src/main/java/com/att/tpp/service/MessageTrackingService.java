package com.att.tpp.service;

import java.io.IOException;


public interface MessageTrackingService {
	
	boolean parseDIPMessage(String csiDipMsg, String msgType) throws IOException, Exception;
}
