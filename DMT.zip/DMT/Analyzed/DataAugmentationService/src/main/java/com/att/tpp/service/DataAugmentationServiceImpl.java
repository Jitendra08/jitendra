package com.att.tpp.service;

import java.io.IOException;
import java.math.BigDecimal;
import java.net.URL;
import java.sql.Timestamp;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Collection;
import java.util.Date;

import javax.xml.soap.SOAPMessage;
import javax.xml.transform.Source;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.stream.StreamResult;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.att.tpp.dao.DataAugmentationDao;
import com.att.tpp.enumuration.CSIDipType;
import com.att.tpp.utils.DataAugXMLParser;
import com.att.tpp.utils.TPP_ProvisioningRequestXMLGenerator;
import com.att.tpp.model.CSIDipKeys;
import com.att.tpp.model.CsidipArchive;
import com.att.tpp.utils.ValidateXMLUtil;
import com.att.tpp.ws.InquireAccountProfile;
import com.att.tpp.ws.InquireFanProfile;
import com.att.tpp.ws.InquireFanProfileContacts;
import com.att.tpp.ws.InquireSubscriberParentalControl;
import com.att.tpp.ws.RomeInquireFanProfile;
import com.att.tpp.ws.InquireCustomerInformationForm;
import com.att.tpp.xml.model.BillingAccount.FAN;
import com.att.tpp.xml.model.CustRegContactInfoBASE;
import com.att.tpp.xml.model.SalesReps;
import com.att.tpp.xml.model.TPPProvisioningRequest;
import com.cingular.csi.csi.namespaces.container._public.inquireaccountprofileresponse.InquireAccountProfileResponseInfo;
import com.cingular.csi.csi.namespaces.container._public.inquirecustomerinformationformresponse.InquireCustomerInformationFormResponseInfo;
import com.cingular.csi.csi.namespaces.container._public.inquirefanprofileresponse.InquireFanProfileResponseInfo;
import com.cingular.csi.csi.namespaces.container._public.inquiresubscriberparentalcontrolsresponse.InquireSubscriberParentalControlsResponseInfo;


/**
 * @author Satish Gottumukkala June 2014
 * 
 *         DataAugmentationServiceImpl serves the DataAugmentation Contoller requests
 *         by using the CSI Webservice and the util services.
 */

@Service("dataAugmentationService")
public class DataAugmentationServiceImpl implements DataAugmentationService {
	
	@Autowired
	private InquireAccountProfile inquireAccountProfile;
	
	@Autowired
	private InquireFanProfile inquireFanProfile;
	
	@Autowired
	private InquireSubscriberParentalControl inquireSubscriberParentalControl;
	
	@Autowired
	private InquireFanProfileContacts inquireFanProfileContacts;
	
	@Autowired
	private RomeInquireFanProfile  romeInquireFanProfile;
	
	@Autowired
	private InquireCustomerInformationForm inquireCustomerInformationForm;
	
	@Autowired
	private DataAugmentationDao dataAugmentationDao;
	
	private static Logger dataAugmentationServiceLog = Logger.getLogger(DataAugmentationServiceImpl.class);

	private final static String schemaDir = "//com//att//tpp//common//schemas//";	
	
	
	@Override
	//Validate the provisioning request XML with XSD
	public boolean validateXML(String inputXML, String xsdName)
			throws IOException, Exception {
		boolean validationResult = false;
		StringBuilder schemaLocation = new StringBuilder(schemaDir);
		schemaLocation.append(xsdName);
		URL xsdPath = DataAugmentationServiceImpl.class
				.getResource(schemaLocation.toString());
		dataAugmentationServiceLog.debug("xsdPath :" + xsdPath.toString());
		validationResult = ValidateXMLUtil.validateWithXSD(inputXML,xsdPath.toString());
		dataAugmentationServiceLog.debug("validationResult :" + validationResult);
		return validationResult;
	}

	
	@Override
	public TPPProvisioningRequest invokeCSIWebService(String csiDips, String requestXML, CSIDipKeys csiDipKeys)
			throws Exception {
		
		//Write logic to get the msidn or fan 
		//Todo: Place holder for response info
		
		/*csiDips="IBP";*/
		
		InquireAccountProfileResponseInfo inquireAccountProfileResponse = null;
		InquireFanProfileResponseInfo inquireFanProfileResponse = null;
		InquireSubscriberParentalControlsResponseInfo  inquireSubscriberParentalControlsResponse = null;		
		//InquireFANProfileContactsResponse inquireFanProfileContactsResponse = null;
		Collection<CustRegContactInfoBASE> inquireFanProfileContactsResponse = null;
		Collection<SalesReps> romeInquireFanProfileResponse = null;
		InquireCustomerInformationFormResponseInfo  inquireCustomerInformationFormResponse = null;	
		String iapResFAN = null;
		String iapResBAN = null;
		dataAugmentationServiceLog.info("DIP Type : "+ csiDips);
		
		if (csiDips.toUpperCase().contains(CSIDipType.IAP.toString().toUpperCase())) {		
			 //inquireAccountProfileResponse = inquireAccountProfile.getInquireAccountProfileResponse("2142050279", "testMessageId");
			try{
			 inquireAccountProfileResponse = inquireAccountProfile.getInquireAccountProfileResponse(csiDipKeys);
			 //dataAugmentationServiceLog.info("DIP Type : "+ csiDips);
			// dataAugmentationServiceLog.info("BAN : "+ inquireAccountProfileResponse.getAccount().getBillingAccountNumber());
			}catch(Exception e){
				dataAugmentationServiceLog.error("Exception occured in IAP Dip service : "+ e.getMessage());
				//e.printStackTrace();
			}
			//TPP_ProvisionRequest.xml and inserting into CSI_DIP Archive
			//New logic --> Insert into DB except for clob

		}
		
		if(inquireAccountProfileResponse != null){
			iapResFAN = inquireAccountProfileResponse.getAccount().getFan();
			dataAugmentationServiceLog.info("FAN number from IAP DIP :: "+ iapResFAN);
			iapResBAN = inquireAccountProfileResponse.getAccount().getBillingAccountNumber();
			dataAugmentationServiceLog.info("BAN number from IAP DIP :: "+ iapResBAN);
			
			 //DEALER_CODE
			dataAugmentationServiceLog.info("DEALER_CODE : "+ inquireAccountProfileResponse.getAccount().getCommission().getDealer().getCode());
			//AGENT_LOCATION
			dataAugmentationServiceLog.info("AGENT_LOCATION : "+ inquireAccountProfileResponse.getAccount().getCommission().getLocation());
			// DLR_NAME or ATTUID ??
			dataAugmentationServiceLog.info("SalesRepID : "+ inquireAccountProfileResponse.getAccount().getCommission().getSalesRepresentative());
			//Do we need this??
			dataAugmentationServiceLog.info("SalesRepID : "+ inquireAccountProfileResponse.getAccount().getCommission().getDualCommission());
		}

		if(csiDipKeys.getFanData() != null){
			String strfan = csiDipKeys.getFanData().getCurrentFAN();
			dataAugmentationServiceLog.info("FAN number from Request xml :: "+ strfan);
			if(strfan !=null && !strfan.equalsIgnoreCase("null") && !strfan.equals("")){
				dataAugmentationServiceLog.info("FAN number from Request xml is not null.");
			}else if(iapResFAN!=null && !iapResFAN.equalsIgnoreCase("null") && !iapResFAN.equals("")){
				dataAugmentationServiceLog.info("Creating FAN Data with IAP FAN number setting into csiDipKeys...");
				csiDipKeys.setFanData(new FAN(iapResFAN));
			}else {
				dataAugmentationServiceLog.info("FAN is null in both IAP DIP and Request xml...");
			}
		}else if(iapResFAN!=null && !iapResFAN.equalsIgnoreCase("null") && !iapResFAN.equals("")){
			dataAugmentationServiceLog.info("FanData is null so creating FAN Data with IAP FAN number setting into csiDipKeys.");
			csiDipKeys.setFanData(new FAN(iapResFAN));
		}else {
			dataAugmentationServiceLog.info("FAN is null in both IAP DIP and Request xml");
		}
		
		//String iapResFAN = null;
		if (csiDips.toUpperCase().contains(CSIDipType.IFP.toString().toUpperCase())) {
			/**********************************************
			 * Start
			 * Below parts moved up to make common for all other DIPs  
			 */
			/*if(inquireAccountProfileResponse != null){
				iapResFAN = inquireAccountProfileResponse.getAccount().getFan();
				dataAugmentationServiceLog.info("IFP DIP :: FAN number from IAP DIP :: "+ iapResFAN);
			}
			if(csiDipKeys.getFanData() != null){
				String strfan = csiDipKeys.getFanData().getCurrentFAN();
				dataAugmentationServiceLog.info("IFP DIP :: FAN number from Request xml :: "+ strfan);
				if(strfan !=null){
					dataAugmentationServiceLog.info("IFP DIP :: FAN number from Request xml is not null.");
				}else{
					dataAugmentationServiceLog.info("IFP DIP :: IAP FAN number setting into csiDipKeys. ");
						csiDipKeys.getFanData().setCurrentFAN(iapResFAN);
				}
			}else{
				dataAugmentationServiceLog.info("IFP DIP :: Creating FAN Data with IAP FAN number setting into csiDipKeys.");
				csiDipKeys.setFanData(new FAN(iapResFAN));
			}*/
			/**********************************************
			 * End
			 * Below parts moved up to make common for all other DIPs  
			 */
			if(csiDipKeys.getFanData()!=null && csiDipKeys.getFanData().getCurrentFAN()!=null){
				try{
					inquireFanProfileResponse = inquireFanProfile.getInquireFanProfileResponse(csiDipKeys);
					//dataAugmentationServiceLog.info("ContractId : "+ inquireFanProfileResponse.getProfile().getContractId());
				}catch(Exception e){
					dataAugmentationServiceLog.info("Exception occured in IFP Dip service : "+ e);
					e.printStackTrace();
				}
			}else{
				dataAugmentationServiceLog.info("IFP DIP :: Fan is null in csiDipKeys.");
			}

			
		} 
		
		if (csiDips.toUpperCase().contains(CSIDipType.IBP.toString().toUpperCase())) {
			if(csiDipKeys.getFanData()!=null && csiDipKeys.getFanData().getCurrentFAN()!=null){
				try{
					inquireFanProfileContactsResponse = inquireFanProfileContacts.getInquireFanProfileContactsResponse(csiDipKeys);
				}catch(Exception e){
					dataAugmentationServiceLog.info("Exception occured in IBP Dip service : "+ e);
					e.printStackTrace();
				}
			}else{
				dataAugmentationServiceLog.info("IBP DIP :: Fan is null in csiDipKeys.");
			}
			//Invoke InquireFanProfile from Rome to get salesReps info
			if (csiDips.toUpperCase().contains(CSIDipType.IFP.toString().toUpperCase())) {
				if(csiDipKeys.getFanData()!=null && csiDipKeys.getFanData().getCurrentFAN()!=null){
					try{
						romeInquireFanProfileResponse = romeInquireFanProfile.getInquireFanProfileResponse(csiDipKeys);
					}catch(Exception e){
						dataAugmentationServiceLog.info("Exception occured in RomeInquireFanProfile  Dip service : "+ e);
						e.printStackTrace();
					}
				}else{
					dataAugmentationServiceLog.info("Skip RomeInquireFanProfile since FAN is not avaiable");
				}
			}
		} 
		
		if (csiDips.toUpperCase().contains(CSIDipType.IPCP.toString().toUpperCase())) {
			 try{
			 inquireSubscriberParentalControlsResponse = inquireSubscriberParentalControl.getInquireSubscriberParentalControlResponse(csiDipKeys);
				}catch(Exception e){
					dataAugmentationServiceLog.info("Exception occured in IPCP Dip service : "+ e);
					e.printStackTrace();
				}
			//dataAugmentationServiceLog.info("ReasonCode : "+ inquireSubscriberParentalControlsResponse.getParentalControls().getReasonCode());
		} 
		
//		String iapBAN = null;
//		String iapFAN = null;
		if (csiDips.toUpperCase().contains(CSIDipType.ICIF.toString().toUpperCase())) {
			/**********************************************
			 * Start
			 * Below parts moved up to make common for all other DIPs  
			 */
			
/*			dataAugmentationServiceLog.info("csiDipKeys.getHeader().getAtlasEventType() : "+ csiDipKeys.getHeader().getAtlasEventType());
			dataAugmentationServiceLog.info("inquireAccountProfileResponse :: "+inquireAccountProfileResponse);
			if(inquireAccountProfileResponse !=null){
				dataAugmentationServiceLog.info("inquireAccountProfileResponse.getAccount() :: "+inquireAccountProfileResponse.getAccount());
				dataAugmentationServiceLog.info("inquireAccountProfileResponse.getAccount().getBillingAccountNumber() : "+ inquireAccountProfileResponse.getAccount().getBillingAccountNumber());
				dataAugmentationServiceLog.info("inquireAccountProfileResponse.getAccount().getFan() : "+ inquireAccountProfileResponse.getAccount().getFan());
			}
			dataAugmentationServiceLog.info("csiDipKeys.getAccountData() : "+ csiDipKeys.getAccountData());
			dataAugmentationServiceLog.info("csiDipKeys.getFanData() : "+ csiDipKeys.getFanData());
			dataAugmentationServiceLog.info("csiDipKeys.getAccountData().getBan() : "+ csiDipKeys.getAccountData().getBan());
			
			if(csiDipKeys.getHeader().getAtlasEventType()!= null && csiDipKeys.getHeader().getAtlasEventType().equalsIgnoreCase("DCMNotification") && inquireAccountProfileResponse != null){
				dataAugmentationServiceLog.info("Inside the DCM ICIF loop");
				iapBAN = inquireAccountProfileResponse.getAccount().getBillingAccountNumber();
				iapFAN = inquireAccountProfileResponse.getAccount().getFan();
				dataAugmentationServiceLog.info("iapBAN : "+ iapBAN);
				dataAugmentationServiceLog.info("iapFAN : "+ iapFAN);
				if(csiDipKeys.getAccountData() != null){
					csiDipKeys.getAccountData().setBan(iapBAN);
					dataAugmentationServiceLog.info("BAN set for ICIF from IAP DIP : : "+ csiDipKeys.getAccountData().getBan());
				}
				if(iapFAN != null){
					if(csiDipKeys.getFanData() != null){
						csiDipKeys.getFanData().setCurrentFAN(iapFAN);
						dataAugmentationServiceLog.info("Inside if :: FAN set for ICIF from IAP DIP : "+ csiDipKeys.getFanData().getCurrentFAN());
					}else{
						csiDipKeys.setFanData(new FAN(iapFAN));
						dataAugmentationServiceLog.info("Inside else :: FAN set for ICIF from IAP DIP ::: "+ csiDipKeys.getFanData().getCurrentFAN());
					}
				}
			}*/
				/**********************************************
				 * End
				 * Below parts moved up to make common for all other DIPs  
				 */
			/*******************************
			 * Assignning iapResBAN to BAN number not required for other DIPs 
			 * as it is mandatory field in Atlas xml.			 * 
			 */
			if(csiDipKeys.getAccountData()!=null && csiDipKeys.getAccountData().getBan()!=null && !csiDipKeys.getAccountData().getBan().equals("") && !csiDipKeys.getAccountData().getBan().equalsIgnoreCase("null")){
				dataAugmentationServiceLog.info("BAN is present in Request xml.");
			}else if(iapResBAN!=null && !iapResBAN.equalsIgnoreCase("null") && !iapResBAN.equals("")){
				csiDipKeys.getAccountData().setBan(iapResBAN);
				dataAugmentationServiceLog.info("BAN set for ICIF from IAP DIP :: "+ csiDipKeys.getAccountData().getBan());
			}else{
					dataAugmentationServiceLog.info("BAN is null in both IAP and Request xml.");
			}
			
		//	dataAugmentationServiceLog.info("ICIF Dip :: BAN : "+ csiDipKeys.getAccountData().getBan());
		//	dataAugmentationServiceLog.info("ICIF Dip :: FAN : "+ csiDipKeys.getFanData().getCurrentFAN());
			 try{
				 inquireCustomerInformationFormResponse = inquireCustomerInformationForm.getInquireCustomerInformationFormResponse(csiDipKeys);
				}catch(Exception e){
					dataAugmentationServiceLog.info("Exception occured in ICIF Dip service : "+ e);
					e.printStackTrace();
				}
		}
		
		TPPProvisioningRequest tppProvisioningRequest = new TPPProvisioningRequest();
		
		//TPP_ProvisionRequest.xml( InquireAccountProfileResponseInfo, InquireFanProfileResponseInfo, inquireFanProfileContactsResponse, InquireSubscriberParentalControlsResponseInfo)
		//Insert result into DB
		DataAugXMLParser dataAugXML = new DataAugXMLParser();
		tppProvisioningRequest = dataAugXML.getTPPProvReq(requestXML, inquireAccountProfileResponse, inquireFanProfileResponse,
				inquireFanProfileContactsResponse, inquireSubscriberParentalControlsResponse, inquireCustomerInformationFormResponse, csiDips,romeInquireFanProfileResponse);
		// dataAugmentationServiceLog.info("DIP Type : "+ csiDips);
		
		//Write logic to grab all response and build TPPProvRequest		
		 
		return tppProvisioningRequest;
	}
	
	
	
	public  boolean persistDipResults(CSIDipKeys csiDipKeys, String eventName, String errorCode, String errorDesc) throws ParseException {
		com.att.tpp.model.CsidipArchive csiDipArchive = new CsidipArchive();
		BigDecimal bigDecimal = new BigDecimal(0);
		
		String msisdn = csiDipKeys.getAccountData().getMsisdn();
		String subId = csiDipKeys.getAccountData().getSubscriberNumber();
		String messageId = csiDipKeys.getHeader().getTransactionId();
		
		csiDipArchive.setProvsystrxid(messageId);
		csiDipArchive.setMsisdn(msisdn);
		csiDipArchive.setSubid(subId);
		csiDipArchive.setEventName(eventName);
		csiDipArchive.setTimestamp(generateTimeStamp());
		csiDipArchive.setCsidipcount(bigDecimal);
		csiDipArchive.setErrorcode(errorCode);
		if(errorDesc != null && errorDesc.length() > 199){
			csiDipArchive.setErrordesc(errorDesc.substring(0, 199).toString());
		}else{
			csiDipArchive.setErrordesc(errorDesc);
		}
		csiDipArchive.setLoadXml("");
		csiDipArchive.setMaxcsicount(bigDecimal);
		
		boolean persistDipResult = dataAugmentationDao.persistDipResult(csiDipArchive);
		return persistDipResult;
		
	}
	
	
	public  Timestamp generateTimeStamp() throws ParseException {
		Date now = new Date();
		String VPP_DATE_FORMAT = "dd-MM-yyyy hh:mm a";
		SimpleDateFormat simpleDateFormat = new SimpleDateFormat(VPP_DATE_FORMAT);
		String formatedString = simpleDateFormat.format(now);
		java.util.Date parsedDate = simpleDateFormat.parse(formatedString);
		java.sql.Timestamp timestamp = new java.sql.Timestamp(
				parsedDate.getTime());
		return timestamp;
	}
	
	
	public String getCTNFromMsidn(String msisdn) {
		String ctn=null;
		if(msisdn.length()>10){
		
			ctn = msisdn.substring(((msisdn.length())-10), (msisdn.length()));
		}else{
			ctn=msisdn;
		}
		return ctn;
	}


	@Override
	public String createTPPProvReqXML(
			TPPProvisioningRequest tppProvisioningRequest) throws Exception {
		 String tppProvReqXML="";
         TPP_ProvisioningRequestXMLGenerator tppProvReqXMLGenerator = new TPP_ProvisioningRequestXMLGenerator();
         tppProvReqXML = tppProvReqXMLGenerator.createProvReqXML(tppProvisioningRequest);
         return tppProvReqXML;
	}
	
	
	
	public void printSOAPResponse(SOAPMessage soapResponse) throws Exception {
        TransformerFactory transformerFactory = TransformerFactory.newInstance();
        Transformer transformer = transformerFactory.newTransformer();
        Source sourceContent = soapResponse.getSOAPPart().getContent();
        dataAugmentationServiceLog.info("\nResponse SOAP Message = ");
        StreamResult result = new StreamResult(System.out);
        transformer.transform(sourceContent, result);        
    }


	
	public boolean updateDipResults(String transactionId,
			String tppProvisioningRequestXML) {
		boolean isUpdated = false;
		
		isUpdated = dataAugmentationDao.updateDipResults(transactionId, tppProvisioningRequestXML);
		
		return isUpdated;
		
	}
	
	
	


}