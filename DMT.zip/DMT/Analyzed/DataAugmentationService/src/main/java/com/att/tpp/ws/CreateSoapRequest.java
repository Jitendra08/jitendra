package com.att.tpp.ws;

import java.beans.ConstructorProperties;

import javax.xml.namespace.QName;
import javax.xml.soap.MessageFactory;
import javax.xml.soap.SOAPBody;
import javax.xml.soap.SOAPElement;
import javax.xml.soap.SOAPEnvelope;
import javax.xml.soap.SOAPHeader;
import javax.xml.soap.SOAPMessage;
import javax.xml.soap.SOAPPart;

public class CreateSoapRequest {
	
	private String user;
	private String pass;
	private String transport;
	
	/**
	 * @param user
	 * @param pass
	 */
	@ConstructorProperties({"username", "password", "transport"})
	public CreateSoapRequest(String username, String password, String transport) {
		this.user = username;
		this.pass = password;
		this.transport = transport;
	}
	
	public String getBaseUrl(){
		return transport;		
	}

	public SOAPMessage createIBPSOAPRequest(String fan) throws Exception {
        MessageFactory messageFactory = MessageFactory.newInstance();
        SOAPMessage soapMessage = messageFactory.createMessage();
        SOAPPart soapPart = soapMessage.getSOAPPart();

        String serverURI = "http://services";
        String xsdPath ="http://cingular.com/base/interfaces/InquireFANProfileContactsRequest.xsd";

        // SOAP Envelope
        SOAPEnvelope envelope = soapPart.getEnvelope();
        envelope.addNamespaceDeclaration("ser", serverURI);
        envelope.addNamespaceDeclaration("inq", xsdPath);
        /*
        Constructed SOAP Request Message:
		<soapenv:Envelope xmlns:inq="http://cingular.com/base/interfaces/InquireFANProfileContactsRequest.xsd" xmlns:ser="http://services" xmlns:soapenv="http://schemas.xmlsoap.org/soap/envelope/">
		   <soapenv:Header>
		      <wsse:Security soapenv:mustUnderstand="1" xmlns:wsse="http://docs.oasis-open.org/wss/2004/01/oasis-200401-wss-wssecurity-secext-1.0.xsd" xmlns:wsu="http://docs.oasis-open.org/wss/2004/01/oasis-200401-wss-wssecurity-utility-1.0.xsd">
		         <wsse:UsernameToken xmlns:wsu="...">
		            <wsse:Username>3pp_app</wsse:Username>
		            <wsse:Password Type="http://docs.oasis-open.org/wss/2004/01/oasis-200401-wss-username-token-profile-1.0#PasswordText">3pp_appst</wsse:Password>
		         </wsse:UsernameToken>
		      </wsse:Security>
		   </soapenv:Header>
		   <soapenv:Body>
		      <ser:inquireFANProfileContacts>
		         <inq:InquireFANProfileContactsRequest>
		            <inq:RequestID>1</inq:RequestID>
		            <inq:fan>05680277</inq:fan>
		         </inq:InquireFANProfileContactsRequest>
		      </ser:inquireFANProfileContacts>
		   </soapenv:Body>
		</soapenv:Envelope>
         */

        // SOAP Body
        SOAPBody soapBody = envelope.getBody();
        SOAPElement soapBodyElem = soapBody.addChildElement("inquireFANProfileContacts", "ser");
        SOAPElement soapBodyElem1 = soapBodyElem.addChildElement("InquireFANProfileContactsRequest", "inq");
        SOAPElement soapBodyElem2 = soapBodyElem1.addChildElement("RequestID", "inq");
        soapBodyElem2.addTextNode("1");
        SOAPElement soapBodyElem3 = soapBodyElem1.addChildElement("fan", "inq");
        soapBodyElem3.addTextNode(fan);

        SOAPHeader header = envelope.getHeader();

        SOAPElement security =
                header.addChildElement("Security", "wsse", "http://docs.oasis-open.org/wss/2004/01/oasis-200401-wss-wssecurity-secext-1.0.xsd");

        SOAPElement usernameToken =
                security.addChildElement("UsernameToken", "wsse");
        usernameToken.addAttribute(new QName("xmlns:wsu"), "http://docs.oasis-open.org/wss/2004/01/oasis-200401-wss-wssecurity-utility-1.0.xsd");

        SOAPElement username =
                usernameToken.addChildElement("Username", "wsse");
        username.addTextNode(user);

        SOAPElement password =
                usernameToken.addChildElement("Password", "wsse");
        password.setAttribute("Type", "http://docs.oasis-open.org/wss/2004/01/oasis-200401-wss-username-token-profile-1.0#PasswordText");
        password.addTextNode(pass);

        soapMessage.saveChanges();

        /* Print the request message */
        System.out.print("Request SOAP Message = ");
        soapMessage.writeTo(System.out);
        System.out.println();

        return soapMessage;
    }
	
	/*Creating the SOAP message for ROME's InquireFanProfile API*/
	public SOAPMessage createRomeInquireFanProfileSOAPRequest(String fan) throws Exception {
        MessageFactory messageFactory = MessageFactory.newInstance();
        SOAPMessage soapMessage = messageFactory.createMessage();
        SOAPPart soapPart = soapMessage.getSOAPPart();

        String serverURI = "http://services";
        String xsdPath ="http://cingular.com/base/interfaces/InquireFANProfileRequest.xsd";

        // SOAP Envelope
        SOAPEnvelope envelope = soapPart.getEnvelope();
        envelope.addNamespaceDeclaration("ser", serverURI);
        envelope.addNamespaceDeclaration("inq", xsdPath);
        /* Example InquireFanProfile Request
        <soapenv:Envelope xmlns:soapenv="http://schemas.xmlsoap.org/soap/envelope/" xmlns:ser="http://services" xmlns:inq="http://cingular.com/base/interfaces/InquireFANProfileRequest.xsd"> 
   			<soapenv:Header> 
      			<wsse:Security xmlns:wsse="http://docs.oasis-open.org/wss/2004/01/oasis-200401-wss-wssecurity-secext-1.0.xsd"> 
         			wsse:UsernameToken> 
            			<wsse:Username></wsse:Username> 
            			<wsse:Password Type="http://docs.oasis-open.org/wss/2004/01/oasis-200401-wss-username-token-profile-1.0#PasswordText"></wsse:Password> 
         			</wsse:UsernameToken> 
      			</wsse:Security> 
   			</soapenv:Header> 
   			<soapenv:Body> 
      			<ser:inquireFANProfile> 
         			<inq:InquireFANProfileRequest> 
            			<inq:RequestID>110889997</inq:RequestID> 
            			<inq:fan>5747634</inq:fan> 
         			</inq:InquireFANProfileRequest> 
      			</ser:inquireFANProfile> 
   			</soapenv:Body> 
		</soapenv:Envelope> */

        // SOAP Body
        SOAPBody soapBody = envelope.getBody();
        SOAPElement soapBodyElem = soapBody.addChildElement("inquireFANProfile", "ser");
        SOAPElement soapBodyElem1 = soapBodyElem.addChildElement("InquireFANProfileRequest", "inq");
        SOAPElement soapBodyElem2 = soapBodyElem1.addChildElement("RequestID", "inq");
        soapBodyElem2.addTextNode("1");
        SOAPElement soapBodyElem3 = soapBodyElem1.addChildElement("fan", "inq");
        soapBodyElem3.addTextNode(fan);

        SOAPHeader header = envelope.getHeader();

        SOAPElement security =
                header.addChildElement("Security", "wsse", "http://docs.oasis-open.org/wss/2004/01/oasis-200401-wss-wssecurity-secext-1.0.xsd");

        SOAPElement usernameToken =
                security.addChildElement("UsernameToken", "wsse");
        usernameToken.addAttribute(new QName("xmlns:wsu"), "http://docs.oasis-open.org/wss/2004/01/oasis-200401-wss-wssecurity-utility-1.0.xsd");

        SOAPElement username =
                usernameToken.addChildElement("Username", "wsse");
        username.addTextNode(user);

        SOAPElement password =
                usernameToken.addChildElement("Password", "wsse");
        password.setAttribute("Type", "http://docs.oasis-open.org/wss/2004/01/oasis-200401-wss-username-token-profile-1.0#PasswordText");
        password.addTextNode(pass);

        soapMessage.saveChanges();

        /* Print the request message */
        System.out.print("Request SOAP Message = ");
        soapMessage.writeTo(System.out);
        System.out.println();

        return soapMessage;
    }

}
