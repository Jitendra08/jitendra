package com.att.tpp.jms.sender;

import javax.jms.JMSException;
import javax.jms.Message;
import javax.jms.Queue;
import javax.jms.Session;
import javax.jms.TextMessage;

import org.apache.log4j.Logger;
import org.springframework.jms.core.JmsTemplate;
import org.springframework.jms.core.MessageCreator;

import com.att.tpp.model.ProcessingResult;

/**
 * The TestMessageSender class uses the injected JMSTemplate to send a message
 * to a specified Queue. In our case we're sending messages to 'TestQueueTwo'
 */
public class WorkFlowRequestSender
{
	private JmsTemplate jmsTemplate;
	private Queue workFlowRequestQueue;
	private static final Logger workFlowRequestSenderLog = Logger.getLogger(WorkFlowRequestSender.class);
	private final static String PROV_SYSTEM_TRANSID = "PROV_SYSTEM_TRANSID";
	private final static String MSISDN = "MSISDN";
	
	/**
	 * Sends message to gatewayProvisioningRequestQueue using JMS Template.
	 * @param provReqXML the message_p
	 * @throws JMSException the jms exception
	 */
	public void sendMessage(final ProcessingResult processingResult) throws JMSException
	{
		
		workFlowRequestSenderLog.info("Sending TPP_ProvisioningRequest Message From DataAugmentation Service to WorkFlow Service");

		jmsTemplate.send(this.workFlowRequestQueue, new MessageCreator(){

			@Override
			public Message createMessage(Session session) throws JMSException {
				TextMessage message = session.createTextMessage(processingResult.getTppProvReq().toString());
				message.setStringProperty(PROV_SYSTEM_TRANSID,processingResult.getTransactionId());
				message.setStringProperty(MSISDN,processingResult.getMsisdn());
				return message;
			}
			
		});		
		
	}

	/**
	 * Sets the jms template.
	 *
	 * @param template the jms template
	 */
	public void setJmsTemplate(JmsTemplate tmpl)
	{
		this.jmsTemplate = tmpl;
	}

	/**
	 * Sets the test queue.
	 *
	 * @param workFlowRequestQueue the new test queue
	 */
	public void setWorkFlowRequestQueue(Queue workFlowRequestQueue)
	{
		this.workFlowRequestQueue = workFlowRequestQueue;
	}
}