package com.att.tpp.service;

import java.io.IOException;
import java.text.ParseException;

import javax.xml.soap.SOAPMessage;

import com.att.tpp.model.CSIDipKeys;
import com.att.tpp.xml.model.TPPProvisioningRequest;



public interface DataAugmentationService {

	boolean validateXML(String requestXML, String tppProvisioningrequestxsd) throws IOException, Exception;
	
	TPPProvisioningRequest invokeCSIWebService(String csiDips, String requestXML,  CSIDipKeys csiDipKeys) throws Exception;

	boolean persistDipResults(CSIDipKeys csiDipKeys, String eventName, String errorCode,	String errorDesc) throws ParseException;

	String getCTNFromMsidn(String msisdn);

	String createTPPProvReqXML(TPPProvisioningRequest tppProvisioningRequest)throws Exception ;
	
    void printSOAPResponse(SOAPMessage soapResponse) throws Exception;

	boolean updateDipResults(String transactionId,
			String tppProvisioningRequestXML);
	
	
	
	
}
