package com.att.tpp.jms.sender;

import javax.jms.JMSException;
import javax.jms.Message;
import javax.jms.Queue;
import javax.jms.Session;
import javax.jms.TextMessage;

import org.apache.log4j.Logger;
import org.springframework.jms.core.JmsTemplate;
import org.springframework.jms.core.MessageCreator;

/**
 * The TestMessageSender class uses the injected JMSTemplate to send a message
 * to a specified Queue. In our case we're sending messages to 'TestQueueTwo'
 */
public class CSIMessageTrackingSender
{
	private JmsTemplate jmsTemplate;
	private Queue cSIMessageTrackingQueue;
	private static final Logger csiMessageTrackingSenderLog = Logger.getLogger(CSIMessageTrackingSender.class);
	private final static String TYPE = "TYPE";
	
	/**
	 * Sends message to gatewayProvisioningRequestQueue using JMS Template.
	 * @param provReqXML the message_p
	 * @throws JMSException the jms exception
	 */
	public void sendMessage(final String csiMessage, final String type) throws JMSException
	{
		
		csiMessageTrackingSenderLog.info("Sending DIP Messages From DataAugmentation Service to CSIMessageTrackingQueue Service");

		jmsTemplate.send(this.cSIMessageTrackingQueue, new MessageCreator(){

			@Override
			public Message createMessage(Session session) throws JMSException {
				TextMessage message = session.createTextMessage(csiMessage.toString());
				message.setStringProperty(TYPE,type.toString());
				return message;
			}
			
		});		
		
	}

	/**
	 * Sets the jms template.
	 *
	 * @param template the jms template
	 */
	public void setJmsTemplate(JmsTemplate tmpl)
	{
		this.jmsTemplate = tmpl;
	}

	/**
	 * Sets the test queue.
	 *
	 * @param csiMessageTrackingQueue the new test queue
	 */
	public void setCSIMessageTrackingQueue(Queue cSIMessageTrackingQueue)
	{
		this.cSIMessageTrackingQueue = cSIMessageTrackingQueue;
	}
}