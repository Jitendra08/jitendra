package com.att.tpp.ws;


import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.net.URL;
import java.security.KeyStore;
import java.security.cert.Certificate;

import javax.net.ssl.HttpsURLConnection;
import javax.net.ssl.KeyManagerFactory;
import javax.net.ssl.SSLContext;
import javax.net.ssl.SSLPeerUnverifiedException;
import javax.net.ssl.SSLSocketFactory;
import javax.net.ssl.TrustManagerFactory;


public class HttpsClient {
	static SSLContext ssl_ctx;
	static String current = null;
	static String keyStoreFile = "/3PPROME.jks";
	static String keyStorePassword = "3pp_appst";

	
	/** This is just a Proof of concept for test purpose.Below are the steps - SJ3125
		1) openssl s_client -connect dsl-rome.it.att.com:31643
		2) vi ROMEPROD.cer and copy the cert from above command to it
		3) in ssl directory (where we have 3ppTruststore), create a new RomeTrustStore --->>
		password use same as in server.properties for Rome/Base -->> 3pp_appst 3pp_appst
		This one actually worked & generated 3PPRomeProd.jks, use the Rome password 3pp_appst from server.properties-->>
		keytool -import -alias RomeProd_cert -trustcacerts -file RomeProd.cer -keystore 3PPRomeProd.jks
		
		Option 2: if you want to put the file in existing keystore, use this command (not tried) -->
		keytool -importcert -file ROMEPROD.cer -keystore 3ppTruststore -alias ROME_CERT
		4) Add this to the server.properties in the config alias directory.
		romekeystoreFileName=/opt/app/d1tpp1m2/3pp/sites/tomcat/latest_tomcat/3pp/ssl/3PPROME.jks  
		---to cross check the new jks file --- keytool -list -v -keystore 3PPRomeProd.jks
	 **/
	
	public static void main(String[] args) {
		{
			try {
				current = new File( "." ).getCanonicalPath();
				String https_url = "https://zltv6447.vci.att.com:41334/DSL_StoredProcsWS/DSL_BaseStoredProcs";//change per required end-point to test
				URL url = new URL(https_url);
				HttpsURLConnection con = (HttpsURLConnection) url.openConnection();

                con.setRequestMethod("POST");
                con.setDoOutput(true);
                con.setDoInput(true);
                con.setRequestProperty("Content-Type", "text/xml");
                con.setRequestProperty("base.user", "3pp_app");
                con.setRequestProperty("base.pass", "3pp_appst");
                //con.setRequestProperty("Authorization", "Basic M3BwX2FwcDozcHBfYXBwc3Q=");
				con.setSSLSocketFactory(getSSLSocket());
				//con.connect();
				String str = getData().toString();
				System.out.println("sending1  .."+str);
				BufferedWriter w = new BufferedWriter(new OutputStreamWriter(con.getOutputStream()));
				w.write(str);
				w.flush();
				w.close();

				// dump all the content
				System.out.println("sending3"+ print_content(con));
				print_https_cert(con);
				
			}
			catch (Exception ex) {
				ex.printStackTrace();
			}

		}
	}

	public static SSLSocketFactory getSSLSocket() {
		SSLSocketFactory socketFactory = null;
		try {
			

			final String keystoreName = current+keyStoreFile;
			final String keystorePassword = keyStorePassword;
			final String TRUST_STORE_PATH = current+keyStoreFile;
			final String TRUST_STORE_PASSWORD = keyStorePassword;

			KeyStore ks = KeyStore.getInstance("jks");
			ks.load(new FileInputStream(keystoreName), keystorePassword.toCharArray());

			System.out.println("Curent dir " + current + " keystoreName "+ keystoreName);
			KeyStore truststore = KeyStore.getInstance(KeyStore.getDefaultType());
			InputStream truststoreInput = new FileInputStream(TRUST_STORE_PATH);
			truststore.load(truststoreInput, TRUST_STORE_PASSWORD.toCharArray());
			System.out.println("Truststore has " + truststore.size() + " keys");

			TrustManagerFactory trustManagerFactory = TrustManagerFactory.getInstance(TrustManagerFactory.getDefaultAlgorithm());
			trustManagerFactory.init(truststore);

			// Setup keystore
			KeyManagerFactory keyManagerFactory = KeyManagerFactory.getInstance(KeyManagerFactory.getDefaultAlgorithm());
			keyManagerFactory.init(ks, keystorePassword.toCharArray());


			System.out.println("Key " + ks.size());
			System.out.println("Trust " + truststore.size());

			// Setup the SSL context to use the truststore and keystore
			ssl_ctx = SSLContext.getInstance("TLSv1.2");
			ssl_ctx.init(keyManagerFactory.getKeyManagers(), trustManagerFactory.getTrustManagers(), null);

			System.out.println("keyManagerFactory " + keyManagerFactory.getKeyManagers().length);
			System.out.println("trustManagerFactory " + trustManagerFactory.getTrustManagers().length);

			socketFactory = (SSLSocketFactory) HttpsClient.ssl_ctx.getSocketFactory();
			
			String[] cip = socketFactory.getDefaultCipherSuites();
			
			for (int i = 0; i < cip.length; i++) {
				
				System.out.println("i " +i);
				System.out.println("Cipher " + cip[i]);
			}


		}
		catch (Exception ex) {
			System.out.println("JAYAL EXCEPTION " +ex);
			ex.printStackTrace();
		}
		return socketFactory;
	}

	
	

	public static StringBuffer getData() {
		StringBuffer str = new StringBuffer();

		try {
			BufferedReader br = new BufferedReader(new FileReader(current+"/rome.xml"));
			String sCurrentLine;

			while ((sCurrentLine = br.readLine()) != null) {
				str.append(sCurrentLine);
				System.out.println(sCurrentLine);
			}

		}
		catch (IOException e) {
			e.printStackTrace();
		}
		return str;
	}

	private static void print_https_cert(HttpsURLConnection con) {

		if (con != null) {

			try {
				con.connect();
				System.out.println("Cipher Suite : " + con.getCipherSuite());
				System.out.println("\n");

				Certificate[] certs = con.getServerCertificates();
				for (Certificate cert : certs) {
					System.out.println("Cert Type : " + cert.getType());
					System.out.println("Cert Hash Code : " + cert.hashCode());
					System.out.println("Cert Public Key Algorithm : " + cert.getPublicKey().getAlgorithm());
					System.out.println("Cert Public Key Format : " + cert.getPublicKey().getFormat());
					System.out.println("\n");
				}

			}
			catch (SSLPeerUnverifiedException e) {
				e.printStackTrace();
			}
			catch (IOException e) {
				e.printStackTrace();
			}

		}

	}

	private static String print_content(HttpsURLConnection con) {
		String input=null;
		if (con != null) {

			try {
				System.out.println("Response Code : " + con.getResponseCode());
				System.out.println("Response Message : " + con.getResponseMessage());
				
				System.out.println("****** Content of the URL ********");
				BufferedReader br = new BufferedReader(new InputStreamReader(con.getInputStream()));



				while ((input = br.readLine()) != null) {
					System.out.println(input);
				}
				//br.close();

			}
			catch (IOException e) {
				e.printStackTrace();
			}

		}
		return input;	
	}
}
