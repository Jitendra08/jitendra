package com.att.tpp.utils;

import groovy.util.slurpersupport.NodeChildren;

import java.util.Collection;

import com.att.tpp.xml.model.BillingAccount.Address;







import com.att.tpp.model.CSIDipKeys
import com.att.tpp.xml.model.BillingAccount.BANEmail;
import com.att.tpp.xml.model.BillingAccount.BillingCycle;
import com.att.tpp.xml.model.BillingAccount.BillingMarket;
import com.att.tpp.xml.model.BillingAccount.Email;
import com.att.tpp.xml.model.BillingAccount.FAN;
import com.att.tpp.xml.model.BillingAccount.Name;
import com.att.tpp.xml.model.BillingAccount.Phone;
import com.att.tpp.xml.model.Attribute
import com.att.tpp.xml.model.BillingAccountAddress
import com.att.tpp.xml.model.BillingAccountEmail
import com.att.tpp.xml.model.BillingAccountName
import com.att.tpp.xml.model.BillingAccountPhone
import com.att.tpp.xml.model.DealerInfo;
import com.att.tpp.xml.model.NameInfoCSIDP;
import com.att.tpp.xml.model.Product
import com.att.tpp.xml.model.SubscriberStatusInfo;
import com.att.tpp.xml.model.Account;
import com.att.tpp.xml.model.AccountType;
import com.att.tpp.xml.model.AccountTypeInfo;
import com.att.tpp.xml.model.BillingAccount;
import com.att.tpp.xml.model.CombinedBillingType;
import com.att.tpp.xml.model.CustRegContactInfoBASE;
import com.att.tpp.xml.model.DealerCommissionInfo
import com.att.tpp.xml.model.Device
import com.att.tpp.xml.model.DualCommisionsInfo
import com.att.tpp.xml.model.Equipment;
import com.att.tpp.xml.model.EventTypeInfo;
import com.att.tpp.xml.model.FinancialNotificationType;
import com.att.tpp.xml.model.ImmutableKeyInfo;
import com.att.tpp.xml.model.MarketInfo;
import com.att.tpp.xml.model.MarketingOption
import com.att.tpp.xml.model.MarketingOptions;
import com.att.tpp.xml.model.ParentalControlsSettingInfo;
import com.att.tpp.xml.model.SIM
import com.att.tpp.xml.model.SalesReps;
import com.att.tpp.xml.model.SegmentType;
import com.att.tpp.xml.model.ServiceInfo;
import com.att.tpp.xml.model.Subscriber;
import com.att.tpp.xml.model.Subscriber.Contact
import com.att.tpp.xml.model.Subscriber.EmailInfo
import com.att.tpp.xml.model.SubscriberAddress
import com.att.tpp.xml.model.SubscriberContact
import com.att.tpp.xml.model.SubscriberEmailInfo
import com.att.tpp.xml.model.TNAddress
import com.att.tpp.xml.model.TNInfo
import com.att.tpp.xml.model.TaxExemption
import com.att.tpp.xml.model.SubscriberStatusDetailInfo;
import com.att.tpp.xml.model.TNUpdateInfo;
import com.att.tpp.xml.model.TPPSKUOrder;
import com.att.tpp.xml.model.Header;
import com.att.tpp.xml.model.Notification;
import com.att.tpp.xml.model.Order;
import com.att.tpp.xml.model.ProvisioningCarrier;
import com.att.tpp.xml.model.RoutingCarrier;
import com.att.tpp.xml.model.Sender;
import com.att.tpp.xml.model.Products;
import com.att.tpp.xml.model.Delta;
import com.att.tpp.xml.model.Forms;
import com.att.tpp.xml.model.FormData;
import com.att.tpp.xml.model.ParameterDetails;
import com.att.tpp.xml.model.OrderDocumentInfo;
import com.att.tpp.xml.model.OrderNotificationInfo;
import com.att.tpp.xml.model.SubscriberStatusDetailInfo;
import com.att.tpp.xml.model.TPPProvisioningRequest;
import com.att.tpp.xml.model.NameInfo;
import com.att.tpp.xml.model.NGPNameInfo;
import com.att.tpp.xml.model.AddressTwoLineSimpleInfo;
import com.att.tpp.xml.model.AddressZipInfo;
import com.att.tpp.xml.model.PhoneInfo;
import com.att.tpp.xml.model.AttributeInfo;
import com.att.tpp.xml.model.VendorDetails;
import com.cingular.base.interfaces.inquirefanprofilecontactsresponse.InquireFANProfileContactsResponse;
import com.cingular.csi.csi.namespaces.container._public.inquireaccountprofileresponse.InquireAccountProfileResponseInfo;
import com.cingular.csi.csi.namespaces.container._public.inquirefanprofileresponse.InquireFanProfileResponseInfo;
import com.cingular.csi.csi.namespaces.container._public.inquiresubscriberparentalcontrolsresponse.InquireSubscriberParentalControlsResponseInfo;
import com.cingular.csi.csi.namespaces.container._public.inquirecustomerinformationformresponse.InquireCustomerInformationFormResponseInfo;

import org.apache.log4j.*
import groovy.util.logging.*


/**
 * @author SC9833
 *
 */
@Log4j
class DataAugXMLParser {
	
	public DataAugXMLParser() {
	// TODO Auto-generated constructor stub
		
	}
	
	/**
	 * Provide CSIDipKeys model based on TPP_ProvisioningRequest XML.
	 *
	 * @param provReqXML TPP_ProvisioningRequest XML to be parsed
	 * @return CSIDipKeys
	 */
	def CSIDipKeys getCSIKeyInfo(String provReqXML){
		def tppProvReq = new XmlSlurper().parseText(provReqXML)
		def header = tppProvReq.Header
		def order = tppProvReq.Order
		def account = order.Account
		def fan = order.BillingAccount.FAN
		def products = tppProvReq.Products
		def orderNotification = order.TPP_SKUOrder.OrderNotification
		
		//def transactionId = new Header(header.@TransactionId.toString())  //TransactionId is a guaranteed field.  No need for null or blank check.
		//def transactionId = new Header(header.@TransactionId.toString(),header.@atlasEventType.toString())
		def transactionId = new Header(header.@TransactionId.toString(),header.@Atlas_Event_Type.toString())
		def parsedAccount = new Account(account.@MSISDN.toString(), account.@SubscriberNumber.toString(), account.@BAN.toString())  //MSISDN is a guaranteed field.  No need for null or blank check.
		def parsedFAN = null
		
		def parsedProducts = null;
		def parsedOrderId = null;
		
		//FAN check
		//log.info("FAN size---> " + fan.size().toString())
		if(fan.size() > 0){
			if(fan.@currentFAN.size() > 0){
				parsedFAN = new FAN(fan.@currentFAN.toString())
			}
		}
		//Products
		
		if(products.size() > 0){
			parsedProducts = new Products( products.Product.collect{
			new Product("3PP" ,it.@Id.toString(), it.@IPID.toString(), it.@Action.toString(), it.@EffectiveDate.toString(), it.@ExpirationDate.toString(),
			it.Attribute.collect{ new Attribute(it.@Name.toString(), it.@Value.toString()) }
			)})
		}
		
		//SKU Order
		if(orderNotification != null){
			parsedOrderId = orderNotification.orderId.location.toString()+"-"+orderNotification.orderId.activity.toString()+"-"+orderNotification.orderId.orderId.toString();
			log.info ("DATAug XML Parser parsedOrderId:: "+parsedOrderId)
		}
		
		return new CSIDipKeys(transactionId, parsedAccount, parsedFAN, parsedProducts, parsedOrderId)
	}
	
	
	/**
	 * Provide Account model based on TPP_ProvisioningRequest XML node child account (tppProvReq.Order.Account).
	 *
	 * @param account NodeChildren to be parsed
	 * @return Account
	 */
	def Account getProvReqAccount(NodeChildren account){				
		
		def parsedAccount = null
		
		parsedAccount = new Account(account.@MSISDN.toString(),
			(account.@PrevMSISDN.size()>0) ? account.@PrevMSISDN.toString() : null,
			(account.@WirelessServiceId.size()>0) ? account.@WirelessServiceId.toString() : null,
			account.@SubscriberNumber.toString(),
			account.@BAN.toString(),
			(account.@BANName.size()>0) ? account.@BANName.toString() : null,
			(account.@prevBAN.size()>0) ? account.@prevBAN.toString() : null,
			(account.@accountTypeIndicator.size()>0) ? account.@accountTypeIndicator.toString() : null,
			(account.@socEffectiveDate.size()>0) ? account.@socEffectiveDate.toString() : null,
			(account.@InvoiceId.size()>0) ? account.@InvoiceId.toString() : null,
			(account.@EOD_GROUP_ID.size()>0) ? account.@EOD_GROUP_ID.toString() : null)
		
		
		return parsedAccount
	}
	
	/**
	 * Provide Account model based on TPP_ProvisioningRequest XML node child account (tppProvReq.Order.Account).
	 *
	 * @param account NodeChildren to be parsed
	 * @return Account
	 */
	def Account getProvReqDCMAccount(NodeChildren account,InquireAccountProfileResponseInfo inquireAccountProfileResponse){
		
		def parsedAccount = null;
		def iapBAN = null;
		def iapFAN = null;
		def accTypeInd = null;
		def iapSubNumber = null;
		//log.info("Inside  getProvReqDCMAccount");
		iapBAN = inquireAccountProfileResponse?.account?.billingAccountNumber?.toString();
		log.info("Inside  getProvReqDCMAccount :: iapBAN "+iapBAN);
		accTypeInd = inquireAccountProfileResponse?.account?.accountType?.accountType.toString();
		//log.info("Inside  getProvReqDCMAccount :: accTypeInd "+accTypeInd);
		if(accTypeInd.equalsIgnoreCase("null"))
		{
			accTypeInd=null;
			//log.info("Inside  getProvReqDCMAccount if :: accTypeInd "+accTypeInd);
		}
		iapSubNumber = inquireAccountProfileResponse?.account?.subscriber?.get(0)?.getSubscriber()?.subscriptionID;
		//log.info("Inside  getProvReqDCMAccount :: iapSubNumber "+iapSubNumber);
		
		
		parsedAccount = new Account(account.@MSISDN.toString(),
			(account.@PrevMSISDN.size()>0) ? account.@PrevMSISDN.toString() : null,
			(account.@WirelessServiceId.size()>0) ? account.@WirelessServiceId.toString() : null,
			//account.@SubscriberNumber.toString(),
			//(iapSubNumber.size()>0) ? iapSubNumber : null,
			iapSubNumber,
			//account.@BAN.toString(),
			//(iapBAN.size()>0) ? iapBAN : null,
			iapBAN,
			(account.@BANName.size()>0) ? account.@BANName.toString() : null,
			(account.@prevBAN.size()>0) ? account.@prevBAN.toString() : null,
			(account.@accountTypeIndicator.size()>0) ? account.@accountTypeIndicator.toString() : accTypeInd,
			(account.@socEffectiveDate.size()>0) ? account.@socEffectiveDate.toString() : null,
			(account.@InvoiceId.size()>0) ? account.@InvoiceId.toString() : null,
			(account.@EOD_GROUP_ID.size()>0) ? account.@EOD_GROUP_ID.toString() : null)
		
		
		return parsedAccount
	}
	
	/**
	 * Provide FAN model based on TPP_ProvisioningRequest XML.
	 *
	 * @param provReqXML TPP_ProvisioningRequest XML to be parsed
	 * @return FAN
	 */
	def FAN getProvReqFAN(String provReqXML){
		def tppProvReq = new XmlSlurper().parseText(provReqXML)
		
		//Order
		def order = tppProvReq.Order
		
		//BillingAccount		
		def fan = order.BillingAccount.FAN
		
		def parsedFAN = null
		
		//FAN check
		//println("FAN size---> " + fan.size().toString())
		if(fan.size() > 0){
			if(fan.@currentFAN.size() > 0){
				parsedFAN = new FAN(fan.@currentFAN.toString())
			}
		}
				
		return parsedFAN 
	}
	 	
	
	/**
	 * Provide parsed TPP_ProvisioningRequest XML into TPPProvisioningRequest model.
	 * 
	 * @param provReqXML TPP_ProvisioningRequest XML to be parsed
	 * @return TPPPRovisioningRequest 
	 */
	def TPPProvisioningRequest getTPPProvReq(String provReqXML, InquireAccountProfileResponseInfo inquireAccountProfileResponse,
		                                     InquireFanProfileResponseInfo inquireFanProfileResponse,Collection<CustRegContactInfoBASE> parseCustRegContactInfo_BASE,
											  InquireSubscriberParentalControlsResponseInfo  inquireSubscriberParentalControlsResponse, InquireCustomerInformationFormResponseInfo inquireCustomerInformationFormResponse,
											  String csiDips, Collection<SalesReps> romeInquireFanProfileSalesReps
											 ){
		def tppProvReq = new XmlSlurper().parseText(provReqXML)
		
		//TPP ProvReq XML
		def header = tppProvReq.Header
		def sender = header.Sender
		def notification = header.Notification
		def order = tppProvReq.Order		
		def products = tppProvReq.Products
		
		//Account
		def account = order.Account
		
		//Subscriber
		def subscriber = order.Subscriber
		def subscriberContact = subscriber.Contact
		def subscriberAddress = subscriber.Address
		//added for Subscriber Email
		def subscriberEmail = subscriber.Email
		//End added for Subscriber Email
		
		def subscriberPrevContact = subscriber.PrevContact
		def subscriberPrevAddress = subscriber.PrevAddress
		def subscriberPrevEmail = subscriber.PrevEmail
		//SubscriberStatusDetail
		def subscriberStatusDetail = order.SubscriberStatusDetail
		
		//Equipment
		def equipment = order.Equipment
		def device = equipment.Device
		def sim = equipment.SIM
		
		//Service Info
		def serviceInfo = order.ServiceInfo
		
		//Market Options
		def marketOptions = order.MarketingOptions //This element has 1 or more children
		
		//Billing Account
		def billingAccount = order.BillingAccount
		
		//Financial Notification
		def financialNotification = order.FinancialNotification
		
		//SKU Order
		def orderNotification = order.TPP_SKUOrder.OrderNotification
		
		//FemtocellNotification
		def femtoCellNotification = order.FemtocellTNUpdate
		
		//ServiceStatusNotification
		def serviceStatusNotification = order.ImmutableKeys
		
		//Parental Controls Info
		def parentalControlsSetting = order.ParentalControlsSettingInfo
		
		//Account Type Info
		/*def accountTypeInfo = order.AccountTypeInfo*/
		
		/*//Segment Type Info
		def segmentType = order.segmentType*/
		
		//Sales Reps
		/*def salesReps = order.salesReps*/  //This element has 0 or more children
		
		//Customer Reg Contact Info
		/*def custRegContactInfo_BASE = order.CustRegContactInfo_BASE*/  //This element has 0 or more children
		
		//Combined Billing
		def combinedBilling = order.CombinedBilling
		
		//Delta
		def delta = order.Delta
		
		//VendorDetails
		def vendorDetails = order.VendorDetails
		
		//MarketInfo
		def atlasMarketInfo = order.MarketInfo
		
		//Event Type
		def eventType = order.EventType
		
		//Event Type
		def taxExemption = order.TaxExemption
		
		//Header/Sender Object
		def parsedSender = new Sender(sender.@Login.toString(), sender.@Password.toString())
		
		//Header/Notification Object
		def parsedNotification = new Notification(notification.@URL.toString())
		
		//Header Object
		def parsedHeader = new Header(header.@Atlas_Event_Type.toString(), header.@TransactionId.toString(), 
			header.@ProvisioningCarrier.toString(), header.@RoutingCarrier.toString(), 
			header.@TimeStamp.toString(), parsedSender, parsedNotification)
		
		// Order/Account Object		
		//def parsedAccount = getProvReqAccount(account)
		def parsedAccount = null;
		//Account details for DCM flow
		if(header.@Atlas_Event_Type.toString().equalsIgnoreCase("DCMNotification")){
			//log.info("Inside  call getProvReqDCMAccount");
			parsedAccount = getProvReqDCMAccount(account,inquireAccountProfileResponse)
		}else{
			parsedAccount = getProvReqAccount(account)
		}

		
		// Order/Subscriber/Contact
//		def parsedSubContact = subscriberContact.collect {
//			new Contact((it.@NamePrefix.size()>0) ? it.@NamePrefix.toString() : null, it.@FirstName.toString(), 
//				(it.@MiddleName.size()>0) ? it.@MiddleName.toString() : null,
//				it.@LastName.toString(), 
//				(it.@NameSuffix.size()>0) ? it.@NameSuffix.toString() : null,
//				(it.@PhoneNumber.size()>0) ? it.@PhoneNumber.toString() : null,
//				(it.@PersonalEmailAddress.size()>0) ? it.@PersonalEmailAddress.toString() : null,
//				(it.@BusinessEmailAddress.size()>0) ? it.@BusinessEmailAddress.toString() : null)
//			
//		}
		
		def iapSubContact = inquireAccountProfileResponse?.account?.subscriber
		
		def parsedSubContact = null;
		def parsedContact = null;
		def parsedCurrentSubContact = null;
		def parsedPreviousSubContact = null;
		/*
		 * Start - Subscriber Name Added for CS-FOBPM
		 */
		if(csiDips!=null && csiDips.contains("ACCT"))
		{
			//Subscriber Name from IAP Response
			if(iapSubContact != null){
				if(iapSubContact.get(0)?.getSubscriber()?.contactInformation?.name != null){
					log.info("Inside  ACCT DIP DataAugXMLParser IAP Response Subscriber size---> " + inquireAccountProfileResponse?.account?.subscriber?.size())
					parsedCurrentSubContact = new SubscriberContact(
							iapSubContact.get(0)?.getSubscriber()?.contactInformation?.name?.firstName.toString(),
							iapSubContact.get(0)?.getSubscriber()?.contactInformation?.name?.lastName.toString()
					)
					parsedContact = new Contact(parsedCurrentSubContact)
				}
			}else if(subscriberContact.size() > 0){
				log.info("Inside  ACCT DIP DataAugXMLParser Atlas XML subscriberContact size::"+subscriberContact.size());
				parsedCurrentSubContact = new SubscriberContact(
					subscriberContact.@FirstName.toString(),
					subscriberContact.@LastName.toString()
				)
				parsedContact = new Contact(parsedCurrentSubContact)
			}
			
			if(subscriberPrevContact.size() > 0){
					log.info("Inside  ACCT DIP DataAugXMLParser Atlas XML subscriberPrevContact size::"+subscriberPrevContact.size());
					parsedPreviousSubContact = new SubscriberContact(
						subscriberPrevContact.@FirstName.toString(),
						subscriberPrevContact.@LastName.toString()
					)
					parsedContact = new Contact(parsedCurrentSubContact, parsedPreviousSubContact)
			}
		}else{
		/*
		 * End - Added for CS-FOBPM
		 */
		if(iapSubContact != null)
		{
			if(iapSubContact.get(0)?.getSubscriber()?.contactInformation?.name != null){
				
				log.info("Inside DataAugXMLParser iapSubContact  Name - Subscriber size---> " + inquireAccountProfileResponse?.account?.subscriber?.size())
				parsedSubContact = parsedSubContact = new SubscriberContact(
							iapSubContact.get(0)?.getSubscriber()?.contactInformation?.name?.firstName.toString(),
							iapSubContact.get(0)?.getSubscriber()?.contactInformation?.name?.lastName.toString()
					)
					parsedContact = new Contact(parsedSubContact)
				}else if(iapSubContact.get(0)?.getSubscriber()?.contactInformation?.businessName != null){
					log.info("Inside DataAugXMLParser iapSubContact  Business Contact ---> " + iapSubContact.get(0)?.getSubscriber()?.contactInformation?.businessName?.contact?.firstName.toString())
					
					parsedSubContact = new SubscriberContact(
						iapSubContact.get(0)?.getSubscriber()?.contactInformation?.businessName?.contact?.firstName.toString(),
						iapSubContact.get(0)?.getSubscriber()?.contactInformation?.businessName?.contact?.lastName.toString()
					)
					parsedContact = new Contact(parsedSubContact)
				}else{
					log.info("Inside DataAugXMLParser iapSubContact Contact is empty!!!!!")
				}
			}else{
				log.info("Inside DataAugXMLParser iapSubContact Subscriber is empty!!!!!")
			}
		}
		
		// Order/Subscriber/Address
/*		def parsedSubAddress = subscriberAddress.collect {
			new com.att.tpp.xml.model.Address(
				(it.@Type.size()>0) ? it.@Type.toString() : null,
				(it.@Street.size()>0) ? it.@Street.toString() : null,
				(it.@City.size()>0) ? it.@City.toString() : null, 
				(it.@State.size()>0) ? it.@State.toString() : null, 
				(it.@PostalCode.size()>0) ? it.@PostalCode.toString() : null, 
				//(it.@PostalPlusCode.size()>0) ? it.@PostalPlusCode.toString() : null, 
				//(it.@CountryName.size()>0) ? it.@CountryName.toString() : null, 
				(it.@CountryCode.size()>0) ? it.@CountryCode.toString() : null,  
				//(it.@GeoCode.size()>0) ? it.@GeoCode.toString() : null, 
				//(it.@LocalCompanyName.size()>0) ? it.@LocalCompanyName.toString() : null
			)
		}*/
		
		
		def iapSubAddress = inquireAccountProfileResponse?.account?.subscriber
		
		def parsedSubAddress = null;
		def parsedAddress = null;
		def parsedCurrentSubAddress=null;
		def parsedPreviousSubAddress=null;
		/*
		 * Start - Subscriber Address Added for CS-FOBPM
		 */
		if(csiDips!=null && csiDips.contains("ACCT"))
		{
			//Subscriber Address from IAP Response
			if(iapSubAddress != null){
				if(iapSubAddress.get(0)?.getSubscriber()?.contactInformation?.ppuAddress != null){
					
					log.info("Inside ACCT DIP DataAugXMLParser IAP Response iapSubAddress Subscriber size---> " + inquireAccountProfileResponse?.account?.subscriber?.size())
					
					parsedCurrentSubAddress = new SubscriberAddress(
							iapSubAddress.get(0)?.getSubscriber()?.contactInformation?.ppuAddress?.addressType.toString(),
							iapSubAddress.get(0)?.getSubscriber()?.contactInformation?.ppuAddress?.addressLine1.toString(),
							iapSubAddress.get(0)?.getSubscriber()?.contactInformation?.ppuAddress?.city.toString(),
							iapSubAddress.get(0)?.getSubscriber()?.contactInformation?.ppuAddress?.state.toString(),
							iapSubAddress.get(0)?.getSubscriber()?.contactInformation?.ppuAddress?.zip?.zipCode.toString(),
							iapSubAddress.get(0)?.getSubscriber()?.contactInformation?.ppuAddress?.country.toString()
					)
					parsedAddress=new com.att.tpp.xml.model.Subscriber.Address(parsedCurrentSubAddress);
				}
			}else if(subscriberAddress.size() > 0){
				log.info("Inside ACCT DIP DataAugXMLParser Atlas XML subscriberAddress ::"+subscriberAddress.size());
				parsedCurrentSubAddress = new SubscriberAddress(
					subscriberAddress.@Type.toString(),
					subscriberAddress.@Street.toString(),
					subscriberAddress.@City.toString(),
					subscriberAddress.@State.toString(),
					subscriberAddress.@PostalCode.toString(),
					subscriberAddress.@CountryCode.toString()
				)
				parsedAddress=new com.att.tpp.xml.model.Subscriber.Address(parsedCurrentSubAddress);
			}
				
			if(subscriberPrevAddress.size() > 0){
				log.info("Inside ACCT DIP DataAugXMLParser Atlas XML subscriberPrevAddress ::"+subscriberPrevAddress.size());
				parsedPreviousSubAddress = new SubscriberAddress(
					subscriberPrevAddress.@Type.toString(),
					subscriberPrevAddress.@Street.toString(),
					subscriberPrevAddress.@City.toString(),
					subscriberPrevAddress.@State.toString(),
					subscriberPrevAddress.@PostalCode.toString(),
					subscriberPrevAddress.@CountryCode.toString()
				)
				parsedAddress=new com.att.tpp.xml.model.Subscriber.Address(parsedCurrentSubAddress,parsedPreviousSubAddress);
			}
		}else{
		
		/*
		 * End - Added for CS-FOBPM
		 */
			if(iapSubAddress != null)
			{
				if(iapSubAddress.get(0)?.getSubscriber()?.contactInformation?.ppuAddress != null){
					
					log.info("Inside DataAugXMLParser IAP Response iapSubAddress Subscriber size---> " + inquireAccountProfileResponse?.account?.subscriber?.size())
					
					parsedSubAddress = new SubscriberAddress(
						iapSubAddress.get(0)?.getSubscriber()?.contactInformation?.ppuAddress?.addressType.toString(),
						iapSubAddress.get(0)?.getSubscriber()?.contactInformation?.ppuAddress?.addressLine1.toString(),
						iapSubAddress.get(0)?.getSubscriber()?.contactInformation?.ppuAddress?.city.toString(),
						iapSubAddress.get(0)?.getSubscriber()?.contactInformation?.ppuAddress?.state.toString(),
						iapSubAddress.get(0)?.getSubscriber()?.contactInformation?.ppuAddress?.zip?.zipCode.toString(),
						iapSubAddress.get(0)?.getSubscriber()?.contactInformation?.ppuAddress?.country.toString()
					)
					parsedAddress=new com.att.tpp.xml.model.Subscriber.Address(parsedSubAddress);
				}else{
					log.info("Inside DataAugXMLParser IAP Response iapSubAddress Address is empty!!!!!")
				}
			}else{
				log.info("Inside DataAugXMLParser IAP Response iapSubAddress Subscriber is empty!!!!!")
			}
		}
		//Added for Subscriber Email
		// Order/Subscriber/Email
/*		def parsedSubEmail = subscriberEmail.collect {
			new Email(
				(it.@emailAddress.size()>0) ? it.@emailAddress.toString() : null,
				(it.@primaryAddressIndicator.size()>0) ? it.@primaryAddressIndicator.toBoolean() : false,
				(it.@emailType.size()>0) ? it.@emailType.toString() : null)
		}*/
		
		
		/*
		 * Start - Subscriber EMail Added for CS-FOBPM
		 */
		def parsedCurrentSubEMail = null;
		def parsedPrevSubEMail = null;
		def parsedEmail = null;
		def parsedSubEmail = null;
		def iapSubEmail = inquireAccountProfileResponse?.account?.subscriber
		if(csiDips!=null && csiDips.contains("ACCT"))
		{
			//Subscriber EMail from IAP Response
			if(iapSubEmail != null){
				if(iapSubEmail.get(0)?.getSubscriber()?.contactInformation?.email?.emailAddress != null){
					
					log.info("Inside ACCT DIP DataAugXMLParser iapSubEmail Email ---> " + iapSubEmail.get(0)?.getSubscriber()?.contactInformation?.email?.emailAddress.toString())
					
					parsedCurrentSubEMail = new SubscriberEmailInfo(
							iapSubEmail.get(0)?.getSubscriber()?.contactInformation?.email?.emailAddress.toString(),
							iapSubEmail.get(0)?.getSubscriber()?.contactInformation?.email?.emailType.toString(),
							iapSubEmail.get(0)?.getSubscriber()?.contactInformation?.email?.primaryAddressIndicator.toBoolean()
					)
					parsedEmail = new EmailInfo(parsedCurrentSubEMail);
				}else{
					log.info("Inside ACCT DIP DataAugXMLParser iapSubEmail Email is empty!!!!!")
				}			
			}else if(subscriberEmail.size() > 0){
				log.info("Inside ACCT DIP DataAugXMLParser Atlas XML subscriberEmail ::"+subscriberEmail.size());
				parsedCurrentSubEMail = new SubscriberEmailInfo(
					subscriberEmail.@emailAddress.toString(),
					subscriberEmail.@emailType.toString()
				)
				parsedEmail=new EmailInfo(parsedCurrentSubEMail);
			}
				
			if(subscriberPrevEmail.size() > 0){
				log.info("Inside  ACCT DIP  DataAugXMLParser subscriberPrevEmail ::"+subscriberPrevEmail.size());
				parsedPrevSubEMail = new SubscriberEmailInfo(
					subscriberPrevEmail.@emailAddress.toString(),
					subscriberPrevEmail.@emailType.toString()
				)
				parsedEmail=new EmailInfo(parsedCurrentSubEMail,parsedPrevSubEMail);
			}
		}else{
		
		/*
		 * End - Added for CS-FOBPM
		 */
		
			if(iapSubEmail != null)
			{
				if(iapSubEmail.get(0)?.getSubscriber()?.contactInformation?.email?.emailAddress != null){
					
					log.info("Inside  DataAugXMLParser iapSubEmail Email ---> " + iapSubEmail.get(0)?.getSubscriber()?.contactInformation?.email?.emailAddress.toString())
					
					parsedSubEmail = new SubscriberEmailInfo(
							iapSubEmail.get(0)?.getSubscriber()?.contactInformation?.email?.emailAddress.toString(),
							iapSubEmail.get(0)?.getSubscriber()?.contactInformation?.email?.emailType.toString(),
							iapSubEmail.get(0)?.getSubscriber()?.contactInformation?.email?.primaryAddressIndicator.toBoolean()
					)
					parsedEmail = new EmailInfo(parsedSubEmail);
				}
				else{
					log.info("Inside  DataAugXMLParser iapSubEmail Email is empty!!!!!")
				}			
			}
			else{
				log.info("Inside  DataAugXMLParser iapSubEmail Subscriber is empty!!!!!")
			}
		}
		//End Added for Subscriber Email
		// Order/Subscriber
		def parsedSubscriber = new Subscriber(parsedContact, parsedAddress, parsedEmail)
		
		// Order/SubscriberStatusDetail
		def parsedSubscriberStatusDetail = null
	/*
	 * Added extra null check for subscriberStatus to handle the empty subscriberStatus tag from IAP response.
	 */
		if(subscriberStatusDetail.size() > 0 ){
			parsedSubscriberStatusDetail = new SubscriberStatusDetailInfo(
				subscriberStatusDetail.subscriberStatus.toString(),				
				subscriberStatusDetail.statusReasonCode.toString(),
				(subscriberStatusDetail.isSuspensionVoluntary.size()>0) ? subscriberStatusDetail.isSuspensionVoluntary : null			
			)			
		}else{
			def subscriberStatusFrmIAP = inquireAccountProfileResponse?.account?.subscriber?.get(0)?.getSubscriber()?.subscriberStatus
			def subscriberStatusTemp = inquireAccountProfileResponse?.account?.subscriber?.get(0)?.getSubscriber()?.subscriberStatus?.subscriberStatus
			if(subscriberStatusFrmIAP!=null && subscriberStatusTemp!=null){
				parsedSubscriberStatusDetail = new SubscriberStatusDetailInfo(
					subscriberStatusFrmIAP.subscriberStatus.toString(),
					subscriberStatusFrmIAP.statusReasonCode.toString(),
					(subscriberStatusDetail.isSuspensionVoluntary.size()>0) ? subscriberStatusDetail.isSuspensionVoluntary.toBoolean() : null
				)
			 }
		 }	
		
		// Order/Equipment
		def parsedEquipment = null
		def parsedDevice = null
		def parsedSIM = null
		
		if(equipment.size() >  0){
			if(device.size() > 0 ){
				parsedDevice = new Device(
					device.@Make.toString(),
					device.@Model.toString(),
					device.@ESN.toString(),
					device.@IMEI.toString(),
					device.@MMSCapable.toBoolean()
				)
				if(sim.size() > 0){
					parsedSIM = new SIM(
						sim.@IMSI.toString(),
						sim.@ICCID.toString()						
					)
					parsedEquipment = new Equipment(parsedDevice, parsedSIM)					
				}
				else{
					parsedEquipment = new Equipment(parsedDevice)					
				}
			}
		}
		
		// Order/ServiceInfo
		def parsedServiceInfo = null
		
		if (serviceInfo.size() > 0){
			if(serviceInfo.@PrevNetworkGroup.size() > 0){
				if(serviceInfo.@PrepaidPlatformType.size() > 0){
					
					parsedServiceInfo = new ServiceInfo(
						serviceInfo.@Language.toString(),
						serviceInfo.@Currency.toString(),
						serviceInfo.@Generation.toString(),
						serviceInfo.@NetworkGroup.toString(),
						serviceInfo.@PrevNetworkGroup.toString(),
						serviceInfo.@PaymentType.toString(),
						serviceInfo.@PrepaidPlatformType.toString()						
					)					
				}				
			}
			else{
				parsedServiceInfo = new ServiceInfo(
					serviceInfo.@Language.toString(),
					serviceInfo.@Currency.toString(),
					serviceInfo.@Generation.toString(),
					serviceInfo.@NetworkGroup.toString(),
					serviceInfo.@PaymentType.toString()																
					)
			}			
		}
		
		// Order/MarketingOptions
		def parsedMarketingOptions = null
		
		if(marketOptions.size() > 0){
			parsedMarketingOptions = marketOptions.MarketingOption.collect {
				new MarketingOption(
					it.@Name.toString(),
					it.@Value.toBoolean().booleanValue()
				)
			}
		}
		// Order/BillingAccount
		def parsedBillingAccont = null
		//Added DCMNotification condition to get Billing Account for DCM flow
		if(billingAccount.size() > 0 || header.@Atlas_Event_Type.toString().equalsIgnoreCase("SWCNotification") || header.@Atlas_Event_Type.toString().equalsIgnoreCase("DCMNotification")){
			parsedBillingAccont = getParsedBillingAccount(billingAccount, inquireAccountProfileResponse, inquireFanProfileResponse, csiDips)
		}
		
		// Order/FinancialNotification
		def parsedFinancialNotification = null
		
		if(financialNotification.size() > 0){
			parsedFinancialNotification = getParsedFinancialNotification(financialNotification)
		}
		
		// Order/TPP_SKUOrder
		// Need to push this through without parsing if possible
		//Can be skipped since SKU orders do not make it to DIPArchive
		// Now it is required for TPP_SKU data for ICIF dip
		def orderNotifReq = order.TPP_SKUOrder;
		def parsedTppskuOrder = null;
		log.info ("Inside  DataAugXMLParser orderNotifReq.size():: "+orderNotifReq.size())
		if(orderNotifReq.size()>0)
		{
			parsedTppskuOrder = getParsedOrderNotification(orderNotifReq);
		}
		
		// Order/FemtocellTNUpdate
		def parsedFemtocellTNUpdate = null
		
		if(femtoCellNotification.size() > 0){
			parsedFemtocellTNUpdate = getParsedFemtoCellTNUpdate(femtoCellNotification)
		}
		
		// Order/ImmutableKeys
		//Need to push this through without parsing if possible
		
		// Order/ParentalControlsSettingInfo
		def parsedParentalControls = null
		def reasonCode = inquireSubscriberParentalControlsResponse?.parentalControls?.purchaseBlocking?.reasonCode
		
		if(inquireSubscriberParentalControlsResponse!=null && reasonCode!=null &&  reasonCode.length()>0){
			
			def parentalControl = inquireSubscriberParentalControlsResponse?.parentalControls?.purchaseBlocking
			
			if(!parentalControl.equals(null)){
				parsedParentalControls = new ParentalControlsSettingInfo(parentalControl?.indicator.toString(), parentalControl?.reasonCode.toString())
			}
			
		}
		
		// Order/AccountTypeInfo
		def parsedAccountTypeInfo = null
		def accountTypeTemp = inquireAccountProfileResponse?.account?.accountType?.accountType
		
		if(inquireAccountProfileResponse != null && accountTypeTemp!=null && accountTypeTemp.length() > 0){
			
			parsedAccountTypeInfo = new AccountTypeInfo(inquireAccountProfileResponse?.account.accountType.accountType.toString(), inquireAccountProfileResponse?.account.accountType.accountSubType.toString())
		}
		
		// Order/segmentType		
		def parsedSegmentType = null		
		
		def segmentType = inquireFanProfileResponse?.profile?.segmentType
		
		if(inquireFanProfileResponse != null && segmentType!=null)
		{
			parsedSegmentType = new SegmentType(segmentType.segmentCode.toString(), segmentType.segmentDescription.toString(), segmentType.subsegmentCode.toString(), segmentType.subsegmentDescription.toString())
		}
		
		// Order/MarketInfo
		def parsedMarketInfo = null
		/*
		def marketInfo = inquireAccountProfileResponse?.account?.billingMarket
		 
		if(inquireAccountProfileResponse !=null && inquireAccountProfileResponse?.account?.billingMarket?.billingMarket?.length() > 0){
			
			parsedMarketInfo = new MarketInfo(marketInfo.billingMarket.toString(), marketInfo.billingSubMarket.toString(), marketInfo.localMarket.toString())
		}
		*/
		def marketInfo = inquireAccountProfileResponse?.account?.subscriber?.get(0)?.getSubscriber()?.billingMarket
		if(atlasMarketInfo!=null && atlasMarketInfo.size() > 0 ){
			parsedMarketInfo = new MarketInfo(atlasMarketInfo.billingMarket.toString(), atlasMarketInfo.billingSubMarket.toString())
		}else if(inquireAccountProfileResponse !=null && inquireAccountProfileResponse?.account?.subscriber?.get(0)?.getSubscriber()?.billingMarket?.billingMarket?.length() > 0){
			parsedMarketInfo = new MarketInfo(marketInfo.billingMarket.toString(), marketInfo.billingSubMarket.toString(), marketInfo.localMarket.toString())
		}
		// Order/salesReps		
		def parsedSalesReps = null
		def salesReps = inquireFanProfileResponse?.profile?.salesReps
		
		//If salesReps from ROME InquireFanProfile dip is not null, then replace salesReps from CSI InquireFanProfile by it
		if (romeInquireFanProfileSalesReps !=null) {
			parsedSalesReps = romeInquireFanProfileSalesReps;
			log.info("Replacing salesReps from CSI inquireFanProfile by that of ROME InquireFanProfile")
			//reset salesReps to skip the block below
			salesReps = null
		}
		
		if(inquireFanProfileResponse != null &&  salesReps!=null ){			
			
			
			parsedSalesReps = salesReps.collect {
				new SalesReps( new NameInfoCSIDP(it.name?.namePrefix?.toString(), it.name?.firstName?.toString(),
					                             it.name?.middleName?.toString(), it.name?.lastName?.toString(),
												  it.name?.nameSuffix?.toString(), it.name?.additionalTitle?.toString() ),
								new DealerInfo(it.dealerCode?.code?.toString(), it.dealerCode?.secondaryCode?.toString()),
								it.position?.toString(), 
								it.territory?.toString(),
								it.jobTitle?.toString()
							  )
			}
		}
		//Order/LocationAccountId
		def parsedLocationId = null;
		if(inquireFanProfileResponse!=null && inquireFanProfileResponse?.profile?.billingInfo?.locationAccountID?.length()>0){
			parsedLocationId = inquireFanProfileResponse.profile.billingInfo.locationAccountID.toString()
		}
		log.info("Inside  DataAugXMLParser parsedLocationId---> " +parsedLocationId)

		//Order/FirstNet Indicator
		def parsedFirstNetIndicator = null;
		def ifpRestrictions = inquireFanProfileResponse?.profile?.restrictions;
		if(inquireFanProfileResponse!=null && ifpRestrictions != null){
			ifpRestrictions?.offering.collect{
				log.info("Inside  DataAugXMLParser Inside loop --parsedFirstNetIndicator---> offeringName>>"+it.offeringName+"it.isDisabled()>>>"+it.disabled)
				if(it.offeringName != null && (it.offeringName?.toString()=="FNP1" || it.offeringName?.toString()=="FNE1" || it.offeringName?.toString()=="FNV1") && (it.disabled?.toString()=="false")){
					parsedFirstNetIndicator=it.offeringName.toString();
				}
				
			}
		}
		log.info("Inside  DataAugXMLParser parsedFirstNetIndicator---> " +parsedFirstNetIndicator)
		
		//Order/Delta
		
		def parsedDelta = new Delta(
			delta.Attribute.collect{ 
				new Attribute(it.@Name.toString(), it.@Value.toString()) 
				}
			)
		
		// Order/CustRegContactInfo_BASE
		
//		/**
//		 * @param namePrefix
//		 * @param firstName
//		 * @param middleName
//		 * @param lastName
//		 * @param jobTitle
//		 * @param workPhoneNumber
//		 * @param email
//		 * @param type
//		 */
//		def parseCustRegContactInfo_BASE = null
//		
//		if(inquireFanProfileContactsResponse != null && inquireFanProfileContactsResponse?.contact?.get(0)?.firstName?.toString().length()>0)
//		{
//			def custRegContactInfo_BASE = inquireFanProfileContactsResponse.contact
//			parseCustRegContactInfo_BASE = custRegContactInfo_BASE.collect
//			{
//				new CustRegContactInfoBASE (it.namePrefix.toString(), it.firstName.toString(), it.middleName.toString(),
//					                        it.lastName.toString(), it.jobTitle.toString(), it.workPhoneNumber.toString(),
//											it.email.toString(), it.type.toString())
//			}
//		}
		
		
		
		// Order/CombinedBilling
		//Need to push this through without parsing if possible
		
		
		// Order/FormData
		//InquireCustomerInformationFormResponseInfo inquireCustomerInformationFormResponse
		def parsedFormsData = null
		def icifFormData = inquireCustomerInformationFormResponse?.formData;
		
		if(icifFormData != null)
		{
				log.info("FormData size---> " + inquireCustomerInformationFormResponse?.formData?.size())
				/*
				icifFormData.collect{
					log.info("FormName---> " + it.formName.toString());
					log.info("size of parameter details ---> " + it.parameterDetails.size());
				}
				*/
				parsedFormsData = new Forms(
						icifFormData.collect{
						new FormData(
							it.identifier.toString(),
							it.name.toString(),
							it.formName.toString(),
							it.templateIdentifier.toString(),
							it.token.toString(),
							it.formType.toString(),
							it.status.toString(),							
							it.parameterDetails.collect{
								new ParameterDetails(
									it.name.toString(),
									it.group.toString(),
									it.value.collect{
										it.toString()
									}
								)
							}
						)
					}
				)
		}
		else{
			log.info("FormData is empty!!!!!")
		}
		
		//Order/VendorDetails
		def parsedVendorDetails = null
		
		if(vendorDetails.size() > 0){
			parsedVendorDetails = new VendorDetails(vendorDetails?.VendorName?.toString(),
													vendorDetails?.CompanyName?.toString(),
													vendorDetails?.OrderId?.toString())
		}
		// Order/EnterpriseType
		def parsedEnterpriseType = null
		
		if(inquireFanProfileResponse!=null && inquireFanProfileResponse?.profile?.enterpriseType != null){
			parsedEnterpriseType = inquireFanProfileResponse.profile?.enterpriseType?.toString();
		}
		// Order/EventType
		def parsedEventType = null
		
		if(eventType.size() > 0){
			parsedEventType = new EventTypeInfo(eventType.EventName.toString())
		}

		// Order/TaxExemption
		def parsedTaxExemption = null
		
		if(inquireAccountProfileResponse !=null && inquireAccountProfileResponse?.account?.taxExemption !=null &&inquireAccountProfileResponse?.account?.taxExemption?.status?.length() > 0){
			parsedTaxExemption = new TaxExemption(taxExemption.status.toString(), taxExemption.entityType.toString(),
												  taxExemption.effectiveDate.toString(), taxExemption.expirationDate.toString()
												 )
		}
		
		
		def parsedDealerCommission
		if(inquireAccountProfileResponse !=null && inquireAccountProfileResponse?.account?.commission !=null ){
			def dealerCommissionInfo = inquireAccountProfileResponse?.account?.commission
			
			parsedDealerCommission = new DealerCommissionInfo(
				new DealerInfo(dealerCommissionInfo.dealer?.code?.toString(), dealerCommissionInfo.dealer?.secondaryCode?.toString()),
				dealerCommissionInfo.location?.toString(),
				dealerCommissionInfo.salesRepresentative?.toString(),
				new DualCommisionsInfo(dealerCommissionInfo.dualCommission?.creditCheckAgent?.toString(),dealerCommissionInfo.dualCommission?.creditCheckAgentLocation?.toString()),
				dealerCommissionInfo.affiliateSalesRepCode?.toString(),
				dealerCommissionInfo.billingTelephoneNumber?.toString(),
				dealerCommissionInfo.customerCode?.toString()
				
				)
		}
		
		/**
		 * @param account *
		 * @param subscriber *
		 * @param subscriberStatusDetail *
		 * @param equipment *
		 * @param serviceInfo *
		 * @param marketingOptions *
		 * @param billingAccount *
		 * @param financialNotification * 
		 * @param tppskuOrder //need to just pass through
		 * @param * femtocellTNUpdate //need to just pass through
		 * @param immutableKeys //need to just pass through
		 * @param * parentalControlsSettingInfo //populated by dip
		 * @param * accountTypeInfo //populated by dip
		 * @param segmentType //populated by dip
		 * @param marketInfo //populated by dip
		 * @param salesReps //populated by dip
		 * @param custRegContactInfoBASE //populated by dip
		 * @param combinedBilling //need to just pass through
		 * @param eventType *
		 */

		
		//Order Object
		
		def parsedOrder = new Order(parsedAccount, parsedSubscriber,
			parsedSubscriberStatusDetail, parsedEquipment, parsedServiceInfo, null,
			parsedBillingAccont, parsedFinancialNotification, parsedTppskuOrder, parsedFemtocellTNUpdate,
			null, parsedParentalControls, parsedAccountTypeInfo, parsedSegmentType, parsedMarketInfo,
			parsedSalesReps, parseCustRegContactInfo_BASE, null, parsedDelta, parsedFormsData, parsedEventType, 
			parsedTaxExemption, parsedLocationId, parsedVendorDetails, parsedEnterpriseType, parsedFirstNetIndicator,parsedDealerCommission
		)
/*		
		def parsedOrder = new Order(parsedAccount, parsedSubscriber,
			parsedSubscriberStatusDetail, parsedEquipment, parsedServiceInfo, null,
			parsedBillingAccont, parsedFinancialNotification, parsedTppskuOrder, parsedFemtocellTNUpdate,
			null, parsedParentalControls, parsedAccountTypeInfo, parsedSegmentType, parsedMarketInfo,
			null, parseCustRegContactInfo_BASE, null, parsedDelta, parsedFormsData, parsedEventType, parsedTaxExemption, parsedLocationId
		)
		
		def parsedOrder = new Order(parsedAccount, parsedSubscriber,
			parsedSubscriberStatusDetail, parsedEquipment, parsedServiceInfo, null,
			parsedBillingAccont, parsedFinancialNotification, null, parsedFemtocellTNUpdate,
			null, parsedParentalControls, parsedAccountTypeInfo, parsedSegmentType, parsedMarketInfo,
			null, parseCustRegContactInfo_BASE, null, parsedDelta, parsedFormsData, parsedEventType, parsedTaxExemption
		)*/
		
	/*	def parsedOrder = new Order(parsedAccount, parsedSubscriber,
			parsedSubscriberStatusDetail, parsedEquipment, parsedServiceInfo, null,
			parsedBillingAccont, parsedFinancialNotification, null, parsedFemtocellTNUpdate,
			null, parsedParentalControls, parsedAccountTypeInfo, parsedSegmentType, parsedMarketInfo,
			null, parseCustRegContactInfo_BASE, null, parsedDelta, parsedEventType, parsedTaxExemption
		)
		
		def parsedOrder = new Order(parsedAccount, parsedSubscriber, 
			parsedSubscriberStatusDetail, parsedEquipment, parsedServiceInfo, null,
			parsedBillingAccont, parsedFinancialNotification, null, parsedFemtocellTNUpdate, 
			null, parsedParentalControls, parsedAccountTypeInfo, parsedSegmentType, parsedMarketInfo,
			null, parseCustRegContactInfo_BASE, null, parsedEventType, parsedTaxExemption
		)*/
		
		
		/*def parsedOrder = new Order(parsedAccount, parsedSubscriber,
			parsedSubscriberStatusDetail, parsedEquipment, parsedServiceInfo, parsedMarketingOptions,
			parsedBillingAccont, parsedFinancialNotification, null, parsedFemtocellTNUpdate,
			null, parsedParentalControls, parsedAccountTypeInfo, parsedSegmentType, parsedMarketInfo,
			parsedSalesReps, parseCustRegContactInfo_BASE, null, parsedEventType
		)*/
		
		
		//public TPPProvisioningRequest(Header header, Order order, Products products)
		/**
		 * Use this constructor with Provisioning Request!
		 * @param category
		 * @param id
		 * @param action
		 * @param attribute
		 */

		
		return new TPPProvisioningRequest(parsedHeader, 
			                              parsedOrder,			
								          new Products( products.Product.collect{
								                 new Product("3PP" ,it.@Id.toString(), it.@IPID.toString(), it.@Action.toString(), it.@EffectiveDate.toString(), it.@ExpirationDate.toString(),
										         it.Attribute.collect{ new Attribute(it.@Name.toString(), it.@Value.toString()) }
										         )}))
		
		
		
		
	}
	
	/**
	 * Provide BillingAccount model based on TPP_ProvisioningRequest XML node child account (tppProvReq.Order.BillingAccount).
	 *
	 * @param billingAccount (tppProvReq.Order.BillingAccount) NodeChildren to be parsed
	 * @return BillingAccount
	 */
	def BillingAccount getParsedBillingAccount(NodeChildren billingAccount, InquireAccountProfileResponseInfo inquireAccountProfileResponse,
		                                       InquireFanProfileResponseInfo inquireFanProfileResponse, String csiDips){
		def fan = billingAccount.FAN
		def fanName = billingAccount.FANName
		def contractId = billingAccount.ContractId
		def contractType = billingAccount.ContractType
		def billingCycle = billingAccount.BillingCycle
		def name = billingAccount.Name
		def address = billingAccount.Address
		def phone = billingAccount.Phone
		def email = billingAccount.Email
		def banEmail = billingAccount.BANEmail
		def billingMarket = billingAccount.BillingMarket
		
		def pFan = null
		def pFanName = null
		def pContractId = null
		def pContractType = null
		def pBillingCycle = null
		def pName = null
		def pCurrentName = null
		def pPreviousName = null
		def pAddress = null
		def pCurrentAddress = null
		def pPreviousAddress = null
		def pPhone = null
		def pCurrentPhone = null
		def pPreviousPhone = null
		def pEmail = null
		def pCurrentEmail = null
		def pPreviousEmail = null
		def pBanEmail = null
		def pBillingMarket = null
		
		//FAN check
		//log.info("Inside  DataAugXMLParser FAN size---> " + fan.size().toString())
		if(fan.size() > 0){
			if(fan.@currentFAN.size() > 0){
				if(fan.@previousFAN.size() > 0){
					pFan = new FAN(fan.@currentFAN.toString(), fan.@previousFAN.toString())
				}
				else{
					pFan = new FAN(fan.@currentFAN.toString())
				}
			}
		}
		else if((inquireAccountProfileResponse != null && inquireAccountProfileResponse?.account?.fan?.length()>0) || (inquireFanProfileResponse != null && inquireFanProfileResponse?.profile?.fan?.length()>0))
		{
			if(inquireFanProfileResponse?.profile?.fan?.length()>0)
			pFan = new FAN(inquireFanProfileResponse?.profile?.fan.toString())
			if(inquireAccountProfileResponse?.account?.fan?.length()>0)
			pFan = new FAN(inquireAccountProfileResponse.account.fan.toString())
		}
		
		//FANName check
		//log.info("Inside  DataAugXMLParser FANName size---> " + fanName.size().toString())
		if(fanName.size() > 0){
			pFanName = fanName.toString()
		}else
	     if(inquireFanProfileResponse!=null && inquireFanProfileResponse?.profile?.billingInfo?.companyName?.length()>0)
		 {
			 pFanName = inquireFanProfileResponse.profile.billingInfo.companyName.toString()
		 }
		
		//ContractID check
		if(contractId.size() > 0){
			pContractId = contractId.toString()
		}else
	     if(inquireFanProfileResponse != null && inquireFanProfileResponse?.profile?.contractId?.length()>0)
		 {
			pContractId =inquireFanProfileResponse.profile.contractId.toString()
		 }
		
		//ContractType check
		if(contractType.size() > 0){
			pContractType = contractType.toString()
		}else
	     if(inquireFanProfileResponse != null && inquireFanProfileResponse?.profile?.contractType?.length()>0)
		 {
			pContractType =inquireFanProfileResponse.profile.contractType.toString()
			log.info("contractType From IFP---> " + pContractType)
		 }
		
		//BillingCycle check
		if(billingCycle.size() > 0){
			if(billingCycle.@current.size() > 0){
				if(billingCycle.@previous.size() > 0){
					pBillingCycle = new BillingCycle(billingCycle.@current.toString(), billingCycle.@previous.toString())
				}
				else{
					pBillingCycle = new BillingCycle(billingCycle.@current.toString())
				}
			}
		}else
	     if(inquireAccountProfileResponse != null && inquireAccountProfileResponse?.account?.accountBilling?.billingCycle.toString().length()>0)
		 {
			 pBillingCycle = new BillingCycle(inquireAccountProfileResponse?.account?.accountBilling?.billingCycle.toString())
		 }
		
		//Name check
		
		 /*
		  * Start - Added for CS-FOBPM
		  */
		 if(csiDips!=null && csiDips.contains("ACCT"))
		 {
			 if ((inquireAccountProfileResponse!=null && inquireAccountProfileResponse.account?.subscriber?.get(0)?.getSubscriber()?.contactInformation?.name?.firstName?.length()>0) ||
				 (inquireAccountProfileResponse!=null && inquireAccountProfileResponse.account?.subscriber?.get(0)?.getSubscriber()?.contactInformation?.businessName?.contact?.firstName?.length()>0) ||
				 (inquireAccountProfileResponse!=null && inquireAccountProfileResponse.account?.customer?.name?.firstName?.length()>0) ||
				 (inquireAccountProfileResponse!=null && inquireAccountProfileResponse.account?.customer?.businessName?.contact?.firstName?.length()>0))
			 {
				 def contactInfoIAPSubscriber = inquireAccountProfileResponse.account?.subscriber?.get(0)?.getSubscriber()?.contactInformation
				 def contactInfoIAPAccount = inquireAccountProfileResponse.account?.customer
				 if(contactInfoIAPAccount?.name?.firstName?.length()>0){
						 log.info("Inside  DataAugXMLParser  ACCT DIP Billing Account - IAP Response First Name");
						 pCurrentName = new BillingAccountName(name?.current?.@Type.toString(), contactInfoIAPAccount?.businessName?.businessName.toString(),
							 contactInfoIAPAccount?.doingBusinessAs.toString(), contactInfoIAPAccount.name.firstName.toString(),
							 contactInfoIAPAccount.name.lastName.toString())
							 
						 pName = new Name(pCurrentName)
				   }else if(contactInfoIAPAccount?.businessName?.contact?.firstName?.length()>0){
						 log.info("Inside  DataAugXMLParser  ACCT DIP Billing Account - IAP Response Business Name - First Name");
						 pCurrentName = new BillingAccountName(name?.current?.@Type.toString(), contactInfoIAPAccount.businessName.businessName.toString(),
							 contactInfoIAPAccount?.doingBusinessAs.toString(), contactInfoIAPAccount.businessName.contact.firstName.toString(),
							 contactInfoIAPAccount.businessName.contact.lastName.toString())
						   
						 pName = new Name(pCurrentName)
				   }
			 }
		 }else{
		 /*
		  * End - Added for CS-FOBPM
		  */
			  if ((inquireAccountProfileResponse!=null && inquireAccountProfileResponse.account?.subscriber?.get(0)?.getSubscriber()?.contactInformation?.name?.firstName?.length()>0) ||
				  (inquireAccountProfileResponse!=null && inquireAccountProfileResponse.account?.subscriber?.get(0)?.getSubscriber()?.contactInformation?.businessName?.contact?.firstName?.length()>0) ||
				  (inquireAccountProfileResponse!=null && inquireAccountProfileResponse.account?.customer?.name?.firstName?.length()>0) ||
				  (inquireAccountProfileResponse!=null && inquireAccountProfileResponse.account?.customer?.businessName?.contact?.firstName?.length()>0))
			  {
				  def contactInfoIAPSubscriber = inquireAccountProfileResponse.account?.subscriber?.get(0)?.getSubscriber()?.contactInformation
				  def contactInfoIAPAccount = inquireAccountProfileResponse.account?.customer
	  			  if(contactInfoIAPSubscriber?.name?.firstName?.length()>0)
				  {
					  log.info("====================>Inside  DataAugXMLParser  Billing Account - in Subscriber First Name")
					  pCurrentName = new BillingAccountName(name?.current?.@Type.toString(), contactInfoIAPAccount?.businessName?.businessName.toString(),
						  contactInfoIAPAccount?.doingBusinessAs.toString(), contactInfoIAPSubscriber.name.firstName.toString(),
															contactInfoIAPSubscriber.name.lastName.toString())
					  pName = new Name(pCurrentName)
				  }
				  else
				  {
				  if(contactInfoIAPSubscriber?.businessName?.contact?.firstName?.length()>0)
							  {
								  log.info("====================>Inside  DataAugXMLParser  Billing Account - in Subscriber Business Name - First Name")
								  pCurrentName = new BillingAccountName(name?.current?.@Type.toString(), contactInfoIAPAccount?.businessName?.businessName.toString(),
									  contactInfoIAPAccount?.doingBusinessAs.toString(), contactInfoIAPSubscriber.businessName.contact.firstName.toString(),
									  contactInfoIAPSubscriber.businessName.contact.lastName.toString())
								  
								  pName = new Name(pCurrentName)
							  }
					  				  
					  else
						{	  if(contactInfoIAPAccount?.name?.firstName?.length()>0)
								  {				
									  log.info("====================> Inside  DataAugXMLParser  Billing Account - in Account First Name")
									  pCurrentName = new BillingAccountName(name?.current?.@Type.toString(), contactInfoIAPAccount?.businessName?.businessName.toString(),
										  contactInfoIAPAccount?.doingBusinessAs.toString(), contactInfoIAPAccount.name.firstName.toString(),
										  contactInfoIAPAccount.name.lastName.toString())
										  
									  pName = new Name(pCurrentName)				  
								  }		
							  else
							  if(contactInfoIAPAccount?.businessName?.contact?.firstName?.length()>0)
							  {
								  log.info("====================>Inside  DataAugXMLParser  Billing Account - in Account Business Name - First Name")
								  pCurrentName = new BillingAccountName(name?.current?.@Type.toString(), contactInfoIAPAccount.businessName.businessName.toString(),
									  contactInfoIAPAccount?.doingBusinessAs.toString(), contactInfoIAPAccount.businessName.contact.firstName.toString(),
									  contactInfoIAPAccount.businessName.contact.lastName.toString())
									
								  pName = new Name(pCurrentName)
							  }
							  
						}
				  }
				  
			  }
			  else
			  if(name.size() > 0){
				  
				  if(name.current.size() > 0 && name.current.toString()!="N/A" && name.current.toString()!="NA"){
					  log.info("====================>Inside  DataAugXMLParser  Billing Account -  in Atlas xml First Name")
					  pCurrentName = new BillingAccountName(name.current.@Type.toString(), name.current.@BusinessName.toString(), name.current.@DoingBusinessNameAs.toString(), name.current.@FirstName.toString(), name.current.@LastName.toString())
					  pName = new Name(pCurrentName)
					  if(name.previous.size() > 0){
						  pPreviousName = new BillingAccountName(name.previous.@Type.toString(), name.previous.@BusinessName.toString(), name.previous.@DoingBusinessNameAs.toString(), name.previous.@FirstName.toString(), name.previous.@LastName.toString())
						  pName = new Name(pCurrentName, pPreviousName)
					  }
				  }
			  }
			  }
				  
		
		//Address Check
		//log.info("Address size---> " + address.size().toString())
		//log.info("Address number of children ---> " + address.children().size().toString())
		//log.info("Address depth of element with children (this includes the Address element also) ---> " + address.depthFirst().collect {it}.size().toString())
		/*def countyName =""
		
		if(inquireAccountProfileResponse != null && inquireAccountProfileResponse?.account?.subscriber?.get(0)?.getSubscriber()?.contactInformation?.ppuAddress?.county?.countyName.length()>0)
		{
			 countyName = inquireAccountProfileResponse?.account?.subscriber?.get(0)?.getSubscriber()?.contactInformation?.ppuAddress?.county?.countyName.toString()
		}*/
		
		/*
		 * Start - Added for CS-FOBPM
		 */
		if(csiDips!=null && csiDips.contains("ACCT")){
			if(inquireAccountProfileResponse != null && inquireAccountProfileResponse?.account?.customer?.address?.addressLine1?.length()>0){
				log.info("Inside  DataAugXMLParser  ACCT DIP Billing Account - IAP Response Address");
				 def addressFrmIAPAccount = inquireAccountProfileResponse?.account?.customer?.address
				 def zipcode =""
				 def zipCodeInternational= ""
				 def internationalAddressLine= ""
				 
				 if(addressFrmIAPAccount?.zip?.zipCode?.length()<=6)
				 zipcode =addressFrmIAPAccount.zip.zipCode.toString()
				 if(addressFrmIAPAccount?.zip?.zipCode?.length()>=6)
				 zipCodeInternational = addressFrmIAPAccount.zip.zipCode.toString()

				 def addressType=null;
				 if(addressFrmIAPAccount!=null && addressFrmIAPAccount.addressType!=null){
					 addressType=addressFrmIAPAccount.addressType.value().toString();
				 }
				 if(addressFrmIAPAccount!=null && addressType!=null && addressType.equalsIgnoreCase("F"))
				 internationalAddressLine = addressFrmIAPAccount.internationalAddressLine.toString()
				 
				 pCurrentAddress = new BillingAccountAddress(addressType, addressFrmIAPAccount.addressLine1.toString(),
															 addressFrmIAPAccount.addressLine2.toString(), addressFrmIAPAccount.city.toString(),
															 addressFrmIAPAccount.state.toString(), zipcode.toString(),
															 zipCodeInternational.toString(), internationalAddressLine.toString(),
															  addressFrmIAPAccount.zip.zipCodeExtension.toString(), addressFrmIAPAccount.country?.toString(),
															   "", "", addressFrmIAPAccount.zip.zipGeoCode.toString(), addressFrmIAPAccount.county?.countyName?.toString())
				 
				 pAddress = new BillingAccount.Address(pCurrentAddress)
			 }else{
				 log.info("Inside DataAugXMLParser ACCT DIP Billing Account Address check - No Account Level Address found in IAP DIP");
			 }
		}else{
		/*
		 * End - Added for CS-FOBPM
		 */

		
		/* Commented below line as the address.size check is not required for the both request xml and response from IAP (ion Issue reported by Boost for Email not populating) */
		//if(address.size() > 0){
			if(address.current.size() > 0 || address.current.@AddressLine1.size()>0){				
				pCurrentAddress = new BillingAccountAddress(address.current.@Type.toString(), address.current.@AddressLine1.toString(),
					                                        address.current.@AddressLine2.toString(), address.current.@City.toString(),
															 address.current.@State.toString(), address.current.@PostalCode.toString(),
															  address.current.@InternationalPostalCode.toString(),
															   address.current.@InternationalAddressLine.toString(),
															    address.current.@PostalPlusCode.toString(), address.current.@CountryName.toString(),
																 address.current.@CountryCode.toString(), address.current.@LocalCompanyName.toString(),
																  address.current.@GeoCode.toString(), address.current.@CountyName.toString())
				pAddress = new BillingAccount.Address(pCurrentAddress)
				if(address.previous.size() > 0){
					pPreviousAddress = new BillingAccountAddress(address.previous.@Type.toString(), address.previous.@AddressLine1.toString(), 
						                                         address.previous.@AddressLine2.toString(), address.previous.@City.toString(),
																  address.previous.@State.toString(), address.previous.@PostalCode.toString(),
																   address.previous.@InternationalPostalCode.toString(), 
																   address.previous.@InternationalAddressLine.toString(), address.previous.@PostalPlusCode.toString(),
																    address.previous.@CountryName.toString(), address.previous.@CountryCode.toString(),
																	 address.previous.@LocalCompanyName.toString(), address.previous.@GeoCode.toString(),
																	 address.previous.@CountyName.toString())
					pAddress = new BillingAccount.Address(pCurrentAddress, pPreviousAddress)
				}
			}else{
		     if(inquireAccountProfileResponse != null && inquireAccountProfileResponse?.account?.customer?.address?.addressLine1?.length()>0)
			 {
				 def addressFrmIAPAccount = inquireAccountProfileResponse?.account?.customer?.address
				 def zipcode =""
				 def zipCodeInternational= ""
				 def internationalAddressLine= ""
				 
				 if(addressFrmIAPAccount?.zip?.zipCode?.length()<=6)
				 zipcode =addressFrmIAPAccount.zip.zipCode.toString()
				 if(addressFrmIAPAccount?.zip?.zipCode?.length()>=6)
				 zipCodeInternational = addressFrmIAPAccount.zip.zipCode.toString()

				 def addressType=null;
				 if(addressFrmIAPAccount!=null && addressFrmIAPAccount.addressType!=null){
					 addressType=addressFrmIAPAccount.addressType.value().toString();
				 }
				 if(addressFrmIAPAccount!=null && addressType!=null && addressType.equalsIgnoreCase("F"))
				 internationalAddressLine = addressFrmIAPAccount.internationalAddressLine.toString()
				 
				 pCurrentAddress = new BillingAccountAddress(addressType, addressFrmIAPAccount.addressLine1.toString(),
					                                         addressFrmIAPAccount.addressLine2.toString(), addressFrmIAPAccount.city.toString(),
															 addressFrmIAPAccount.state.toString(), zipcode.toString(),
															 zipCodeInternational.toString(), internationalAddressLine.toString(),
															  addressFrmIAPAccount.zip.zipCodeExtension.toString(), addressFrmIAPAccount.country?.toString(),
															   "", "", addressFrmIAPAccount.zip.zipGeoCode.toString(), addressFrmIAPAccount.county?.countyName?.toString())
				 
				 pAddress = new BillingAccount.Address(pCurrentAddress)
			 }else
		      if(inquireAccountProfileResponse!=null && inquireAccountProfileResponse?.account?.subscriber?.get(0)?.getSubscriber()?.contactInformation?.ppuAddress?.addressLine1?.length()>0)
			  {
				  def addressFrmIAPSubscriber = inquireAccountProfileResponse.account.subscriber.get(0).getSubscriber().contactInformation.ppuAddress
				  def zipcode =""
				  def zipCodeInternational= ""
				  def internationalAddressLine= ""
				  
				  if(addressFrmIAPSubscriber.zip.zipCode.length()<=6)
				  zipcode =addressFrmIAPSubscriber.zip.zipCode.toString()
				  if(addressFrmIAPSubscriber.zip.zipCode.length()>=6)
				  zipCodeInternational = addressFrmIAPSubscriber.zip.zipCode.toString()
				  
				  def addressType=null;
				  if(addressFrmIAPSubscriber!=null && addressFrmIAPSubscriber.addressType!=null){
					   addressType=addressFrmIAPSubscriber.addressType.value().toString();
				   }
				  
				  if(addressFrmIAPSubscriber!=null && addressType !=null && addressType.equalsIgnoreCase("F"))
				  internationalAddressLine = addressFrmIAPSubscriber.internationalAddressLine.toString()
				  
				  pCurrentAddress = new BillingAccountAddress(addressType, addressFrmIAPSubscriber.addressLine1.toString(),
															  addressFrmIAPSubscriber.addressLine2.toString(), addressFrmIAPSubscriber.city.toString(),
															  addressFrmIAPSubscriber.state.toString(), zipcode.toString(),
															  zipCodeInternational.toString(), internationalAddressLine.toString(),
															   addressFrmIAPSubscriber.zip.zipCodeExtension.toString(), addressFrmIAPSubscriber.country?.toString(),
																"", "", addressFrmIAPSubscriber.zip.zipGeoCode.toString(), addressFrmIAPSubscriber.county?.countyName?.toString())
				  
				  pAddress = new BillingAccount.Address(pCurrentAddress)
			  }
			}
		//}
		}
		//Phone check
		/* Commented below line as the phone.size check is not required for the both request xml and response from IAP (ion Issue reported by Boost for Email not populating) */
		//if(phone.size() > 0){
			if(phone.current.size() > 0 && (phone.current.@homePhone.size()>0 || phone.current.@workPhone.size()>0 || phone.current.@workPhoneExtension.size()>0 || phone.current.@canBeReachedPhone.size()>0 )){
				pCurrentPhone = new BillingAccountPhone(phone.current.@homePhone.toString(), phone.current.@workPhone.toString(), phone.current.@workPhoneExtension.toString(), phone.current.@canBeReachedPhone.toString())				
				pPhone = new Phone(pCurrentPhone)
				if(phone.previous.size() > 0){
					pPreviousPhone = new BillingAccountPhone(phone.previous.@homePhone.toString(), phone.previous.@workPhone.toString(), phone.previous.@workPhoneExtension.toString(), phone.previous.@canBeReachedPhone.toString())					
					pPhone = new Phone(pCurrentPhone, pPreviousPhone)
				}
			}
			else
			{
				def phoneFrmAccount = inquireAccountProfileResponse?.account?.customer?.phone
				def phoneFrmSubscriber = inquireAccountProfileResponse?.account?.subscriber?.get(0)?.getSubscriber()?.contactInformation?.phone
				if(inquireAccountProfileResponse!=null && phoneFrmAccount!=null && phoneFrmAccount?.canBeReachedPhone?.length()>0)
				{					
					pCurrentPhone = new BillingAccountPhone(phoneFrmAccount.homePhone.toString(), phoneFrmAccount.workPhone.toString(),
						                                    phoneFrmAccount.workPhoneExtension.toString(), phoneFrmAccount.workPhoneExtension.toString())
					pPhone = new Phone(pCurrentPhone)
				}else
				if(inquireAccountProfileResponse!=null && phoneFrmSubscriber!=null && phoneFrmSubscriber?.canBeReachedPhone?.length()>0)
				{
					pCurrentPhone = new BillingAccountPhone(phoneFrmSubscriber.homePhone.toString(), phoneFrmSubscriber.workPhone.toString(),
															phoneFrmSubscriber.workPhoneExtension.toString(), phoneFrmSubscriber.workPhoneExtension.toString())
					pPhone = new Phone(pCurrentPhone)
				}
				
			}
		//}
		
		//Email check
		/* Commented below line as the email.size check is not required for the both request xml and response from IAP (ion Issue reported by Boost for Email not populating)*/
		//if(email.size() > 0){
			log.debug("email.current.size() ::"+email.current.size());
			log.debug("email.children().@emailAddress.size() :: "+email.children().@emailAddress.size());			
			if(email.current.size() > 0 && email.children().@emailAddress.size() >0){
				log.debug("Inside  email.current");
				pCurrentEmail = email.children().collect{					
					if (!it.findAll{it.name() == "current"}.collect{curr -> curr.@emailAddress.toString()}.equals([])){						
						new BillingAccountEmail(it.findAll{it.name() == "current"}.@emailType.toString(), it.findAll{it.name() == "current"}.@emailAddress.toString())
					}										
				}
				pEmail = new BillingAccount.Email(pCurrentEmail)
				log.debug("email.previous.size() ::"+email.previous.size());
				if(email.previous.size() > 0){	
					log.debug("Inside  email.previous");
					pPreviousEmail = email.children().collect{
						if (!it.findAll{it.name() == "previous"}.collect{prev -> prev.@emailAddress.toString()}.equals([])){
							new BillingAccountEmail(it.findAll{it.name() == "previous"}.@emailType.toString(), it.findAll{it.name() == "previous"}.@emailAddress.toString())
						}											
					}
					pEmail = new BillingAccount.Email(pCurrentEmail, pPreviousEmail)
				}
			}
			else
			{
				
				def emailFrmAccount = inquireAccountProfileResponse?.account?.customer?.email
				log.debug("Inside else part emailFrmAccount from IAP:: "+emailFrmAccount);
				def emailFrmSubscriber = inquireAccountProfileResponse?.account?.subscriber?.get(0)?.getSubscriber()?.contactInformation?.email
				log.debug("emailFrmSubscriber :: "+emailFrmSubscriber);
				if(inquireAccountProfileResponse!=null && emailFrmAccount!=null && emailFrmAccount?.emailAddress?.length()>0)
				{
					log.debug("Inside if emailFrmAccount from IAP pCurrentEmail:: ");
					pCurrentEmail = emailFrmAccount.collect{						
							new BillingAccountEmail(it.emailType.toString(), it.emailAddress)					
					}
					pEmail = new BillingAccount.Email(pCurrentEmail)
				}
				else
				if(inquireAccountProfileResponse!=null && emailFrmSubscriber!=null && emailFrmSubscriber?.emailAddress?.length()>0)
				{
					log.debug("Inside else if emailFrmSubscriber from IAP pCurrentEmail:::: ");
					pCurrentEmail = emailFrmSubscriber.collect{
							new BillingAccountEmail(it.emailType.toString(), it.emailAddress)
					}
					pEmail = new BillingAccount.Email(pCurrentEmail)
				}
				
			}
	//	}
		
		//Debug output
//		pEmail*.each{
//			curr -> curr.current*.each{
//				it -> log.info(" Current Email <>----> " + it.emailType)
//			}
//			
//			curr.previous*.each{
//				prevIT -> log.info(" Previous Email <>----> " + prevIT.emailType)
//			}
//			
//		}
		
		//BANEmail check
		log.info("Inside DataAugXMLParser BANEmail size---> " + banEmail.size().toString())
		def emailFrmAccount = inquireAccountProfileResponse?.account?.customer?.email
		if(inquireAccountProfileResponse!=null && emailFrmAccount!=null && emailFrmAccount?.emailAddress?.length() > 0){			
			pBanEmail = new BANEmail(emailFrmAccount.emailType.toString(), emailFrmAccount?.emailAddress.toString())			
		}
		
		//BillingMarket check
		log.info("Inside DataAugXMLParser BillingMarket size---> " + billingMarket.size().toString())
		if(billingMarket.size() > 0){
			if(billingMarket.@current.size() > 0){
				if(billingMarket.@previous.size() > 0){
					pBillingMarket = new BillingMarket(billingMarket.@current.toString(), billingMarket.@previous.toString())
				}
				else{
					pBillingMarket = new BillingMarket(billingMarket.@current.toString())
				}
			}
		}
		
		return new BillingAccount(pFan, pFanName, pContractId, pContractType, pBillingCycle, pName, pAddress, pPhone, pEmail, pBanEmail, pBillingMarket)
	}
	
	/**
	 * Provide FinancialNotificationType model based on TPP_ProvisioningRequest XML node child account (tppProvReq.Order.FinancialNotification).
	 *
	 * @param financialNotification (tppProvReq.Order.FinancialNotification) NodeChildren to be parsed
	 * @return FinancialNotificationType
	 */
	def FinancialNotificationType getParsedFinancialNotification(NodeChildren financialNotification){
		def parsedAdjustmentAmount = null
		def parsedAdjustmentCode = null		
		
		if(financialNotification.@AdjustmentAmount.size() > 0){
			parsedAdjustmentAmount = financialNotification.@AdjustmentAmount.toString()			
			
			if(financialNotification.@AdjustmentCode.size() > 0){
				parsedAdjustmentCode = financialNotification.@AdjustmentCode.toString()			 
			}			
		}	
		
		return new FinancialNotificationType(parsedAdjustmentAmount, parsedAdjustmentCode) 
		
	}
	
	/**
	 * Provide TNUpdateInfo model based on TPP_ProvisioningRequest XML node child account (tppProvReq.Order.FemtocellTNUpdate).
	 *
	 * @param femtoCellNotification (tppProvReq.Order.FemtocellTNUpdate) NodeChildren to be parsed
	 * @return TNUpdateInfo
	 */
	def TNUpdateInfo getParsedFemtoCellTNUpdate(NodeChildren femtoCellNotification){
		def femtoAddress = femtoCellNotification.FemtocellAddress
		def femtoInfo =  femtoCellNotification.FemtocellAdditionalInfo
		
		def parsedTNAddress = null
		def parsedTNInfo = null
		
		if(femtoAddress.size() > 0){
			parsedTNAddress = new TNAddress(femtoAddress.@HNO.toString(), femtoAddress.@HNS.toString(), femtoAddress.@PRD.toString(), femtoAddress.@STN.toString(), 
				femtoAddress.@MCN.toString(), femtoAddress.@STA.toString(), femtoAddress.@LOC.toString(), femtoAddress.@STS.toString(), femtoAddress.@POD.toString(), femtoAddress.@ZIP.toString())
						
			if(femtoInfo.size() > 0){
				parsedTNInfo = new TNInfo(femtoInfo.@ExternalKey.toString(), femtoInfo.@NENAID.toString(), femtoInfo.@CLS.toString(), femtoInfo.@TYS.toString(), femtoInfo.@Latitude.toString(), femtoInfo.@Longitude.toString())
			}		
		}
		
		return new TNUpdateInfo(parsedTNAddress, parsedTNInfo)		
	}
	
	//For ICIF dip - parsing TPP_Prov req data for TPP_SKU 
	def TPPSKUOrder getParsedOrderNotification(NodeChildren orderNotifReq)
	{
		def customer = orderNotifReq.OrderNotification?.Customer
		def businessNameElem = ""
		if(customer.businessName.size()!=0)
		{
			businessNameElem =customer.businessName.toString()
		}
		else
		if(customer.Name.size()!=0)
		{
			businessNameElem=customer?.Name?.firstName.toString() + customer?.Name?.lastName.toString()
		}
		log.info ("Inside DataAugXMLParser orderNotifReq.OrderNotification.orderId.location.toString():: "+orderNotifReq.OrderNotification.orderId.location.toString())
		def parsedOrderNotification = new TPPSKUOrder.OrderNotification(
			orderNotifReq.OrderNotification.@EventName.toString(),			
			new OrderNotificationInfo(
				new OrderDocumentInfo(
					orderNotifReq.OrderNotification.orderId.location.toString(),
					orderNotifReq.OrderNotification.orderId.activity.toString(),
					orderNotifReq.OrderNotification.orderId.orderId.toString()
					),
					orderNotifReq.OrderNotification.orderWarehouse.toString(),
					orderNotifReq.OrderNotification.orderDate.toString(),
					orderNotifReq.OrderNotification?.paymentMethod.toString(),
					new OrderNotificationInfo.Customer(
						customer.customerId.toString(),
						new NameInfo(
							customer?.Name?.namePrefix.toString(),
							customer?.Name?.firstName.toString(),
							customer?.Name?.middleName.toString(),
							customer?.Name?.lastName.toString(),
							customer?.Name?.nameSuffix.toString(),
							customer?.Name?.additionalTitle.toString()
							),
						businessNameElem,
						new NGPNameInfo(
							customer?.Name?.namePrefix.toString(),
							customer?.Name?.firstName.toString(),
							customer?.Name?.middleName.toString(),
							customer?.Name?.lastName.toString(),
							customer?.Name?.nameSuffix.toString(),
							customer?.Name?.additionalTitle.toString(),
							businessNameElem
							),
						new AddressTwoLineSimpleInfo(
							customer?.ShippingAddress?.Attention.toString(),
							customer?.ShippingAddress?.AddressLine1.toString(),
							customer?.ShippingAddress?.AddressLine2.toString(),
							customer?.ShippingAddress?.City.toString(),
							customer?.ShippingAddress?.State.toString(),
							new AddressZipInfo(
								customer?.ShippingAddress?.Zip?.zipCode.toString(),
								customer?.ShippingAddress?.Zip?.zipCodeExtension.toString(),
								customer?.ShippingAddress?.Zip?.zipGeoCode.toString()
							),
							customer?.ShippingAddress?.Country.toString()
						),
						new OrderNotificationInfo.Customer.BillingAccountData(
							customer?.BillingAccountData?.billingMarket.toString(),
							customer?.BillingAccountData?.billingSubMarket.toString(),
							customer?.BillingAccountData?.billingAccountNumber.toString()
						),
						customer.Email.collect{
							new EmailInfo(
								new SubscriberEmailInfo(
									it.emailAddress.toString(),
									it.emailType.toString(),
									it.primaryAddressIndicator.toBoolean(),
									it.language.toString()
									)
								)
							},
						new PhoneInfo(
							customer?.Phone?.homePhone.toString(),
							customer?.Phone?.workPhone.toString(),
							customer?.Phone?.workPhoneExtension.toString(),
							customer?.Phone?.canBeReachedPhone.toString()
							)
																	 
					), //End of Customer Element in SKU Order
					orderNotifReq.OrderNotification.OrderAttributes?.collect{
						new AttributeInfo (
							it.attributeName.toString(),
							it.attributeValue.toString()
							)
						},
					orderNotifReq.OrderNotification.OrderLine?.collect{
						new OrderNotificationInfo.OrderLine(
							it.lineNumber.toInteger(),
							it.actionCode.toString(),
							it.vendorItemId.toString(),
							it.cingularItemId.toString(),
							it.salesRep.toString(),
							it.quantity.toLong(),
							it.extendedPrice.toBigDecimal(),
							it.subscriberNumber.toString()
							)
						}
					)
			)

		return new TPPSKUOrder(parsedOrderNotification);
	}

		/**
	 * Provide ParentalControlsSettingInfo model based on TPP_ProvisioningRequest XML node child account (tppProvReq.Order.ParentalControlsSettingInfo).
	 *
	 * @param parentalControlsSetting (tppProvReq.Order.ParentalControlsSettingInfo) NodeChildren to be parsed
	 * @return ParentalControlsSettingInfo
	 */
	/*def ParentalControlsSettingInfo getParsedParentalControls(NodeChildren parentalControlsSetting){
		def indicator = parentalControlsSetting.indicator
		def reason = parentalControlsSetting.reasonCode
		
		def parsedIndicator = null
		def parsedReason = null
		
		if(indicator.size() > 0){
			parsedIndicator = indicator.toBoolean()
			
			if(reason.size() > 0){
				parsedReason = indicator.toString()				
			}
		}
		
		return new ParentalControlsSettingInfo(parsedIndicator, parsedReason)
	}*/
	
	/**
	 * Provide AccountTypeInfo model based on TPP_ProvisioningRequest XML node child account (tppProvReq.Order.AccountTypeInfo).
	 *
	 * @param accountTypeInfo (tppProvReq.Order.AccountTypeInfo) NodeChildren to be parsed
	 * @return AccountTypeInfo
	 */
	/*def AccountTypeInfo getParsedAccountTypeInfo(NodeChildren accountTypeInfo, InquireAccountProfileResponseInfo inquireAccountProfileResponse){
		def accType = accountTypeInfo.accountType_CSIIAPDip
		def accSubType = accountTypeInfo.accountSubType_CSIIAPDip
		
		def parsedAccType = null
		def parsedAccSubType = null
		
		if(accType.size() > 0){
			parsedAccType = accType.toString()
			if(accSubType.size() > 0){
				parsedAccSubType = accSubType.toString()
			}
		}
		
		return new AccountTypeInfo(parsedAccType, parsedAccSubType)
	}*/
	/**
	 * This method will provide the ConversationId from the CSI API Response
	 * @param provResXML is the response from the CSI
	 * @return parsedConId - ConversationId
	 */
	def String getHeaderInfo(String csiResXML){
		def strCSIResponseXML = new XmlSlurper().parseText(csiResXML)
		def messageHeader = strCSIResponseXML.Header.MessageHeader.TrackingMessageHeader
		def parsedConId = null
		parsedConId=messageHeader.conversationId.toString();
		return parsedConId;
	}
	
	static main(args) {
		DataAugXMLParser dx = new DataAugXMLParser()
		def temp = dx.getTPPProvReq(new File("C:\\JavaDevSpace\\testMrc1.xml").text)
		
		def account = dx.getProvReqAccount(new File("C:\\JavaDevSpace\\testMrc1.xml").text)
		def fan = dx.getProvReqFAN(new File("C:\\JavaDevSpace\\testMrc1.xml").text)
		
		println("RoutingCarrier ---> " + temp.header.routingCarrier)
		
		println("MSISDN ---> " + account.msisdn)
		println("SUBID ---> " + account.subscriberNumber)
		println("BAN ---> " + account.ban)
		
		//Check if FAN model is null.  Don't traverse model if null.
		if(fan != null){
			println("FAN ---> " + fan.currentFAN)
		}
		else{
			println("FAN ---> value is null (no FAN populated)")
		}	
	}
}
