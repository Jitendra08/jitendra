package com.att.tpp.enumuration;

public enum CSIDipType {
	IAP, IBP, IFP, IPCP, ICIF
}
