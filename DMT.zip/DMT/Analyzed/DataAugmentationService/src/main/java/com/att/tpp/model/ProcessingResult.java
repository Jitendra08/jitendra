package com.att.tpp.model;

import java.io.Serializable;

/**
 *
 * @author sg625m
 */

public class ProcessingResult implements Serializable  {
	
	private static final long serialVersionUID = 1L;
	
	boolean isValidRequest=false;
	boolean isValidProductExist=false;
	boolean isPersistedInDB=false;
	boolean isDeletedFromDB=false;
	boolean isSystemReroute=false;
	private String transactionId;
	private String msisdn;
	private String csiEventName;
	private String tppProvReq;

	
	public String getMsisdn() {
		return msisdn;
	}


	public void setMsisdn(String msisdn) {
		this.msisdn = msisdn;
	}


	public boolean isSystemReroute() {
		return isSystemReroute;
	}


	public void setSystemReroute(boolean isSystemReroute) {
		this.isSystemReroute = isSystemReroute;
	}


	public boolean isDeletedFromDB() {
		return isDeletedFromDB;
	}


	public void setDeletedFromDB(boolean isDeletedFromDB) {
		this.isDeletedFromDB = isDeletedFromDB;
	}


	boolean isCSIDipExist=false;

	


	public String getTransactionId() {
		return transactionId;
	}


	public void setTransactionId(String transactionId) {
		this.transactionId = transactionId;
	}


	public boolean isValidRequest() {
		return isValidRequest;
	}


	public void setValidRequest(boolean isValidRequest) {
		this.isValidRequest = isValidRequest;
	}


	public boolean isValidProductExist() {
		return isValidProductExist;
	}


	public void setValidProductExist(boolean isValidProductExist) {
		this.isValidProductExist = isValidProductExist;
	}


	public boolean isPersistedInDB() {
		return isPersistedInDB;
	}


	public void setPersistedInDB(boolean isPersistedInDB) {
		this.isPersistedInDB = isPersistedInDB;
	}


	public boolean isCSIDipExist() {
		return isCSIDipExist;
	}


	public void setCSIDipExist(boolean isCSIDipExist) {
		this.isCSIDipExist = isCSIDipExist;
	}

	
	public String getCsiEventName() {
		return csiEventName;
	}


	public void setCsiEventName(String csiEventName) {
		this.csiEventName = csiEventName;
	}


	public ProcessingResult() {
	}


	public String getTppProvReq() {
		return tppProvReq;
	}


	public void setTppProvReq(String tppProvReq) {
		this.tppProvReq = tppProvReq;
	}
	

}
