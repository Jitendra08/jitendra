package com.att.tpp.controller;

import java.io.IOException;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.att.tpp.model.CSIDipKeys;
import com.att.tpp.model.ProcessingResult;
import com.att.tpp.service.DataAugmentationService;
import com.att.tpp.utils.DataAugXMLParser;
import com.att.tpp.xml.model.TPPProvisioningRequest;


@Service("dataAugmentationController")
public class DataAugmentationController {
	
	
	@Autowired
	private DataAugmentationService dataAugmentationService;	
	

	private static final Logger dataAugmentationControllerLog = Logger.getLogger(DataAugmentationController.class);
	private final static String TPP_ProvisioningRequestXSD = "TPP_ProvisioningRequest.xsd";
	
	
	public ProcessingResult processRequest(String requestXML, String csiDips) throws IOException, Exception{
		//Validate XML
		boolean isValidRequest = false;
		boolean isCsiDipArchiveUpdated = false;		
		String tppProvReqXML=null;
		
		isValidRequest = dataAugmentationService.validateXML(requestXML,TPP_ProvisioningRequestXSD);		 
		ProcessingResult processingResult = new ProcessingResult();
		
		dataAugmentationControllerLog.info("XML Validation After Receiving from Gateway Queue: " + isValidRequest);
				
		if (isValidRequest) {
			// Parse XML get MSIDN and FAN
			DataAugXMLParser dataAugXML = new DataAugXMLParser();
			CSIDipKeys csiDipkeys = dataAugXML.getCSIKeyInfo(requestXML);
			dataAugmentationControllerLog.debug("CSI Dip Keys");
			dataAugmentationControllerLog.debug("CSI Dip Keys MSISDN: " + csiDipkeys.getAccountData().getMsisdn());
			dataAugmentationControllerLog.debug("CSI Dip Keys SubId: " + csiDipkeys.getAccountData().getSubscriberNumber());
			dataAugmentationControllerLog.debug("CSI Dip Keys TransactionId: " + csiDipkeys.getHeader().getTransactionId());
			//dataAugmentationControllerLog.info("CSI Dip Keys FAN: " + csiDipkeys.getFanData().getCurrentFAN());
			

			// Identify csiDips
            // call wsTemplate to ws call			
			//Generate TPP_ProvRequest
			//Validate TPP_ProvRequest
			//Pass to Listener
			
			TPPProvisioningRequest tppProvisioningRequest = dataAugmentationService.invokeCSIWebService(csiDips, requestXML, csiDipkeys);			
		
			//Get Inbound TPPProvRequest model
			// Generate XML
			dataAugmentationControllerLog.info("Creating XML!");
			tppProvReqXML = dataAugmentationService.createTPPProvReqXML(tppProvisioningRequest);
			dataAugmentationControllerLog.info("Done Creating XML!");
			dataAugmentationControllerLog.info("Setting XML in Model!");
			processingResult.setTppProvReq(tppProvReqXML);
			dataAugmentationControllerLog.info("Done Setting XML in Model!");
			
			//Based on MessageID update CSIDipArchive with TPP Prov Request	
			dataAugmentationControllerLog.info("Updating Load_XML in CSI Dip Archive for messagId: " + csiDipkeys.getHeader().getTransactionId());
			isCsiDipArchiveUpdated = dataAugmentationService.updateDipResults(csiDipkeys.getHeader().getTransactionId(), tppProvReqXML);
			dataAugmentationControllerLog.info("Updated Load_XML in CSI Dip Archive for messagId: " + csiDipkeys.getHeader().getTransactionId() + "Successfully updated: " + isCsiDipArchiveUpdated);
			
			
			
			//Set Processing Result			
			processingResult.setCsiEventName(csiDips);			
			processingResult.setTransactionId(csiDipkeys.getHeader().getTransactionId());
			processingResult.setMsisdn(csiDipkeys.getAccountData().getMsisdn());
			
			
			// Validate the tppProvReqXML
			dataAugmentationControllerLog.info("Validating XML!");
			isValidRequest = dataAugmentationService.validateXML(tppProvReqXML,TPP_ProvisioningRequestXSD);
			dataAugmentationControllerLog.info("Done Validating XML!");
			
			dataAugmentationControllerLog.debug("XML Validation After Data Augmentation: " + isValidRequest);
			dataAugmentationControllerLog.info("isValidRequest:" +isValidRequest+ ", XML After Augmentation: " + tppProvReqXML);
			processingResult.setValidRequest(isValidRequest);
			
			
		}
		
		return processingResult;
	}
	

	public DataAugmentationController() {
		// TODO Auto-generated constructor stub
	}

}
