package com.att.tpp.utils

import com.att.tpp.xml.model.CustRegContactInfoBASE
import com.att.tpp.xml.model.DealerInfo
import com.att.tpp.xml.model.NameInfoCSIDP
import com.att.tpp.xml.model.SalesReps
import javax.xml.soap.SOAPMessage;

class IBPResponseParser {
	
	def Collection<CustRegContactInfoBASE> getCustRegContactInfoBASE(SOAPMessage respMesg){
		
		def stream = new ByteArrayOutputStream()
		respMesg.writeTo(stream)
		
		def envelope = new XmlSlurper().parse(new ByteArrayInputStream(stream.toByteArray()))
		def contactInfo = envelope.Body.inquireFANProfileContactsResponse.InquireFANProfileContactsResponse.contact
		def blank = ""
		
		def parsedCustRegContactInfo = contactInfo.collect{
			//println("LastName: " + it.lastName.toString())
			new CustRegContactInfoBASE(
				(it.namePrefix.size()>0) ? it.namePrefix.toString() : blank, 
				it.firstName.toString(), 
				(it.middleName.size()>0) ? it.middleName.toString()  : blank, 
				it.lastName.toString(), 
				(it.jobTitle.size()>0) ? it.jobTitle.toString()  : blank, 
				(it.workPhoneNumber.size()>0) ? it.workPhoneNumber.toString()  : blank, 
				(it.email.size()>0) ? it.email.toString() : blank, 
				it.type.toString()
				)			
		}
		
		return parsedCustRegContactInfo
		
	}
	
	
	def Collection<SalesReps> getSalesReps(SOAPMessage respMesg){
		
		def stream = new ByteArrayOutputStream()
		respMesg.writeTo(stream)
		
		def envelope = new XmlSlurper().parse(new ByteArrayInputStream(stream.toByteArray()))
		def salesReps = envelope.Body.inquireFANProfileResponse.InquireFANProfileResponse.salesReps
		def blank = ""
		
		/*
		 * Rome/Base IFP salesRep model
		salesRep
			ContactInfo
			     namePrefix
			     firstName
			     middleName
			     lastName
			     jobTitle
				 workPhoneNumber
			 dealerCode
			 position
			 territory
			 email

		 * */
		def parsedSalesReps = salesReps.collect{
			new SalesReps( new NameInfoCSIDP(it.namePrefix?.toString(), it.firstName?.toString(),
											 it.middleName?.toString(), it.lastName?.toString(),null,null ),
							new DealerInfo(it.dealerCode?.toString()),
							it.position?.toString(),
							it.territory?.toString(),
							it.jobTitle?.toString(),
							it.workPhoneNumber?.toString(),
							it.email?.toString()
						  )
			}
		
		return parsedSalesReps
		
	}

}
