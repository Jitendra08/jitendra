
package com.att.tpp.jms.listener;

import java.io.IOException;

import javax.jms.JMSException;
import javax.jms.Message;
import javax.jms.MessageListener;
import javax.jms.TextMessage;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.att.tpp.controller.DataAugmentationController;
import com.att.tpp.jms.sender.WorkFlowRequestSender;
import com.att.tpp.model.ProcessingResult;

/**
 * Class handles  SWC incoming messages
 */
@Service
public class DataAugmentationRequestListener implements MessageListener
{
	private static final Logger dataAugRequestListenerLog = Logger.getLogger(DataAugmentationRequestListener.class);
	
	@Autowired
	private WorkFlowRequestSender workFlowRequestSender;
	
	@Autowired
	private DataAugmentationController dataAugmentationController;


	/**
	 * Method implements JMS onMessage and acts as the entry
	 * point for messages consumed by Springs DefaultMessageListenerContainer.
	 * When DefaultMessageListenerContainer picks a message from the queue it
	 * invokes this method with the message payload.
	 */
	public void onMessage(Message dataAugReqMsg)
	{
		dataAugRequestListenerLog.debug("Received message from DataAugmentation Request Queue [" + dataAugReqMsg +"]");

		/* The message must be of type TextMessage */
		if (dataAugReqMsg instanceof TextMessage)			
		{
			ProcessingResult processingResult =  new ProcessingResult();
			try
			{
				String dataAugRequestXML = ((TextMessage) dataAugReqMsg).getText();
				dataAugRequestListenerLog.info("DataAugmentation request XML received: " + dataAugRequestXML);
				
				//Send request to Augment the XML payload of this message
				String csiDips = dataAugReqMsg.getStringProperty("csiDips");  //Get the CSI DIPS requested for this message				
				//String csiDips = dataAugReqMsg.getStringProperty("eventName");  //Get the CSI DIPS requested for this message		
				
				dataAugRequestListenerLog.info("csiDips : " + csiDips);
				
				processingResult = dataAugmentationController.processRequest(dataAugRequestXML, csiDips);
				dataAugRequestListenerLog.info("TransacationId: " + processingResult.getTransactionId());
								
				/* call message sender to put message onto second queue */
				//workFlowRequestSender.sendMessage(dataAugReqMsg);	//This sends message with all JMS properties
				
				
				if (processingResult.isValidRequest() && processingResult.getTppProvReq()!=null) {
					workFlowRequestSender.sendMessage(processingResult);
					dataAugRequestListenerLog.info("Sent request to Workflow queue, ProvSystemTransId "+processingResult.getTransactionId());

				}	

			}
			catch (JMSException jmsExc)
			{
				String errMsg = "An error occurred extracting GateWay message";
				dataAugRequestListenerLog.error(errMsg, jmsExc);
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			} catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		else
		{
			String errMsg = "GateWay Message is not of expected type TextMessage";
			dataAugRequestListenerLog.error(errMsg);
			throw new RuntimeException(errMsg);
		}
	}

	/**
	 * Sets the message sender.
	 *
	 * @param workFlowRequestSender the new message sender
	 */
	public void setWorkFlowRequestSender(WorkFlowRequestSender workFlowRequestSender)
	{
		this.workFlowRequestSender = workFlowRequestSender;
	}
}