package com.att.tpp.ws;

import java.beans.ConstructorProperties;
import java.math.BigInteger;

import javax.xml.datatype.XMLGregorianCalendar;
import javax.xml.ws.Holder;

import org.apache.log4j.Logger;
import com.att.tpp.utils.XMLDateUtil;
import com.cingular.csi.csi.namespaces.types._public.cingulardatamodel.MessageHeaderSecurity;
import com.cingular.csi.csi.namespaces.types._public.cingulardatamodel.MessageHeaderSequence;
import com.cingular.csi.csi.namespaces.types._public.cingulardatamodel.MessageHeaderTracking;
import com.cingular.csi.csi.namespaces.types._public.messageheader.MessageHeaderInfo;

public class CSIMessageHeaderService {
	
	private static Logger csiMessageHeaderServiceLog = Logger.getLogger(CSIMessageHeaderService.class);

	private String user;
	private String pass;
	private String version;
	private String dataaugttl;
	
	@ConstructorProperties({"user", "pass", "version", "dataaugttl"})
	public CSIMessageHeaderService(String user, String pass, String version, String dataaugttl){
		this.user = user;
		this.pass = pass;
		this.version = version;
		this.dataaugttl = dataaugttl;
	}

	public Holder<MessageHeaderInfo> generateCSIMessageHeader(String messageId)	throws Exception {
		XMLGregorianCalendar date = null;
		date = XMLDateUtil.getNow();
		csiMessageHeaderServiceLog.info("Inside CSIMessageHeaderService, messageId:"+messageId);

		MessageHeaderInfo newHeader = new MessageHeaderInfo();
		/* Modified the TTL time to 60 secs from 30 sec as per WR #3093828 - Fix for Boeing Sev2_CM20161013_118952647_Change in TTL 
		 * This is the temporary fix. Later(after permanent fix) we will revert back to 30 sec.
		 * */	
    	//BigInteger ttl = new BigInteger("60000");
		csiMessageHeaderServiceLog.info("dataaugttl>>>"+dataaugttl);
		BigInteger ttl = new BigInteger(dataaugttl);
		MessageHeaderSecurity userPass = new MessageHeaderSecurity();
		userPass.setUserName(user);
		userPass.setUserPassword(pass);

		MessageHeaderSequence sequence = new MessageHeaderSequence();
		sequence.setSequenceNumber("1");
		sequence.setTotalInSequence("1");

		MessageHeaderTracking tracking = new MessageHeaderTracking();
		tracking.setMessageId(messageId);
		tracking.setVersion(version);
		tracking.setOriginalVersion(version);
		tracking.setOriginatorId("3PP");
		tracking.setTimeToLive(ttl);
		tracking.setDateTimeStamp(date);

		newHeader.setSecurityMessageHeader(userPass);
		newHeader.setSequenceMessageHeader(sequence);
		newHeader.setTrackingMessageHeader(tracking);

		Holder<MessageHeaderInfo> messageHeader = new Holder<MessageHeaderInfo>(newHeader);

		return messageHeader;
	}

}