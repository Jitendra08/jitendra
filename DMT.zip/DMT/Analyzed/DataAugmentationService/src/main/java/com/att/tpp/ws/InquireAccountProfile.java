package com.att.tpp.ws;

import com.att.tpp.model.CSIDipKeys;
import com.cingular.csi.csi.namespaces.container._public.inquireaccountprofileresponse.InquireAccountProfileResponseInfo;



 



public interface InquireAccountProfile {

	InquireAccountProfileResponseInfo getInquireAccountProfileResponse(CSIDipKeys csiDipKeys) throws Exception;

	
}
