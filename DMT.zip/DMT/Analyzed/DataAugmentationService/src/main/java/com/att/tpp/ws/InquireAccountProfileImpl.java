package com.att.tpp.ws;

import javax.xml.ws.Holder;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.att.tpp.enumuration.CSIDipType;
import com.att.tpp.model.CSIDipKeys;
import com.att.tpp.service.DataAugmentationService;
import com.cingular.csi.csi.namespaces.container._public.inquireaccountprofilerequest.InquireAccountProfileRequestInfo;
import com.cingular.csi.csi.namespaces.container._public.inquireaccountprofilerequest.InquireAccountProfileRequestInfo.AccountOrSubscriptionIDSelector;
import com.cingular.csi.csi.namespaces.container._public.inquireaccountprofileresponse.InquireAccountProfileResponseInfo;
import com.cingular.csi.csi.namespaces.types._public.cingulardatamodel.AccountSelectorInfo;
import com.cingular.csi.csi.namespaces.types._public.messageheader.MessageHeaderInfo;
import com.cingular.csi.csi.namespaces.v118.wsdl.cingularwirelesscsi.CSIApplicationException;
import com.cingular.csi.csi.namespaces.v118.wsdl.cingularwirelesscsi.InquireAccountProfilePortType;

@Transactional
@Service("inquireAccountProfile")
public class InquireAccountProfileImpl implements InquireAccountProfile {

	private static Logger inquireAccountProfileLog = Logger.getLogger(InquireAccountProfileImpl.class);
	
	private final static String Success = "Success";	

	@Autowired
	private CSIMessageHeaderService csiMessageHeaderService;
	
	
	@Autowired
	private InquireAccountProfilePortType iapDip;
	
	
	@Autowired
	private DataAugmentationService dataAugmentationService;

	

	@Override
	public InquireAccountProfileResponseInfo getInquireAccountProfileResponse(CSIDipKeys csiDipKeys) throws Exception{
		
		String msisdn = csiDipKeys.getAccountData().getMsisdn();
		String messageId = csiDipKeys.getHeader().getTransactionId();
		
		msisdn = dataAugmentationService.getCTNFromMsidn(msisdn);
		
 		inquireAccountProfileLog.info("Inside the IAP DIP Webservice method with CTN:"+msisdn +" TransactionId:"+messageId);
		
		// Generating Message Header
		Holder<MessageHeaderInfo> messageHeader = null;
		try {
			messageHeader = csiMessageHeaderService.generateCSIMessageHeader("IAP_"+messageId);
		} catch (Exception e) {
			inquireAccountProfileLog.info("Exception occured while generating CSIMessageHeader, TransactionId: "+messageId);
			e.printStackTrace();
			throw e;
		}
		
		//Create webservice request
		AccountSelectorInfo accountSelectorInfo = new AccountSelectorInfo();
		accountSelectorInfo.setSubscriberNumber(msisdn);

		AccountOrSubscriptionIDSelector aosIDSelector = new AccountOrSubscriptionIDSelector();		
		aosIDSelector.setAccountSelector(accountSelectorInfo);
		
		InquireAccountProfileRequestInfo iapRequestData = new InquireAccountProfileRequestInfo();
		iapRequestData.setAccountOrSubscriptionIDSelector(aosIDSelector);
		iapRequestData.setMask("SN");
		
		
		
		//Call webservice and return response
		InquireAccountProfileResponseInfo iapResp = null;
		boolean persistDipResults=false;
		try {
			inquireAccountProfileLog.info("Before posting to CSI for IAP DIP with CTN:"+msisdn +" TransactionId:"+messageId);
			iapResp = iapDip.inquireAccountProfile(messageHeader, iapRequestData);
			inquireAccountProfileLog.info("After receiving response from IAP DIP with CTN:"+msisdn +" TransactionId:"+messageId);
			// Insert result in to the CSIDIP_ARCHIVE table
			persistDipResults = dataAugmentationService.persistDipResults(csiDipKeys, CSIDipType.IAP.toString(), Success,Success);
			inquireAccountProfileLog.info("IAP Persist Dip Results in CSIDIP_Archive table: "+persistDipResults);
		} catch (CSIApplicationException e) {
			inquireAccountProfileLog.info("CSIApplicationException for IAP DIP with CTN:"+msisdn +" TransactionId:"+messageId);
			// Insert result in to the CSIDIP_ARCHIVE table
			inquireAccountProfileLog.info("ErrorCode: "+ e.getFaultInfo().getResponse().getCode());
			//inquireAccountProfileLog.info("ErrorDesc: "+ e.getFaultInfo().getResponse().getDescription());	
			persistDipResults = dataAugmentationService.persistDipResults(csiDipKeys, CSIDipType.IAP.toString(), e.getFaultInfo().getResponse().getCode(),e.getFaultInfo().getResponse().getDescription());
			inquireAccountProfileLog.info("Inside CSIApplicationException block :: IAP Persist Dip Results in CSIDIP_Archive table: "+persistDipResults);
			//throw e;
		} catch (Exception e) {
			inquireAccountProfileLog.info("Exception in IAP DIP with CTN:"+msisdn +" TransactionId:"+messageId);
			inquireAccountProfileLog.info("Exception in IAP DIP :: getMessage: "+ e.getMessage());
			persistDipResults = dataAugmentationService.persistDipResults(csiDipKeys, CSIDipType.IAP.toString(), "900", e.getMessage());
			inquireAccountProfileLog.info("Inside Exception block :: IAP Persist Dip Results in CSIDIP_Archive table: "+persistDipResults);
			//throw e;
		}
		
		inquireAccountProfileLog.info("IAP Webservice call is successfully completed with MSISDN:"+msisdn +" TransactionId:"+messageId);
		
		
		return iapResp;
	}



	


}