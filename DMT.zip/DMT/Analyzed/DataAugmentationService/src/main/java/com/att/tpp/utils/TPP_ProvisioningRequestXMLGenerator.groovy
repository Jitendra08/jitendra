
package com.att.tpp.utils

import com.att.tpp.xml.model.*;

import groovy.util.Node;
import groovy.xml.MarkupBuilder
import groovy.xml.XmlUtil
import groovy.util.logging.Log4j

@Log4j
class TPP_ProvisioningRequestXMLGenerator {

	public TPP_ProvisioningRequestXMLGenerator() {
	}



	def String createProvReqXML(TPPProvisioningRequest provReq){
		def provReqXML = new StringWriter()
		def xml = new MarkupBuilder(provReqXML)
		
		def equipment= provReq.getOrder()?.getEquipment()
        def skuOrder = provReq.getOrder()?.tppskuOrder
		def delDetails = provReq.getOrder()?.delta
		def forms = provReq.getOrder()?.forms
		def vendorDetails = provReq.getOrder()?.vendorDetails
		
		xml.setDoubleQuotes(true)
		xml.mkp.xmlDeclaration(version: "1.0", encoding: "UTF-8")

		xml.TPP_ProvisioningRequest("xmlns:xsi":"http://www.w3.org/2001/XMLSchema-instance"){
			Header(TransactionId:provReq.header.transactionId,
			ProvisioningCarrier:provReq.header.provisioningCarrier,
			RoutingCarrier:provReq.header.routingCarrier,
			TimeStamp:provReq.header.timeStamp,
			Atlas_Event_Type:provReq.header.atlasEventType,
			//buildHeader(xml, provReq),

			)
			Order(){
				buildAccount(xml, provReq)
				Subscriber(){
					buildContact(xml, provReq)
					buildAddress(xml, provReq)
					buildEmail(xml, provReq)
					buildPrevContact(xml, provReq)
					buildPrevAddress(xml, provReq)
					buildPrevEmail(xml, provReq)
				}
				if(provReq?.order?.subscriberStatusDetail!=null)
				{
				buildSubscriberStatusDetail(xml, provReq)
				}
				if(equipment!=null){
					Equipment(){
						buildDevice(xml, provReq)
						buildSIM(xml, provReq)
					}
				}
				buildServiceInfo(xml, provReq)
				if(provReq?.order?.marketingOptions!=null)
				{
					MarketingOptions()
					{
					buildMarketOptions(xml,provReq)
					}
				}
				BillingAccount()
				{
					buildBillingAccount(xml, provReq)
				}
				if(provReq?.order?.financialNotification!=null)
				{
					buildFinancialNotification(xml, provReq)
					
				}
				if(skuOrder!=null)
				{
					TPP_SKUOrder() 
					{
					buildSKUOrder(xml, provReq)
					}
				}
				if(provReq?.order?.femtocellTNUpdate!=null)
				{
					buildFemtocellTNUpdate(xml, provReq)
					
				}
				/*if(provReq?.order?.immutableKeys!=null)
				{
					buildImmutableKeys(xml, provReq)
					
				}*/
				if(provReq?.order?.parentalControlsSettingInfo!=null)
				 {
					 buildParentalControlsSettingInfo(xml, provReq)
					 
				 }
				 if(provReq?.order?.accountTypeInfo!=null)
				 {
					 buildAccountTypeInfo(xml, provReq)
					 
				 }
				 if(provReq?.order?.segmentType!=null)
				 {
					 buildSegmentType(xml, provReq)
					 
				 }
				 if(provReq?.order?.marketInfo!=null)
				 {
					 buildMarketInfo(xml, provReq)
					 
				 }
				 if(provReq?.order?.salesReps!=null)
				 {
					 buildSalesReps(xml, provReq)
					 
				 }
				 if(provReq?.order?.dealerCommission!=null)
					 {
						 buildDealerCommission(xml, provReq)
						 
				 }
				 if(provReq?.order?.custRegContactInfoBASE!=null)
				 {
					 buildCustRegContactInfoBASE(xml, provReq)
					 
				 }
				 //Added for LocationAccountID changes
				 if(provReq?.order?.locationId!=null)
				 {
					 buildLocationAccountID(xml, provReq)
				 }
				 //Added for FirstNet Indicator Changes
				 if(provReq?.order?.firstNetIndicator!=null)
				 {
					 buildFirstNetIndicator(xml, provReq)
				 }
				 //Added for Delta changes
				if(delDetails != null)
				{
					buildDelta(xml, provReq)
				}
				//Added for FormsData changes
				if(forms != null)
				{
					buildForms(xml, provReq)
				}
				if(vendorDetails != null)
				{
					buildVendorDetails(xml, provReq)
				}
				EventType()
				{
					buildEventType(xml, provReq)
				}
				/* TODO Remove after DLIFE is golive. 
				 * if(provReq?.order?.taxExemption!=null)
				{
					buildTaxExcemption(xml, provReq)
					
				}*/
			}
			buildProducts(xml, provReq)
		}
		log.debug(provReqXML.toString())
		Node root = new XmlParser().parseText(provReqXML.toString())
		cleanNode( root )
		provReqXML = XmlUtil.serialize( root )
		return provReqXML.toString()
	}

	def buildProducts(MarkupBuilder mBuilder, TPPProvisioningRequest provReq){
		mBuilder.Products(){
			provReq.products.product*.each { prod ->
				//log.info("ProductId: " + prod.id)
				Product(Category:"3PP", Id:prod.id, IPID:prod.ipid, Action:prod.action, EffectiveDate:prod.effectiveDate, ExpirationDate:prod.expirationDate){
					prod.attribute*.each{ attrib ->
						Attribute(Name:attrib.name, Value:attrib.value)
					}
				}
			}
		}
	}
//Added for Delta changes
	def buildDelta(MarkupBuilder mBuilder, TPPProvisioningRequest provReq){
		mBuilder.Delta(){
					provReq.order.delta.attribute*.each{ attrib ->
						Attribute(Name:attrib.name, Value:attrib.value)
					}
				}
		}
	
	//Added for FormData changes
	def buildForms(MarkupBuilder mBuilder, TPPProvisioningRequest provReq){
		try{
				mBuilder.Forms(){
					provReq.order.forms.formData*.each{ formdata ->
					mBuilder.FormData(){
	//					Identifier( replaceNull(formdata.identifier))
	//					Name(replaceNull(devdetail.name))
	//					FormName( replaceNull(formdata.formName))
	//					TemplateIdentifier(replaceNull(devdetail.templateIdentifier))
	//					Token( replaceNull(formdata.token))
	//					FormType(replaceNull(formdata.formType))
	//					status(replaceNull(formdata.status))
						//def paramDet = formdata.parameterDetails
						
						if(!formdata.parameterDetails.empty)
						{
							formdata.parameterDetails*.each { paramdetails ->
								mBuilder.Fields(){
									if(paramdetails.name.length() > 0){
										name(replaceNull(paramdetails.name))
									}
									else{
										name("N/A")
									}
									
									if(paramdetails.group.length() > 0){
										group(replaceNull(paramdetails.group))
									}
									else{
										group("N/A")
									}
									
									if(paramdetails.value.iterator().hasNext()){
										value(replaceNull(paramdetails.value.iterator().next().toString()))
									}
									else{
										value("N/A")
									}
									
								}
							}
						}
					}
				}
			}
		}
		catch(NoSuchElementException nsee){
			log.error("Value in Name/Group/Value set is null", nsee)					
		}
//		finally{
//			mBuilder.Forms(){
//				mBuilder.FormData(){
//					mBuilder.Fields(){
//							name("N/A")
//							group("N/A")
//							value("N/A")
//					}
//				}
//			}
//		}
	}
	
	def buildSKUOrder(MarkupBuilder mBuilder, TPPProvisioningRequest provReq){
		
		def tppSKUOrder= provReq.getOrder()?.tppskuOrder?.orderNotification
		def customer = provReq.getOrder()?.tppskuOrder?.orderNotification?.order?.customer
		def billingSKUOrderMAP=  [:]
		
		if(tppSKUOrder!=null)
		{ 
			
			
		mBuilder.OrderNotification(EventName:tppSKUOrder.eventName)
		{			
			
			if(tppSKUOrder.order.orderId !=null)
			{			
			orderId()
			{
				location(replaceNull(tppSKUOrder.order.orderId.location))
				activity(replaceNull(tppSKUOrder.order.orderId.activity))
				orderId(replaceNull(tppSKUOrder.order.orderId.orderId))
			}
			}
			
			orderWarehouse(replaceNull(tppSKUOrder?.order?.orderWarehouse))
			
			orderDate(replaceNull(tppSKUOrder?.order?.orderDate))
			
			paymentMethod(replaceNull(tppSKUOrder?.order?.paymentMethod))
			
			
			
			if(customer!=null)
			{
				
				
				Customer()
				          {
							  customerId(replaceNull(customer?.customerId))
							  
							  if(customer?.businessName!=null || customer?.businessName.length !=0)
							  {							  
							    businessName(replaceNull(customer?.businessName))
							  }
							  if(customer?.ngpName!=null)
							  {
								  NGPName({
								  namePrefix(replaceNull(customer.ngpName.namePrefix))
								  firstName(replaceNull(customer.ngpName.firstName))
								  middleName(replaceNull(customer.ngpName.middleName))
								  lastName(replaceNull(customer.ngpName.lastName))
								  nameSuffix(replaceNull(customer.ngpName.nameSuffix))
								  additionalTitle(replaceNull(customer.ngpName.additionalTitle))
								  businessName(replaceNull(customer.ngpName.businessName))
									  })
							  }
							  
							  
							  if(customer?.shippingAddress!=null)
							  {							  						  
							      ShippingAddress({ Attention(replaceNull(customer.shippingAddress?.attention))
									               AddressLine1(replaceNull(customer.shippingAddress?.addressLine1))
												   AddressLine2(replaceNull(customer.shippingAddress?.addressLine2))
												   City(replaceNull(customer.shippingAddress?.city))
												   State(replaceNull(customer.shippingAddress?.state))
												   Zip({zipCode(replaceNull(customer.shippingAddress?.zip?.zipCode))
													   zipCodeExtension(replaceNull(customer.shippingAddress?.zip?.zipCodeExtension))
													   zipGeoCode(replaceNull(customer.shippingAddress?.zip?.zipGeoCode))})
												   Country(replaceNull(customer.shippingAddress?.country))									  
							                       })
							  }
							  
							  if(customer?.billingAccountData!=null)
							  {
								  
								  BillingAccountData({billingMarket(replaceNull(customer.billingAccountData?.billingMarket))
									  				 billingSubMarket(replaceNull(customer.billingAccountData?.billingSubMarket))
													 billingAccountNumber(replaceNull(customer.billingAccountData?.billingAccountNumber))})							  
							  }
							  
							  
							  if(customer?.email!=null)
							  {
								  customer.email*.each{ eml ->
									  Email({emailAddress(replaceNull(eml?.current?.emailAddress))
										    emailType(replaceNull(eml?.current?.emailType))
											primaryAddressIndicator(replaceNull(eml?.current?.primaryAddressIndicator))
											language(replaceNull(eml?.current?.language))})
									  }
							  }
							  
							  if(customer?.phone!=null)
							  {
								  Phone({homePhone(replaceNull(customer.phone?.homePhone))
									    workPhone(replaceNull(customer.phone?.workPhone))
										workPhoneExtension(replaceNull(customer.phone?.workPhoneExtension))
										canBeReachedPhone(replaceNull(customer.phone?.canBeReachedPhone))
								  })
						      }
							  
						  }
			}
			
			if(tppSKUOrder.order?.orderAttributes!=null)
			{
				tppSKUOrder.order.orderAttributes*.each { ordAttr ->
			     OrderAttributes({attributeName(replaceNull(ordAttr?.attributeName)) 
					             attributeValue(replaceNull(ordAttr?.attributeValue))})
				
				                                         }
			}
			
			
			if(tppSKUOrder.order?.orderLine!=null)
			{
				
				tppSKUOrder.order.orderLine*.each { ordLin ->
					OrderLine({lineNumber(replaceNull(ordLin?.lineNumber))
						      actionCode(replaceNull(ordLin?.actionCode))
							  vendorItemId(replaceNull(ordLin?.vendorItemId))
							  cingularItemId(replaceNull(ordLin?.cingularItemId))
							  salesRep(replaceNull(ordLin?.salesRep))
							  quantity(replaceNull(ordLin?.quantity))
							  extendedPrice(replaceNumericNull(ordLin?.extendedPrice))//Modified from replaceNull to replaceNumericNull to fix WR#3035160 
							  subscriberNumber(replaceNull(ordLin?.subscriberNumber))})
				                                   }
			}
			
			
	   } 
			
			                   
		}
	}


	/**
	 * buildAccountElement provides the Account Element with model attributes
	 *
	 * @param mBuilder
	 * @param msisdn
	 *
	 */
	def buildAccount(MarkupBuilder mBuilder, TPPProvisioningRequest provReq){

		def account= provReq.getOrder()?.getAccount()

		def accountMap = [:]
		if(account!=null){
			
			if(account?.msisdn?.length()==10)			
			accountMap.put("MSISDN","1"+replaceNull(account.msisdn))			
			else
			accountMap.put("MSISDN",replaceNull(account.msisdn))
			
			if(account?.prevMSISDN?.length()==10 && (account?.prevMSISDN?.length()!=0 || account?.prevMSISDN!=null))	
			accountMap.put("PrevMSISDN", "1"+replaceNull(account.prevMSISDN))
			else
			if((account?.prevMSISDN?.length()!=0 || account?.prevMSISDN!=null))
			accountMap.put("PrevMSISDN", replaceNull(account.prevMSISDN))
			
			accountMap.put("WirelessServiceId", replaceNull(account.wirelessServiceId))
			accountMap.put("SubscriberNumber", replaceNull(account.subscriberNumber))
			accountMap.put("BAN", replaceNull(account.ban))
			accountMap.put("BANName",replaceNull(account.banName))
			accountMap.put("prevBAN", replaceNull(account.prevBAN))
			accountMap.put("accountTypeIndicator", replaceNull(account.accountTypeIndicator))
			accountMap.put("socEffectiveDate", replaceNull(account.socEffectiveDate))
			accountMap.put("SubscriberNumber", replaceNull(account.subscriberNumber))
			accountMap.put("InvoiceId", replaceNull(account.invoiceId))
			accountMap.put("EOD_GROUP_ID",replaceNull(account.eodgroupid))

			accountMap=removeEmptyElement(accountMap)

			mBuilder.Account(accountMap)
		}
		else
			(mBuilder.Account())
	}

	/**
	 * buildSender in Header provides the Head
	 */
	def buildHeader(MarkupBuilder mBuilder, TPPProvisioningRequest provReq){
		def headerMap = [:]
		def sender= provReq.header.sender
		def notification= provReq.header.notification
		def transCodes= provReq.header.transactionCode

		if(sender!=null)
		{
			headerMap.put("Login", replaceNull(provReq.header.sender.login))
			headerMap.put("Password", replaceNull(provReq.header.sender.password))
			mBuilder.Sender(headerMap)
			headerMap = [:]
		}
		if(notification!=null)
		{
			headerMap.put("URL", replaceNull(provReq.header.notification.url))
			mBuilder.Notification(headerMap)
			headerMap = [:]
		}
		if(transCodes!=null)
		{
			headerMap.put("final", replaceNull(provReq.header.transactionCode.tcFinal))
			headerMap.put("MajorCode", replaceNull(provReq.header.transactionCode.majorCode))
			headerMap.put("Description", replaceNull(provReq.header.transactionCode.description))

			mBuilder.TransactionCode(headerMap){
				provReq.header.transactionCode.transactionCodeList*.each { trancodeList ->
					TransactionCodeList(ErrorCode: trancodeList.errorCode,
					ErrorMessageText: replaceNull(trancodeList.errorMessageText),
					System: replaceNull(trancodeList.system),
					TimeStamp: replaceNull(trancodeList.timeStamp))
				}}
			headerMap = [:]
		}

	}


	/**
	 * buildSubscriber Status in Order
	 */

	def buildSubscriberStatusDetail(MarkupBuilder mBuilder, TPPProvisioningRequest provReq){

		def subStatusDetail= provReq.getOrder()?.getSubscriberStatusDetail()
		def subStatusDetailMap = [:]
		if(subStatusDetail!=null)
		{
				mBuilder.SubscriberStatusDetail(){				
				subscriberStatus(replaceNull(subStatusDetail.subscriberStatus))
				statusReasonCode(replaceNull(subStatusDetail.statusReasonCode))
				if(subStatusDetail.isSuspensionVoluntary!=null)
				isSuspensionVoluntary(replaceNull(subStatusDetail.isSuspensionVoluntary))
			}
		}
	}

	/**
	 * build  ServiceInfo in Order
	 */

	def buildServiceInfo(MarkupBuilder mBuilder, TPPProvisioningRequest provReq){

		def serviceInfoDetail= provReq.getOrder()?.getServiceInfo()
		def serviceInfoMap = [:]
		if(serviceInfoDetail!=null)
		{
			serviceInfoMap.put("Language", replaceNull(serviceInfoDetail.language))
			serviceInfoMap.put("Currency", replaceNull(serviceInfoDetail.currency))
			serviceInfoMap.put("NetworkGroup", replaceNull(serviceInfoDetail.networkGroup))
			serviceInfoMap.put("Generation", replaceNull(serviceInfoDetail.generation))
			serviceInfoMap.put("PaymentType", replaceNull(serviceInfoDetail.paymentType))
			serviceInfoMap.put("PrevNetworkGroup", replaceNull(serviceInfoDetail.prevNetworkGroup))
			serviceInfoMap.put("PrepaidPlatformType", replaceNull(serviceInfoDetail.prepaidPlatformType))
			serviceInfoMap=removeEmptyElement(serviceInfoMap)
			mBuilder.ServiceInfo(serviceInfoMap)

		}
	}
	
	
	/**
	 * build  Marketing Options in Order
	 */
	def buildMarketOptions(MarkupBuilder mBuilder, TPPProvisioningRequest provReq){
		
		        def marketOptionsDetail= provReq.order.marketingOptions
				
				marketOptionsDetail.marketingOption*.each { markOpt -> 
				              mBuilder.MarketingOption(markOpt.name, markOpt.value)}
				
			}
	
	
	/**
	 * build  BillingAccount in Order
	 */

	def buildBillingAccount(MarkupBuilder mBuilder, TPPProvisioningRequest provReq){

		def billingAccountDetail= provReq.getOrder()?.getBillingAccount()
		def billingAccountMAP=  [:]
		
		if(billingAccountDetail?.FAN!=null)
		{
			billingAccountMAP.put("currentFAN",  replaceNull(billingAccountDetail.FAN.currentFAN))
			billingAccountMAP.put("previousFAN", replaceNull(billingAccountDetail.FAN.previousFAN))
			billingAccountMAP= removeEmptyElement(billingAccountMAP)
			mBuilder.FAN(billingAccountMAP)
			billingAccountMAP = [:]
		}
		if(billingAccountDetail?.fanName!=null)
		{
			mBuilder.FANName(replaceNull(billingAccountDetail?.fanName))
		}
		if(billingAccountDetail?.contractId!=null)
		{
			mBuilder.ContractId(replaceNull(billingAccountDetail?.contractId))
		}
		if(billingAccountDetail?.contractType!=null)
		{
			mBuilder.ContractType(replaceNull(billingAccountDetail?.contractType))
		}		
		if(billingAccountDetail?.billingCycle!=null)
		{
			billingAccountMAP.put("current",  replaceNull(billingAccountDetail.billingCycle.current))
			billingAccountMAP.put("previous", replaceNull(billingAccountDetail.billingCycle.previous))
			billingAccountMAP= removeEmptyElement(billingAccountMAP)
			mBuilder.BillingCycle(billingAccountMAP)
			billingAccountMAP = [:]

		}
		if(billingAccountDetail?.name!=null)
		{
			
			def nameMAP = [:]
			def prevNameMap= [:]
			
			if(billingAccountDetail?.name?.current!=null)
			{
			nameMAP.put("BusinessName",  replaceNull(billingAccountDetail.name.current.businessName))
			nameMAP.put("FirstName", replaceNull(billingAccountDetail.name.current.firstName))
			nameMAP.put("LastName",  replaceNull(billingAccountDetail.name.current.lastName))
			nameMAP.put("Type", replaceNull(billingAccountDetail.name.current.type))
			
			if(!billingAccountDetail?.name?.current?.doingBusinessNameAs.equals("null")){
				nameMAP.put("DoingBusinessNameAs",  replaceNull(billingAccountDetail.name.current.doingBusinessNameAs))
			}
			
			}
			
			if(billingAccountDetail?.name?.previous!=null)
			{
			prevNameMap.put("BusinessName",  replaceNull(billingAccountDetail.name.previous.businessName))
			prevNameMap.put("FirstName", replaceNull(billingAccountDetail.name.previous.firstName))
			prevNameMap.put("LastName",  replaceNull(billingAccountDetail.name.previous.lastName))
			prevNameMap.put("Type", replaceNull(billingAccountDetail.name.previous.type))
			
			if(!billingAccountDetail?.name?.previous?.doingBusinessNameAs?.equals("null")){
				prevNameMap.put("DoingBusinessNameAs",  replaceNull(billingAccountDetail.name.previous.doingBusinessNameAs))
			}
			
			}
			nameMAP= removeEmptyElement(nameMAP)
			prevNameMap= removeEmptyElement(prevNameMap)
			
			              mBuilder.Name(){
			                    current(nameMAP)
			                    previous(prevNameMap)
			                }
		}
		
		if(billingAccountDetail?.address!=null)
		{
			def addressMAP = [:]
			def prevAddressMap= [:]
			
			if(billingAccountDetail?.address?.current!=null)
			{
			addressMAP.put("AddressLine1",  replaceNull(billingAccountDetail.address.current.addressLine1))
			addressMAP.put("AddressLine2", replaceNull(billingAccountDetail.address.current.addressLine2))
			addressMAP.put("City",  replaceNull(billingAccountDetail.address.current.city))
			addressMAP.put("State", replaceNull(billingAccountDetail.address.current.state))
			addressMAP.put("PostalCode",  replaceNull(billingAccountDetail.address.current.postalCode))
			addressMAP.put("Type", replaceNull(billingAccountDetail.address.current.type))
			addressMAP.put("PostalPlusCode",  replaceNull(billingAccountDetail.address.current.postalPlusCode))
			addressMAP.put("CountryName", replaceNull(billingAccountDetail.address.current.countryName))
			addressMAP.put("CountryCode",  replaceNull(billingAccountDetail.address.current.countryCode))
			addressMAP.put("LocalCompanyName", replaceNull(billingAccountDetail.address.current.localCompanyName))
			addressMAP.put("GeoCode",  replaceNull(billingAccountDetail.address.current.geoCode))
			/* TODO Remove after DLIFE is go live. addressMAP.put("CountyName",  replaceNull(billingAccountDetail.address.current.countyName))*/
			addressMAP.put("InternationalPostalCode", replaceNull(billingAccountDetail.address.current.internationalPostalCode))
			addressMAP.put("InternationalAddressLine",  replaceNull(billingAccountDetail.address.current.internationalAddressLine))			
			}
			
			if(billingAccountDetail?.address?.previous!=null)
			{
			prevAddressMap.put("AddressLine1",  replaceNull(billingAccountDetail.address.previous.addressLine1))
			prevAddressMap.put("AddressLine2", replaceNull(billingAccountDetail.address.previous.addressLine2))
			prevAddressMap.put("City",  replaceNull(billingAccountDetail.address.previous.city))
			prevAddressMap.put("State", replaceNull(billingAccountDetail.address.previous.state))
			prevAddressMap.put("PostalCode",  replaceNull(billingAccountDetail.address.previous.postalCode))
			prevAddressMap.put("Type", replaceNull(billingAccountDetail.address.previous.type))
			prevAddressMap.put("PostalPlusCode",  replaceNull(billingAccountDetail.address.previous.postalPlusCode))
			prevAddressMap.put("CountryName", replaceNull(billingAccountDetail.address.previous.countryName))
			prevAddressMap.put("CountryCode",  replaceNull(billingAccountDetail.address.previous.countryCode))
			prevAddressMap.put("LocalCompanyName", replaceNull(billingAccountDetail.address.previous.localCompanyName))
			prevAddressMap.put("GeoCode",  replaceNull(billingAccountDetail.address.previous.geoCode))
			/*TODO Remove after DLIFE is go live. prevAddressMap.put("CountyName",  replaceNull(billingAccountDetail.address.previous.countyName))*/
			prevAddressMap.put("InternationalPostalCode", replaceNull(billingAccountDetail.address.previous.internationalPostalCode))
			prevAddressMap.put("InternationalAddressLine",  replaceNull(billingAccountDetail.address.previous.internationalAddressLine))
			}
			
			addressMAP= removeEmptyElement(addressMAP)
			prevAddressMap= removeEmptyElement(prevAddressMap)
			
			/*mBuilder.Address(current(addressMAP), previous(prevAddressMap))*/
			
			mBuilder.Address(){
				current(addressMAP)
				previous(prevAddressMap)
			}
			
			
		}
		if(billingAccountDetail?.phone!=null)
		{
			def phoneMAP = [:]
			def prevPhoneMap= [:]
			
			if(billingAccountDetail?.phone?.current!=null)
			{
			phoneMAP.put("homePhone",  replaceNull(billingAccountDetail.phone.current.homePhone))
			phoneMAP.put("workPhone", replaceNull(billingAccountDetail.phone.current.workPhone))
			phoneMAP.put("workPhoneExtension",  replaceNull(billingAccountDetail.phone.current.workPhoneExtension))
			phoneMAP.put("canBeReachedPhone", replaceNull(billingAccountDetail.phone.current.canBeReachedPhone))
			}
			
			if(billingAccountDetail?.phone?.previous!=null)
			{
			prevPhoneMap.put("homePhone",  replaceNull(billingAccountDetail.phone.previous.homePhone))
			prevPhoneMap.put("workPhone", replaceNull(billingAccountDetail.phone.previous.workPhone))
			prevPhoneMap.put("workPhoneExtension",  replaceNull(billingAccountDetail.phone.previous.workPhoneExtension))
			prevPhoneMap.put("canBeReachedPhone", replaceNull(billingAccountDetail.phone.previous.canBeReachedPhone))
			}
			phoneMAP= removeEmptyElement(phoneMAP)
			prevPhoneMap= removeEmptyElement(prevPhoneMap)
			
			/*mBuilder.Phone(current(phoneMAP), previous(prevPhoneMap))*/
				mBuilder.Phone(){
				current(phoneMAP)
				previous(prevPhoneMap)
			}
		}
		
		if(billingAccountDetail?.email!=null)
		{
			/*if(provReq.order.billingAccount.email.previous!=null)
			{}*/
			mBuilder.Email({
				provReq?.order?.billingAccount?.email?.current*.each { curr ->
					current(emailType: replaceNull(curr?.emailType),
						    emailAddress: replaceNull(curr?.emailAddress))
				}				
			
				provReq?.order?.billingAccount?.email?.previous*.each { prev ->
					previous(emailType: replaceNull(prev?.emailType),
						    emailAddress: replaceNull(prev?.emailAddress))
				}
			})
		
	}
		
		if(billingAccountDetail?.banEmail !=null)
		{
			/*if(provReq.order.billingAccount.email.previous!=null)
			{}*/
			mBuilder.BANEmail(BANEmailAddress:replaceNull(billingAccountDetail?.banEmail?.banEmailAddress),
				              BANEmailType: replaceNull(billingAccountDetail?.banEmail?.banEmailType))		
	    }
}

	def buildFinancialNotification (MarkupBuilder mBuilder, TPPProvisioningRequest provReq)
	{
		def financialNotification = provReq?.order?.financialNotification
		mBuilder.FinancialNotification(AdjustmentAmount : replaceNull(financialNotification.adjustmentAmount),
			                  AdjustmentCode : replaceNull(financialNotification.adjustmentCode))
	}
	
	
	def buildFemtocellTNUpdate (MarkupBuilder mBuilder, TPPProvisioningRequest provReq)
	{
		def femtocellTNUpdateAddInfo = provReq?.order?.femtocellTNUpdate.femtocellAdditionalInfo
		def femtocellTNUpdateAddrs = provReq?.order?.femtocellTNUpdate.femtocellAddress
		mBuilder.FemtocellTNUpdate()
		{
			FemtocellAddress(POD: replaceNull(femtocellTNUpdateAddrs.pod), MCN: replaceNull(femtocellTNUpdateAddrs.mcn),
				             PRD: replaceNull(femtocellTNUpdateAddrs.prd), HNO: replaceNull(femtocellTNUpdateAddrs.hno), 
							 STA: replaceNull(femtocellTNUpdateAddrs.sta), HNS: replaceNull(femtocellTNUpdateAddrs.hns),
							 STN: replaceNull(femtocellTNUpdateAddrs.stn), STS: replaceNull(femtocellTNUpdateAddrs.sts),
							 LOC: replaceNull(femtocellTNUpdateAddrs.loc), ZIP: replaceNull(femtocellTNUpdateAddrs.zip)
							 )
			FemtocellAdditionalInfo(ExternalKey: replaceNull(femtocellTNUpdateAddInfo.externalKey), TYS: replaceNull(femtocellTNUpdateAddInfo.tys),
				                    Longitude: replaceNull(femtocellTNUpdateAddInfo.longitude), CLS: replaceNull(femtocellTNUpdateAddInfo.cls),
									Latitude: replaceNull(femtocellTNUpdateAddInfo.latitude), NENAID: replaceNull(femtocellTNUpdateAddInfo.nenaid))
		}
	}
	
	/*def buildImmutableKeys (MarkupBuilder mBuilder, TPPProvisioningRequest provReq)
	{
		def buildImmutableKey = provReq?.order?.immutableKeys
		mBuilder.ImmutableKeys()
		{
			provReq?.order?.immutableKeys.user.collect{
				 User(it.action)
				 {
					 UserID()
					 {
						 ID()
						 {
							 AccessID(replaceNull(it.))
						 }
					 }
				 }
			}
			
		}
	}*/	
	
	def buildParentalControlsSettingInfo (MarkupBuilder mBuilder, TPPProvisioningRequest provReq)
	{
		def parentalControlsSettingInfo = provReq?.order?.parentalControlsSettingInfo
		
		mBuilder.ParentalControlsSettingInfo()
		{			
			indicator(replaceNull(parentalControlsSettingInfo.indicator))
			reasonCode(replaceNull(parentalControlsSettingInfo.reasonCode))			
		}
	}
	
	def buildAccountTypeInfo (MarkupBuilder mBuilder, TPPProvisioningRequest provReq)
	{
		def accountTypeInfo = provReq?.order?.accountTypeInfo
		
		mBuilder.AccountTypeInfo()
		{
			accountType_CSIIAPDip(replaceNull(accountTypeInfo.accountTypeCSIIAPDip))
			accountSubType_CSIIAPDip(replaceNull(accountTypeInfo.accountSubTypeCSIIAPDip))
		}
	}	
	
	def buildSegmentType (MarkupBuilder mBuilder, TPPProvisioningRequest provReq)
	{
		def segmentType = provReq?.order?.segmentType
		
		mBuilder.segmentType()
		{
			segmentCode(replaceNull(segmentType.segmentCode))
			segmentDescription(replaceNull(segmentType.segmentDescription))
			subsegmentCode(replaceNull(segmentType.subsegmentCode))
			subsegmentDescription(replaceNull(segmentType.subsegmentDescription))
		}
	}
	
	def buildMarketInfo (MarkupBuilder mBuilder, TPPProvisioningRequest provReq)
	{
		def marketInfo = provReq?.order?.marketInfo
		
		mBuilder.MarketInfo()
		{
			billingMarket(replaceNull(marketInfo.billingMarket))
			billingSubMarket(replaceNull(marketInfo.billingSubMarket))
			if(marketInfo.localMarket!="null")
			localMarket(replaceNull(marketInfo.localMarket))
		}
	}
	
	def buildSalesReps (MarkupBuilder mBuilder, TPPProvisioningRequest provReq)
	{
		def salesReps = provReq?.order?.salesReps
		
			provReq?.order?.salesReps*.each{ salesRep ->
				mBuilder.salesReps(){
				name()
				{
					namePrefix(replaceNull(salesRep.name.namePrefix))
					firstName(replaceNull(salesRep.name.firstName))
					middleName(replaceNull(salesRep.name.middleName))
					lastName(replaceNull(salesRep.name.lastName))
					nameSuffix(replaceNull(salesRep.name.nameSuffix))
					additionalTitle(replaceNull(salesRep.name.additionalTitle))
					
				}
				salesRepresentative(replaceNull(salesRep.salesRepresentative))
				affiliateSalesRepCode(replaceNull(salesRep.affiliateSalesRepCode))
				dealerCode()
				{
					code(replaceNull(salesRep.dealerCode.code))
					secondaryCode(replaceNull(salesRep.dealerCode.secondaryCode))
				}
				position(replaceNull(salesRep.position))
				territory(replaceNull(salesRep.territory))
				jobTitle(replaceNull(salesRep.jobTitle))
				workPhoneNumber(replaceNull(salesRep.workPhoneNumber))
				email(replaceNull(salesRep.email))
		}
		}
	}
	
	def buildDealerCommission (MarkupBuilder mBuilder, TPPProvisioningRequest provReq)
	{
		def dealerCommissionInfo = provReq?.order?.dealerCommission
		
		mBuilder.DealerCommission()
		{
			dealer()
			{
				code(replaceNull(dealerCommissionInfo.dealer.code))
				secondaryCode(replaceNull(dealerCommissionInfo.dealer.secondaryCode))
			}
			location(replaceNull(dealerCommissionInfo.location))
			salesRepresentative(replaceNull(dealerCommissionInfo.salesRepresentative))
			DualCommission()
			{
				creditCheckAgent(replaceNull(dealerCommissionInfo.dualCommission.creditCheckAgent))
				creditCheckAgentLocation(replaceNull(dealerCommissionInfo.dualCommission.creditCheckAgentLocation))
			}
			affiliateSalesRepCode(replaceNull(dealerCommissionInfo.affiliateSalesRepCode))
			billingTelephoneNumber(replaceNull(dealerCommissionInfo.billingTelephoneNumber))
			customerCode(replaceNull(dealerCommissionInfo.customerCode))
			
			 
		}
		
	}
	
	
	def buildCustRegContactInfoBASE (MarkupBuilder mBuilder, TPPProvisioningRequest provReq)
	{
		def custRegContactInfo_BASE = provReq?.order?.custRegContactInfoBASE
		
		provReq?.order?.custRegContactInfoBASE*.each{ custRegCont ->
		mBuilder.CustRegContactInfo_BASE()
		{
			if(custRegCont.namePrefix.size() > 0){
				namePrefix(custRegCont.namePrefix)
			}
			
			firstName(custRegCont.firstName)
			
			if(custRegCont.middleName.size() > 0){
				middleName(custRegCont.middleName)
			}
			
			lastName(custRegCont.lastName)
			
			if(custRegCont.jobTitle.size() > 0){
				jobTitle(custRegCont.jobTitle)
			}
			if(custRegCont.workPhoneNumber.size() > 0){
				workPhoneNumber(custRegCont.workPhoneNumber)
			}
			if(custRegCont.email.size() > 0){
				email(custRegCont.email)
			}
			
			type(custRegCont.type)
		}
		}
	}
	
	def buildLocationAccountID(MarkupBuilder mBuilder, TPPProvisioningRequest provReq)
	{
		def locationId= provReq.getOrder()?.locationId
		mBuilder.LocationAccountID(replaceNull(locationId))
	}
	
	def buildFirstNetIndicator(MarkupBuilder mBuilder, TPPProvisioningRequest provReq){
		def fnIndicator= provReq.getOrder()?.firstNetIndicator
		mBuilder.FirstNetIndicator(replaceNull(fnIndicator))
	}

	def buildEventType(MarkupBuilder mBuilder, TPPProvisioningRequest provReq)
	{
		def eventName= provReq?.order?.eventType?.eventName
		mBuilder.EventName(replaceNull(eventName))
		
	}
	
	def buildTaxExcemption(MarkupBuilder mBuilder, TPPProvisioningRequest provReq)
	{
		def taxExcemption= provReq?.order?.taxExemption
		mBuilder.TaxExemption(status: replaceNull(taxExcemption.status),
			                  entityType: replaceNull(taxExcemption.entityType),
							  effectiveDate: replaceNull(taxExcemption.effectiveDate),
							  expirationDate: replaceNull(taxExcemption.expirationDate) )
		
	}
	
	def buildContact(MarkupBuilder mBuilder, TPPProvisioningRequest provReq){
		log.info ("inside buildContact >>>");
		def contact= provReq.order.subscriber?.contact?.current
		def contactMap = [:]
        if(contact!=null)
		{
			contactMap.put("FirstName", replaceNull(contact?.firstName))
			contactMap.put("LastName", replaceNull(contact?.lastName))
			contactMap=removeEmptyElement(contactMap)
			mBuilder.Contact(contactMap)
		}
	}
	
	def buildPrevContact(MarkupBuilder mBuilder, TPPProvisioningRequest provReq){
		def contactPrev= provReq.order.subscriber?.contact?.previous
		def prevContactMap = [:]
		if(contactPrev!=null)
		{
			prevContactMap.put("FirstName", replaceNull(contactPrev?.firstName))
			prevContactMap.put("LastName", replaceNull(contactPrev?.lastName))
			prevContactMap=removeEmptyElement(prevContactMap)
			mBuilder.PrevContact(prevContactMap)
		}
	}

	def buildAddress(MarkupBuilder mBuilder, TPPProvisioningRequest provReq){

		def address= provReq.getOrder()?.getSubscriber()?.address?.current
		def addressMap = [:]

		if(address!=null)
		{
			log.info ("address type>>>>>"+address?.type);
			if(!address?.type.equals("null")){
				addressMap.put("Type", replaceNull(address?.type.toString()))
			}
			addressMap.put("Street", replaceNull(address?.street))
			addressMap.put("City", replaceNull(address?.city))
			addressMap.put("State", replaceNull(address?.state))
			addressMap.put("PostalCode", replaceNull(address?.postalCode))
			if(!address?.countryCode.equals("null")){
				addressMap.put("CountryCode", replaceNull(address?.countryCode))
			}
			addressMap=removeEmptyElement(addressMap)
			mBuilder.Address(addressMap)
		}

	}
	
	def buildPrevAddress(MarkupBuilder mBuilder, TPPProvisioningRequest provReq){
		
			def addressPrev= provReq.getOrder()?.getSubscriber()?.address?.previous
			def prevAddressMap = [:]
	
			if(addressPrev!=null)
			{
				log.info ("addressPrev type>>>>>"+addressPrev?.type);
				if(!addressPrev?.type.equals("null")){
					prevAddressMap.put("Type", replaceNull(addressPrev?.type.toString()))
				}
				prevAddressMap.put("Street", replaceNull(addressPrev?.street))
				prevAddressMap.put("City", replaceNull(addressPrev?.city))
				prevAddressMap.put("State", replaceNull(addressPrev?.state))
				prevAddressMap.put("PostalCode", replaceNull(addressPrev?.postalCode))
				if(!addressPrev?.countryCode.equals("null")){
					prevAddressMap.put("CountryCode", replaceNull(addressPrev?.countryCode))
				}
				prevAddressMap=removeEmptyElement(prevAddressMap)
				mBuilder.PrevAddress(prevAddressMap)
			}
		
	}

	def buildEmail(MarkupBuilder mBuilder, TPPProvisioningRequest provReq){
		
			def email= provReq.getOrder()?.getSubscriber()?.email?.current
			def emailMap = [:]
	
			if(email!=null)
			{
				log.info ("inside buildEmail >>>"+email?.emailAddress.toString());
				emailMap.put("emailAddress", replaceNull(email?.emailAddress))
				emailMap.put("primaryAddressIndicator", replaceNull(email?.primaryAddressIndicator?.toBoolean()))
				emailMap.put("emailType", replaceNull(email?.emailType))
				emailMap=removeEmptyElement(emailMap)
				mBuilder.Email(emailMap)
			}
		
	}
			
	def buildPrevEmail(MarkupBuilder mBuilder, TPPProvisioningRequest provReq){
		
			def emailPrev= provReq.getOrder()?.getSubscriber()?.email?.previous
			def prevEmailMap = [:]
	
			if(emailPrev!=null)
			{
				log.info ("inside buildEmail >>>"+emailPrev?.emailAddress.toString());
				prevEmailMap.put("emailAddress", replaceNull(emailPrev?.emailAddress))
				prevEmailMap.put("primaryAddressIndicator", replaceNull(emailPrev?.primaryAddressIndicator?.toBoolean()))
				prevEmailMap.put("emailType", replaceNull(emailPrev?.emailType))
				prevEmailMap=removeEmptyElement(prevEmailMap)
				mBuilder.PrevEmail(prevEmailMap)
			}
	}
	def buildDevice(MarkupBuilder mBuilder, TPPProvisioningRequest provReq){

		def equipment= provReq.getOrder()?.getEquipment()
		def deviceMap = [:]

		if(equipment?.device!=null)
		{
			deviceMap.put("Make", replaceNull(equipment.device.make))
			deviceMap.put("Model", replaceNull(equipment.device.model))
			deviceMap.put("ESN", replaceNull(equipment.device.esn))
			deviceMap.put("IMEI", replaceNull(equipment.device.imei))
			deviceMap.put("MMSCapable", replaceNull(equipment.device.mmsCapable))
			deviceMap=removeEmptyElement(deviceMap)
			mBuilder.Device(deviceMap)
		}

	}


	def buildSIM(MarkupBuilder mBuilder, TPPProvisioningRequest provReq){

		def equipment= provReq.getOrder()?.getEquipment()
		def simMap = [:]

		if(equipment?.sim!=null)
		{
			simMap.put("IMSI", replaceNull(equipment.sim.imsi))
			simMap.put("ICCID", replaceNull(equipment.sim.iccid))
			simMap=removeEmptyElement(simMap)
			mBuilder.SIM(simMap)
		}
	}
	
	def buildVendorDetails (MarkupBuilder mBuilder, TPPProvisioningRequest provReq)
	{
		def vendorDetails= provReq.getOrder()?.getVendorDetails()
		
		mBuilder.VendorDetails()
		{
			VendorName(replaceNull(vendorDetails.vendorName))
			CompanyName(replaceNull(vendorDetails.companyName))
			OrderId(replaceNull(vendorDetails.orderId))
		}
	}

	//This method will remove empty elements from the map
	def Map removeEmptyElement(mapValues){
		def mapItr = mapValues.entrySet().iterator()

		while (mapItr.hasNext()) {
			def mapData= mapItr.next();
//			log.info("Key:"+ mapData.key)
//			log.info("Value:"+ mapData.value)
//			log.info("Lenght:"+ mapData.value.length())
			if (mapData.value.length()<=0 ) {
				mapItr.remove()
			}
		}
		return mapValues;

	}

	//This Method cleans empty Nodes and null values nodes
	boolean cleanNode( Node node ) {
		node.attributes().with { a ->
			a.findAll { !it.value }.each { a.remove( it.key ) }
		}
		node.children().with { kids ->
			kids.findAll { it instanceof Node ? !cleanNode( it ) : false }
				.each { kids.remove( it ) }
		}
		node.attributes() || node.children() || node.text()
	}
	
//	//This method will replace Null value with empty string
//	def String replaceNull(value){
//		def outputValue = (value != null) ? value : ''
////		log.info("outputValue:"+outputValue)
//		return outputValue
//
//		/*if (object instanceof value)
//		return new value();
//		else
//		return object.someMethod();*/
//	}
	
	//This method will replace Null value with empty string
	def String replaceNull(value){
		def outputValue = value ?: ''
//		log.info("outputValue:"+outputValue)
		return outputValue

		/*if (object instanceof value)
		return new value();
		else
		return object.someMethod();*/
	}
	/*
	*WR #3035160 - ParseXML error occurs when Zero price comes in SKU order
	*This method will not replace NumericNull in groovy(0.0) value with empty string. 
	*/
	def String replaceNumericNull(value){
		//log.info("InputValue:"+value)
		def outputValue = (value != null) ? value : ''
		//log.info("outputValue:"+outputValue)
		return outputValue
	}


}
