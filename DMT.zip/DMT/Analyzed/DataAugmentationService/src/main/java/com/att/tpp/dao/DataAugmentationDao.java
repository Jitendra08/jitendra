package com.att.tpp.dao;

import com.att.tpp.model.CsidipArchive;



public interface DataAugmentationDao {
	public boolean persistDipResult(CsidipArchive csidipArchive);

	public boolean updateDipResults(String transactionId,
			String tppProvisioningRequestXML);

}