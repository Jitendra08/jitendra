package com.att.tpp.dao;

import org.apache.log4j.Logger;
import org.hibernate.HibernateException;
import org.hibernate.Query;
import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.att.tpp.model.CsidipArchive;




@Repository("dataAugmentationDao")
public class DataAugmentationDaoImpl implements DataAugmentationDao {
	
	private static final Logger dataAugmentationDaoImplLog = Logger.getLogger(DataAugmentationDaoImpl.class);
	
	@Autowired
	private SessionFactory sessionFactoryArchive;


	@Override
	public boolean persistDipResult(CsidipArchive csiDipArchive) {
		dataAugmentationDaoImplLog.debug("Inside DataAugmentationDaoImpl persistDipResult method");
		try {
			//sessionFactoryArchive.getCurrentSession().saveOrUpdate(csiDipArchive);			
			sessionFactoryArchive.getCurrentSession().save(csiDipArchive);		
			sessionFactoryArchive.getCurrentSession().flush();
			return true;
		}catch (HibernateException e) {
			dataAugmentationDaoImplLog.error("Exception occured in the DataAugmentationDaoImpl persistDipResult method :"+e);
			e.printStackTrace();
			return false;
		}
	}


	@Transactional
	public boolean updateDipResults(String transactionId,
			String tppProvisioningRequestXML) {
		dataAugmentationDaoImplLog.debug("Inside DataAugmentationDaoImpl updateDipResults method");
		int success = 0;
		
		Query queryProvTask = sessionFactoryArchive.getCurrentSession()
				.createQuery("update CsidipArchive cda set cda.loadXml = :loadXml where cda.provsystrxid = :provsystrxid");
		queryProvTask.setParameter("provsystrxid", transactionId);
		queryProvTask.setParameter("loadXml",tppProvisioningRequestXML);
		
		try{
		
			success = queryProvTask.executeUpdate();
			
			if(success > 0 ){				
				return true;				
			}
			else{				
				return false;				
			}
			
		}
		catch(HibernateException he){
			
			dataAugmentationDaoImplLog.error("Hibernate Exception occured in updateCompletedProvisioningTask method: " + he.getMessage());
			return false;
			
		}
		
	}  
	
}
	