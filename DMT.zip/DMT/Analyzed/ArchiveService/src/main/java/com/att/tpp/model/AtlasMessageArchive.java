package com.att.tpp.model;

import java.io.Serializable;
import javax.persistence.*;
import java.util.Date;


/**
 * The persistent class for the ATLAS_MESSAGE_ARCHIVE database table.
 * 
 */
@Entity
@Table(name="ATLAS_MESSAGE_ARCHIVE")
@NamedQuery(name="AtlasMessageArchive.findAll", query="SELECT a FROM AtlasMessageArchive a")
public class AtlasMessageArchive implements Serializable {
	private static final long serialVersionUID = 1L;

	@Temporal(TemporalType.TIMESTAMP)
	@Column(name="CREATED_TIMESTAMP")
	private Date createdTimestamp;

	@Column(name="ERROR_MSG")
	private String errorMsg;

	@Column(name="EVENT_NAME")
	private String eventName;

	@Lob
	@Column(name="EVENT_TEXT")
	private String eventText;

	@Id
	@Column(name="MESSAGEID")
	private String messageid;

	private String msisdn;

	public AtlasMessageArchive() {
	}

	public Date getCreatedTimestamp() {
		return this.createdTimestamp;
	}

	public void setCreatedTimestamp(Date createdTimestamp) {
		this.createdTimestamp = createdTimestamp;
	}

	public String getErrorMsg() {
		return this.errorMsg;
	}

	public void setErrorMsg(String errorMsg) {
		this.errorMsg = errorMsg;
	}

	public String getEventName() {
		return this.eventName;
	}

	public void setEventName(String eventName) {
		this.eventName = eventName;
	}

	public String getEventText() {
		return this.eventText;
	}

	public void setEventText(String eventText) {
		this.eventText = eventText;
	}

	public String getMessageid() {
		return this.messageid;
	}

	public void setMessageid(String messageid) {
		this.messageid = messageid;
	}

	public String getMsisdn() {
		return this.msisdn;
	}

	public void setMsisdn(String msisdn) {
		this.msisdn = msisdn;
	}

}