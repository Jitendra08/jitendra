package com.att.tpp.model;

import java.util.Date;

public class ArchiveRequestData {
	private Date receivedTimeStamp;
	private String masterTransactionId;
	
	public ArchiveRequestData() {
	}

	/**
	 * @param masterTransactionId
	 * @param receivedTimeStamp
	 */
	public ArchiveRequestData(String masterTransactionId,	Date receivedTimeStamp) {
		this.masterTransactionId = masterTransactionId;
		this.receivedTimeStamp = receivedTimeStamp;
	}

	public Date getReceivedTimeStamp() {
		return receivedTimeStamp;
	}

	public void setReceivedTimeStamp(Date receivedTimeStamp) {
		this.receivedTimeStamp = receivedTimeStamp;
	}

	public String getMasterTransactionId() {
		return this.masterTransactionId;
	}

	public void setMasterTransactionId(String masterTransactionId) {
		this.masterTransactionId = masterTransactionId;
	}
	
}
