package com.att.tpp.model;

import java.io.Serializable;


public class CompletionNotification implements Serializable {
	private static final long serialVersionUID = 1L;

	private String messageId;

	private String transactionId;

	public CompletionNotification() {
	}
	
	public CompletionNotification(String messageId, String transactionId ) {
		this.messageId=messageId;
		this.transactionId=transactionId;
	}

	public String getMessageId() {
		return messageId;
	}

	public void setMessageId(String messageId) {
		this.messageId = messageId;
	}

	public String getTransactionId() {
		return transactionId;
	}

	public void setTransactionId(String transactionId) {
		this.transactionId = transactionId;
	}


}