package com.att.tpp.utils

import java.util.Collection;
import java.util.Date

import com.att.tpp.model.ArchiveRequestData



class ParseRequestData {

	def ArchiveRequestData archiveReqMasterTransactionId(String inXML){
		def archiveReq = new XmlSlurper().parseText(inXML)
		def now = new Date()
		def prDyn = null

		/**
		 * @param masterTransactionId
		 * @param receivedTimeStamp 
		 */

		return new  ArchiveRequestData(
		archiveReq.@MasterTransactionId.toString(),
		now
	)}

	def String getRootElement(String inXML){
		def provReq = new XmlSlurper().parseText(inXML)
		println("Root Element: " + provReq.name().toString());
		return provReq.name().toString();
	}
	
	def String provReqSubscriberNumber(String inXML){
		def proviReq = new XmlSlurper().parseText(inXML);
		return proviReq.Order.Account.@SubscriberNumber.toString();
	}
	

}



