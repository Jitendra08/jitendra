package com.att.tpp.model;

import java.io.Serializable;

/**
 *
 * @author sg625m
 */

public class ProcessingResult implements Serializable  {
	
	private static final long serialVersionUID = 1L;
	
	boolean isValidRequest=false;
	boolean isInsertDummyTransaction=false;
	boolean isInsertInterfaceArchive=false;
	boolean isInsertMimToolsInterface=false;
	boolean isUpdateTransactionArchive=false;
	boolean isDeletedFromAtlasMessageArchive=false; /* US502960 :: WR # 2810221 - Updated to delete valid transactions from Atlas Message Archive table after life cycle is complete */
	boolean isDeletedFromProvisioningRequests=false;
	boolean isDeletedFromProvisioningTasks=false;
	boolean isDeletedFromTransCodes=false;
	boolean isTimerUpdate=false;
	boolean isDeletedFromProducts=false;
	boolean isDeletedFromProductAttribute=false;
	boolean isDeletedFromDB=false;
	boolean isValidTppCompletionNotification=false;
	boolean isValidGatewayArchive=false;
	boolean isGatewayConfirmed=false;
	private String swcTransactionId;
	private String masterTransactionId;
	private String tppCompletionNotification;
	
	
	public String getTppCompletionNotification() {
		return tppCompletionNotification;
	}


	public void setTppCompletionNotification(String tppCompletionNotification) {
		this.tppCompletionNotification = tppCompletionNotification;
	}


	public boolean isValidTppCompletionNotification() {
		return isValidTppCompletionNotification;
	}


	public void setValidTppCompletionNotification(boolean isValidTppCompletionNotification) {
		this.isValidTppCompletionNotification = isValidTppCompletionNotification;
	}

	public String getSwcTransactionId() {
		return swcTransactionId;
	}


	public void setSwcTransactionId(String swcTransactionId) {
		this.swcTransactionId = swcTransactionId;
	}

	
	public ProcessingResult() {
	}

	public String getMasterTransactionId() {
		return masterTransactionId;
	}

	public void setMasterTransactionId(String masterTransactionId) {
		this.masterTransactionId = masterTransactionId;
	}

	public boolean getValidRequest() {
		return isValidRequest;
	}
	
	public void setValidRequest(boolean isValidRequest) {
		this.isValidRequest = isValidRequest;
	}


	public boolean isValidRequest() {
		return isValidRequest;
	}


	public boolean isInsertInterfaceArchive() {
		return isInsertInterfaceArchive;
	}


	public void setInsertInterfaceArchive(boolean isInsertInterfaceArchive) {
		this.isInsertInterfaceArchive = isInsertInterfaceArchive;
	}


	public boolean isInsertMimToolsInterface() {
		return isInsertMimToolsInterface;
	}


	public void setInsertMimToolsInterface(boolean isInsertMimToolsInterface) {
		this.isInsertMimToolsInterface = isInsertMimToolsInterface;
	}


	public boolean isUpdateTransactionArchive() {
		return isUpdateTransactionArchive;
	}


	public void setUpdateTransactionArchive(boolean isUpdateTransactionArchive) {
		this.isUpdateTransactionArchive = isUpdateTransactionArchive;
	}

	public boolean isDeletedFromProvisioningRequests() {
		return isDeletedFromProvisioningRequests;
	}


	public void setDeletedFromProvisioningRequests(
			boolean isDeletedFromProvisioningRequests) {
		this.isDeletedFromProvisioningRequests = isDeletedFromProvisioningRequests;
	}


	public boolean isDeletedFromProvisioningTasks() {
		return isDeletedFromProvisioningTasks;
	}


	public void setDeletedFromProvisioningTasks(
			boolean isDeletedFromProvisioningTasks) {
		this.isDeletedFromProvisioningTasks = isDeletedFromProvisioningTasks;
	}


	public boolean isDeletedFromTransCodes() {
		return isDeletedFromTransCodes;
	}


	public void setDeletedFromTransCodes(boolean isDeletedFromTransCodes) {
		this.isDeletedFromTransCodes = isDeletedFromTransCodes;
	}


	public boolean isTimerUpdate() {
		return isTimerUpdate;
	}


	public void setTimerUpdate(boolean isTimerUpdate) {
		this.isTimerUpdate = isTimerUpdate;
	}


	public boolean isDeletedFromProducts() {
		return isDeletedFromProducts;
	}


	public void setDeletedFromProducts(boolean isDeletedFromProducts) {
		this.isDeletedFromProducts = isDeletedFromProducts;
	}


	public boolean isDeletedFromProductAttribute() {
		return isDeletedFromProductAttribute;
	}


	public void setDeletedFromProductAttribute(boolean isDeletedFromProductAttribute) {
		this.isDeletedFromProductAttribute = isDeletedFromProductAttribute;
	}

	public boolean isDeletedFromDB() {
		return isDeletedFromDB;
	}


	public void setDeletedFromDB(boolean isDeletedFromDB) {
		this.isDeletedFromDB = isDeletedFromDB;
	}


	public boolean isGatewayConfirmed() {
		return isGatewayConfirmed;
	}


	public void setGatewayConfirmed(boolean isGatewayConfirmed) {
		this.isGatewayConfirmed = isGatewayConfirmed;
	}


	public boolean isInsertDummyTransaction() {
		return isInsertDummyTransaction;
	}


	public void setInsertDummyTransaction(boolean isInsertDummyTransaction) {
		this.isInsertDummyTransaction = isInsertDummyTransaction;
	}


	public boolean isValidGatewayArchive() {
		return isValidGatewayArchive;
	}


	public void setValidGatewayArchive(boolean isValidGatewayArchive) {
		this.isValidGatewayArchive = isValidGatewayArchive;
	}


	public boolean isDeletedFromAtlasMessageArchive() {
		return isDeletedFromAtlasMessageArchive;
	}


	public void setDeletedFromAtlasMessageArchive(
			boolean isDeletedFromAtlasMessageArchive) {
		this.isDeletedFromAtlasMessageArchive = isDeletedFromAtlasMessageArchive;
	}
	

}
