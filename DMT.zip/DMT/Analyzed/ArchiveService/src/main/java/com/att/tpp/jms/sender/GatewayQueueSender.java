package com.att.tpp.jms.sender;

import javax.jms.JMSException;
import javax.jms.Message;
import javax.jms.Queue;
import javax.jms.Session;
import javax.jms.TextMessage;

import org.apache.log4j.Logger;
import org.springframework.jms.core.JmsTemplate;
import org.springframework.jms.core.MessageCreator;

import com.att.tpp.model.ProcessingResult;

/**
 * 
 * The GatewayQueueSender class uses the injected JMSTemplate to send a message
 * to gatewayConfirmationQueue. 
 */
public class GatewayQueueSender
{
	private JmsTemplate jmsTemplate;
	private Queue gatewayConfirmationQueue;
	private static final Logger gatewayRequestSenderLog = Logger.getLogger(GatewayQueueSender.class);
	private final static String swcTransactionId = "swcTransactionId";
	
	/**
	 * Sends message to gatewayConfirmationQueue using JMS Template.
	 * @param provReqXML the message_p
	 * @throws JMSException the jms exception
	 */
	public void sendMessage(final ProcessingResult processingResult) throws JMSException
	{
		
		gatewayRequestSenderLog.info("Sending TPP_ProvisioningRequest Message From Transformation Service to GateWay Service");

		jmsTemplate.send(this.gatewayConfirmationQueue, new MessageCreator(){

			@Override
			public Message createMessage(Session session) throws JMSException {
				TextMessage message = session.createTextMessage(processingResult.getTppCompletionNotification().toString());
				message.setStringProperty(swcTransactionId,processingResult.getSwcTransactionId());				
				return message;
			}
			
		});		
		
	}
	/**
	 * Sets the jms template.
	 *
	 * @param template the jms template
	 */
	public void setJmsTemplate(JmsTemplate tmpl)
	{
		this.jmsTemplate = tmpl;
	}

	/**
	 * Sets the test queue.
	 *
	 * @param gatewayConfirmationQueue the new test queue
	 */
	public void setGatewayConfirmationQueue(Queue gatewayConfirmationQueue)
	{
		this.gatewayConfirmationQueue = gatewayConfirmationQueue;
	}
}