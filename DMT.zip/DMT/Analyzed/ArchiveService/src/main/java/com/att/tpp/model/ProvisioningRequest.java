package com.att.tpp.model;

import java.io.Serializable;
import javax.persistence.*;
import java.math.BigDecimal;
import java.util.Date;


/**
 * The persistent class for the PROVISIONING_REQUESTS database table.
 * 
 */
@Entity
@Table(name="PROVISIONING_REQUESTS")
public class ProvisioningRequest implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@Column(name="MASTER_TRANSID")
	private String masterTransid;

	@Temporal(TemporalType.TIMESTAMP)
	@Column(name="BEGIN_PROCESSING_TIME")
	private Date beginProcessingTime;

	@Column(name="COMPLETED_TASKS_COUNT")
	private BigDecimal completedTasksCount;

	@Column(name="CURRENT_SOLN_COUNT")
	private BigDecimal currentSolnCount;

	@Column(name="EVENT_TYPE")
	private String eventType;

	@Column(name="LOCATION")
	private String location;

	@Column(name="MSISDN")
	private String msisdn;

	@Column(name="PAYLOAD")
	@Lob
	private String payload;

	@Column(name="PAYLOAD_OVERFLOW")
	private String payloadOverflow;

	@Column(name="PROCESSING_STATUS")
	private String processingStatus;

	@Column(name="PROV_SYSTEM_TRANSID")
	private String provSystemTransid;

	@Column(name="PROVISIONING_CARRIER")
	private String provisioningCarrier;

	@Temporal(TemporalType.TIMESTAMP)
	@Column(name="RECEIVED_TIME_STAMP")
	private Date receivedTimeStamp;

	@Column(name="ROUTING_CARRIER")
	private String routingCarrier;

	@Column(name="TOTAL_SOLN_COUNT")
	private BigDecimal totalSolnCount;

	@Column(name="TOTAL_TASKS_COUNT")
	private BigDecimal totalTasksCount;

	public ProvisioningRequest() {
	}

	public String getMasterTransid() {
		return this.masterTransid;
	}

	public void setMasterTransid(String masterTransid) {
		this.masterTransid = masterTransid;
	}

	public Date getBeginProcessingTime() {
		return this.beginProcessingTime;
	}

	public void setBeginProcessingTime(Date beginProcessingTime) {
		this.beginProcessingTime = beginProcessingTime;
	}

	public BigDecimal getCompletedTasksCount() {
		return this.completedTasksCount;
	}

	public void setCompletedTasksCount(BigDecimal completedTasksCount) {
		this.completedTasksCount = completedTasksCount;
	}

	public BigDecimal getCurrentSolnCount() {
		return this.currentSolnCount;
	}

	public void setCurrentSolnCount(BigDecimal currentSolnCount) {
		this.currentSolnCount = currentSolnCount;
	}

	public String getEventType() {
		return this.eventType;
	}

	public void setEventType(String eventType) {
		this.eventType = eventType;
	}

	public String getLocation() {
		return this.location;
	}

	public void setLocation(String location) {
		this.location = location;
	}

	public String getMsisdn() {
		return this.msisdn;
	}

	public void setMsisdn(String msisdn) {
		this.msisdn = msisdn;
	}

	public String getPayload() {
		return this.payload;
	}

	public void setPayload(String payload) {
		this.payload = payload;
	}

	public String getPayloadOverflow() {
		return this.payloadOverflow;
	}

	public void setPayloadOverflow(String payloadOverflow) {
		this.payloadOverflow = payloadOverflow;
	}

	public String getProcessingStatus() {
		return this.processingStatus;
	}

	public void setProcessingStatus(String processingStatus) {
		this.processingStatus = processingStatus;
	}

	public String getProvSystemTransid() {
		return this.provSystemTransid;
	}

	public void setProvSystemTransid(String provSystemTransid) {
		this.provSystemTransid = provSystemTransid;
	}

	public String getProvisioningCarrier() {
		return this.provisioningCarrier;
	}

	public void setProvisioningCarrier(String provisioningCarrier) {
		this.provisioningCarrier = provisioningCarrier;
	}

	public Date getReceivedTimeStamp() {
		return this.receivedTimeStamp;
	}

	public void setReceivedTimeStamp(Date receivedTimeStamp) {
		this.receivedTimeStamp = receivedTimeStamp;
	}

	public String getRoutingCarrier() {
		return this.routingCarrier;
	}

	public void setRoutingCarrier(String routingCarrier) {
		this.routingCarrier = routingCarrier;
	}

	public BigDecimal getTotalSolnCount() {
		return this.totalSolnCount;
	}

	public void setTotalSolnCount(BigDecimal totalSolnCount) {
		this.totalSolnCount = totalSolnCount;
	}

	public BigDecimal getTotalTasksCount() {
		return this.totalTasksCount;
	}

	public void setTotalTasksCount(BigDecimal totalTasksCount) {
		this.totalTasksCount = totalTasksCount;
	}

}