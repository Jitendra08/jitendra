package com.att.tpp.model;

import java.io.Serializable;

import javax.persistence.*;


/**
 * The persistent class for the PRODUCT_ATTRIBUTE database table.
 * 
 */
@Entity
@Table(name="PRODUCT_ATTRIBUTE")
public class ProductAttribute implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@Column(name="\"ACTION\"")
	private String action;

	@Id
	@Column(name="ATTRIBUTE_NAME")
	private String attributeName;

	@Id
	@Column(name="ATTRIBUTE_VALUE")
	private String attributeValue;

	@Id
	@Column(name="PRODUCT_ID")
	private String productId;

	@Id
	@Column(name="TASK_TRANSID")
	private String taskTransid;

	public ProductAttribute() {
	}

	public String getAction() {
		return this.action;
	}

	public void setAction(String action) {
		this.action = action;
	}

	public String getAttributeName() {
		return this.attributeName;
	}

	public void setAttributeName(String attributeName) {
		this.attributeName = attributeName;
	}

	public String getAttributeValue() {
		return this.attributeValue;
	}

	public void setAttributeValue(String attributeValue) {
		this.attributeValue = attributeValue;
	}

	public String getProductId() {
		return this.productId;
	}

	public void setProductId(String productId) {
		this.productId = productId;
	}

	public String getTaskTransid() {
		return this.taskTransid;
	}

	public void setTaskTransid(String taskTransid) {
		this.taskTransid = taskTransid;
	}

}