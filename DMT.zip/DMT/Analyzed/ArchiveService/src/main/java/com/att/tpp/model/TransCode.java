package com.att.tpp.model;

import java.io.Serializable;
import javax.persistence.*;
import java.util.Date;


/**
 * The persistent class for the TRANS_CODES database table.
 * 
 */
@Entity
@Table(name="TRANS_CODES")
@NamedQuery(name="TransCode.findAll", query="SELECT t FROM TransCode t")
public class TransCode implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@Column(name="ACTION")
	private String action;

	@Id
	@Temporal(TemporalType.TIMESTAMP)
	@Column(name="ERROR_TIME")
	private Date errorTime;

	@Id
	@Column(name="MAJORCODE")
	private String majorcode;

	@Id
	@Column(name="MAJORDESC")
	private String majordesc;

	@Id
	@Column(name="MASTER_TRANSID")
	private String masterTransid;

	@Id
	@Column(name="MINORCODE")
	private String minorcode;

	@Id
	@Column(name="MINORDESC")
	private String minordesc;

	@Id
	@Column(name="PRODUCT_ID")
	private String productId;

	@Id
	@Column(name="TASK_TRANSID")
	private String taskTransid;

	public TransCode() {
	}

	public String getAction() {
		return this.action;
	}

	public void setAction(String action) {
		this.action = action;
	}

	public Date getErrorTime() {
		return this.errorTime;
	}

	public void setErrorTime(Date errorTime) {
		this.errorTime = errorTime;
	}

	public String getMajorcode() {
		return this.majorcode;
	}

	public void setMajorcode(String majorcode) {
		this.majorcode = majorcode;
	}

	public String getMajordesc() {
		return this.majordesc;
	}

	public void setMajordesc(String majordesc) {
		this.majordesc = majordesc;
	}

	public String getMasterTransid() {
		return this.masterTransid;
	}

	public void setMasterTransid(String masterTransid) {
		this.masterTransid = masterTransid;
	}

	public String getMinorcode() {
		return this.minorcode;
	}

	public void setMinorcode(String minorcode) {
		this.minorcode = minorcode;
	}

	public String getMinordesc() {
		return this.minordesc;
	}

	public void setMinordesc(String minordesc) {
		this.minordesc = minordesc;
	}

	public String getProductId() {
		return this.productId;
	}

	public void setProductId(String productId) {
		this.productId = productId;
	}

	public String getTaskTransid() {
		return this.taskTransid;
	}

	public void setTaskTransid(String taskTransid) {
		this.taskTransid = taskTransid;
	}

}