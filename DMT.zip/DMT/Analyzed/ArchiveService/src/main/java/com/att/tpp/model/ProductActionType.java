package com.att.tpp.model;

import java.io.Serializable;

import javax.persistence.Entity;

@Entity
public class ProductActionType implements Serializable {
	private static final long serialVersionUID = 1L;

	String taskTransId = null;
	String productId = null;
	String action = null;
	
	public ProductActionType() {
		
	}
	
	public String getTaskTransId() {
		return taskTransId;
	}

	public void setTaskTransId(String taskTransId) {
		this.taskTransId = taskTransId;
	}

	public String getProductId() {
		return productId;
	}
	public void setProductId(String productId) {
		this.productId = productId;
	}
	public String getAction() {
		return action;
	}
	public void setAction(String action) {
		this.action = action;
	}
	
}