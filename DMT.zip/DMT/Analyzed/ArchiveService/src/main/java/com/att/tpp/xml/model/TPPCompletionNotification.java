package com.att.tpp.xml.model;

public class TPPCompletionNotification {

    private CompletionNotification completionNotification;

	public TPPCompletionNotification (CompletionNotification completionNotification) {
		this.completionNotification = completionNotification;
	}

	public CompletionNotification getCompletionNotification() {
		return completionNotification;
	}

	public void setCompletionNotification(CompletionNotification completionNotification) {
		this.completionNotification = completionNotification;
	}



    

}
