package com.att.tpp.model;

import java.io.Serializable;
import javax.persistence.*;
import java.util.Date;



/**
 * The persistent class for the GATEWAY_ARCHIVE database table.
 * 
 */
@Entity
@Table(name="GATEWAY_ARCHIVE")
@NamedQuery(name="GatewayArchive.findAll", query="SELECT g FROM GatewayArchive g")
public class GatewayArchive implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	private String messageid;

	@Temporal(TemporalType.TIMESTAMP)
	@Column(name="CREATED_TIMESTAMP")
	private Date createdTimestamp;

	@Lob
	@Column(name="EVENT_TEXT")
	private String eventText;
	
	@Column(name="MSISDN")
	private String msisdn;

	@Column(name="ROUTING_CARRIER")
	private String routingCarrier;

	public GatewayArchive() {
	}

	public String getMessageid() {
		return this.messageid;
	}

	public void setMessageid(String messageid) {
		this.messageid = messageid;
	}

	public Date getCreatedTimestamp() {
		return this.createdTimestamp;
	}

	public void setCreatedTimestamp(Date createdTimestamp) {
		this.createdTimestamp = createdTimestamp;
	}

	public String getEventText() {
		return this.eventText;
	}

	public void setEventText(String eventText) {
		this.eventText = eventText;
	}

	public String getMsisdn() {
		return this.msisdn;
	}

	public void setMsisdn(String msisdn) {
		this.msisdn = msisdn;
	}

	public String getRoutingCarrier() {
		return this.routingCarrier;
	}

	public void setRoutingCarrier(String routingCarrier) {
		this.routingCarrier = routingCarrier;
	}

}