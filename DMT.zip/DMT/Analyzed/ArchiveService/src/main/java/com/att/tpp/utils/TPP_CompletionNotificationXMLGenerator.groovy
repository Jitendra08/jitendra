package com.att.tpp.utils

import com.att.tpp.xml.model.TPPCompletionNotification
import com.att.tpp.model.CompletionNotification

import groovy.xml.MarkupBuilder


class TPP_CompletionNotificationXMLGenerator {

	public TPP_CompletionNotificationXMLGenerator() {
	}


	def String createProvReqXML(TPPCompletionNotification complNotif){
		def complNotifXML = new StringWriter()
		def xml = new MarkupBuilder(complNotifXML)

		def completionNotification= complNotif.getCompletionNotification()
		xml.setDoubleQuotes(true)
		xml.mkp.xmlDeclaration(version: "1.0", encoding: "UTF-8")

		xml.CompletionNotification("xmlns:xsi":"http://www.w3.org/2001/XMLSchema-instance",
			Prov_System_TransID:completionNotification.messageId, Master_TransID:completionNotification.transactionId)


		return complNotifXML.toString()
	}
}
