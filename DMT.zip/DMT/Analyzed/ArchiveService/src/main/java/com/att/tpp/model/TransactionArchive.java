package com.att.tpp.model;

import java.io.Serializable;

import javax.persistence.*;

import java.util.Date;


/**
 * The persistent class for the TRANSACTION_ARCHIVE database table.
 * 
 */
@Entity
@Table(name="TRANSACTION_ARCHIVE")
public class TransactionArchive implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@Column(name="MASTER_TRANSID")
	private String masterTransId;
	
	@Id
	@Temporal(TemporalType.TIMESTAMP)
	@Column(name="CREATED_TIMESTAMP")
	private Date createdTimestamp;
	
	@Id
	@Column(name="PROV_SYSTEM_TRANSID")
	private String provSystemTransid;
	
	@Id
	@Column(name="LOCATION")
	private String location;
	
	@Id
	@Temporal(TemporalType.TIMESTAMP)
	@Column(name="EVENT_TIMESTAMP")
	private Date eventTimestamp;
	
	@Id
	@Column(name="MSISDN")
	private String msisdn;
	
	@Id
	@Column(name="CARRIER_NAME")
	private String carrierName;
	
	@Id
	@Column(name="TRANSACTION_MAJOR_CODE")
	private String transactionMajorCode;
	
	@Id
	@Temporal(TemporalType.TIMESTAMP)
	@Column(name="RECEIVED_TRANSACTION")
	private Date receivedTransaction;
	
	@Id
	@Temporal(TemporalType.TIMESTAMP)
	@Column(name="BEGIN_PROCESSING")
	private Date beginProcessing;
	
	@Id
	@Temporal(TemporalType.TIMESTAMP)
	@Column(name="END_PROCESSING")
	private Date endProcessing;
	
	@Id
	@Column(name="PROCESSING_DURATION")
	private String processingDuration;
	
	@Lob
	@Column(name="EVENT_TEXT")
	private String eventText;
	
	@Id
	@Column(name="EVENT_TEXT_OVERFLOW")
	private String eventTextOverflow;
	
	@Id
	@Column(name="ROUTING_CARRIER")
	private String routingCarrier;

	public String getMasterTransId() {
		return masterTransId;
	}

	public void setMasterTransId(String masterTransId) {
		this.masterTransId = masterTransId;
	}

	public Date getCreatedTimestamp() {
		return createdTimestamp;
	}

	public void setCreatedTimestamp(Date createdTimestamp) {
		this.createdTimestamp = createdTimestamp;
	}

	public String getProvSystemTransid() {
		return provSystemTransid;
	}

	public void setProvSystemTransid(String provSystemTransid) {
		this.provSystemTransid = provSystemTransid;
	}

	public String getLocation() {
		return location;
	}

	public void setLocation(String location) {
		this.location = location;
	}

	public Date getEventTimestamp() {
		return eventTimestamp;
	}

	public void setEventTimestamp(Date eventTimestamp) {
		this.eventTimestamp = eventTimestamp;
	}

	public String getMsisdn() {
		return msisdn;
	}

	public void setMsisdn(String msisdn) {
		this.msisdn = msisdn;
	}

	public String getCarrierName() {
		return carrierName;
	}

	public void setCarrierName(String carrierName) {
		this.carrierName = carrierName;
	}

	public String getTransactionMajorCode() {
		return transactionMajorCode;
	}

	public void setTransactionMajorCode(String transactionMajorCode) {
		this.transactionMajorCode = transactionMajorCode;
	}

	public Date getReceivedTransaction() {
		return receivedTransaction;
	}

	public void setReceivedTransaction(Date receivedTransaction) {
		this.receivedTransaction = receivedTransaction;
	}

	public Date getBeginProcessing() {
		return beginProcessing;
	}

	public void setBeginProcessing(Date beginProcessing) {
		this.beginProcessing = beginProcessing;
	}

	public Date getEndProcessing() {
		return endProcessing;
	}

	public void setEndProcessing(Date endProcessing) {
		this.endProcessing = endProcessing;
	}

	public String getProcessingDuration() {
		return processingDuration;
	}

	public void setProcessingDuration(String processingDuration) {
		this.processingDuration = processingDuration;
	}

	public String getEventText() {
		return eventText;
	}

	public void setEventText(String eventText) {
		this.eventText = eventText;
	}

	public String getEventTextOverflow() {
		return eventTextOverflow;
	}

	public void setEventTextOverflow(String eventTextOverflow) {
		this.eventTextOverflow = eventTextOverflow;
	}

	public String getRoutingCarrier() {
		return routingCarrier;
	}

	public void setRoutingCarrier(String routingCarrier) {
		this.routingCarrier = routingCarrier;
	}

	public static long getSerialversionuid() {
		return serialVersionUID;
	}


	
}