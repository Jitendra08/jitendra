package com.att.tpp.model;

import java.io.Serializable;
import javax.persistence.*;

/**
 * The primary key class for the PROVISIONING_TASKS database table.
 * 
 */
@Embeddable
public class ProvisioningTaskPK implements Serializable {
	//default serial version id, required for serializable classes.
	private static final long serialVersionUID = 1L;

	@Column(name="MASTER_TRANSID")
	private String masterTransid;

	@Column(name="TASK_TRANSID")
	private String taskTransid;

	public ProvisioningTaskPK() {
	}
	public String getMasterTransid() {
		return this.masterTransid;
	}
	public void setMasterTransid(String masterTransid) {
		this.masterTransid = masterTransid;
	}
	public String getTaskTransid() {
		return this.taskTransid;
	}
	public void setTaskTransid(String taskTransid) {
		this.taskTransid = taskTransid;
	}
}