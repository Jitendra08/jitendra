package com.att.tpp.controller;

import java.beans.ConstructorProperties;
import java.io.IOException;
import java.math.BigDecimal;
import java.sql.Timestamp;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Collections;
import java.util.Comparator;
import java.util.Date;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.TimeZone;

import javax.jms.JMSException;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.att.tpp.model.ArchiveRequestData;
import com.att.tpp.xml.model.CompletionNotification;
import com.att.tpp.xml.model.TPPCompletionNotification;
import com.att.tpp.model.GatewayArchive;
import com.att.tpp.model.InterfaceArchive;
import com.att.tpp.model.MimToolsInterfaceStat;
import com.att.tpp.model.ProcessingResult;
import com.att.tpp.model.Product;
import com.att.tpp.model.ProductAttribute;
import com.att.tpp.model.ProvisioningRequest;
import com.att.tpp.model.ProvisioningTask;
import com.att.tpp.model.TransCode;
import com.att.tpp.model.TransactionArchive;
import com.att.tpp.service.ArchiveService;
import com.att.tpp.utils.ParseRequestData;

import org.json.JSONObject;
import com.att.aft.dme2.internal.jackson.map.ObjectMapper;

/**
 * @author Satish Gottumukkala May 2014
 * @author Alan Potts June 2014
 * 
 *         ArchiveController handles all the business logic associated with
 *         provisioning request using the archive service.
 */

@Service("archiveController")
public class ArchiveController {

	private static final Logger archiveControllerLog = Logger
			.getLogger(ArchiveController.class);
	private final static String TPP_ArchiveRequesXSD = "TPP_ArchiveRequest.xsd";
	// Not used since we are pulling original XML from gateway_archive
	private final static String TPP_ProvisioningRequestXSD = "TPP_ProvisioningRequest.xsd";
	private final static String TPP_CompletionNotificationXSD = "TPP_CompletionNotification.xsd";

	List<TransCode> transCodes = null;

	@Autowired
	private ArchiveService archiveService;
	
	
private static String enableClob; 
/* US502960 :: WR # 2810221 - Updated to delete valid transactions from Atlas Message Archive table after life cycle is complete. */
	
	@ConstructorProperties({"enableClob"})
	public ArchiveController(String enableClob){
		ArchiveController.enableClob=enableClob;
	}
	
	public static String getEnableClob() {
		return enableClob;
	}

	public static void setEnableClob(String enableClob) {
		ArchiveController.enableClob = enableClob;
	}
	

	/*
	 * Validate the incoming request. If valid and has valid product id insert
	 * into archive table. else drop the request.
	 */

	public ProcessingResult processRequest(String archiveRequestXML,
			String swcTransId) throws IOException, Exception {
		boolean isValidRequest = false;
		boolean isValidTppCompletionNotification = false;
		List<ProvisioningRequest> provisioningRequest = new ArrayList<ProvisioningRequest>();
		List<Product> product = new ArrayList<Product>();
		// Not used since we are pulling the original XML from gateway_archive
		List<ProductAttribute> productAttribute = new ArrayList<ProductAttribute>();
		List<ProvisioningTask> provisioningTasks = new ArrayList<ProvisioningTask>();
		ProcessingResult processingResult = new ProcessingResult();
		Date date = new Date();

		// Validate the request XML
		isValidRequest = archiveService.validateXML(archiveRequestXML,
				TPP_ArchiveRequesXSD);

		archiveControllerLog.info("XML Validation : " + isValidRequest);
		ObjectMapper mapper = new ObjectMapper();
		if (isValidRequest) {
			// Setting the swcTransaction id from the message properties
			// Check if it is used, if not remove the swcTransId
			archiveControllerLog.info("Inside processRequest(), swcTransId : "+swcTransId);
			if (!swcTransId.isEmpty()) {
				processingResult.setSwcTransactionId(swcTransId);
				archiveControllerLog.info("swcTransactionId : "
						+ processingResult.getSwcTransactionId());
			}
			// Parse the archive request
			archiveControllerLog.info("Inside processRequest(), Before parsing XML");
			ArchiveRequestData archiveReqData = parseXMLData(archiveRequestXML);
			archiveControllerLog.info("Inside processRequest(), MasterTransId parsed from XML: "+archiveReqData.getMasterTransactionId());
			processingResult.setMasterTransactionId(archiveReqData
					.getMasterTransactionId());

			archiveControllerLog.info("Master Transaction ID: "
					+ processingResult.getMasterTransactionId());
			// Populating provisioningRequest if master trans id in DB
			provisioningRequest = archiveService.MasterIdInDB(processingResult
					.getMasterTransactionId());
			if ((provisioningRequest != null)
					&& (provisioningRequest.size()) > 0) {
				processingResult.setValidRequest(isValidRequest);
				archiveControllerLog
						.info("Master Transaction is in Provisioning Request table");
				// Grabbing Trans Codes now
				transCodes = (List<TransCode>) archiveService
						.getTransCodes(processingResult
								.getMasterTransactionId());

				// Grabbing Product Table now
				product = (List<Product>) archiveService
						.getProducts(processingResult.getMasterTransactionId());

				// Grabbing Product Attribute Table now
				productAttribute = (List<ProductAttribute>) archiveService
						.getProductAttributes(processingResult
								.getMasterTransactionId());

				// Gathering provisioningTasks
				provisioningTasks = archiveService
						.getProvisioningTask(provisioningRequest.get(0)
								.getMasterTransid());

				archiveControllerLog.debug("transcodes :" + transCodes.size());

				// If no trans codes are present, populating with dummy data
				if (transCodes == null || transCodes.isEmpty()) {
					archiveControllerLog
							.info("No transcodes found. Inserting dummy transaction");

					/* transCodes = new ArrayList<TransCodes>(); */
					TransCode dummyTransCode = new TransCode();
					dummyTransCode.setMasterTransid(processingResult
							.getMasterTransactionId().trim());
					// dummyTransCode.setTaskTransId(processingResult.getSwcTransactionId().trim());

					dummyTransCode.setTaskTransid(getTaskTransId(provisioningTasks));
					dummyTransCode.setMajorcode("72000");
					dummyTransCode.setMajordesc("Fatal Technical Error");
					dummyTransCode.setMinorcode("72500");
					dummyTransCode
							.setMinordesc("Fatal Exception occurred during provisioning");
					dummyTransCode.setAction("N/A");
					dummyTransCode.setProductId("N/A");
					dummyTransCode.setErrorTime(new Timestamp(date.getTime()));
					transCodes.add(dummyTransCode);
					boolean isSuccess = archiveService
							.insertDummyTransCode(dummyTransCode);
					if (!isSuccess) {
						archiveControllerLog
								.error("insertDummyTransCode failed with : "
										+ transCodes);
						processingResult.setInsertDummyTransaction(false);
						return processingResult;
					}
					archiveControllerLog.debug("transCodes dummy inserted : "
							+ transCodes);
				}

				archiveControllerLog.debug("Checking on our data now....");
				
				// List for last error trans codes based on date

				List<TransCode> lastErrorCodeTransCodes = new ArrayList<TransCode>();
				// Creating a hashset of all trans_codes that are unique
				HashSet<TransCode> hs = new HashSet<TransCode>();
				hs.addAll(transCodes);

				lastErrorCodeTransCodes.addAll(hs);
				
				Iterator<TransCode> lECTIterator = lastErrorCodeTransCodes.iterator();
				
				while (lECTIterator.hasNext()) {
					TransCode transCodes = lECTIterator.next();
					/* Removing Post Successful transcode entry to avoid errorTimestamp conflict with Async success response transcode entry*/
					if ((transCodes.getMajordesc()
							.contains("HTTP Post Successful to"))) {
						archiveControllerLog
								.debug("Removing object from lastErrorCodeTransCodes");
						lECTIterator.remove();
					}
				}
				/******************************** BEGIN ***************************************************************************************** 
				*Commented after discussing with MikeP and SocratesC because we need to have latest error code received from vendor to be archived. 				 
				*********************************************************************************************************************************/				
//				else {
//						if (dateString == null) {
//							dateString = transCodes.getErrorTime();
//						} else if (transCodes.getErrorTime().after(dateString)) {
//							dateString = transCodes.getErrorTime();
//						}}
//				}
//				archiveControllerLog.debug("Max date on trans_codes is: "+ dateString);

				// Now removing all older transactions from
				// lastErrorCodeTransactions
//				lECTIterator = lastErrorCodeTransCodes.iterator();
//
//				while (lECTIterator.hasNext()) {
//
//					TransCode transCodes = lECTIterator.next();
				
//
//					if (transCodes.getErrorTime().before(dateString)) {
//						archiveControllerLog
//								.debug("Removing transaction from lastErrorCodeTransCodes. Error date is older then most current");
//						lECTIterator.remove();
//					}
//				}
				/******************************** END ***************************************************************************************** 
				*Commented after discussing with MikeP and SocratesC because we need to have latest error code received from vendor to be archived.  
				*********************************************************************************************************************************/
					
				/******************************** BEGIN CODE FIX *****************************************************************************************
				 * Fix for WR# 2740833 - Transactions are archiving with incorrect Error Code
				 * Fix for WR# 2704575 - Transaction has two product_id but it is archiving one product only
				 ****************************************************************************************************************************************/
				TransCode transCode = null;

				archiveControllerLog.info("lastErrorCodeTransCodes size : "+ lastErrorCodeTransCodes.size());
				/* Commented because we used it for Unit Testing only for displaying unsorted transcodes list */
//				for (Iterator<TransCode> iterator = lastErrorCodeTransCodes.iterator(); iterator.hasNext();) {
//					transCode = (TransCode) iterator.next();
//					archiveControllerLog.info("lastErrorCodeTransCodes list before --> TaskId : "+transCode.getTaskTransid()+" minorDesc : "+transCode.getMinordesc()+" errorTime : "+transCode.getErrorTime());				
//					}

				List<TransCode> bufferTaskIdTransCodes = new ArrayList<TransCode>();
				Map<String, List<TransCode>> transMap = new HashMap<String, List<TransCode>>();
				
				String prodIdTaskIdKey = null;
				
				/* Looping through the unsorted transcodes list and adding to List on hashmap based on Key:taskId */
				for (Iterator<TransCode> iterator = lastErrorCodeTransCodes.iterator(); iterator.hasNext();) {
						transCode = (TransCode) iterator.next();
						archiveControllerLog.debug("Current iterator --> TaskId : "+transCode.getTaskTransid()+" minorDesc : "+transCode.getMinordesc()+" errorTime : "+transCode.getErrorTime());
						prodIdTaskIdKey = transCode.getTaskTransid()+"_group_"+transCode.getProductId()+"_action_"+transCode.getAction(); /* Generating key based on Task Trans ID and product ID for each entry in transcodes list */
						addToMap(transMap, prodIdTaskIdKey, transCode); /* Adding transcode object to hashmap based on Task Trans ID and product ID as key */
						archiveControllerLog.info("Added to Hashmap --> prodIdTaskIdKey : "+prodIdTaskIdKey+" minorDesc : "+transCode.getMinordesc()+" errorTime : "+transCode.getErrorTime());						
					}
					
					lastErrorCodeTransCodes.clear(); /* Clearing all entries in transcodes list as we backed it up in Hashmap */
					archiveControllerLog.debug("lastErrorCodeTransCodes size : "+ lastErrorCodeTransCodes.size());
					
				/* Looping through the hashmap based on Key:taskId and sorting list based on Error Time Descending */
				for (Map.Entry<String, List<TransCode>> entry : transMap.entrySet()) {
						bufferTaskIdTransCodes = entry.getValue();
						Collections.sort(bufferTaskIdTransCodes, new Comparator<TransCode>(){public int compare(TransCode t1, TransCode t2){return t2.getErrorTime().compareTo(t1.getErrorTime());}});
						lastErrorCodeTransCodes.add(bufferTaskIdTransCodes.get(0)); /* Adding latest error code entry to lastErrorCodeTransCodes */
						archiveControllerLog.info("Added to lastErrorCodeTransCodes --> TaskId : "+bufferTaskIdTransCodes.get(0).getTaskTransid()+" ProductID : "+bufferTaskIdTransCodes.get(0).getProductId()+" ActionType : "+bufferTaskIdTransCodes.get(0).getAction()+" minorDesc : "+bufferTaskIdTransCodes.get(0).getMinordesc()+" errorTime : "+bufferTaskIdTransCodes.get(0).getErrorTime());
						bufferTaskIdTransCodes.clear(); /* Clearing entries in bufferTaskIdTransCodes list as we already added to lastErrorCodeTransCodes */
					}
					archiveControllerLog.info("lastErrorCodeTransCodes size : "+ lastErrorCodeTransCodes.size());
					
					/* Commented because we used it for Unit Testing only for displaying sorted transcodes list */					
//					for (Iterator<TransCode> iterator = lastErrorCodeTransCodes.iterator(); iterator.hasNext();) {
//						transCode = (TransCode) iterator.next();
//						archiveControllerLog.info("lastErrorCodeTransCodes list After --> TaskId : "+transCode.getTaskTransid()+" minorDesc : "+transCode.getMinordesc()+" errorTime : "+transCode.getErrorTime());				
//						}
				
					/******************************** END CODE FIX *****************************************************************************************
					 * Fix for WR# 2740833 - Transactions are archiving with incorrect Error Code
					 * Fix for WR# 2704575 - Transaction has two product_id but it is archiving only one product_id
					 ****************************************************************************************************************************************/
				archiveControllerLog.debug("New lastErrorCodeTransCodes size : "+ lastErrorCodeTransCodes.size());
				
				// List of all unique productId Action pairs

				// TODO Not sure if I need this logic anymore
				/*
				 * List<ProductActionType> productActionType = new
				 * ArrayList<ProductActionType>();
				 * 
				 * for (int i = 0; i < transCodes.size(); i++) {
				 * ProductActionType pATObject = new ProductActionType(); //
				 * Logic to populate productActionType list if
				 * (productActionType.isEmpty()) { if
				 * (transCodes.get(i).getErrorTime().equals(dateString)) {
				 * 
				 * pATObject.setTaskTransId(transCodes.get(i)
				 * .getTaskTransId()); pATObject.setProductId(transCodes.get(i)
				 * .getProductId());
				 * pATObject.setAction(transCodes.get(i).getAction());
				 * productActionType.add(pATObject);
				 * 
				 * archiveControllerLog.debug("Added taskTransId: " +
				 * pATObject.getTaskTransId() + ", productId: " +
				 * pATObject.getProductId() + ", action : " +
				 * pATObject.getAction()); } } else { if
				 * (transCodes.get(i).getErrorTime().equals(dateString)) {
				 * pATObject.setTaskTransId(transCodes.get(i)
				 * .getTaskTransId()); pATObject.setProductId(transCodes.get(i)
				 * .getProductId());
				 * pATObject.setAction(transCodes.get(i).getAction());
				 * 
				 * int pATFound = 0; for (int i2 = 0; i2 <
				 * productActionType.size(); i2++) {
				 * 
				 * if (productActionType .get(i2) .getTaskTransId() .trim()
				 * .equals(pATObject.getTaskTransId() .trim()) &&
				 * productActionType .get(i2) .getProductId() .trim()
				 * .equals(pATObject .getProductId().trim()) &&
				 * productActionType .get(i2) .getAction() .trim()
				 * .equals(pATObject.getAction() .trim())) { pATFound = 1; } }
				 * 
				 * if (pATFound == 0) {
				 * 
				 * productActionType.add(pATObject);
				 * 
				 * System.out .println("Added taskTransId : " +
				 * pATObject.getTaskTransId() + ", productId: " +
				 * pATObject.getProductId() + ", action : " +
				 * pATObject.getAction()); } } }
				 * 
				 * archiveControllerLog.debug(transCodes.get(i).getTaskTransId()
				 * + "||" + transCodes.get(i).getErrorTime() + "||" +
				 * transCodes.get(i).getProductId() + "||" +
				 * transCodes.get(i).getAction() + "||" +
				 * transCodes.get(i).getMajorCode() + "||" +
				 * transCodes.get(i).getMajorDesc() + "||" +
				 * transCodes.get(i).getMinorCode() + "||" +
				 * transCodes.get(i).getMajorDesc()); }
				 */

				// Iteration for insert to update_interface
				// Check this logic

				lECTIterator = lastErrorCodeTransCodes.iterator();

				while (lECTIterator.hasNext()) {

					TransCode transCodes = lECTIterator.next();

					InterfaceArchive iAObject = new InterfaceArchive();

					archiveControllerLog
							.debug("Preparing insert statement for interface_archive");
					iAObject.setEventTimestamp(new Timestamp(date.getTime()));
					archiveControllerLog.debug("Timestamp : "
							+ iAObject.getEventTimestamp());
					iAObject.setLocation(provisioningRequest.get(0)
							.getLocation().trim());
					archiveControllerLog.debug("Location : "
							+ iAObject.getLocation());
					iAObject.setMasterTransid(provisioningRequest.get(0)
							.getMasterTransid().trim());
					archiveControllerLog.debug("Master Trans Id : "
							+ iAObject.getMasterTransid().trim());
					iAObject.setProductId(transCodes.getProductId().trim());
					archiveControllerLog.debug("Product Id : "
							+ iAObject.getProductId().trim());
					iAObject.setAction(transCodes.getAction().trim());
					archiveControllerLog.debug("Action : "
							+ iAObject.getAction());
					String taskId = transCodes.getTaskTransid().trim();
					String interfaceName = "";
					if (taskId.contains("$")){
						interfaceName = taskId.substring(taskId.lastIndexOf("_") + 1, taskId.indexOf("$"));
					} else {
						interfaceName = "Unknown";
					}
					iAObject.setInterfaceName(interfaceName.trim());
					archiveControllerLog.debug("Interface Name : "
							+ iAObject.getInterfaceName().trim());
					iAObject.setCarrierName(provisioningRequest.get(0)
							.getProvisioningCarrier().trim());
					archiveControllerLog.debug("Carrier Name : "
							+ iAObject.getCarrierName().trim());
					iAObject.setErrorTimeStamp(transCodes.getErrorTime());
					archiveControllerLog.debug("Error Timestamp : "
							+ iAObject.getErrorTimeStamp());
					iAObject.setMinorErrorCode(transCodes.getMinorcode().trim());
					archiveControllerLog.debug("Minor Code : "
							+ iAObject.getMinorErrorCode().trim());
					// This logic is to cut any minor description lengths to 255
					// or set to success if empty
					archiveControllerLog
							.debug("Minor Error Code Description Length: "
									+ transCodes.getMinordesc().trim());
					if (transCodes.getMinordesc() == null
							|| transCodes.getMinordesc().length() == 0) {
						iAObject.setMinorErrorDescription("Success");
					} else if (transCodes.getMinordesc().length() > 255) {
						iAObject.setMinorErrorDescription(transCodes
								.getMinordesc().substring(0, 255).trim());
					} else {
						iAObject.setMinorErrorDescription(transCodes
								.getMinordesc().trim());
					}

					archiveControllerLog.debug("Minor Code Description : "
							+ iAObject.getMinorErrorDescription());
					iAObject.setRoutingCarrier(provisioningRequest.get(0)
							.getRoutingCarrier().trim());
					archiveControllerLog.debug("Routing Carrier : "
							+ iAObject.getRoutingCarrier().trim());

					// TODO Need to verify logic for post count
					Iterator<ProvisioningTask> pTIterator = provisioningTasks
							.iterator();

					while (pTIterator.hasNext()) {

						ProvisioningTask provTasks = pTIterator.next();

						if (transCodes.getTaskTransid().equals(
								provTasks.getId().getTaskTransid())) {
							if (provTasks.getCurrTechRetryCount().add(provTasks.getCurrNoRespRetryCount()).equals(BigDecimal.ZERO)) {
								iAObject.setPostCount(BigDecimal.ONE);
								archiveControllerLog.debug("Post Count : "
										+ iAObject.getPostCount());
							} else if (provTasks.getCurrTechRetryCount().equals(BigDecimal.ZERO)) {
								iAObject.setPostCount(provTasks
										.getCurrNoRespRetryCount().add(BigDecimal.ONE));
								archiveControllerLog.debug("Post Count : "
										+ iAObject.getPostCount());
							} else {
								iAObject.setPostCount(provTasks.getCurrTechRetryCount().add(
										provTasks.getCurrNoRespRetryCount()).add(BigDecimal.ONE)
								);
								archiveControllerLog.debug("Post Count : "
										+ iAObject.getPostCount());
							}
						}

					}

					boolean interfaceArchiveSuccessful = archiveService
							.insertInterfaceArchive(iAObject);
					if (!interfaceArchiveSuccessful) {
						archiveControllerLog
								.error("Update to interface_archive unsuccessful for master_transid : "
										+ iAObject.getMasterTransid()
										+ " ProductId : "
										+ iAObject.getProductId()
										+ " Action : " + iAObject.getAction());
						processingResult.setInsertInterfaceArchive(false);
						return processingResult;
					} else {
						archiveControllerLog.info("{"+mapper.writeValueAsString(iAObject)+"}");
						processingResult.setInsertInterfaceArchive(true);
					}
				}

				// Setting up update to mim_tools_interface_stats
				Map<String, Integer> productCount = new HashMap<String, Integer>();
				archiveControllerLog
						.debug("Preparing insert statement for mim_tools_interface_status. Number of products: "
								+ product.size());

				Iterator<Product> pIterator = product.iterator();
				while (pIterator.hasNext()) {

					Product prdct = pIterator.next();

					String productName = prdct.getTaskTransid().substring(
							prdct.getTaskTransid().lastIndexOf("_") + 1,
							prdct.getTaskTransid().indexOf("$"));
					archiveControllerLog.debug("Product Name is: "
							+ productName);
					if (productCount.containsKey(productName)) {

						productCount.put(productName,
								productCount.get(productName) + 1);
						archiveControllerLog.debug("Product Name exists in productCount. New Count: "
										+ productCount.get(productName));
					} else {
						archiveControllerLog.debug("Product Name does not exist in productCount.");
						productCount.put(productName, 1);
					}

				}

				archiveControllerLog.debug("Product Count : "
						+ productCount.size());

				// Starting insert loop for mim_tools_interface_status
				archiveControllerLog
						.debug("Inserting into MIM_TOOLS_INTERFACE_STATUS");
				@SuppressWarnings("rawtypes")
				Iterator it = productCount.entrySet().iterator();

				while (it.hasNext()) {

					@SuppressWarnings("rawtypes")
					Map.Entry pairs = (Map.Entry) it.next();
					MimToolsInterfaceStat mimInsertObject = new MimToolsInterfaceStat();

					mimInsertObject.setTimestamp(new Timestamp(date.getTime()));
					archiveControllerLog.debug("Timestamp : "
							+ mimInsertObject.getTimestamp());
					mimInsertObject.setCarrierName(provisioningRequest.get(0)
							.getProvisioningCarrier().trim());
					archiveControllerLog.debug("Carrier Name : "
							+ mimInsertObject.getCarrierName().trim());
					mimInsertObject.setLocation(provisioningRequest.get(0)
							.getLocation().trim());
					archiveControllerLog.debug("Location : "
							+ mimInsertObject.getLocation().trim());
					mimInsertObject.setMasterTransid(provisioningRequest.get(0)
							.getMasterTransid().trim());
					archiveControllerLog.debug("Master Trans Id : "
							+ mimInsertObject.getMasterTransid().trim());
					mimInsertObject.setInterfaceName(pairs.getKey().toString()
							.trim());
					archiveControllerLog.debug("Interface Name : "
							+ mimInsertObject.getInterfaceName().trim());
					mimInsertObject.setTransCount(new BigDecimal(pairs.getValue().toString()));
					archiveControllerLog.debug("Trans Count : "
							+ mimInsertObject.getTransCount());
					mimInsertObject.setRoutingCarrier(provisioningRequest
							.get(0).getRoutingCarrier().trim());
					archiveControllerLog.debug("Routing Carrier : "
							+ mimInsertObject.getRoutingCarrier().trim());

					boolean insertMimToolsInterfaceStatusSucces = archiveService
							.insertMimToolsInterfaceStat(mimInsertObject);

					if (!insertMimToolsInterfaceStatusSucces) {
						archiveControllerLog
								.error("Insert into MIM_TOOLS_INTERFACE_STATUS failed for MasterTransId : "
										+ provisioningRequest.get(0)
												.getMasterTransid());
						processingResult.setInsertMimToolsInterface(false);
						return processingResult;
					} else {
						processingResult.setInsertMimToolsInterface(true);
					}

				}

				// Get original XML from event_text from gateway_archive
				List<GatewayArchive> gatewayArchive = archiveService
						.getGatewayArchive(provisioningRequest.get(0)
								.getProvSystemTransid());
				
			   //Verify record exist and set the tppProvisioningRequestXML				
				String tppProvisioningRequestXML = null;
				
				if (gatewayArchive.size() > 0) {					
					tppProvisioningRequestXML = gatewayArchive.get(0).getEventText();
				}else{
					tppProvisioningRequestXML="NoGatwayRecord";
					archiveControllerLog.info("GatewayArchive has no record of this transaction.***NoRecord");
				}
				    processingResult.setValidGatewayArchive(true);
					archiveControllerLog.debug("Original XML --->"+ tppProvisioningRequestXML.toString());

					// TODO UpdateTransactionArchive

					TransactionArchive transactionArchive = new TransactionArchive();
					Date currentTimestamp = new Timestamp(date.getTime());
					transactionArchive.setMasterTransId(provisioningRequest
							.get(0).getMasterTransid().trim());
					transactionArchive.setCreatedTimestamp(currentTimestamp);
					transactionArchive.setProvSystemTransid(provisioningRequest
							.get(0).getProvSystemTransid().trim());
					transactionArchive.setLocation(provisioningRequest.get(0)
							.getLocation().trim());
					transactionArchive.setEventTimestamp(currentTimestamp);
					transactionArchive.setMsisdn(provisioningRequest.get(0)
							.getMsisdn().trim());
					transactionArchive.setCarrierName(provisioningRequest
							.get(0).getProvisioningCarrier().trim());

					// TODO Verify if logic is right for max error code
					String majorCode = null;

					Iterator<TransCode> tIterator = transCodes.iterator();

					while (tIterator.hasNext()) {

						TransCode transC = tIterator.next();

						if (majorCode == null) {
							majorCode = transC.getMajorcode();
						} else if (Integer.parseInt(majorCode) < Integer
								.parseInt(transC.getMajorcode())) {
							majorCode = transC.getMajorcode();
						}
					}
					transactionArchive.setTransactionMajorCode(majorCode);

					transactionArchive
							.setReceivedTransaction(provisioningRequest.get(0)
									.getReceivedTimeStamp());
					transactionArchive.setBeginProcessing(provisioningRequest
							.get(0).getBeginProcessingTime());
					transactionArchive.setEndProcessing(currentTimestamp);

					// Getting processing time
					String processingDuration = Long.toString(currentTimestamp
							.getTime()
							- provisioningRequest.get(0)
									.getBeginProcessingTime().getTime());
					transactionArchive
							.setProcessingDuration(processingDuration);
/*
 * xml size check part is commented as we moved the column EVENT_TEXT from VARCHAR2 to CLOB 
 */
					// Checking Original XML for length. If longer than 4000,
					// breaking it up
			/*		if (tppProvisioningRequestXML.length() > 4000) {
						
						transactionArchive.setEventText(tppProvisioningRequestXML.substring(0, 4000).trim());
			*/			
						/*
						 * It seems in production the XML sizes have become larger than an 8000 character string.
						 * Archive service throws the below exception.  Very cryptic but some research found talks about converting on the fly.
						 * I believe since the length of the remaining string is greater than 4000 characters the underlying code tries to do a conversion and fails
						 * Thus the message below:
						 * 
						 * WARN [org.hibernate.util.JDBCExceptionReporter] - SQL Error: 1460, SQLState: 72000
						 * ERROR [org.hibernate.util.JDBCExceptionReporter] - ORA-01460: unimplemented or unreasonable conversion requested
						 * 
						 * Fix hard code the exact length of the overflow.  This might cut some long XMLs but should prevent the error.
						 * Other solutions would be to convert the column to a CLOB, but I think that will impact the performance of the Archive service for large XMLs.
						 * 
						 */
						
						
				/*		if(tppProvisioningRequestXML.length() > 8000){
							archiveControllerLog.info("Length of XML is greater than 8000 characters!");
							archiveControllerLog.info("Length of XML= " + tppProvisioningRequestXML.length());
							transactionArchive.setEventTextOverflow(tppProvisioningRequestXML.substring(4001, 8000).trim());
						}
						else{
							archiveControllerLog.info("Length of XML is greater than 4000 BUT less than 8000 characters!");
							archiveControllerLog.info("Length of XML = " + tppProvisioningRequestXML.length());
							transactionArchive.setEventTextOverflow(tppProvisioningRequestXML.substring(4001, tppProvisioningRequestXML.length()).trim());
						}
						
						
					} else {
						archiveControllerLog.info("Length of XML = " + tppProvisioningRequestXML.length());
						transactionArchive
								.setEventText(tppProvisioningRequestXML.trim());
					} */
					
					transactionArchive.setEventText(tppProvisioningRequestXML.trim());
					
					transactionArchive.setRoutingCarrier(provisioningRequest
							.get(0).getRoutingCarrier().trim());

					boolean isTransactionArchiveSuccessful = archiveService
							.updateTransactionArchive(transactionArchive);

					if (isTransactionArchiveSuccessful) {
						processingResult.setUpdateTransactionArchive(true);
					} else {
						archiveControllerLog
								.error("Insert into Transaction Archive has failed. : "
										+ transactionArchive.toString());
						processingResult.setUpdateTransactionArchive(false);
						return processingResult;
					}

					// TODO Deletion process
					archiveControllerLog
							.info("Starting deletion process for request : "
									+ provisioningRequest.get(0)
											.getMasterTransid());
					
				
					
					boolean isSuccess = false;
					/* US502960 :: WR # 2810221 - Updated to delete valid transactions from Atlas Message Archive table after life cycle is complete */
					if(ArchiveController.getEnableClob().equalsIgnoreCase("Y") || ArchiveController.getEnableClob().equalsIgnoreCase("TRUE")){
						archiveControllerLog.info("enableClob property is true, transaction not Deleted from AtlasMessageArchive");
						isSuccess = true;
					}
					else{
						archiveControllerLog.debug("Routing Carrier :: "+transactionArchive.getRoutingCarrier());
						if(	(transactionArchive.getRoutingCarrier().contains("CNGLR"))	
								|| (transactionArchive.getRoutingCarrier().equalsIgnoreCase("CSI")) ){
							archiveControllerLog.info("SWC or CSI inbound is not inserted into AtlasMessageArchive");
							isSuccess = true;
						}
						else{
					isSuccess = archiveService
							.deleteFromAtlasMessageArchive(provisioningRequest
									.get(0).getProvSystemTransid());					
					archiveControllerLog
							.info("Deleted from AtlasMessageArchive : "
									+ isSuccess);
						}
					}
					
					processingResult
					.setDeletedFromAtlasMessageArchive(isSuccess);

					isSuccess = archiveService
							.deleteFromProvisioningRequests(provisioningRequest
									.get(0).getMasterTransid());
					processingResult
							.setDeletedFromProvisioningRequests(isSuccess);
					archiveControllerLog
							.info("Deleted from ProvisioningRequests : "
									+ processingResult
											.isDeletedFromProvisioningRequests());

					isSuccess = archiveService
							.deleteFromProvisioningTasks(provisioningRequest
									.get(0).getMasterTransid());
					processingResult.setDeletedFromProvisioningTasks(isSuccess);
					archiveControllerLog
							.info("Deleted from ProvisioningTasks : "
									+ processingResult
											.isDeletedFromProvisioningTasks());

					isSuccess = archiveService
							.deleteFromTransCodes(provisioningRequest.get(0)
									.getMasterTransid());
					processingResult.setDeletedFromTransCodes(isSuccess);
					archiveControllerLog.info("Deleted from TransCodes : "
							+ processingResult.isDeletedFromTransCodes());

					isSuccess = archiveService.updateTimer(provisioningRequest
							.get(0).getProvSystemTransid());
					processingResult.setTimerUpdate(isSuccess);
					archiveControllerLog.info("Updated Timer : "
							+ processingResult.isTimerUpdate());

					isSuccess = archiveService
							.deleteFromProduct(provisioningRequest.get(0)
									.getMasterTransid());
					processingResult.setDeletedFromProducts(isSuccess);
					archiveControllerLog.info("Deleted from Product : "
							+ processingResult.isDeletedFromProducts());

					isSuccess = archiveService
							.deleteFromProductAttribute(provisioningRequest
									.get(0).getMasterTransid());
					processingResult.setDeletedFromProductAttribute(isSuccess);
					archiveControllerLog
							.info("Deleted from ProductAttribute : "
									+ processingResult
											.isDeletedFromProductAttribute());

					if (processingResult.isDeletedFromProvisioningRequests()
							&& processingResult.isDeletedFromAtlasMessageArchive()
							&& processingResult.isDeletedFromProvisioningTasks()
							&& processingResult.isDeletedFromTransCodes()
							&& processingResult.isTimerUpdate()
							&& processingResult.isDeletedFromProducts()
							&& processingResult.isDeletedFromProductAttribute()) {
						processingResult.setDeletedFromDB(true);
					} else {
						archiveControllerLog
								.error("Error processing record deletion from tables");

						processingResult.setDeletedFromDB(false);
						return processingResult;
					}

					// Generate XML for Gateway Confirmation
					CompletionNotification completionNotification = new CompletionNotification();
					completionNotification.setMessageId(provisioningRequest
							.get(0).getProvSystemTransid());
					completionNotification.setTransactionId(processingResult
							.getMasterTransactionId());
					TPPCompletionNotification TPPCompletionNotification = new TPPCompletionNotification(
							completionNotification);

					String tppCompletionNotificationXML = archiveService
							.createCompletionNotificationXML(TPPCompletionNotification);

					processingResult
							.setTppCompletionNotification(tppCompletionNotificationXML);
					archiveControllerLog.debug("tppCompletionNotification --->"
							+ tppCompletionNotificationXML.toString());
					isValidTppCompletionNotification = archiveService
							.validateXML(tppCompletionNotificationXML,
									TPP_CompletionNotificationXSD);
					archiveControllerLog
							.debug("isValidTppCompletionNotification:"
									+ isValidTppCompletionNotification);
					processingResult
							.setValidTppCompletionNotification(isValidTppCompletionNotification);

/*				} else {
					archiveControllerLog
							.error("GatewayArchive has no record of this transaction");
					//processingResult.setValidGatewayArchive(false);
					return processingResult;
				}*/

			} else {
				archiveControllerLog
						.info("Invalid Archive Request, Dropping the Transaction");
				processingResult
						.setValidTppCompletionNotification(isValidTppCompletionNotification);
			}
		}
		return processingResult;
	}
	

	/*
	 * Add the transcode object to the List on the Map based on combined key of taksTransID,productId and action
	 * If taskTransId does not new key, value pair
	 * Else add the transcode object to existing list based on key
	 */
	
	public void addToMap(Map <String, List<TransCode>> map, String key, TransCode value){
		  if(!map.containsKey(key)){
		    map.put(key, new ArrayList<TransCode>());
		  }
		  map.get(key).add(value);
	}


	/*
	 * Parse the provisioning request XML and capture values in the
	 * ArchiveRequestData
	 */
	private ArchiveRequestData parseXMLData(String archiveRequestXML) {
		ParseRequestData parseRequestData = new ParseRequestData();
		ArchiveRequestData archiveReqData = parseRequestData
				.archiveReqMasterTransactionId(archiveRequestXML);
		archiveControllerLog.debug("Master TransactionId :"
				+ archiveReqData.getMasterTransactionId());
		return archiveReqData;
	}

	private String getTaskTransId(List<ProvisioningTask> provisioningTask) {
		// Get the TraskTransId from the ProvisioningTasks
		String taskTransIdForDummy = "";
		for (ProvisioningTask provisioningTask2 : provisioningTask) {
			if (provisioningTask2.getId().getTaskTransid()
					.contains("$")) {
				taskTransIdForDummy = provisioningTask2.getId().getTaskTransid();
			}
		}
		return taskTransIdForDummy;
	}
	
	public String getDateWithGMTFormat(){
        Calendar currentTimeStamp = Calendar.getInstance();
        Date strCurrTime = currentTimeStamp.getTime();
        SimpleDateFormat sdf = new SimpleDateFormat("yyyy/MM/dd HH:mm:ss z");
        sdf.setTimeZone(TimeZone.getTimeZone("GMT"));
        String strDate = null;
        try {
        strDate = sdf.format(strCurrTime);
        archiveControllerLog.info("SimpleDateFormat : "+strDate);
        } catch (Exception e) {
        e.printStackTrace();
        }
        return strDate;
    }
   

}
