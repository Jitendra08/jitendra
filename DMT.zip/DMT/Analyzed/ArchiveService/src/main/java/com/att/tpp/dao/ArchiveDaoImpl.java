package com.att.tpp.dao;

import java.util.List;

import org.apache.log4j.Logger;
import org.hibernate.HibernateException;
import org.hibernate.Query;
import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.att.tpp.model.InterfaceArchive;
import com.att.tpp.model.MimToolsInterfaceStat;
import com.att.tpp.model.Product;
import com.att.tpp.model.ProductAttribute;
import com.att.tpp.model.ProvisioningRequest;
import com.att.tpp.model.ProvisioningTask;
import com.att.tpp.model.TransCode;
import com.att.tpp.model.GatewayArchive;
import com.att.tpp.model.TransactionArchive;

/**
 * @author Satish Gottumukkala June 2014
 * @author Alan Potts June 2014
 * 
 *         ArchiveDaoImpl handle to retrieve data from tpp_config schema tables.
 *         and insert or delete data from the tpp_archive schema tables.
 */

@Repository("archiveDao")
public class ArchiveDaoImpl implements ArchiveDao {

	private static final Logger archiveDaoLog = Logger
			.getLogger(ArchiveDaoImpl.class);

	@Autowired
	private SessionFactory sessionFactoryData;

	@Autowired
	private SessionFactory sessionFactoryArchive;

	@SuppressWarnings("unchecked")
	@Override
	@Transactional
	public List<ProvisioningRequest> masterTransactionInDB(String masterTransid)
			throws Exception {
		archiveDaoLog
				.debug("Inside the transactionInDB and passed masterTransid:"
						+ masterTransid);

		List<ProvisioningRequest> masterTransIdList = (List<ProvisioningRequest>) sessionFactoryData
				.getCurrentSession()
				.createQuery(
						"FROM ProvisioningRequest WHERE masterTransid = :masterTransid")
				.setParameter("masterTransid", masterTransid).list();
		archiveDaoLog.debug("Returned from masterTransactionInDB HQL: "
				+ masterTransIdList.size());

		return masterTransIdList;
	}

	@Override
	@SuppressWarnings("unchecked")
	@Transactional
	public List<TransCode> getTransCodes(String masterTransid)
			throws Exception {
		List<TransCode> transCodes=null;
		archiveDaoLog.debug("Inside the getTransCodes DAO Impl");
		transCodes = (List<TransCode>) sessionFactoryData
				.getCurrentSession()
				.createQuery(
						"FROM TransCode WHERE masterTransid = :masterTransid")
				.setParameter("masterTransid", masterTransid).list();
		archiveDaoLog.debug("Returned from getTransCodes HQL: "
				+ transCodes.size());
		return transCodes;
	}

	@Override
	@Transactional
	public Boolean insertDummyTransCode(TransCode transCodes)
			throws Exception {
		archiveDaoLog.debug("Inside the insertDummyTransCode");

		try {
			sessionFactoryData.getCurrentSession().saveOrUpdate(transCodes);
			sessionFactoryData.getCurrentSession().flush();
			return true;
		} catch (HibernateException he) {
			archiveDaoLog
					.error("Hibernate Exception occured occured inserting into TransCode Table: "
							+ he.getMessage());
			return false;
		}
	}

	@SuppressWarnings("unchecked")
	@Override
	@Transactional
	public List<Product> getProducts(String masterTransactionId) {
		archiveDaoLog.debug("Inside the getProducts DAO Impl");
		List<Product> products = (List<Product>) sessionFactoryData
				.getCurrentSession()
				.createQuery("FROM Product WHERE taskTransid like :transId")
				.setParameter("transId", masterTransactionId + "%").list();
		archiveDaoLog
				.debug("Returned from getProducts HQL: " + products.size());
		return products;
	}

	@SuppressWarnings("unchecked")
	@Override
	@Transactional
	public List<ProductAttribute> getProductAttributes(
			String masterTransactionId) {
		archiveDaoLog.debug("Inside the getProductAttributes DAO Impl");
		List<ProductAttribute> productAttributes = (List<ProductAttribute>) sessionFactoryData
				.getCurrentSession()
				.createQuery(
						"FROM ProductAttribute WHERE taskTransid like :transId")
				.setParameter("transId", masterTransactionId).list();
		archiveDaoLog.debug("Returned from getProductAttributes HQL: "
				+ productAttributes.size());
		return productAttributes;
	}

	@Override
	@Transactional
	public boolean insertInterfaceArchive(InterfaceArchive iAObject) {
		archiveDaoLog.debug("Inside the insertInterfaceArchive");

		try {
			sessionFactoryArchive.getCurrentSession().saveOrUpdate(
					iAObject);
			sessionFactoryArchive.getCurrentSession().flush();
			return true;
		} catch (HibernateException he) {
			archiveDaoLog
					.error("Hibernate Exception occured occured inserting into InterfaceArchive Table: "
							+ he.getMessage());
			return false;
		}

	}

	@Override
	@Transactional
	public boolean insertMimInterfaceStat(
			MimToolsInterfaceStat mimInsertObject) {
		archiveDaoLog.debug("Inside the insertMimInterfaceStatus");

		try {
			sessionFactoryArchive.getCurrentSession().saveOrUpdate(
					mimInsertObject);
			sessionFactoryArchive.getCurrentSession().flush();
			return true;
		} catch (HibernateException he) {
			archiveDaoLog
					.error("Hibernate Exception occured occured inserting into MimToolsInterfaceStatus Table: "
							+ he.getMessage());
			return false;
		}

	}

	@SuppressWarnings("unchecked")
	@Override
	@Transactional
	public List<ProvisioningTask> getProvisioningTask(String masterTransid) {
		archiveDaoLog.debug("Inside the getProvisioningTasks DAO Impl");
		List<ProvisioningTask> provisioningTask = (List<ProvisioningTask>) sessionFactoryData
				.getCurrentSession()
				.createQuery(
						"from ProvisioningTask pt where pt.id.masterTransid = :masterTransid")
				.setParameter("masterTransid", masterTransid).list();
		archiveDaoLog.debug("Returned from getProvisioningTasks HQL: "
				+ provisioningTask.size());
		return provisioningTask;
	}

	@Override
	@Transactional
	public boolean updateTransactionArchive(
			TransactionArchive transactionArchive) {
		try {
			sessionFactoryArchive.getCurrentSession().saveOrUpdate(
					transactionArchive);
			sessionFactoryArchive.getCurrentSession().flush();
			return true;
		} catch (HibernateException he) {
			archiveDaoLog
					.error("Hibernate Exception occured occured inserting into transactionArchive Table: "
							+ he.getMessage());
			return false;
		}

	}

	@SuppressWarnings("unchecked")
	@Override
	@Transactional
	public List<GatewayArchive> getGatewayArchive(String transactionId) {
		archiveDaoLog.debug("Inside the getGatewayArchive DAO Impl");
		List<GatewayArchive> gatewayArchive = (List<GatewayArchive>) sessionFactoryArchive
				.getCurrentSession()
				.createQuery(
						"FROM GatewayArchive where messageid = :transactionId")
				.setParameter("transactionId", transactionId).list();
		archiveDaoLog.debug("Returned from getProvisioningTasks HQL: "
				+ gatewayArchive.size());
		return gatewayArchive;
	}

	/* US502960 :: WR # 2810221 - Updated to delete valid transactions from Atlas Message Archive table after life cycle is complete */
	@Override
	@Transactional
	public boolean deleteFromAtlasMessageArchive(String messageid) {
		archiveDaoLog
				.debug("Inside the deleteFromAtlasMessageArchive DAO Impl");

		try {
			sessionFactoryArchive
					.getCurrentSession()
					.createQuery(
							"delete AtlasMessageArchive where messageid = :messageid")
					.setParameter("messageid", messageid)
					.executeUpdate();
			sessionFactoryArchive.getCurrentSession().flush();
			return true;
		} catch (HibernateException he) {
			archiveDaoLog
					.error("Hibernate Exception occured occured deleting from AtlasMessageArchive Table: "
							+ he.getMessage());
			return false;
		}
	}
	
	@Override
	@Transactional
	public boolean deleteFromProvisioningRequests(String masterTransid) {
		archiveDaoLog
				.debug("Inside the deleteFromProvisioningRequests DAO Impl");

		try {
			sessionFactoryData
					.getCurrentSession()
					.createQuery(
							"delete ProvisioningRequest where masterTransid = :masterTransid")
					.setParameter("masterTransid", masterTransid)
					.executeUpdate();
			sessionFactoryData.getCurrentSession().flush();
			return true;
		} catch (HibernateException he) {
			archiveDaoLog
					.error("Hibernate Exception occured occured deleting from ProvisioningRequsts Table: "
							+ he.getMessage());
			return false;
		}
	}

	@Override
	@Transactional
	public boolean deleteFromProvisioningTasks(String masterTransid) {
		archiveDaoLog.debug("Inside the deleteFromProvisioningTasks DAO Impl");

		try {
			sessionFactoryData
					.getCurrentSession()
					.createQuery(
							"delete ProvisioningTask pt where pt.id.masterTransid = :masterTransid")
					.setParameter("masterTransid", masterTransid)
					.executeUpdate();
			sessionFactoryData.getCurrentSession().flush();
			return true;
		} catch (HibernateException he) {
			archiveDaoLog
					.error("Hibernate Exception occured occured deleting from ProvisioningTasks Table: "
							+ he.getMessage());
			return false;
		}
	}

	@Override
	@Transactional
	public boolean deleteFromTransCodes(String masterTransid) {
		archiveDaoLog.debug("Inside the deleteFromTransCodes DAO Impl");

		try {
			sessionFactoryData
					.getCurrentSession()
					.createQuery(
							"delete TransCode where masterTransid = :masterTransid")
					.setParameter("masterTransid", masterTransid)
					.executeUpdate();
			sessionFactoryData.getCurrentSession().flush();
			return true;
		} catch (HibernateException he) {
			archiveDaoLog
					.error("Hibernate Exception occured occured deleting from TransCodes Table: "
							+ he.getMessage());
			return false;
		}
	}
	
	/*
	 * ToDo: Potentially we need to deprecate this method
	 * Because Timer table record is already deleted when it reaches Archive service cleanup
	 * For now we are leaving it here but future enhancement is to deprecate this method
	 */
	@Override
	@Transactional
	public boolean updateTimer(String transactionId) {
		
		int success; 
		Query queryUpdateTimer = sessionFactoryData.getCurrentSession().createQuery("update Timer t set retryInd = :retryInd where t.id.taskTransid = :transactionId"); 
		queryUpdateTimer.setParameter("transactionId", transactionId);
		queryUpdateTimer.setParameter("retryInd","N");	
		
		try {
//			sessionFactoryData.getCurrentSession()
//			.createQuery("update Timer t set retryInd = :retryInd where t.id.taskTransid = :transactionId")
//			.setParameter("transactionId", transactionId)
//			.setParameter("retryInd", "N")
//			.executeUpdate();
//			sessionFactoryData.getCurrentSession().flush();
			
			success = queryUpdateTimer.executeUpdate(); /* Debug */
			archiveDaoLog.debug("Inside updateTimer(), updated timer "+success+" records");
			sessionFactoryData.getCurrentSession().flush();
			return true;
		} catch (HibernateException he) {
			archiveDaoLog
					.error("Hibernate Exception occured occured inserting into Timer Table: "
							+ he.getMessage());
			return false;
		}
	}

	@Override
	@Transactional
	public boolean deleteFromProduct(String transactionId) {
		archiveDaoLog.debug("Inside the deleteFromProduct DAO Impl");

		try {
			sessionFactoryData
					.getCurrentSession()
					.createQuery(
							"delete Product where taskTransid like :transactionId")
					.setParameter("transactionId", transactionId + "%")
					.executeUpdate();
			sessionFactoryData.getCurrentSession().flush();
			return true;
		} catch (HibernateException he) {
			archiveDaoLog
					.error("Hibernate Exception occured occured deleting from Product Table: "
							+ he.getMessage());
			return false;
		}
	}

	@Override
	@Transactional
	public boolean deleteFromProductAttribute(String transactionId) {
		archiveDaoLog.debug("Inside the deleteFromProductAttribute DAO Impl");

		try {
			sessionFactoryData
					.getCurrentSession()
					.createQuery(
							"delete ProductAttribute where taskTransid like :transactionId")
					.setParameter("transactionId", transactionId + "%")
					.executeUpdate();
			sessionFactoryData.getCurrentSession().flush();
			return true;
		} catch (HibernateException he) {
			archiveDaoLog
					.error("Hibernate Exception occured occured deleting from ProductAttribute Table: "
							+ he.getMessage());
			return false;
		}
	}

}