package com.att.tpp.model;

import java.io.Serializable;
import javax.persistence.*;
import java.math.BigDecimal;
import java.util.Date;


/**
 * The persistent class for the INTERFACE_ARCHIVE database table.
 * 
 */
@Entity
@Table(name="INTERFACE_ARCHIVE")
public class InterfaceArchive implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@Column(name="\"ACTION\"")
	private String action;

	@Id
	@Column(name="CARRIER_NAME")
	private String carrierName;

	@Id
	@Temporal(TemporalType.TIMESTAMP)
	@Column(name="ERROR_TIME_STAMP")
	private Date errorTimeStamp;

	@Id
	@Temporal(TemporalType.TIMESTAMP)
	@Column(name="EVENT_TIMESTAMP")
	private Date eventTimestamp;

	@Id
	@Column(name="INTERFACE_NAME")
	private String interfaceName;

	@Id
	@Column(name="LOCATION")
	private String location;

	@Id
	@Column(name="MASTER_TRANSID")
	private String masterTransid;

	@Id
	@Column(name="MINOR_ERROR_CODE")
	private String minorErrorCode;

	@Id
	@Column(name="MINOR_ERROR_DESCRIPTION")
	private String minorErrorDescription;

	@Id
	@Column(name="POST_COUNT")
	private BigDecimal postCount;

	@Id
	@Column(name="PRODUCT_ID")
	private String productId;

	@Id
	@Column(name="ROUTING_CARRIER")
	private String routingCarrier;

	public InterfaceArchive() {
	}

	public String getAction() {
		return this.action;
	}

	public void setAction(String action) {
		this.action = action;
	}

	public String getCarrierName() {
		return this.carrierName;
	}

	public void setCarrierName(String carrierName) {
		this.carrierName = carrierName;
	}

	public Date getErrorTimeStamp() {
		return this.errorTimeStamp;
	}

	public void setErrorTimeStamp(Date errorTimeStamp) {
		this.errorTimeStamp = errorTimeStamp;
	}

	public Date getEventTimestamp() {
		return this.eventTimestamp;
	}

	public void setEventTimestamp(Date eventTimestamp) {
		this.eventTimestamp = eventTimestamp;
	}

	public String getInterfaceName() {
		return this.interfaceName;
	}

	public void setInterfaceName(String interfaceName) {
		this.interfaceName = interfaceName;
	}

	public String getLocation() {
		return this.location;
	}

	public void setLocation(String location) {
		this.location = location;
	}

	public String getMasterTransid() {
		return this.masterTransid;
	}

	public void setMasterTransid(String masterTransid) {
		this.masterTransid = masterTransid;
	}

	public String getMinorErrorCode() {
		return this.minorErrorCode;
	}

	public void setMinorErrorCode(String minorErrorCode) {
		this.minorErrorCode = minorErrorCode;
	}

	public String getMinorErrorDescription() {
		return this.minorErrorDescription;
	}

	public void setMinorErrorDescription(String minorErrorDescription) {
		this.minorErrorDescription = minorErrorDescription;
	}

	public BigDecimal getPostCount() {
		return this.postCount;
	}

	public void setPostCount(BigDecimal postCount) {
		this.postCount = postCount;
	}

	public String getProductId() {
		return this.productId;
	}

	public void setProductId(String productId) {
		this.productId = productId;
	}

	public String getRoutingCarrier() {
		return this.routingCarrier;
	}

	public void setRoutingCarrier(String routingCarrier) {
		this.routingCarrier = routingCarrier;
	}

}