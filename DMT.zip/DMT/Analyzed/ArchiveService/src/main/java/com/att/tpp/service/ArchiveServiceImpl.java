package com.att.tpp.service;

import java.io.IOException;
import java.net.URL;
import java.util.List;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.att.tpp.dao.ArchiveDao;
import com.att.tpp.model.GatewayArchive;
import com.att.tpp.model.InterfaceArchive;
import com.att.tpp.model.MimToolsInterfaceStat;
import com.att.tpp.model.Product;
import com.att.tpp.model.ProductAttribute;
import com.att.tpp.model.ProvisioningRequest;
import com.att.tpp.model.ProvisioningTask;
import com.att.tpp.model.TransCode;
import com.att.tpp.model.TransactionArchive;
import com.att.tpp.utils.TPP_CompletionNotificationXMLGenerator;
import com.att.tpp.utils.ValidateXMLUtil;
import com.att.tpp.xml.model.TPPCompletionNotification;

/**
 * @author Satish Gottumukkala May 2014
 * 
 *         ArchiveServiceImpl serves the Archive Controller requests by using
 *         the ArchiveDao and the util services.
 */

@Service("archiveService")
public class ArchiveServiceImpl implements ArchiveService {

	@Autowired
	private ArchiveDao archiveDao;

	private final static String schemaDir = "//com//att//tpp//common//schemas//";

	private static Logger archiveServiceLog = Logger
			.getLogger(ArchiveServiceImpl.class);

	public ArchiveServiceImpl() {
	}

	ValidateXMLUtil validateXMLUtil = new ValidateXMLUtil();

	@Override
	// Validate the provisioning request XML with XSD
	public Boolean validateXML(String inputXML, String xsdName)
			throws IOException, Exception {
		boolean validationResult = false;
		StringBuilder schemaLocation = new StringBuilder(schemaDir);
		schemaLocation.append(xsdName);
		URL xsdPath = ArchiveServiceImpl.class.getResource(schemaLocation
				.toString());
		archiveServiceLog.debug("xsdPath :" + xsdPath.toString());
		validationResult = validateXMLUtil.validateWithXSD(inputXML,
				xsdPath.toString());
		archiveServiceLog.debug("validationResult :" + validationResult);
		return validationResult;
	}

	@Override
	@Transactional("dataTransactionManager")
	public List<ProvisioningRequest> MasterIdInDB(String masterTransid)
			throws Exception {
		List<ProvisioningRequest> MasterIdInDB = archiveDao
				.masterTransactionInDB(masterTransid);
		return MasterIdInDB;
	}

	// TODO Need to fix trans code part
	@Override
	@Transactional("dataTransactionManager")
	public List<TransCode> getTransCodes(String masterTransid)
			throws Exception {

		List<TransCode> transCodes = archiveDao.getTransCodes(masterTransid);
		return transCodes;
	}

	@Override
	@Transactional("dataTransactionManager")
	public boolean insertDummyTransCode(TransCode transCodes) {
		boolean isSuccess = false;
		try {
			isSuccess = archiveDao.insertDummyTransCode(transCodes);
			return isSuccess;
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return isSuccess;
	}

	@Override
	@Transactional("dataTransactionManager")
	public List<Product> getProducts(String masterTransactionId) {

		List<Product> products = archiveDao.getProducts(masterTransactionId);
		return products;
	}

	@Override
	@Transactional("dataTransactionManager")
	public List<ProductAttribute> getProductAttributes(
			String masterTransactionId) {

		List<ProductAttribute> productAttributes = archiveDao
				.getProductAttributes(masterTransactionId);
		return productAttributes;
	}

	@Override
	@Transactional("archiveTransactionManager")
	public boolean insertInterfaceArchive(InterfaceArchive iAObject) {
		boolean isSuccess = false;
		isSuccess = archiveDao.insertInterfaceArchive(iAObject);
		return isSuccess;
	}

	@Override
	@Transactional("archiveTransactionManager")
	public boolean insertMimToolsInterfaceStat(
			MimToolsInterfaceStat mimInsertObject) {
		boolean isSuccess = false;
		isSuccess = archiveDao.insertMimInterfaceStat(mimInsertObject);
		return isSuccess;
	}

	@Override
	@Transactional("dataTransactionManager")
	public List<ProvisioningTask> getProvisioningTask(String masterTransid) {
		List<ProvisioningTask> provisioningTask = archiveDao
				.getProvisioningTask(masterTransid);
		return provisioningTask;
	}

	@Override
	@Transactional("archiveTransactionManager")
	public List<GatewayArchive> getGatewayArchive(String transactionId) {
		List<GatewayArchive> gatewayArchive = archiveDao.getGatewayArchive(transactionId);
		return gatewayArchive;
	}

	@Override
	public String createCompletionNotificationXML(
			TPPCompletionNotification completionNotification) {
		String tppProvReqXML="";
        TPP_CompletionNotificationXMLGenerator tppCompletionNotificationXMLGenerator = new TPP_CompletionNotificationXMLGenerator();
        tppProvReqXML = tppCompletionNotificationXMLGenerator.createProvReqXML(completionNotification);
        return tppProvReqXML;
	}

	@Override
	@Transactional("archiveTransactionManager")
	public boolean updateTransactionArchive(
			TransactionArchive transactionArchive) {
		boolean isSuccess = false;
		isSuccess = archiveDao.updateTransactionArchive(transactionArchive);
		return isSuccess;
	}

	/* US502960 :: WR # 2810221 - Updated to delete valid transactions from Atlas Message Archive table after life cycle is complete */
	@Override
	@Transactional("archiveTransactionManager")
	public boolean deleteFromAtlasMessageArchive(String messageid) {
		boolean isSuccess = false;
		isSuccess = archiveDao.deleteFromAtlasMessageArchive(messageid);
		return isSuccess;
		
	}
	
	@Override
	@Transactional("dataTransactionManager")
	public boolean deleteFromProvisioningRequests(String masterTransid) {
		boolean isSuccess = false;
		isSuccess = archiveDao.deleteFromProvisioningRequests(masterTransid);
		return isSuccess;
		
	}

	@Override
	@Transactional("dataTransactionManager")
	public boolean deleteFromProvisioningTasks(String masterTransid) {
		boolean isSuccess = false;
		isSuccess = archiveDao.deleteFromProvisioningTasks(masterTransid);
		return isSuccess;
	}

	@Override
	@Transactional("dataTransactionManager")
	public boolean deleteFromTransCodes(String masterTransid) {
		boolean isSuccess = false;
		isSuccess = archiveDao.deleteFromTransCodes(masterTransid);
		return isSuccess;
	}

	@Override
	@Transactional("dataTransactionManager")
	public boolean updateTimer(String transactionId) {
		boolean isSuccess = false;
		isSuccess = archiveDao.updateTimer(transactionId);
		return isSuccess;
	}

	@Override
	@Transactional("dataTransactionManager")
	public boolean deleteFromProduct(String transactionId) {
		boolean isSuccess = false;
		isSuccess = archiveDao.deleteFromProduct(transactionId);
		return isSuccess;
	}

	@Override
	@Transactional("dataTransactionManager")
	public boolean deleteFromProductAttribute(String transactionId) {
		boolean isSuccess = false;
		isSuccess = archiveDao.deleteFromProductAttribute(transactionId);
		return isSuccess;
	}

}