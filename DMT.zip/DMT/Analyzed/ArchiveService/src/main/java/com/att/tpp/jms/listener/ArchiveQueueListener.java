
package com.att.tpp.jms.listener;

import javax.jms.JMSException;
import javax.jms.Message;
import javax.jms.MessageListener;
import javax.jms.TextMessage;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;




import com.att.tpp.controller.ArchiveController;
import com.att.tpp.jms.sender.GatewayQueueSender;
import com.att.tpp.model.ProcessingResult;


/**
 * @author Satish Gottumukkala May 2014 
 * @author Alan Potts June 2014
 * ArchiveQueueListener consume messages from archive queue and processes message.
 *  
 */
public class ArchiveQueueListener implements MessageListener
{
	private static final Logger archiveQueueListenerLog = Logger.getLogger(ArchiveQueueListener.class);
	
	@Autowired
	private ArchiveController archiveController;

	private GatewayQueueSender gatewayQueueSender;
	


	public void onMessage(Message provReqMsg)
	{
		archiveQueueListenerLog.debug("Received message in ArchiveQueueListener [" + provReqMsg +"]");

		/* The message must be of type TextMessage */
		if (provReqMsg instanceof TextMessage)			
		{
			try
			{
				
				String archiveRequestXML = ((TextMessage) provReqMsg).getText();
				archiveQueueListenerLog.info("Archive request XML received : " + archiveRequestXML);

				//Return the processing results
				String swcTransId = null;
				if(!provReqMsg.getStringProperty("swcTransactionId").isEmpty()){
				swcTransId = provReqMsg.getStringProperty("swcTransactionId"); 
				}
				
				ProcessingResult processingResult =archiveController.processRequest(archiveRequestXML, swcTransId);
				
				//If request is valid and has valid product send to the remote queue for persistence
				if (processingResult.isValidRequest()) {
			
					archiveQueueListenerLog.debug("Request processed and back into listener: " + processingResult.isValidRequest());

					if (processingResult.isInsertMimToolsInterface() 
							&& processingResult.isUpdateTransactionArchive() 
							&& processingResult.isValidGatewayArchive() 
							&& processingResult.isValidTppCompletionNotification()
							&& processingResult.isDeletedFromDB()){
						if(processingResult.isInsertDummyTransaction()){
							if(processingResult.isInsertInterfaceArchive()){
								archiveQueueListenerLog.info("Request processing was successful. Sending Gateway Confirmation");
								gatewayQueueSender.sendMessage(processingResult);
							}
						} else if (processingResult.isInsertInterfaceArchive()){
							archiveQueueListenerLog.info("Request processing was successful. Sending Gateway Confirmation");
							gatewayQueueSender.sendMessage(processingResult);
						}
					} else {
						archiveQueueListenerLog.error("Error while processing this transaction : " + processingResult.getMasterTransactionId());
					
						
					
					}
					
				}
				
			}
			catch (JMSException jmsException)
			{
				String errorMsg = "Error occurred while extracting message in ArchiveRequestListener ";
				archiveQueueListenerLog.error(errorMsg, jmsException);
			}  catch (Exception e) {
				e.printStackTrace();
			}
		}
		else
		{
			String errorMsg = "Message is not of expected type TextMessage in ArchiveRequestListener";
			archiveQueueListenerLog.error(errorMsg);
			throw new RuntimeException(errorMsg);
		}
	}
	
	public void setGatewayQueueSender(GatewayQueueSender gatewayQueueSender)
	{
		this.gatewayQueueSender = gatewayQueueSender;
	}

}