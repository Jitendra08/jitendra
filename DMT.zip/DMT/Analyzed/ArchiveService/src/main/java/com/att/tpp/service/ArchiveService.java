package com.att.tpp.service;

import java.io.IOException;
/*import java.util.Collection;*/
import java.util.List;

import com.att.tpp.model.GatewayArchive;
import com.att.tpp.model.InterfaceArchive;
import com.att.tpp.model.MimToolsInterfaceStat;
import com.att.tpp.model.Product;
import com.att.tpp.model.ProductAttribute;
import com.att.tpp.model.ProvisioningRequest;
import com.att.tpp.model.ProvisioningTask;
import com.att.tpp.model.TransCode;
import com.att.tpp.model.TransactionArchive;
import com.att.tpp.xml.model.TPPCompletionNotification;

public interface ArchiveService {
	
	public Boolean validateXML(String inputXML, String xsd) throws IOException, Exception;

	public List<ProvisioningRequest> MasterIdInDB(String masterTransid) throws Exception;

	public List<TransCode> getTransCodes(String masterTransid) throws Exception;

	public boolean insertDummyTransCode(TransCode dummyTransCode) throws Exception;

	public List<Product> getProducts(String masterTransactionId);

	public List<ProductAttribute> getProductAttributes(String masterTransactionId);

	public boolean insertInterfaceArchive(InterfaceArchive iAObject);

	public boolean insertMimToolsInterfaceStat(
			MimToolsInterfaceStat mimInsertObject);

	public List<ProvisioningTask> getProvisioningTask(
			String masterTransid);

	public List<GatewayArchive> getGatewayArchive(String transactionId);

	public String createCompletionNotificationXML(
			TPPCompletionNotification completionNotification);

	public boolean updateTransactionArchive(
			TransactionArchive transactionArchive);

	public boolean deleteFromProvisioningRequests(String masterTransid);
	
	public boolean deleteFromAtlasMessageArchive(String messageid); /* US502960 :: WR # 2810221 - Updated to delete valid transactions from Atlas Message Archive table after life cycle is complete */

	public boolean deleteFromProvisioningTasks(String masterTransid);

	public boolean deleteFromTransCodes(String masterTransid);

	public boolean updateTimer(String transactionId);

	public boolean deleteFromProduct(String transactionId);

	public boolean deleteFromProductAttribute(String transactionId);

}
