package com.att.tpp.model;

import java.io.Serializable;
import javax.persistence.*;
import java.math.BigDecimal;
import java.util.Date;


/**
 * The persistent class for the MIM_TOOLS_INTERFACE_STATS database table.
 * 
 */
@Entity
@Table(name="MIM_TOOLS_INTERFACE_STATS")
@NamedQuery(name="MimToolsInterfaceStat.findAll", query="SELECT m FROM MimToolsInterfaceStat m")
public class MimToolsInterfaceStat implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@Column(name="CARRIER_NAME")
	private String carrierName;

	@Id
	@Column(name="INTERFACE_NAME")
	private String interfaceName;

	@Id
	@Column(name="LOCATION")
	private String location;

	@Id
	@Column(name="MASTER_TRANSID")
	private String masterTransid;

	@Id
	@Column(name="ROUTING_CARRIER")
	private String routingCarrier;

	@Id
	@Temporal(TemporalType.TIMESTAMP)
	@Column(name="\"TIMESTAMP\"")
	private Date timestamp;

	@Id
	@Column(name="TRANS_COUNT")
	private BigDecimal transCount;

	public MimToolsInterfaceStat() {
	}

	public String getCarrierName() {
		return this.carrierName;
	}

	public void setCarrierName(String carrierName) {
		this.carrierName = carrierName;
	}

	public String getInterfaceName() {
		return this.interfaceName;
	}

	public void setInterfaceName(String interfaceName) {
		this.interfaceName = interfaceName;
	}

	public String getLocation() {
		return this.location;
	}

	public void setLocation(String location) {
		this.location = location;
	}

	public String getMasterTransid() {
		return this.masterTransid;
	}

	public void setMasterTransid(String masterTransid) {
		this.masterTransid = masterTransid;
	}

	public String getRoutingCarrier() {
		return this.routingCarrier;
	}

	public void setRoutingCarrier(String routingCarrier) {
		this.routingCarrier = routingCarrier;
	}

	public Date getTimestamp() {
		return this.timestamp;
	}

	public void setTimestamp(Date timestamp) {
		this.timestamp = timestamp;
	}

	public BigDecimal getTransCount() {
		return this.transCount;
	}

	public void setTransCount(BigDecimal transCount) {
		this.transCount = transCount;
	}

}