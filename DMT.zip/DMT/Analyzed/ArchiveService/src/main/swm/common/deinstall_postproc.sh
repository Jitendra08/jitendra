#!/bin/sh
##############################################################################
# - Deinstall Postproc
# - Copyright AT&T Intellectual Properties
##############################################################################

# put anything that needs to run after file deinstall here

exit 0
