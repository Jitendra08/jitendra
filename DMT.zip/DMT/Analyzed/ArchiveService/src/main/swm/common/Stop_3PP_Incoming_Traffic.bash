#!/bin/bash
#####################################################################################################
#Script Name    : Stop_3PP_Incoming_Traffic
#Script Author  : Suganthan Rajabathar
#Brief Desc     : This script will stop 3PP services running in Tomcat instance which sends incoming traffic from Atlas, SwitchControl, DCM and Intrado
#Creation Date  : 06/07/2016
#Update Date    :
##1
#Change History :
##1
#####################################################################################################


#####################################################################################################
#Variable Declaration :
Verify='OK'
STOP_ACTION=stop
PATH_STRING=?path=
#Location=`pwd`
Location=/opt/app/$VTIER/3pp/Deployment_Automation
#####################################################################################################


#####################################################################################################
#Function <Function Name> :
#
#####################################################################################################
#function Main_Fun()
#function Stop_Ind_Tomcat_Serv()
#function Verify_Stop()
#function Cleanup()
#####################################################################################################
# Invoking Functions
#####################################################################################################
function Main_Fun
{
Stop_Ind_Tomcat_Serv GDDNAtlasExtractorService
Stop_Ind_Tomcat_Serv SWCCollectorService
Stop_Ind_Tomcat_Serv CSICollectorService

Cleanup

Info_TIME=`date`
echo "[INFO] $Info_TIME : Sleeping for 10 minutes after stopping incoming traffic to process current Transactions "
sleep 60
}

function Stop_Ind_Tomcat_Serv
{
Info_TIME=`date`
echo "[INFO] $Info_TIME : Stopping $1"
wget "http://${TOMCAT_ADMIN_USER}:${TOMCAT_ADMIN_PW}${TOMCAT_ADMIN_SERVER_URL}${STOP_ACTION}${PATH_STRING}/$1" -O $Location/$1.txt -q
sleep 2
Verify_Stop $1
}
function Verify_Stop
{
Info_TIME=`date`
echo "[INFO] $Info_TIME : Verifying $1 stopped or not?"
if grep -q $Verify $Location/$1.txt;
then
Info_TIME=`date`
echo "[INFO] $Info_TIME : $1 is Stopped!!"
else
        Error_TIME=`date`
    echo "[Error] $Error_TIME -- $1 NOT stopped. Please check tomcat GUI"
fi
}

function Cleanup
{
Info_TIME=`date`
echo "[INFO] $Info_TIME :Deleting output files"
rm -f $Location/GDDNAtlasExtractorService.txt
rm -f $Location/SWCCollectorService.txt
rm -f $Location/CSICollectorService.txt
Info_TIME=`date`
echo "[INFO] $Info_TIME :Deleted output files"
}

Main_Fun
