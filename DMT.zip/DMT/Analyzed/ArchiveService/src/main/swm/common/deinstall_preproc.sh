#!/bin/sh
##############################################################################
# - Install Postproc
# - Copyright AT&T Intellectual Properties
##############################################################################
 
DTE=`date "+%m%d%y-%H%M%S"`
TMP_DIR=/tmp/tomcat-war-undeploy.${DTE}
echo "mkdir ${TMP_DIR}"
mkdir ${TMP_DIR}
TOMCAT_LOG=${TMP_DIR}/tomcat.log
ACTION=undeploy
PATH_STRING=?path=/

ARTIFACT_NAME=${artifactId}.war
WAR_FILE=${INSTALL_ROOT}/${distFilesRootDirPath}/lib/${ARTIFACT_NAME}

# Display localized properties

echo "ARTIFACT_NAME : ${ARTIFACT_NAME}"
echo "WAR_FILE : ${WAR_FILE}"
echo "TOMCAT_ADMIN_SERVER_URL : ${TOMCAT_ADMIN_SERVER_URL}"




echo "DeInstallation application ${ARTIFACT_NAME} using CURL command:"
echo "curl -T ${WAR_FILE} http://${TOMCAT_ADMIN_USER}:${TOMCAT_ADMIN_PW}${TOMCAT_ADMIN_SERVER_URL}${ACTION}${PATH_STRING}${artifactId}"

# DeInstallation the application using ${JBOSS_CLI}
curl 'http://'${TOMCAT_ADMIN_USER}:${TOMCAT_ADMIN_PW}${TOMCAT_ADMIN_SERVER_URL}${ACTION}${PATH_STRING}${artifactId} &> ${TOMCAT_LOG}

OK_COUNT=`fgrep Undeployed ${TOMCAT_LOG} |fgrep OK -c`


if [ ${OK_COUNT} -gt 0 ];then
        echo "deInstallation of ${ARTIFACT_NAME} is successful."
        cat ${TOMCAT_LOG}
        echo "Cleaning up temporary folder : ${TMP_DIR}"
		rm -rf ${TMP_DIR}
        exit 0
else
        echo echo "deInstallation of ${ARTIFACT_NAME} failed."
        cat ${TOMCAT_LOG}
      	exit 1
fi
