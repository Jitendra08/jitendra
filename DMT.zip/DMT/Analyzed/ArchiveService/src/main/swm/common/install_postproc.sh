#!/bin/sh
##############################################################################
# - Install Postproc
# - Copyright AT&T Intellectual Properties
##############################################################################
 
DTE=`date "+%m%d%y-%H%M%S"`
TMP_DIR=/tmp/tomcat-war-deploy-${artifactId}-${version}.${DTE}
echo "mkdir ${TMP_DIR}"
mkdir ${TMP_DIR}
TOMCAT_LOG=${TMP_DIR}/tomcat.log
DEPLOY_ACTION=deploy
UNDEPLOY_ACTION=undeploy
PATH_STRING=?path=/

STOP_3PP_INCOMMING_TRAFFIC_SCRIPT=../../common/Stop_3PP_Incoming_Traffic.bash


ARTIFACT_NAME=${artifactId}-${version}.war
WAR_FILE=${INSTALL_ROOT}/${distFilesRootDirPath}/lib/${ARTIFACT_NAME}

# Display localized properties

echo "ARTIFACT_NAME : ${ARTIFACT_NAME}"
echo "WAR_FILE : ${WAR_FILE}"
echo "TOMCAT_ADMIN_SERVER_URL : ${TOMCAT_ADMIN_SERVER_URL}"



#------------------------------------------------------------------------
#- RUN STOP_3PP_INCOMMING_TRAFFIC_SCRIPT
#------------------------------------------------------------------------
sh -x ${STOP_3PP_INCOMMING_TRAFFIC_SCRIPT} || {
    echo "ERROR: STOP_3PP_INCOMMING_TRAFFIC_SCRIPT script failed"
    exit 1
}


#Undeploy application
wget "http://${TOMCAT_ADMIN_USER}:${TOMCAT_ADMIN_PW}${TOMCAT_ADMIN_SERVER_URL}${UNDEPLOY_ACTION}${PATH_STRING}${artifactId}" -O ${TOMCAT_LOG} -q

sleep 10



echo "Install application ${ARTIFACT_NAME} using wget command:"
echo "wget "http://${TOMCAT_ADMIN_USER}:${TOMCAT_ADMIN_PW}${TOMCAT_ADMIN_SERVER_URL}${DEPLOY_ACTION}${PATH_STRING}${artifactId}&war=${WAR_FILE}" -O ${TOMCAT_LOG} -q"

wget "http://${TOMCAT_ADMIN_USER}:${TOMCAT_ADMIN_PW}${TOMCAT_ADMIN_SERVER_URL}${DEPLOY_ACTION}${PATH_STRING}${artifactId}&war=${WAR_FILE}" -O ${TOMCAT_LOG} -q

OK_COUNT=`fgrep Deployed ${TOMCAT_LOG} |fgrep OK -c`



if [ ${OK_COUNT} -gt 0 ];then
        echo "Installation of ${ARTIFACT_NAME} is successful."
        cat ${TOMCAT_LOG}
        echo "Cleaning up temporary folder : ${TMP_DIR}"
		rm -rf ${TMP_DIR}
        exit 0
else
        echo echo "Installation of ${ARTIFACT_NAME} failed."
        cat ${TOMCAT_LOG}
      	exit 1
fi
