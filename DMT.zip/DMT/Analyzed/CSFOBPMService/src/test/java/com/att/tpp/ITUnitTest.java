package com.att.tpp;

import static org.junit.Assert.*;

import org.junit.Test;

public class ITUnitTest {

	@Test
	public void greets() {
		String msg = "{\"message\":\"Hello world!\"}";
		System.out.println("Inside Unit test :: msg ::" + msg);
		
	}

}