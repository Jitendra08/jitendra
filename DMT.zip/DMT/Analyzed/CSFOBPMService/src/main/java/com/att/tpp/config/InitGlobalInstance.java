package com.att.tpp.config;
import java.util.Hashtable;
import java.util.Map;


public class InitGlobalInstance {
	
	private static Hashtable<String, RetryConfigElement> retryConfig = new Hashtable<String, RetryConfigElement>();
  
	private static Object lock = new Object();

	private static org.apache.log4j.Logger logger = org.apache.log4j.Logger.getLogger("bw.logger");   


  public static  void storeCurrentRetryConfig ( String system, int retryAttempt , String retryType, int waitTime) {
       
    try {

      RetryConfigElement retryConfigElement = new RetryConfigElement (system , retryAttempt , waitTime , retryType); 
      String key = system + "_" + retryType +"_"+retryAttempt;
      retryConfig.put( key , retryConfigElement );
    } catch (Exception e ) {
      //e.printStackTrace();
    	logger.error("Exception in CSFOBPM InitGlobalInstance storeCurrentRetryConfig method : "+e.getMessage());
    }     
  }

   public static  Map getRetryConfig () {
      return retryConfig;
   }

   public static void emptyConfigTables () {
     logger.debug("emptyConfigTables invoked"); 
      synchronized  ( lock ) {
        retryConfig.clear();
      }
   }
   
}



