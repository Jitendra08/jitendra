package com.att.tpp.model;

import java.io.Serializable;
import java.math.BigDecimal;

import javax.persistence.*;


/**
 * The persistent class for the CSFOBPM_MESSAGE_TRACKING database table.
 * 
 */
@Entity
@Table(name="CSFOBPM_MESSAGE_TRACKING")
@NamedQuery(name="CsfobpmMessageTracking.findAll", query="SELECT c FROM CsfobpmMessageTracking c")
public class CsfobpmMessageTracking implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
    @Column(name="TPP_TRANSID", nullable=false)
	private String tppTransid;

	@Column(name="MSISDN")
	private String msisdn;

	@Column(name="SUBID")
	private String subid;

	@Column(name="EVENT_NAME")
	private String eventName;

	@Column(name="CSI_RESPONSE_CODE")
	private String csiResponseCode;

	@Column(name="CSI_RESPONSE_DESC")
	private String csiResponseDesc;

	@Column(name="DB_TIMESTAMP")
	private java.sql.Timestamp dbTimestamp;
	
	@Column(name="CSI_REQUEST_TIME")
	private java.sql.Timestamp csiRequestTime;
	
	@Column(name="CSI_RESPONSE_TIME")
	private java.sql.Timestamp csiResponseTime;
	
	@Column(name="LOCATION")
	private String location;
	
	@Column(name="CONVID")
	private String convid;

	@Lob
	@Column(name="INPUT_XML")
	private String inputXml;
	
	@Lob
	@Column(name="CSFOBPM_REQ_XML")
	private String csfobpmReqXml;
	
	@Lob
	@Column(name="CSFOBPM_RES_XML")
	private String csfobpmResXml;

	@Column(name="RETRY_COUNT")
	private BigDecimal retryCount;

	public String getTppTransid() {
		return tppTransid;
	}

	public void setTppTransid(String tppTransid) {
		this.tppTransid = tppTransid;
	}

	public String getMsisdn() {
		return msisdn;
	}

	public void setMsisdn(String msisdn) {
		this.msisdn = msisdn;
	}

	public String getSubid() {
		return subid;
	}

	public void setSubid(String subid) {
		this.subid = subid;
	}

	public String getEventName() {
		return eventName;
	}

	public void setEventName(String eventName) {
		this.eventName = eventName;
	}

	public String getCsiResponseCode() {
		return csiResponseCode;
	}

	public void setCsiResponseCode(String csiResponseCode) {
		this.csiResponseCode = csiResponseCode;
	}

	public String getCsiResponseDesc() {
		return csiResponseDesc;
	}

	public void setCsiResponseDesc(String csiResponseDesc) {
		this.csiResponseDesc = csiResponseDesc;
	}

	public java.sql.Timestamp getDbTimestamp() {
		return dbTimestamp;
	}

	public void setDbTimestamp(java.sql.Timestamp dbTimestamp) {
		this.dbTimestamp = dbTimestamp;
	}

	public java.sql.Timestamp getCsiRequestTime() {
		return csiRequestTime;
	}

	public void setCsiRequestTime(java.sql.Timestamp csiRequestTime) {
		this.csiRequestTime = csiRequestTime;
	}

	public java.sql.Timestamp getCsiResponseTime() {
		return csiResponseTime;
	}

	public void setCsiResponseTime(java.sql.Timestamp csiResponseTime) {
		this.csiResponseTime = csiResponseTime;
	}

	public String getLocation() {
		return location;
	}

	public void setLocation(String location) {
		this.location = location;
	}

	public String getConvid() {
		return convid;
	}

	public void setConvid(String convid) {
		this.convid = convid;
	}

	public String getInputXml() {
		return inputXml;
	}

	public void setInputXml(String inputXml) {
		this.inputXml = inputXml;
	}

	public String getCsfobpmReqXml() {
		return csfobpmReqXml;
	}

	public void setCsfobpmReqXml(String csfobpmReqXml) {
		this.csfobpmReqXml = csfobpmReqXml;
	}

	public String getCsfobpmResXml() {
		return csfobpmResXml;
	}

	public void setCsfobpmResXml(String csfobpmResXml) {
		this.csfobpmResXml = csfobpmResXml;
	}

	public BigDecimal getRetryCount() {
		return retryCount;
	}

	public void setRetryCount(BigDecimal retryCount) {
		this.retryCount = retryCount;
	}
	
}