package com.att.tpp.utils

import com.att.tpp.xml.model.Account
import com.att.tpp.xml.model.Attribute
import com.att.tpp.xml.model.BillingAccount
import com.att.tpp.xml.model.BillingAddressInfo
import com.att.tpp.xml.model.BillingContactInfo
import com.att.tpp.xml.model.BillingEmailInfo
import com.att.tpp.xml.model.BillingPhoneInfo
import com.att.tpp.xml.model.CSFOBPMProvRequestData
import com.att.tpp.xml.model.EventTypeInfo
import com.att.tpp.xml.model.Fields
import com.att.tpp.xml.model.FormData
import com.att.tpp.xml.model.Forms
import com.att.tpp.xml.model.Order
import com.att.tpp.xml.model.Product
import com.att.tpp.xml.model.Subscriber
import com.att.tpp.xml.model.SubscriberAddress
import com.att.tpp.xml.model.SubscriberContact
import com.att.tpp.xml.model.SubscriberEmailInfo
import com.att.tpp.xml.model.TaskInfo
import com.sun.media.sound.AudioSynthesizer
import com.att.tpp.xml.model.BillingAccount.BillingAddress
import com.att.tpp.xml.model.BillingAccount.BillingContact
import com.att.tpp.xml.model.BillingAccount.BillingCycle
import com.att.tpp.xml.model.BillingAccount.FAN
import com.att.tpp.xml.model.Subscriber.Address
import com.att.tpp.xml.model.Subscriber.Contact
import com.att.tpp.xml.model.Subscriber.EmailInfo

import groovy.util.logging.Log4j
import groovy.util.slurpersupport.NodeChildren

@Log4j
class ParseProvRequestData {		
	
	def String parseSystemName(String requestXML){		
		def provRequest = new XmlSlurper().parseText(requestXML)
		def systemName = provRequest?.TaskInfo?.@System.toString()
		return systemName;	
	}
	
	/**
	 * This method will provide the ConversationId from the CSFOBPM API Response
	 * @param provResXML is the response from the CSFOBPM
	 * @return parsedConId - ConversationId
	 */
	def String getHeaderInfo(String csiResXML){
		def strCSIResponseXML = new XmlSlurper().parseText(csiResXML)
		def messageHeader = strCSIResponseXML.Header.MessageHeader.TrackingMessageHeader
		def parsedConId = null
		parsedConId=messageHeader.conversationId.toString();
		return parsedConId;
	}
	
	public CSFOBPMProvRequestData parseCSFOBPMRequestXML(String provReqXML) {
		def now = new Date()
		
		def csfobpmProvRequest = new XmlSlurper().parseText(provReqXML)
		
		//TaskInfo
		def taskinfo = csfobpmProvRequest.TaskInfo
		
		def parsedTaskTransId=taskinfo?.@Task_TransID.toString()
		def parsedMasterTransId =parsedTaskTransId?.substring(0,parsedTaskTransId?.indexOf("_"));
		
		def parsedTaskInfo = new TaskInfo(	taskinfo.@Task_TransID.toString(), 
											taskinfo.@NotificationURL.toString(),
											taskinfo.@RoutingCarrier.toString(),
											taskinfo.@ProvisioningCarrier.toString(),
											taskinfo.@System.toString(),
											taskinfo.@URL.toString(),
											taskinfo.@ProxyEnabled.toString(),
											taskinfo.@CurrentTechRetryCount.toString(),
											taskinfo.@MaxTechRetryCount.toString(),
											taskinfo.@CurrentNoResponseRetryCount.toString(),
											taskinfo.@MaxNoResponseRetryCount.toString(),
											taskinfo.@EventType.toString()
											)
		
		def order = csfobpmProvRequest.Order;
		//Account
		def account = order.Account	
		
		def parsedAccount = new Account	(	account.@MSISDN.toString(),
											(account.@PrevMSISDN.size()>0) ? account.@PrevMSISDN.toString() : null,
											account.@SubscriberNumber.toString(),
											account.@BAN.toString(),
											(account.@BANName.size()>0) ? account.@BANName.toString() : null,
											(account.@prevBAN.size()>0) ? account.@prevBAN.toString() : null,
											(account.@accountTypeIndicator.size()>0) ? account.@accountTypeIndicator.toString() : null,
											(account.@socEffectiveDate.size()>0) ? account.@socEffectiveDate.toString() : null
										)

		//Subscriber
		def subscriber = order.Subscriber
		def	parsedSubscriber = getParsedSubscriber(subscriber);
		
		// Order/BillingAccount
		def billingAccount = order.BillingAccount
		def	parsedBillingAccount = getParsedBillingAccount(billingAccount);
		
		// Order/Location Id
		def parsedLocationId=null;
		log.info("LocationAccountID>>>"+order?.LocationAccountID?.toString());
		parsedLocationId=order?.LocationAccountID?.toString();
		
		// Order/FormData
		def parsedFormsData = null
		def forms = csfobpmProvRequest?.Order?.Forms;
		parsedFormsData = getFormData(forms);
		
		// Order/EventType
		def eventType = order.EventType;
		def parsedEventType = null
		
		if(eventType.size() > 0){
			parsedEventType = new EventTypeInfo(eventType.EventName.toString())
		}

		def parsedOrder = new Order(parsedAccount, parsedSubscriber, parsedBillingAccount, parsedLocationId, parsedFormsData, parsedEventType)
		
		def products = csfobpmProvRequest.Products;
		def parsedProducts = getProductDetails(products);
		
		return new CSFOBPMProvRequestData(parsedTaskTransId, parsedMasterTransId, parsedTaskInfo, parsedOrder, parsedProducts)
	}

	
	def Subscriber getParsedSubscriber(NodeChildren subscriber){
		
		def subscriberContact = subscriber.Contact
		def subscriberAddress = subscriber.Address
		def subscriberEmail = subscriber.Email
		def subscriberPrevContact = subscriber.PrevContact
		def subscriberPrevAddress = subscriber.PrevAddress
		def subscriberPrevEmail = subscriber.PrevEmail
		
		def parsedSubContact = null;
		def parsedContact = null;
		def parsedCurrentSubContact = null;
		def parsedPreviousSubContact = null;
		
		if(subscriberContact.size() > 0){
			log.info("Inside  parseCSFOBPMRequestXML subscriberContact ::"+subscriberContact.size());
			parsedCurrentSubContact = new SubscriberContact(
				subscriberContact.@FirstName.toString(),
				subscriberContact.@LastName.toString()
			)
			parsedContact = new Contact(parsedCurrentSubContact)
		}
		if(subscriberPrevContact.size() > 0){
			log.info("Inside  parseCSFOBPMRequestXML subscriberPrevContact ::"+subscriberPrevContact.size());
			parsedPreviousSubContact = new SubscriberContact(
				subscriberPrevContact.@FirstName.toString(),
				subscriberPrevContact.@LastName.toString()
			)
			parsedContact = new Contact(parsedCurrentSubContact, parsedPreviousSubContact)
		}
		
		def parsedSubAddress = null;
		def parsedAddress = null;
		def parsedCurrentSubAddress=null;
		def parsedPreviousSubAddress=null;

		if(subscriberAddress.size() > 0){
			log.info("Inside  parseCSFOBPMRequestXML subscriberAddress ::"+subscriberAddress.size());
			parsedCurrentSubAddress = new SubscriberAddress(
				subscriberAddress.@Type.toString(),
				subscriberAddress.@Street.toString(),
				subscriberAddress.@City.toString(),
				subscriberAddress.@State.toString(),
				subscriberAddress.@PostalCode.toString(),
				subscriberAddress.@CountryCode.toString()
			)
			parsedAddress=new Address(parsedCurrentSubAddress);
		}
			
		if(subscriberPrevAddress.size() > 0){
			log.info("Inside  parseCSFOBPMRequestXML subscriberPrevAddress ::"+subscriberPrevAddress.size());
			parsedPreviousSubAddress = new SubscriberAddress(
				subscriberPrevAddress.@Type.toString(),
				subscriberPrevAddress.@Street.toString(),
				subscriberPrevAddress.@City.toString(),
				subscriberPrevAddress.@State.toString(),
				subscriberPrevAddress.@PostalCode.toString(),
				subscriberPrevAddress.@CountryCode.toString()
			)
			parsedAddress=new Address(parsedCurrentSubAddress,parsedPreviousSubAddress);
		}
		
		def parsedCurrentSubEMail = null;
		def parsedPrevSubEMail = null;
		def parsedEmail = null;
		def parsedSubEmail = null;

		if(subscriberEmail.size() > 0){
			log.info("Inside  parseCSFOBPMRequestXML subscriberEmail ::"+subscriberEmail.size());
			parsedCurrentSubEMail = new SubscriberEmailInfo(
				subscriberEmail.@emailAddress.toString(),
				subscriberEmail.@emailType.toString()
			)
			parsedEmail=new EmailInfo(parsedCurrentSubEMail);
		}
		if(subscriberPrevEmail.size() > 0){
			log.info("Inside  parseCSFOBPMRequestXML subscriberPrevEmail ::"+subscriberPrevEmail.size());
			parsedPrevSubEMail = new SubscriberEmailInfo(
				subscriberPrevEmail.@emailAddress.toString(),
				subscriberPrevEmail.@emailType.toString()
			)
			parsedEmail=new EmailInfo(parsedCurrentSubEMail,parsedPrevSubEMail);
		}
		return new Subscriber(parsedContact, parsedAddress, parsedEmail)
	}
	
	def BillingAccount getParsedBillingAccount(NodeChildren billingAccount){
		
		//FAN check
		def fan = billingAccount.FAN
		def parsedFan = null;
		
		if(fan.size() > 0){
			if(fan.@currentFAN.size() > 0){
				if(fan.@previousFAN.size() > 0){
					parsedFan = new FAN(fan.@currentFAN.toString(), fan.@previousFAN.toString())
				}
				else{
					parsedFan = new FAN(fan.@currentFAN.toString())
				}
			}
		}
		
		//FANName check
		def fanName = billingAccount.FANName
		def parsedFanName = null;
		if(fanName.size() > 0){
			parsedFanName = fanName.toString()
		}
		
		
		//ContractID check
		def contractId = billingAccount.ContractId
		def parsedContractId=null;
		
		if(contractId.size() > 0){
			parsedContractId = contractId.toString()
		}
		
		//ContractType check
		def contractType = billingAccount.ContractType
		def parsedContractType=null;
		if(contractType.size() > 0){
			parsedContractType = contractType.toString()
		}
		
		//BillingCycle check
		def billingCycle = billingAccount.BillingCycle
		def parsedBillingCycle=null;
		if(billingCycle.size() > 0){
			if(billingCycle.@current.size() > 0){
				if(billingCycle.@previous.size() > 0){
					parsedBillingCycle = new BillingCycle(billingCycle.@current.toString(), billingCycle.@previous.toString())
				}
				else{
					parsedBillingCycle = new BillingCycle(billingCycle.@current.toString())
				}
			}
		}
		
		def parsedBillingContact = null;
		def parsedCurrentBillingContact = null;
		def parsedPreviousBillingContact = null;
		
		def billingName = billingAccount.Name;
		
		if(billingName.size() > 0){
			log.info("Inside  parseCSFOBPMRequestXML billingName ::"+billingName.size());
			parsedCurrentBillingContact = new BillingContactInfo(
				billingName?.current?.@FirstName.toString(),
				billingName?.current?.@LastName.toString(),
				billingName?.current?.@BusinessName.toString()
			)
			parsedBillingContact = new BillingContact(parsedCurrentBillingContact)
			
			if(billingName?.previous?.size() > 0){
				log.info("Inside  parseCSFOBPMRequestXML billingPrevName ::"+billingName?.previous?.size());
				parsedPreviousBillingContact = new BillingContactInfo(
					billingName?.previous?.@FirstName.toString(),
					billingName?.previous?.@LastName.toString(),
					billingName?.previous?.@BusinessName.toString()
				)
				parsedBillingContact = new BillingContact(parsedCurrentBillingContact, parsedPreviousBillingContact)
			}
		}
		
		
		def parsedBillingAddress = null;
		def billingAddress = billingAccount.Address;
		def parsedCurrentBillingAddress = null;
		def parsedPreviousBillingAddress = null;
		
		if(billingAddress?.current?.size() > 0){
			parsedCurrentBillingAddress = new BillingAddressInfo(
					billingAddress?.current?.@Type.toString(), 
					billingAddress?.current?.@AddressLine1.toString(),
					billingAddress?.current?.@AddressLine2.toString(), 
					billingAddress?.current?.@CountryName.toString(),
					billingAddress?.current?.@State.toString(), 
					billingAddress?.current?.@PostalPlusCode.toString(),
					billingAddress?.current?.@PostalCode.toString(), 
					billingAddress?.current?.@LocalCompanyName.toString(),
					billingAddress?.current?.@City.toString(),
					billingAddress?.current?.@CountryCode.toString(),
					billingAddress?.current?.@GeoCode.toString()
					)
			
			parsedBillingAddress = new BillingAccount.BillingAddress(parsedCurrentBillingAddress)
			
			if(billingAddress?.previous?.size() > 0){
				parsedPreviousBillingAddress = new BillingAddressInfo(
						billingAddress?.previous?.@Type.toString(), 
						billingAddress?.previous?.@AddressLine1.toString(),
						billingAddress?.previous?.@AddressLine2.toString(), 
						billingAddress?.previous?.@CountryName.toString(),
						billingAddress?.previous?.@State.toString(), 
						billingAddress?.previous?.@PostalPlusCode.toString(),
						billingAddress?.previous?.@PostalCode.toString(), 
						billingAddress?.previous?.@LocalCompanyName.toString(),
						billingAddress?.previous?.@City.toString(),
						billingAddress?.previous?.@CountryCode.toString(),
						billingAddress?.previous?.@GeoCode.toString()
						)
				
				parsedBillingAddress = new BillingAccount.BillingAddress(parsedCurrentBillingAddress,parsedPreviousBillingAddress)
			}
		}
		
		def parsedBillingPhone = null;
		def billingPhone = billingAccount.Phone;
		def parsedCurrentBillingPhone = null;
		def parsedPreviousBillingPhone = null;
		log.info("billingPhone.current.size() ::"+billingPhone?.current?.size());
		if(billingPhone.current.size() > 0){
			log.info("Inside  billingPhone.current");
			parsedCurrentBillingPhone = new BillingPhoneInfo(
						billingPhone?.current?.@homePhone.toString(),
						billingPhone?.current?.@canBeReachedPhone.toString(),
						billingPhone?.current?.@workPhone.toString(),
						billingPhone?.current?.@workPhoneExtension.toString()
					)
			parsedBillingPhone = new BillingAccount.BillingPhone(parsedCurrentBillingPhone)
			
			log.info("billingPhone.previous.size() ::"+billingPhone?.previous?.size());
			
			if(billingPhone.previous.size() > 0){
				log.info("Inside  billingPhone.previous");
				parsedPreviousBillingPhone = new BillingPhoneInfo(
						billingPhone?.previous?.@homePhone.toString(),
						billingPhone?.previous?.@canBeReachedPhone.toString(),
						billingPhone?.previous?.@workPhone.toString(),
						billingPhone?.previous?.@workPhoneExtension.toString()
				)
				parsedBillingPhone = new BillingAccount.BillingPhone(parsedCurrentBillingPhone, parsedPreviousBillingPhone)
			}
		}
		
		
		def parsedBillingEmail = null;
		def billingEmail = billingAccount.Email;
		def parsedCurrentBillingEmail = null;
		def parsedPreviousBillingEmail = null;
		log.info("billingEmail.current.size() ::"+billingEmail?.current?.size());
		if(billingEmail.current.size() > 0){
			log.debug("Inside  billingEmail.current");
			parsedCurrentBillingEmail = new BillingEmailInfo(
						billingEmail?.current?.@emailType.toString(), 
						billingEmail?.current?.@emailAddress.toString()
					)
			parsedBillingEmail = new BillingAccount.BillingEmail(parsedCurrentBillingEmail)
			
			log.info("billingEmail.previous.size() ::"+billingEmail?.previous?.size());
			
			if(billingEmail.previous.size() > 0){
				log.info("Inside  email.previous");
				parsedPreviousBillingEmail = new BillingEmailInfo(
						billingEmail?.previous?.@emailType.toString(), 
						billingEmail?.previous?.@emailAddress.toString()
				)
				parsedBillingEmail = new BillingAccount.BillingEmail(parsedCurrentBillingEmail, parsedPreviousBillingEmail)
			}
		}
		
		
		return new BillingAccount(parsedFan, parsedFanName, parsedContractId, parsedContractType, parsedBillingCycle, parsedBillingContact, parsedBillingAddress, parsedBillingPhone, parsedBillingEmail)
	}
	
	
	
	def getFormData(NodeChildren formsDet){
		def parsedForms = null;
		log.info("Inside  parseCSFOBPMRequestXML forms ::"+formsDet.size());
		if(formsDet.size() > 0){
			log.info("Inside  parseCSFOBPMRequestXML forms ::"+formsDet.size());
			parsedForms = new Forms(
				formsDet.FormData.collect{
					new FormData(
						it.Fields.collect{
							new Fields(
								it.name.toString(),
								it.group.toString(),
								it.value.collect{
									it.toString()
								}
							)
						}
					)
				}
			)
		}
			
		return parsedForms;
	}
		
		
	def getProductDetails(NodeChildren products){
		
		def parsedProducts = null;
		log.info("Inside  parseCSFOBPMRequestXML getProductDetails ::"+products.size());
		if(products.size() > 0){
			parsedProducts = products.Product.collect{
				Product product = new Product(	it.@Category.toString(),
												it.@Id.toString(), 
												it.@Action.toString(), 
												it.@EffectiveDate.toString(), 
												it.@EffectiveDate.toString(),
												it.Attribute.collect{ 
													new Attribute(
														it.@Name.toString(), 
														it.@Value.toString()
														) 
													}
												)
				}
			}
		
		return parsedProducts;
	}	
		
	
	static main(args) {
		
		ParseProvRequestData csfopbmParseReq = new ParseProvRequestData()
		println("csfopbmParseReq --->Start " )
		def pepoReqInfo = csfopbmParseReq.parseCSFOBPMRequestXML(new File("C:\\TestXML\\testTranReq.xml").text);
		
		println("formData size >>>"+pepoReqInfo?.order?.forms?.formData?.size());
		println("testTranReq --->End " )
	}
	
}