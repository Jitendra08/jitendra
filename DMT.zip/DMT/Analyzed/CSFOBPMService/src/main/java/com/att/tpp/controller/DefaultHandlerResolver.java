/**
 * 
 */
package com.att.tpp.controller;

/**
 * @author rg730b
 *
 */
import java.util.List;

import javax.xml.ws.handler.Handler;
import javax.xml.ws.handler.HandlerResolver;
import javax.xml.ws.handler.PortInfo;
 
@SuppressWarnings("rawtypes")
public class DefaultHandlerResolver implements HandlerResolver {
 private String enabled;	
 private List<Handler> handlerList;
 
 public List<Handler> getHandlerChain(PortInfo portInfo) {
  return handlerList;
 }
 
 public void setHandlerList(List<Handler> handlerList) {
  this.handlerList = handlerList;
 }

/**
 * @return the enabled
 */
public String getEnabled() {
	return enabled;
}

/**
 * @param enabled the enabled to set
 */
public void setEnabled(String enabled) {
	this.enabled = enabled;
}
}
