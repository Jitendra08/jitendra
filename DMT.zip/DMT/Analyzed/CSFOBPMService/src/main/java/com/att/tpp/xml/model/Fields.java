/**
 * 
 */
package com.att.tpp.xml.model;

import java.util.List;

/**
 * @author rg730b
 *
 */
public class Fields {
	private String name;
	private String group;
	private List<String> value;
	
	
	/**
	 * @param name
	 * @param group
	 * @param value
	 */
	public Fields(String name, String group, List<String> value) {
		this.name = name;
		this.group = group;
		this.value = value;
	}
	/**
	 * @return the name
	 */
	public String getName() {
		return name;
	}
	/**
	 * @param name the name to set
	 */
	public void setName(String name) {
		this.name = name;
	}
	/**
	 * @return the group
	 */
	public String getGroup() {
		return group;
	}
	/**
	 * @param group the group to set
	 */
	public void setGroup(String group) {
		this.group = group;
	}
	/**
	 * @return the value
	 */
	public List<String> getValue() {
		return value;
	}
	/**
	 * @param value the value to set
	 */
	public void setValue(List<String> value) {
		this.value = value;
	}
	
	

}
