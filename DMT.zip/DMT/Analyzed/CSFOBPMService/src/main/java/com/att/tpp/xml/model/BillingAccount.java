package com.att.tpp.xml.model;


public class BillingAccount {

	private BillingAccount.FAN fan;
	private String fanName;
	private String contractId;
	private String contractType;
	private BillingAccount.BillingCycle billingCycle;
    private BillingAccount.BillingContact contact;
    private BillingAccount.BillingAddress address;
    private BillingAccount.BillingPhone phone;
    private BillingAccount.BillingEmail email;
    
    
    
	public BillingAccount(FAN fan, String fanName, String contractId, String contractType, BillingCycle billingCycle,
			BillingContact contact, BillingAddress address, BillingPhone phone, BillingEmail email) {
		super();
		this.fan = fan;
		this.fanName = fanName;
		this.contractId = contractId;
		this.contractType = contractType;
		this.billingCycle = billingCycle;
		this.contact = contact;
		this.address = address;
		this.phone = phone;
		this.email = email;
	}

	public BillingAccount(BillingContact contact, BillingAddress address,
    		BillingEmail email) {
		super();
		this.contact = contact;
		this.address = address;
		this.email = email;
	}
    
    public BillingAccount(BillingContact contact, BillingAddress address) {
		this.contact = contact;
		this.address = address;
	}
    

    
    public String getFanName() {
		return fanName;
	}

	public void setFanName(String fanName) {
		this.fanName = fanName;
	}

	public String getContractId() {
		return contractId;
	}

	public void setContractId(String contractId) {
		this.contractId = contractId;
	}

	public String getContractType() {
		return contractType;
	}

	public void setContractType(String contractType) {
		this.contractType = contractType;
	}

    public static class FAN {

    	private String currentFAN;
    	private String previousFAN;

 		public FAN(String currentFAN) {
			this.currentFAN = currentFAN;
		}

		public FAN(String currentFAN, String previousFAN) {
			this.currentFAN = currentFAN;
			this.previousFAN = previousFAN;
		}

		public String getCurrentFAN() {
            return currentFAN;
        }

        public void setCurrentFAN(String value) {
            this.currentFAN = value;
        }

        public String getPreviousFAN() {
            return previousFAN;
        }

        public void setPreviousFAN(String value) {
            this.previousFAN = value;
        }

    }

    public static class BillingCycle {

    	private String current;
    	private String previous;
 
		public BillingCycle(String current) {
			this.current = current;
		}

		public BillingCycle(String current, String previous) {
			this.current = current;
			this.previous = previous;
		}

        public String getCurrent() {
            return current;
        }

        public void setCurrent(String value) {
            this.current = value;
        }

        public String getPrevious() {
            return previous;
        }

        public void setPrevious(String value) {
            this.previous = value;
        }

    }
    
	public static class BillingAddress {
		
    	private BillingAddressInfo current;
    	private BillingAddressInfo previous;
    	
    	public BillingAddress(BillingAddressInfo current){
			this.current = current;
		}
		
		public BillingAddress(BillingAddressInfo current,
				BillingAddressInfo previous) {
			this.current = current;
			this.previous = previous;
		}
		
		public BillingAddressInfo getCurrent() {
			return current;
		}
		public void setCurrent(BillingAddressInfo current) {
			this.current = current;
		}
		public BillingAddressInfo getPrevious() {
			return previous;
		}
		public void setPrevious(BillingAddressInfo previous) {
			this.previous = previous;
		}
		
	}
	
	public static class BillingContact {
		
    	private BillingContactInfo current;
    	private BillingContactInfo previous;
    	
    	public BillingContact(BillingContactInfo current){
			this.current = current;
		}
		
		public BillingContact(BillingContactInfo current,
				BillingContactInfo previous) {
			this.current = current;
			this.previous = previous;
		}
    	
		public BillingContactInfo getCurrent() {
			return current;
		}
		public void setCurrent(BillingContactInfo current) {
			this.current = current;
		}
		public BillingContactInfo getPrevious() {
			return previous;
		}
		public void setPrevious(BillingContactInfo previous) {
			this.previous = previous;
		}
    	
	}
	
	public static class BillingPhone {
		
    	private BillingPhoneInfo current;
    	private BillingPhoneInfo previous;
    	
    	public BillingPhone(BillingPhoneInfo current) {
			this.current = current;
		}

		public BillingPhone(BillingPhoneInfo current, BillingPhoneInfo previous) {
			this.current = current;
			this.previous = previous;
		}
    	
		public BillingPhoneInfo getCurrent() {
			return current;
		}
		public void setCurrent(BillingPhoneInfo current) {
			this.current = current;
		}
		public BillingPhoneInfo getPrevious() {
			return previous;
		}
		public void setPrevious(BillingPhoneInfo previous) {
			this.previous = previous;
		}
    	
 	}
	
	public static class BillingEmail {
		
    	private BillingEmailInfo current;
    	private BillingEmailInfo previous;
    	
    	public BillingEmail(BillingEmailInfo current) {
			this.current = current;
		}

		public BillingEmail(BillingEmailInfo current,
				BillingEmailInfo previous) {
			this.current = current;
			this.previous = previous;
		}
    	
		public BillingEmailInfo getCurrent() {
			return current;
		}
		public void setCurrent(BillingEmailInfo current) {
			this.current = current;
		}
		public BillingEmailInfo getPrevious() {
			return previous;
		}
		public void setPrevious(BillingEmailInfo previous) {
			this.previous = previous;
		}
    	
 	}

}
