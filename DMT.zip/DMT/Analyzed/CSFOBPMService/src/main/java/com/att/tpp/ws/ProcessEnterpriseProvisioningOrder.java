/**
 * 
 */
package com.att.tpp.ws;

import com.att.tpp.model.CsfobpmResponseData;
import com.att.tpp.xml.model.CSFOBPMProvRequestData;

/**
 * @author rg730b
 *
 */
public interface ProcessEnterpriseProvisioningOrder {
	
	CsfobpmResponseData getRequestAcknowledgementInfo(CSFOBPMProvRequestData csfobpmRequestData, String provRequestXML, String messageId) throws Exception;

}
