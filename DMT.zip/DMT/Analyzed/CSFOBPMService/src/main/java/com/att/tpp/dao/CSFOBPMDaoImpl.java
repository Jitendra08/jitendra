package com.att.tpp.dao;

import java.math.BigDecimal;
import java.sql.Timestamp;
import java.util.Calendar;
import java.util.Iterator;
import java.util.List;

import org.apache.log4j.Logger;
import org.hibernate.Hibernate;
import org.hibernate.HibernateException;
import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.type.StandardBasicTypes;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.att.tpp.model.CSIRetryErrors;
import com.att.tpp.model.CsfobpmMessageTracking;
import com.att.tpp.model.CsfobpmResponseData;
import com.att.tpp.model.RetryConfiguration;
import com.att.tpp.model.jpa.ProvisioningRequest;
import com.att.tpp.model.jpa.ProvisioningTask;
import com.att.tpp.model.jpa.Timer;
import com.att.tpp.model.jpa.TransCode;

@Repository("csfobpmDao")
public class CSFOBPMDaoImpl implements CSFOBPMDao {
	
	private static final Logger csfobpmDaoImpl = Logger.getLogger(CSFOBPMDaoImpl.class);
	
	@Autowired
	private SessionFactory sessionFactoryArchive;
	
	@Autowired
	private SessionFactory sessionFactoryData;
	
	@Autowired
	private SessionFactory sessionFactoryConfig;
	
	@SuppressWarnings("unchecked")
	@Override
	public List<RetryConfiguration> getRetryConfigurationList() {
		csfobpmDaoImpl.debug("Inside the getRetryConfiguartionList");
		List<RetryConfiguration> retryConfigurationList=null;
		retryConfigurationList = (List<RetryConfiguration>) sessionFactoryConfig
				//.openSession()
				.getCurrentSession()
				.createQuery("from RetryConfiguration")
				.list();			
		//sessionFactoryConfig.close();
		return retryConfigurationList;
	}

	
	@SuppressWarnings("unchecked")
	@Override
	public List<ProvisioningRequest> queryProvisioningRequest(String masterTransId) {
		csfobpmDaoImpl.debug("Inside the getProvisoningRequestList");
		List<ProvisioningRequest> provisioningRequestList=null;
		provisioningRequestList = (List<ProvisioningRequest>) sessionFactoryData
				.getCurrentSession()
				.createQuery("from ProvisioningRequest pr where pr.masterTransid = :masterTransId")
		        .setParameter("masterTransId", masterTransId)
				.list();			
		  
		return provisioningRequestList;
	}
	
	@Override
	public Boolean insertTransCodes(List<TransCode> transCodeList) {
		Session session = sessionFactoryData.openSession();
		try {
			Iterator<TransCode> transCodesForInsertIterator = transCodeList.iterator();
			while (transCodesForInsertIterator.hasNext()) {
				TransCode transCode = transCodesForInsertIterator.next();
				sessionFactoryData.getCurrentSession().save(transCode);
			}
			session.flush();
			session.clear();				
		} catch (HibernateException he) {
			csfobpmDaoImpl.error("Hibernate Exception occured occured inserting into TransCodes Table: "+ he.getMessage());
			//he.printStackTrace();
			return false;
		}
		return true;
	}
	
	@Override
	public boolean updateInterfaceTable(String interfaceName, String connectivityStatus) {
		csfobpmDaoImpl.debug("Inside CSFOBPMDaoImpl updateInterfaceForOnHold method");		
		int success = 0;
		Query queryUpdateInterface = sessionFactoryArchive.getCurrentSession()
				.createQuery("update Interface i set i.connectivityStatus = :connectivityStatus where i.interfaceName = :interfaceName");
		queryUpdateInterface.setParameter("connectivityStatus", connectivityStatus);
		queryUpdateInterface.setParameter("interfaceName",interfaceName.trim());		
		try{
			success = queryUpdateInterface.executeUpdate();	
			sessionFactoryData.getCurrentSession().flush();
		}
		catch(HibernateException he){
			csfobpmDaoImpl.error("Hibernate Exception occured in updateInterfaceTable method: " + he.getMessage());
		}
		
		return isSuccess(success);	
	}
	
	@SuppressWarnings("unchecked")
	@Override
	public List<ProvisioningTask> queryProvisioningTasks(String taskTransId) {
		csfobpmDaoImpl.debug("Inside the queryProvisioningTasks");
		List<ProvisioningTask> provisioningTaskList=null;
		provisioningTaskList = (List<ProvisioningTask>) sessionFactoryData
				.getCurrentSession()
				.createQuery("from ProvisioningTask pt where pt.id.taskTransid = :taskTransId")
		        .setParameter("taskTransId", taskTransId)
				.list();			
		  
		return provisioningTaskList;
	}
	
	@SuppressWarnings("unchecked")
	@Override
	public List<Timer> queryTimerTable(String taskTransId) {
		csfobpmDaoImpl.debug("Inside the queryTimerTable");
		List<Timer> TimerList=null;
		TimerList = (List<Timer>) sessionFactoryData
				.getCurrentSession()
				.createQuery("from Timer t where t.id.taskTransid = :taskTransId")
		        .setParameter("taskTransId", taskTransId)
				.list();			
		  
		return TimerList;
	}


	@Override
	public boolean updateTimer(String taskTransId, String timerState, int timerDuration, String payLoad, String payLoadOverflow) {

		csfobpmDaoImpl.debug("Inside CSFOBPMDaoImpl updateTimer method");		
		int success = 0;

		Calendar expiryTime = getCalendarTimeStamp();
		expiryTime.add(Calendar.MILLISECOND,timerDuration);		
		Calendar currentTimeStamp = getCalendarTimeStamp();	
		
		
		Query queryUpdateTimer = sessionFactoryData.getCurrentSession()
				.createQuery("update Timer t set t.id.timerState = :timerState, t.timerDuration = :timerDuration, t.retryInd = :retryInd, t.expiryTime = :expiryTime, t.creationTime = :creationTime, t.payload = :payload, t.payloadOverflow = :payloadOverflow"
						+ " where t.id.taskTransid = :taskTransId");
		queryUpdateTimer.setParameter("taskTransId", taskTransId);
		queryUpdateTimer.setParameter("timerState",timerState);
		queryUpdateTimer.setParameter("timerDuration",timerDuration);
		queryUpdateTimer.setParameter("retryInd","Y");
		queryUpdateTimer.setParameter("expiryTime",expiryTime.getTime());		
		queryUpdateTimer.setParameter("creationTime",currentTimeStamp.getTime());
		queryUpdateTimer.setParameter("payload",payLoad);		
		queryUpdateTimer.setParameter("payloadOverflow",payLoadOverflow);
		try{
			success = queryUpdateTimer.executeUpdate();		
			sessionFactoryData.getCurrentSession().flush();
			sessionFactoryData.getCurrentSession().clear();
			csfobpmDaoImpl.info("Inside CSFOBPMDaoImpl updateTimer method, taskTransId: "+taskTransId+" timerState : "+timerState+" timerDuration : "+timerDuration);
		}
		catch(HibernateException he){
			csfobpmDaoImpl.error("Hibernate Exception occured in updateTimer method: " + he.getMessage());
			return false;
		}
		
		return isSuccess(success);	
	}
	
	

	@Override
	public boolean deleteFromTimer(String taskTransId) {
	    int success = 0;
	    if(taskTransId!=null){
			Query deleteTimerQuery = sessionFactoryData.getCurrentSession()
	                   .createQuery("delete from Timer t where t.id.taskTransid = :taskTransid");
			deleteTimerQuery.setParameter("taskTransid",taskTransId);
		
		try{
			success = deleteTimerQuery.executeUpdate();		
			sessionFactoryData.getCurrentSession().flush();
			sessionFactoryData.getCurrentSession().clear();
		}
		catch(HibernateException he){
			csfobpmDaoImpl.error("Hibernate Exception occured in the responseDaoImpl deleteFromTimer method :"+he.getMessage());
			return false;
		}
	}
	return isSuccess(success);	
	
	}

	@Override
	public boolean updatePostFailedTaskStatus(String taskTransId,
			String taskStatus, BigDecimal currTechRetryCount) {
		int success = 0;
		try {
			
			success = sessionFactoryData
					.getCurrentSession()
					.createQuery(
							"update ProvisioningTask pt set pt.taskStatus = :taskStatus, pt.currTechRetryCount = :currTechRetryCount"
							+ " where pt.id.taskTransid = :taskTransId")
					.setParameter("taskTransId", taskTransId)
					.setParameter("taskStatus", taskStatus)
					.setParameter("currTechRetryCount", currTechRetryCount)
					.executeUpdate();
			sessionFactoryData.getCurrentSession().flush();
			sessionFactoryData.getCurrentSession().clear();
			csfobpmDaoImpl.info("ProvTask : "+taskTransId+" Status updated to : "+taskStatus);
			return isSuccess(success);
		} catch (HibernateException he) {
			csfobpmDaoImpl.error("Hibernate Exception occured in updatePostFailedTaskStatus method: "+ he.getMessage());
			return isSuccess(success);
		}
	}
	
	@Override
	public boolean insertTimer(Timer timer) {
		csfobpmDaoImpl.debug("Inside CSFOBPMDaoImpl insertTimer method");
		try {
			sessionFactoryData.getCurrentSession().saveOrUpdate(timer);				
			sessionFactoryData.getCurrentSession().flush();
			sessionFactoryData.getCurrentSession().clear();
			csfobpmDaoImpl.info("Inside CSFOBPMDaoImpl updateTimer method, taskTransId: "+timer.getId().getTaskTransid()+" timerState : "+timer.getId().getTimerState()+" timerDuration : "+timer.getTimerDuration());
			return true;
		}catch (HibernateException e) {
			csfobpmDaoImpl.error("Exception occured in the CSFOBPMDaoImpl insertTimer method :"+e.getMessage());
			//e.printStackTrace();
			return false;
		}
	}
	
	public Calendar getCalendarTimeStamp() {
		csfobpmDaoImpl.debug("Inside the getCurrentTimeStamp");
		Calendar calendar = Calendar.getInstance();
		try {
			@SuppressWarnings("deprecation")
			Timestamp timestamp = (Timestamp) sessionFactoryData
					.getCurrentSession()
					.createSQLQuery("select sysdate param from dual")
					.addScalar("param", StandardBasicTypes.TIMESTAMP).uniqueResult();

			calendar.setTimeInMillis(timestamp.getTime());
		} catch (Exception e) {
			csfobpmDaoImpl.info("Exception occured in getCalendarTimeStamp method");
		}
		return calendar;
	}


	
	private Boolean isSuccess(int success){
		if (success > 0) {
			return true;
		} 
		else {
			return false;
		}		
	}
	
	@Override
	@SuppressWarnings("unchecked")
	public List<CSIRetryErrors> getCSIRetryError(String eventName) throws Exception {
		csfobpmDaoImpl.info("Inside CSFOBPMDaoImpl getCSIRetryError method"+eventName);
		List<CSIRetryErrors> csiRetryError = (List<CSIRetryErrors>) sessionFactoryConfig
				.getCurrentSession()
				.createQuery("from CSIRetryErrors re where re.eventName = :eventName")
		        .setParameter("eventName", eventName)
				.list();
		return csiRetryError;
	}
	
	@Transactional
	public boolean insertCsfobpmMessage(CsfobpmMessageTracking csfobpmMessageTracking) {
		csfobpmDaoImpl.debug("Inside CSFOBPMDaoImpl insertCsfobpmMsgTracking method");
		try {
			sessionFactoryArchive.getCurrentSession().save(csfobpmMessageTracking);		
			sessionFactoryArchive.getCurrentSession().flush();
			return true;
		}catch (HibernateException e) {
			csfobpmDaoImpl.error("Exception occured in the CSFOBPMDaoImpl persistDIPResult method :"+e.getMessage());
			//e.printStackTrace();
			return false;
		}
	}
	
	@Transactional
	public boolean updateCsfobpmMsg(CsfobpmResponseData resData) {
		csfobpmDaoImpl.debug("Inside CSFOBPMDaoImpl updateCsfobpmMsg method");
		
		int success = 0;
		String errorMsg=null;
		if(resData.getCsiResponsedesc() !=null && resData.getCsiResponsedesc().length() > 200){
			errorMsg=resData.getCsiResponsedesc().substring(0, 199).toString();
		}else{
			errorMsg=resData.getCsiResponsedesc().toString();
		}
		Query queryMsgTracking = sessionFactoryArchive.getCurrentSession()
				.createQuery("update CsfobpmMessageTracking msgTrack "
						+ "set msgTrack.csiResponseCode = :csiResponseCode, msgTrack.csiResponseDesc = :csiResponseDesc, msgTrack.csiResponseTime = :csiResponseTime "
						+ "where msgTrack.tppTransid = :tppTransid and msgTrack.eventName = :eventName and msgTrack.csiResponseCode = :strErrCode");
		
		queryMsgTracking.setParameter("csiResponseCode", resData.getCsiResponsecode());
		queryMsgTracking.setParameter("csiResponseDesc",errorMsg);
		queryMsgTracking.setParameter("csiResponseTime",resData.getResTimeStamp());
		
		queryMsgTracking.setParameter("tppTransid", resData.getTppTransactionid());
		queryMsgTracking.setParameter("eventName",resData.getDipType());
		queryMsgTracking.setParameter("strErrCode","Initializing");
		
		try{
			success = queryMsgTracking.executeUpdate();
			sessionFactoryArchive.getCurrentSession().flush();
			sessionFactoryArchive.getCurrentSession().clear();
			
			if(success > 0 ){				
				return true;				
			}else{				
				return false;				
			}
		}catch(HibernateException he){
			csfobpmDaoImpl.error("Hibernate Exception occured in updateCsfobpmMsg method: " + he.getMessage());
			return false;
		}
		
	} 
	
}
	