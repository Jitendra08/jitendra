package com.att.tpp.xml.model;

import java.util.Collection;

public class Products {

    private Collection<Product> product;

    public Products(Collection<Product> product) {
		this.product = product;
	}

	public Collection<Product> getProduct() {
		return product;
	}

	public void setProduct(Collection<Product> product) {
		this.product = product;
	}


}
