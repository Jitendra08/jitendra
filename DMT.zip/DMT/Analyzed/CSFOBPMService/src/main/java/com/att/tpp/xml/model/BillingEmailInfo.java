/**
 * 
 */
package com.att.tpp.xml.model;

/**
 * @author rg730b
 *
 */
public class BillingEmailInfo {
	
	private String emailType;
	private String emailAddress;
	
	public BillingEmailInfo(String emailType, String emailAddress) {
		super();
		this.emailType = emailType;
		this.emailAddress = emailAddress;
	}

	public String getEmailType() {
		return emailType;
	}

	public void setEmailType(String emailType) {
		this.emailType = emailType;
	}

	public String getEmailAddress() {
		return emailAddress;
	}

	public void setEmailAddress(String emailAddress) {
		this.emailAddress = emailAddress;
	}
	
}
