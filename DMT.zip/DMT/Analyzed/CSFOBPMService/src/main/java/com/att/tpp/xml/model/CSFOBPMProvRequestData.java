/**
 * 
 */
package com.att.tpp.xml.model;

import java.util.Collection;

/**
 * @author rg730b
 *
 */
public class CSFOBPMProvRequestData {
	
	private String taskTransId;
	private String masterTransId;
	private TaskInfo taskinfo;
    private Order order;
    private Collection<Product> product;
    
    public CSFOBPMProvRequestData() {
	}
    
    
	public CSFOBPMProvRequestData(String taskTransId, String masterTransId, TaskInfo taskinfo, Order order, Collection<Product> product) {
		this.taskTransId = taskTransId;
		this.masterTransId = masterTransId;
		this.taskinfo = taskinfo;
		this.order = order;
		this.product = product;
	}
	
	public String getTaskTransId() {
		return taskTransId;
	}


	public void setTaskTransId(String taskTransId) {
		this.taskTransId = taskTransId;
	}


	public String getMasterTransId() {
		return masterTransId;
	}


	public void setMasterTransId(String masterTransId) {
		this.masterTransId = masterTransId;
	}


	public TaskInfo getTaskInfo() {
		return taskinfo;
	}
	
	public void setTaskInfo(TaskInfo taskinfo) {
		this.taskinfo = taskinfo;
	}
	
	public Order getOrder() {
		return order;
	}
	
	public void setOrder(Order order) {
		this.order = order;
	}

	public Collection<Product> getProduct() {
		return product;
	}

	public void setProduct(Collection<Product> product) {
		this.product = product;
	}
    

}
