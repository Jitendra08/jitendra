package com.att.tpp.xml.model;

import java.util.Collection;

public class Product {
    
    private String category;
    private String id;
    private String action;
    private String productDescription;
    private String effectiveDate;
    private String expirationDate;
    private String status;
    private Collection<Attribute> attribute;
    
	public Product() {
	}
	
	public Product(String category, String id, String action, String effectiveDate, String expirationDate,
			Collection<Attribute> attribute) {
		super();
		this.category = category;
		this.id = id;
		this.action = action;
		this.effectiveDate = effectiveDate;
		this.expirationDate = expirationDate;
		this.attribute = attribute;
	}



	public Product(String id, String action, Collection<Attribute> attribute) {
		super();
		this.id = id;
		this.action = action;
		this.attribute = attribute;
	}

	public String getCategory() {
		return category;
	}

	public void setCategory(String category) {
		this.category = category;
	}

	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public String getAction() {
		return action;
	}

	public void setAction(String action) {
		this.action = action;
	}

	public String getProductDescription() {
		return productDescription;
	}

	public void setProductDescription(String productDescription) {
		this.productDescription = productDescription;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public Collection<Attribute> getAttribute() {
		return attribute;
	}

	public void setAttribute(Collection<Attribute> attribute) {
		this.attribute = attribute;
	}

}
