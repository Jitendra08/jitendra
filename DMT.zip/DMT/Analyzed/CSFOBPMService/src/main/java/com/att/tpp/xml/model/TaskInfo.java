/**
 * 
 */
package com.att.tpp.xml.model;

/**
 * @author rg730b
 *
 */
public class TaskInfo {
	
	private String taskTransId; 
	private String notificationURL;
	private String routingCarrier;
	private String provisioningCarrier;
	private String system;
	private String url;
	private String proxyEnabled;
	private String currentTechRetryCount;
	private String maxTechRetryCount;
	private String currentNoResponseRetryCount;
	private String maxNoResponseRetryCount;
	private String eventType;
	
	
	public TaskInfo(String taskTransId, String notificationURL, String routingCarrier, String provisioningCarrier,
			String system, String url, String proxyEnabled, String currentTechRetryCount, String maxTechRetryCount,
			String currentNoResponseRetryCount, String maxNoResponseRetryCount, String eventType) {
		super();
		this.taskTransId = taskTransId;
		this.notificationURL = notificationURL;
		this.routingCarrier = routingCarrier;
		this.provisioningCarrier = provisioningCarrier;
		this.system = system;
		this.url = url;
		this.proxyEnabled = proxyEnabled;
		this.currentTechRetryCount = currentTechRetryCount;
		this.maxTechRetryCount = maxTechRetryCount;
		this.currentNoResponseRetryCount = currentNoResponseRetryCount;
		this.maxNoResponseRetryCount = maxNoResponseRetryCount;
		this.eventType = eventType;
	}


	public String getTaskTransId() {
		return taskTransId;
	}


	public void setTaskTransId(String taskTransId) {
		this.taskTransId = taskTransId;
	}


	public String getNotificationURL() {
		return notificationURL;
	}


	public void setNotificationURL(String notificationURL) {
		this.notificationURL = notificationURL;
	}


	public String getRoutingCarrier() {
		return routingCarrier;
	}


	public void setRoutingCarrier(String routingCarrier) {
		this.routingCarrier = routingCarrier;
	}


	public String getProvisioningCarrier() {
		return provisioningCarrier;
	}


	public void setProvisioningCarrier(String provisioningCarrier) {
		this.provisioningCarrier = provisioningCarrier;
	}


	public String getSystem() {
		return system;
	}


	public void setSystem(String system) {
		this.system = system;
	}


	public String getUrl() {
		return url;
	}


	public void setUrl(String url) {
		this.url = url;
	}


	public String getProxyEnabled() {
		return proxyEnabled;
	}


	public void setProxyEnabled(String proxyEnabled) {
		this.proxyEnabled = proxyEnabled;
	}


	public String getCurrentTechRetryCount() {
		return currentTechRetryCount;
	}


	public void setCurrentTechRetryCount(String currentTechRetryCount) {
		this.currentTechRetryCount = currentTechRetryCount;
	}


	public String getMaxTechRetryCount() {
		return maxTechRetryCount;
	}


	public void setMaxTechRetryCount(String maxTechRetryCount) {
		this.maxTechRetryCount = maxTechRetryCount;
	}


	public String getCurrentNoResponseRetryCount() {
		return currentNoResponseRetryCount;
	}


	public void setCurrentNoResponseRetryCount(String currentNoResponseRetryCount) {
		this.currentNoResponseRetryCount = currentNoResponseRetryCount;
	}


	public String getMaxNoResponseRetryCount() {
		return maxNoResponseRetryCount;
	}


	public void setMaxNoResponseRetryCount(String maxNoResponseRetryCount) {
		this.maxNoResponseRetryCount = maxNoResponseRetryCount;
	}


	public String getEventType() {
		return eventType;
	}


	public void setEventType(String eventType) {
		this.eventType = eventType;
	}
	
	
}
