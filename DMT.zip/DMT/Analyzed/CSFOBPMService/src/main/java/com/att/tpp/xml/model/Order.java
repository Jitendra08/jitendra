/**
 * 
 */
package com.att.tpp.xml.model;

/**
 * @author rg730b
 *
 */
public class Order {
	
	private Account account;
	private Subscriber subscriber;
    private BillingAccount billingAccount;
    private String locationId;
    private Forms forms;
    private EventTypeInfo eventType;
    
    public Order() {
	}
    
	public Order(Account account, Subscriber subscriber, BillingAccount billingAccount, String locationId, Forms forms, EventTypeInfo eventType){
		super();
		this.account = account;
		this.subscriber = subscriber;
		this.billingAccount = billingAccount;
		this.locationId = locationId;
		this.forms = forms;
		this.eventType = eventType;
		
	}

	public Account getAccount() {
		return account;
	}

	public void setAccount(Account account) {
		this.account = account;
	}

	public Subscriber getSubscriber() {
		return subscriber;
	}

	public void setSubscriber(Subscriber subscriber) {
		this.subscriber = subscriber;
	}

	public BillingAccount getBillingAccount() {
		return billingAccount;
	}

	public void setBillingAccount(BillingAccount billingAccount) {
		this.billingAccount = billingAccount;
	}
	
	public String getLocationId() {
		return locationId;
	}

	public void setLocationId(String locationId) {
		this.locationId = locationId;
	}

	public Forms getForms() {
		return forms;
	}

	public void setForms(Forms forms) {
		this.forms = forms;
	}

	public EventTypeInfo getEventType() {
		return eventType;
	}

	public void setEventType(EventTypeInfo eventType) {
		this.eventType = eventType;
	}

}
