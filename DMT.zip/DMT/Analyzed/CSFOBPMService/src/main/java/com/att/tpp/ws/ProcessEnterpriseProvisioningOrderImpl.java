/**
 * 
 */
package com.att.tpp.ws;

import java.sql.Timestamp;
import java.util.Date;

import javax.xml.ws.Holder;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cingular.csi.csi.namespaces.fobpmprovisioning._209_0.wsdl.fobpmprovisioningcsi.ProcessEnterpriseProvisioningOrderPortType;
import com.cingular.csi.csi.namespaces.fobpmprovisioning.infrastructurecommon.container._public.requestacknowledgement.RequestAcknowledgementInfo;
import com.cingular.csi.csi.namespaces.fobpmprovisioning.infrastructurecommon.types._public.messageheader.MessageHeaderInfo;
import com.cingular.csi.csi.namespaces.fobpmprovisioning._209_0.wsdl.fobpmprovisioningcsi.CSIApplicationException;
import com.cingular.csi.csi.namespaces.container._public.processenterpriseprovisioningorderrequest.ProcessEnterpriseProvisioningOrderRequestInfo;
import com.att.tpp.model.CsfobpmResponseData;
import com.att.tpp.service.CSFOBPMService;
import com.att.tpp.utils.TPP_CSFOBPMRequestGenerator;
import com.att.tpp.xml.model.CSFOBPMProvRequestData;

/**
 * @author rg730b
 *
 */

@Service("pepo")
public class ProcessEnterpriseProvisioningOrderImpl implements ProcessEnterpriseProvisioningOrder{
	
	private static final Logger processEnterpriseProvisioningOrderLog = Logger.getLogger(ProcessEnterpriseProvisioningOrderImpl.class);
	
	@Autowired
	private CSFOBPMMessageHeaderService csfobpmMessageHeaderService;
	
	@Autowired
	private ProcessEnterpriseProvisioningOrderPortType pepoDIPType;
	
	@Autowired
	private CSFOBPMService csfobpmService;
	
	 private final static String initializing = "Initializing";
	 private final static String pepo = "PEPO";
	 private final static String exceptionCode = "900";
	
	@Override
	public CsfobpmResponseData getRequestAcknowledgementInfo(CSFOBPMProvRequestData csfobpmRequestData, String provRequestXML, String messageId) throws Exception{
		
		CsfobpmResponseData csfobpmResponseData = new CsfobpmResponseData();
		csfobpmResponseData.setTppTransactionid(messageId);
		csfobpmResponseData.setDipType(pepo);
		
		Holder<MessageHeaderInfo> messageHeader = null;
		try {
			messageHeader = csfobpmMessageHeaderService.generateCSFOBPMMessageHeader(messageId);
		} catch (Exception e) {
			processEnterpriseProvisioningOrderLog.info("Exception occured while generating CSFOBPMMessageHeader, TransactionId: "+messageId);
			//e.printStackTrace();
			processEnterpriseProvisioningOrderLog.error("Exception occured while generating CSFOBPMMessageHeader : "+e.getMessage());
			throw e;
		}
		ProcessEnterpriseProvisioningOrderRequestInfo pepoReqInfo = new ProcessEnterpriseProvisioningOrderRequestInfo();
		TPP_CSFOBPMRequestGenerator pepoInfo = new TPP_CSFOBPMRequestGenerator();
		pepoReqInfo=pepoInfo.generateCSFOBPMRequestData(csfobpmRequestData);
		
		RequestAcknowledgementInfo pepoResp = null;
		boolean persistCSFOBPMdipResults=false;
		boolean updateCSFOBPMdipResults=false;
		try {
			Date reqTime = new Date();
			processEnterpriseProvisioningOrderLog.info("Posting to CSFOBPM with TransactionId: "+messageId +"with time:"+new Timestamp(reqTime.getTime()));
			csfobpmResponseData.setReqTimeStamp(new Timestamp(reqTime.getTime()));
			csfobpmResponseData.setCsiResponsecode(initializing);
			csfobpmResponseData.setCsiResponsedesc(initializing);
			
			persistCSFOBPMdipResults = csfobpmService.insertCsfobpmMessage(provRequestXML, csfobpmRequestData, csfobpmResponseData);
			processEnterpriseProvisioningOrderLog.info("PEPO Request insert in CSFOBPM_MESSAGE_TRACKING table: "+persistCSFOBPMdipResults);
			
			pepoResp = pepoDIPType.processEnterpriseProvisioningOrder(messageHeader, pepoReqInfo);
			
			csfobpmResponseData.setCsiResponsecode(pepoResp.getResponse().getCode());
			csfobpmResponseData.setCsiResponsedesc(pepoResp.getResponse().getDescription());
			Date resTime = new Date();
			csfobpmResponseData.setResTimeStamp(new Timestamp(resTime.getTime()));
			processEnterpriseProvisioningOrderLog.info("Received response from CSFOBPM with TransactionId: "+messageId+"with time:"+new Timestamp(resTime.getTime()));
			//persistCSFOBPMdipResults = csfobpmService.persistDipResults(provRequestXML, csfobpmRequestData, csfobpmResponseData);
			updateCSFOBPMdipResults = csfobpmService.updateCsfobpmMsg(csfobpmResponseData);
			processEnterpriseProvisioningOrderLog.info("PEPO Result insert in CSFOBPM_MESSAGE_TRACKING table: "+updateCSFOBPMdipResults);
			
		} catch (CSIApplicationException e) {
			csfobpmResponseData.setCsiResponsecode(e.getFaultInfo().getResponse().getCode());
			csfobpmResponseData.setCsiResponsedesc(e.getFaultInfo().getResponse().getDescription());
			Date csiExpTime = new Date();
			csfobpmResponseData.setResTimeStamp(new Timestamp(csiExpTime.getTime()));
			processEnterpriseProvisioningOrderLog.info("Received CSIApplicationException from CSFOBPM with TransactionId: "+messageId +" with time: "+new Timestamp(csiExpTime.getTime()));

			//persistCSFOBPMdipResults = csfobpmService.persistDipResults(provRequestXML, csfobpmRequestData, csfobpmResponseData);
			updateCSFOBPMdipResults = csfobpmService.updateCsfobpmMsg(csfobpmResponseData);
			processEnterpriseProvisioningOrderLog.info("CSIApplicationException PEPO Result insert in CSFOBPM_MESSAGE_TRACKING table: "+updateCSFOBPMdipResults);
			
		} catch (Exception e) {
			csfobpmResponseData.setCsiResponsecode(exceptionCode);
			csfobpmResponseData.setCsiResponsedesc(e.getMessage());
			Date expTime = new Date();
			csfobpmResponseData.setResTimeStamp(new Timestamp(expTime.getTime()));
			processEnterpriseProvisioningOrderLog.info("Received Exception from CSFOBPM with TransactionId: "+messageId+" with time: "+new Timestamp(expTime.getTime()));
			
			//persistCSFOBPMdipResults = csfobpmService.persistDipResults(provRequestXML, csfobpmRequestData, csfobpmResponseData);
			updateCSFOBPMdipResults = csfobpmService.updateCsfobpmMsg(csfobpmResponseData);
			processEnterpriseProvisioningOrderLog.info("Exception in PEPO DIP :: PEPO Result insert in CSFOBPM_MESSAGE_TRACKING table: "+updateCSFOBPMdipResults);
		}
		return csfobpmResponseData;
	}

}
