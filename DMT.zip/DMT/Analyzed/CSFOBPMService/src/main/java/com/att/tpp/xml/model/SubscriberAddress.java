package com.att.tpp.xml.model;

public class SubscriberAddress {

	private String type;
	private String street;
	private String city;
	private String state;
	private String postalCode;
	private String postalPlusCode;
	private String countryName;
	private String countryCode;
	private String geoCode;
	private String localCompanyName;
	
	
	/**
	 * @param type
	 * @param street
	 * @param city
	 * @param state
	 * @param postalCode
	 * @param countryCode
	 */
	public SubscriberAddress(String type, String street, String city, String state,
			String postalCode, String countryCode) {
		this.type = type;
		this.street = street;
		this.city = city;
		this.state = state;
		this.postalCode = postalCode;
		this.countryCode = countryCode;
	}

	/**
	 * @param street
	 * @param city
	 * @param state
	 * @param postalCode
	 * @param postalPlusCode
	 * @param countryName
	 * @param countryCode
	 * @param geoCode
	 * @param localCompanyName
	 */
	public SubscriberAddress(String street, String city, String state, String postalCode,
			String postalPlusCode, String countryName, String countryCode,
			String geoCode, String localCompanyName) {
		this.street = street;
		this.city = city;
		this.state = state;
		this.postalCode = postalCode;
		this.postalPlusCode = postalPlusCode;
		this.countryName = countryName;
		this.countryCode = countryCode;
		this.geoCode = geoCode;
		this.localCompanyName = localCompanyName;
	}

	/**
	 * @param type
	 * @param street
	 * @param city
	 * @param state
	 * @param postalCode
	 * @param postalPlusCode
	 * @param countryName
	 * @param countryCode
	 * @param geoCode
	 * @param localCompanyName
	 */
	public SubscriberAddress(String type, String street, String city, String state,
			String postalCode, String postalPlusCode, String countryName,
			String countryCode, String geoCode, String localCompanyName) {
		this.type = type;
		this.street = street;
		this.city = city;
		this.state = state;
		this.postalCode = postalCode;
		this.postalPlusCode = postalPlusCode;
		this.countryName = countryName;
		this.countryCode = countryCode;
		this.geoCode = geoCode;
		this.localCompanyName = localCompanyName;
	}

	/**
	 * @return the type
	 */
	public String getType() {
		return type;
	}
	
	/**
	 * @param type the type to set
	 */
	public void setType(String type) {
		this.type = type;
	}
	
	/**
	 * @return the street
	 */
	public String getStreet() {
		return street;
	}
	
	/**
	 * @param street the street to set
	 */
	public void setStreet(String street) {
		this.street = street;
	}
	
	/**
	 * @return the city
	 */
	public String getCity() {
		return city;
	}
	
	/**
	 * @param city the city to set
	 */
	public void setCity(String city) {
		this.city = city;
	}
	
	/**
	 * @return the state
	 */
	public String getState() {
		return state;
	}
	
	/**
	 * @param state the state to set
	 */
	public void setState(String state) {
		this.state = state;
	}
	
	/**
	 * @return the postalCode
	 */
	public String getPostalCode() {
		return postalCode;
	}
	
	/**
	 * @param postalCode the postalCode to set
	 */
	public void setPostalCode(String postalCode) {
		this.postalCode = postalCode;
	}
	
	/**
	 * @return the postalPlusCode
	 */
	public String getPostalPlusCode() {
		return postalPlusCode;
	}
	
	/**
	 * @param postalPlusCode the postalPlusCode to set
	 */
	public void setPostalPlusCode(String postalPlusCode) {
		this.postalPlusCode = postalPlusCode;
	}
	
	/**
	 * @return the countryName
	 */
	public String getCountryName() {
		return countryName;
	}
	
	/**
	 * @param countryName the countryName to set
	 */
	public void setCountryName(String countryName) {
		this.countryName = countryName;
	}
	
	/**
	 * @return the countryCode
	 */
	public String getCountryCode() {
		return countryCode;
	}
	
	/**
	 * @param countryCode the countryCode to set
	 */
	public void setCountryCode(String countryCode) {
		this.countryCode = countryCode;
	}
	
	/**
	 * @return the geoCode
	 */
	public String getGeoCode() {
		return geoCode;
	}
	
	/**
	 * @param geoCode the geoCode to set
	 */
	public void setGeoCode(String geoCode) {
		this.geoCode = geoCode;
	}
	
	/**
	 * @return the localCompanyName
	 */
	public String getLocalCompanyName() {
		return localCompanyName;
	}
	
	/**
	 * @param localCompanyName the localCompanyName to set
	 */
	public void setLocalCompanyName(String localCompanyName) {
		this.localCompanyName = localCompanyName;
	}
	
}
