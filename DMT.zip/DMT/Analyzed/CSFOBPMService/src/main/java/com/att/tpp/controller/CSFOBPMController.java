package com.att.tpp.controller;

import java.io.IOException;
import java.util.List;

import javax.jms.JMSException;
import javax.xml.transform.TransformerConfigurationException;
import javax.xml.transform.TransformerFactoryConfigurationError;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.att.tpp.model.CSIRetryErrors;
import com.att.tpp.model.CsfobpmResponseData;
import com.att.tpp.model.ProcessingResult;
import com.att.tpp.service.CSFOBPMService;
import com.att.tpp.utils.ParseProvRequestData;
import com.att.tpp.xml.model.CSFOBPMProvRequestData;


@Service("csfobpmController")
public class CSFOBPMController {
	
	@Autowired
	private CSFOBPMService csfobpmService;
	
	private static final Logger csfobpmControllerLog = Logger.getLogger(CSFOBPMController.class);


	private final static String CSFOBPM_TransactionRequestXSD = "CSFOBPM_TransactionRequest.xsd";
	
	
	public ProcessingResult processRequest(String csfobpmRequestXML, String messageId) 	
			throws IOException, Exception {
		ProcessingResult processingResult = new ProcessingResult();
		csfobpmControllerLog.info("CSFOBPM Controller Started");
		ParseProvRequestData parseProvRequestData = new ParseProvRequestData(); 
		boolean isValidRequestXML = csfobpmService.validateXML(csfobpmRequestXML, CSFOBPM_TransactionRequestXSD);
		csfobpmControllerLog.info("isValidRequestXML: "+isValidRequestXML);
		
		if(isValidRequestXML){
			String parseSystemName = parseProvRequestData.parseSystemName(csfobpmRequestXML);
			processingResult.setSystemName(parseSystemName);
			csfobpmControllerLog.info("System Name : "+parseSystemName);
			
			if (parseSystemName != null && parseSystemName != "" && parseSystemName.equalsIgnoreCase("CSFOBPM")) {
				
				/* Parse the CSFOBPMRequestXML and store in the CSFOBPMProvRequestData */
				CSFOBPMProvRequestData csfobpmRequestData = new CSFOBPMProvRequestData();					
				csfobpmRequestData= parseProvRequestData.parseCSFOBPMRequestXML(csfobpmRequestXML);
				
				/* Posting the request to csfobpm */
				CsfobpmResponseData postResultData = csfobpmService.postRequest(csfobpmRequestData, csfobpmRequestXML, messageId);

				/* Insert into TransCodes to update the response status */
				boolean insertTransCodeResult = csfobpmService.insertTransCodes(csfobpmRequestData, postResultData);
				csfobpmControllerLog.info("insertTransCodeResult : "+insertTransCodeResult);
												
				/* Update Timer Table to update the Task status */
				boolean updateTimerTableResult = csfobpmService.updateTimerTable(postResultData,csfobpmRequestXML,csfobpmRequestData);
				csfobpmControllerLog.info("updateTimerTableResult : "+updateTimerTableResult);

				/* If Retry exceeded then call to Workflow service to close the loop */
				boolean retryExceded = csfobpmService.verifyRetryExceeded(csfobpmRequestData, messageId);
				csfobpmControllerLog.info("retryExceded : "+retryExceded);
			
				/* UpdateInterfaceTable	to update the Connectivity status for the Vendor */			
				boolean updateInterface = csfobpmService.updateConnectivityStatus(csfobpmRequestData, csfobpmRequestData.getTaskInfo().getUrl(), postResultData);
				csfobpmControllerLog.info("updateInterface table : "+updateInterface);
				
				/* If Error Code is not retryable then Generate ErrorResponder and Send to Response Service to close the loop */
				if(!(postResultData.getCsiResponsecode().equals("0"))){
					if(verifySendErrorResponse(postResultData)){
						csfobpmControllerLog.info("Inside generateDynamicErrorResponder : ");
						csfobpmService.generateDynamicErrorResponder(csfobpmRequestXML,csfobpmRequestData,postResultData);
					}
				}
			}else{
				csfobpmControllerLog.info("Not CSFOBPM transaction, so dropping the transaciton");
			}
				
		}else{
			csfobpmControllerLog.info("RequestXML is not valid, so dropping the transaciton");
		}
		
		return processingResult;
	}

	private boolean verifySendErrorResponse(CsfobpmResponseData postResultData) throws Exception {		
		csfobpmControllerLog.info("Inside the verifySendErrorResponse :" + postResultData.getCsiResponsecode());
		if(postResultData.getCsiResponsecode()!=null){
			String eventName=postResultData.getDipType();
			List<CSIRetryErrors> csiRetryError = csfobpmService.getCSIRetryError(eventName);
			csfobpmControllerLog.info("Inside the verifySendErrorResponse csiRetryError size :" + csiRetryError.size());
			for (CSIRetryErrors retryInfo : csiRetryError) {
				if(postResultData.getCsiResponsecode().equals(retryInfo.getErrorCode())){
					csfobpmControllerLog.info("Retry Code Exist: " + postResultData.getCsiResponsecode());		
					return false;
				}
			}
		}
		return true;
	}
	
	public void loadInitialData() throws TransformerConfigurationException, TransformerFactoryConfigurationError, JMSException {
		csfobpmService.loadInitialData();
	}
}
