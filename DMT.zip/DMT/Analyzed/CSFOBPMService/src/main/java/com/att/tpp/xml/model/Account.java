package com.att.tpp.xml.model;

public class Account {

    private String msisdn;
    private String prevMSISDN;
    private String subscriberNumber;
    private String ban;
    private String banName;
    private String prevBAN;
    private String accountTypeIndicator;
    private String socEffectiveDate;
        
	public Account(String msisdn) {
		this.msisdn = msisdn;
	}
	
	public Account(String msisdn, String subscriberNumber) {
		this.msisdn = msisdn;
		this.subscriberNumber = subscriberNumber;
	}

	public Account(String msisdn, String subscriberNumber, String ban) {
		this.msisdn = msisdn;
		this.subscriberNumber = subscriberNumber;
		this.ban = ban;
	}

	public Account(	String msisdn, 
					String prevMSISDN, 
					String subscriberNumber, 
					String ban, 
					String banName,
					String prevBAN, 
					String accountTypeIndicator,
					String socEffectiveDate) {
		this.msisdn = msisdn;
		this.prevMSISDN = prevMSISDN;
		this.subscriberNumber = subscriberNumber;
		this.ban = ban;
		this.banName = banName;
		this.prevBAN = prevBAN;
		this.accountTypeIndicator = accountTypeIndicator;
		this.socEffectiveDate = socEffectiveDate;
	}

	public String getMsisdn() {
		return msisdn;
	}
	
	public void setMsisdn(String msisdn) {
		this.msisdn = msisdn;
	}
	
	public String getPrevMSISDN() {
		return prevMSISDN;
	}
	
	public void setPrevMSISDN(String prevMSISDN) {
		this.prevMSISDN = prevMSISDN;
	}
	
	public String getSubscriberNumber() {
		return subscriberNumber;
	}
	
	public void setSubscriberNumber(String subscriberNumber) {
		this.subscriberNumber = subscriberNumber;
	}
	
	public String getBan() {
		return ban;
	}
	
	public void setBan(String ban) {
		this.ban = ban;
	}
	
	public String getBanName() {
		return banName;
	}
	
	public void setBanName(String banName) {
		this.banName = banName;
	}
	
	public String getPrevBAN() {
		return prevBAN;
	}
	
	public void setPrevBAN(String prevBAN) {
		this.prevBAN = prevBAN;
	}
	
	public String getAccountTypeIndicator() {
		return accountTypeIndicator;
	}
	
	public void setAccountTypeIndicator(String accountTypeIndicator) {
		this.accountTypeIndicator = accountTypeIndicator;
	}
	
	public String getSocEffectiveDate() {
		return socEffectiveDate;
	}
	
	public void setSocEffectiveDate(String socEffectiveDate) {
		this.socEffectiveDate = socEffectiveDate;
	}
	
}
