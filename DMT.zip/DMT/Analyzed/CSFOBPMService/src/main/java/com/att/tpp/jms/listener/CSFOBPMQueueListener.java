
package com.att.tpp.jms.listener;

import javax.annotation.PostConstruct;
import javax.jms.JMSException;
import javax.jms.Message;
import javax.jms.MessageListener;
import javax.jms.TextMessage;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;

import com.att.tpp.controller.CSFOBPMController;
import com.att.tpp.model.ProcessingResult;

/**
 * CSFOBPMQueueListener consume messages from Communication request queue and validate the request
 * if valid post to the CSFOBPM.
 */

public class CSFOBPMQueueListener implements MessageListener
{

	private static final Logger csfobpmQueueListenerLog = Logger.getLogger(CSFOBPMQueueListener.class);

	@Autowired
	private CSFOBPMController csfobpmController;
	
	@PostConstruct
	public void loadInitialData() throws Exception {
		csfobpmQueueListenerLog.info("Setting Initial Configurations: Started. It will take few minutes.... please wait");
		csfobpmController.loadInitialData();
		csfobpmQueueListenerLog.info("Setting Initial Configurations: Completed");
	}
	/**
	 * Method implements JMS onMessage and acts as the entry
	 * point for messages consumed by Springs DefaultMessageListenerContainer.
	 * When DefaultMessageListenerContainer picks a message from the queue it
	 * invokes this method with the message payload.
	 */

	public void onMessage(Message csfobpmMessage)
	{
		csfobpmQueueListenerLog.debug("Received message from Communication Queue [" + csfobpmMessage +"]");
		
		/* The message must be of type TextMessage */
		if (csfobpmMessage instanceof TextMessage)
		{
			try
			{
				String requestXML = ((TextMessage) csfobpmMessage).getText();
				csfobpmQueueListenerLog.info("Communication Provisioning request XML received : " + requestXML);				
				String messageId = csfobpmMessage.getStringProperty("csfobpmTransactionId");	
				ProcessingResult processingResult =csfobpmController.processRequest(requestXML, messageId);
				csfobpmQueueListenerLog.info("MessageId :"+processingResult.getTppProvReq());
			}
			catch (JMSException jmsException)
			{
				String errorMsg = "Error occurred while extracting message in CSFOBPMQueueListener ";
				csfobpmQueueListenerLog.error(errorMsg, jmsException);
				
			}catch (Exception e) {
				//e.printStackTrace();
				csfobpmQueueListenerLog.error("Exception occurred while extracting message in CSFOBPMQueueListener"+e.getMessage());
			}
		}
		else
		{
			String errorMsg = "Message is not of expected type TextMessage in CSFOBPMQueueListener";
			csfobpmQueueListenerLog.error(errorMsg);
			throw new RuntimeException(errorMsg);
		}
	}


}