/**
 * 
 */
package com.att.tpp.xml.model;

import java.util.List;

/**
 * @author rg730b
 *
 */
public class FormData {
	
	private List<Fields> fields;
	
	public FormData(List<Fields> fields) {
		this.fields = fields;
	}

	public List<Fields> getFields() {
		return fields;
	}

	public void setParameterDetails(List<Fields> fields) {
		this.fields = fields;
	}

}
