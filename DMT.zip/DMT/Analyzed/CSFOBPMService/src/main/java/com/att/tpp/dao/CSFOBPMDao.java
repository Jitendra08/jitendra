package com.att.tpp.dao;

import java.math.BigDecimal;
import java.util.List;

import com.att.tpp.model.CSIRetryErrors;
import com.att.tpp.model.CsfobpmMessageTracking;
import com.att.tpp.model.CsfobpmResponseData;
import com.att.tpp.model.RetryConfiguration;
import com.att.tpp.model.jpa.ProvisioningRequest;
import com.att.tpp.model.jpa.ProvisioningTask;
import com.att.tpp.model.jpa.Timer;
import com.att.tpp.model.jpa.TransCode;

public interface CSFOBPMDao {
	
	List<RetryConfiguration> getRetryConfigurationList();
	
	List<ProvisioningRequest> queryProvisioningRequest(String masterTransId);	

	Boolean insertTransCodes(List<TransCode> transCodeList);
	
	boolean updateInterfaceTable(String parseSystemName, String connectivityStatus);
	
	List<ProvisioningTask> queryProvisioningTasks(String taskTransId);
	
	List<Timer> queryTimerTable(String taskTransId);
	
	boolean updateTimer(String taskTransId, String waitingsystemresponse, int waitTime, String payLoad, String payLoadOverflow);

	boolean deleteFromTimer(String taskTransId);

	boolean insertTimer(Timer timer);
	
	boolean updatePostFailedTaskStatus(String taskTransId, String taskStatus, BigDecimal currTechRetryCount);
	
	public List<CSIRetryErrors> getCSIRetryError(String eventName) throws Exception;
	
	public boolean insertCsfobpmMessage(CsfobpmMessageTracking csfobpmMessageTracking);
	
	public boolean updateCsfobpmMsg(CsfobpmResponseData resData);

}