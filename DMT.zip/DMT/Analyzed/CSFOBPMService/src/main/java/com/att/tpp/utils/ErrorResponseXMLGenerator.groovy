/**
 * 
 */
package com.att.tpp.utils

import com.att.tpp.model.ProductsPK
import com.att.tpp.model.ProvisioningResponseDynamic
import com.att.tpp.model.TransactionCode
import com.att.tpp.model.TransactionCodeList
import com.att.tpp.xml.model.Products

import groovy.util.logging.Log4j
import groovy.xml.MarkupBuilder

/**
 * @author SC9833
 *
 */
@Log4j
class ErrorResponseXMLGenerator {

	/**
	 * 
	 */
	public ErrorResponseXMLGenerator() {
		// TODO Auto-generated constructor stub
	}
	
	
	/**
	 * getMaxTransCode provides the highest level Major Code.
	 * Leverage this method to get largest Major Code.
	 * 
	 * @param provResp
	 * @return maxCode
	 */
	def TransactionCode getMaxTransCode (ProvisioningResponseDynamic provResp){
		def maxCode = 0  //Initialize maxCode variable to 0, since this is a long data type.
		def maxCodeDesc = null //Initialize maxCodeDesc
		
		def maxCodeList = []  //List of all MajorCodes.
		def maxCodeListwithDesc = [:] //Map of MajorCodes with corresponding Description.
		
		/**
		 * Iterate through the products/product/transactionCode and create a list of transactionCode.majorCodes.		
		 */
		log.info("majorCode: " + provResp.productsCollection.size())
		provResp.productsCollection*.each {
			prod -> prod*.each{
				transCode -> maxCodeListwithDesc.put(transCode.transactionCode.majorCode, transCode.transactionCode.description)  //Populate Map using majorCode as key and description as value.
							 maxCodeList.add(transCode.transactionCode.majorCode)  //Populate list with all TransactionCode MajorCodes
			}
		}
		
		/**
		 * Call Collections.max on the list to get the largest value in the list.
		 */
		maxCode = Collections.max(maxCodeList)
		log.info("Maximum TransCode (buildTransCode): " + maxCode)
		
		maxCodeDesc = maxCodeListwithDesc.get(maxCode)
		log.info("MaxCode with Description: " + maxCodeDesc)		
		
		return new TransactionCode(maxCode, maxCodeDesc)
	}
	
	/**
	 * buildTransactionCode provides the highest error and generates the TransactionCode element.
	 * 
	 * @param mBuilder
	 * @param provResp
	 * 
	 */
	def buildTransactionCode(MarkupBuilder mBuilder, ProvisioningResponseDynamic provResp){
		def transCode = getMaxTransCode(provResp) //Get the TransactionCode with largest MajorCode and associated description for that MajorCode			
		mBuilder.TransactionCode(MajorCode:transCode.majorCode, Description:transCode.description)
	}
	
	/**
	 * buildAccountElement provides the Account Element with MSISDN attribute.
	 * 
	 * @param mBuilder
	 * @param msisdn
	 * 
	 */
	def buildAccountElement(MarkupBuilder mBuilder, def msisdn){
		def values = [:]
		
		values.put("MSISDN", msisdn)
		log.info(msisdn)
				
		mBuilder.Account(values)
	}
	
	/**
	 * buildProductsResponseElement generates the Products Element 
	 * with all the element children including the TransactionCode with TransactionCodeList.
	 * 
	 * 
	 * @param mBuilder
	 * @param provResp
	 * 
	 */
	def buildProductsResponseElement(MarkupBuilder mBuilder, ProvisioningResponseDynamic provResp){
		mBuilder.Products(){
			provResp.productsCollection*.each {			
				prod ->
				log.info("ProductId: " + prod.productsPK.productId)
				Product(Category:prod.category, Id:prod.productsPK.productId, Action:prod.productsPK.action){
					prod*.each{
						transCode ->
						log.info("TransCode: " + transCode.transactionCode.majorCode)
						TransactionCode(MajorCode:transCode.transactionCode.majorCode, Description:transCode.transactionCode.description){
							transCode.transactionCode.transactionCodeList*.each{
								transCodeList ->
								log.info("TransCodeList: " + transCodeList.errorCode.value)
								log.info("TransCodeList Desc: " + transCodeList.errorMessageText)
								TransactionCodeList(ErrorCode:transCodeList.errorCode.value, ErrorMessageText:transCodeList.errorMessageText)
							}							
						}						
					}
				}				
			}
		}
	}
	
	/**
	 * buildErrorRespXML generates the Provisioning Response XML 
	 * based on the values set in Provisioning Response Dynamic model. 
	 * 
	 * @param provResp
	 * @return provRespXML
	 */
	def String buildErrorRespXML(ProvisioningResponseDynamic provResp){		
		def provRespXML = new StringWriter()
		def xml = new MarkupBuilder(provRespXML)
		
		xml.setDoubleQuotes(true)
		xml.mkp.xmlDeclaration(version: "1.0", encoding: "UTF-8")
		
		xml.ProvisioningResponse("xmlns:xsi":"http://www.w3.org/2001/XMLSchema-instance", "xsi:noNamespaceSchemaLocation":"ProvisioningResponse.xsd", System:provResp.getSystemName()){
			Header(TransactionId:provResp.getTransactionId(), ProvisioningCarrier:provResp.getProvisioningCarrier(), RoutingCarrier:provResp.getRoutingCarrier(), TimeStamp:provResp.getReceivedTimeStamp()){
				buildTransactionCode(xml, provResp)
			}
			Order(){
				buildAccountElement(xml, provResp.getMsisdn())
				buildProductsResponseElement(xml, provResp)
			}
		}
		
		return provRespXML.toString()
	}

	static main(args) {		
		def now = new Date()  //Set today to NOW
		def prXML = new ErrorResponseXMLGenerator()
		def prDyn = null
			
		prDyn = new ProvisioningResponseDynamic("TransID_1234567", now, "TestResp", "14255551212",
			"ATT","CNGLR1", collect{[new Products(new ProductsPK("TransID_1234567", "1234", "Add"), "ABS1", new TransactionCode(0, "Success", collect{new TransactionCodeList(0, "Successful")})),
				new Products(new ProductsPK("TransID_1234567", "4567", "Add"), "ABS2", new TransactionCode(1000, "Info", collect{[new TransactionCodeList(1000, "Info"), new TransactionCodeList(70000, "retry"), new TransactionCodeList(1020, "HiKarthik")]}))]})  
		
		println(prXML.buildErrorRespXML(prDyn))
	
	}

}
