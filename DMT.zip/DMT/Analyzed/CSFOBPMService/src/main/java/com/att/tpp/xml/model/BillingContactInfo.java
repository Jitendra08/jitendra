/**
 * 
 */
package com.att.tpp.xml.model;

/**
 * @author rg730b
 *
 */
public class BillingContactInfo {
	
	private String firstName;
	private String lastName;
	private String businessName;
	
	
	public BillingContactInfo(String firstName, String lastName) {
		this.firstName = firstName;
		this.lastName = lastName;
	}
	
	public BillingContactInfo(String firstName, String lastName, String businessName) {
		this.firstName = firstName;
		this.lastName = lastName;
		this.businessName = businessName;
	}

	public String getFirstName() {
		return firstName;
	}
	
	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}
	
	public String getLastName() {
		return lastName;
	}
	
	public void setLastName(String lastName) {
		this.lastName = lastName;
	}

	public String getBusinessName() {
		return businessName;
	}

	public void setBusinessName(String businessName) {
		this.businessName = businessName;
	}

}
