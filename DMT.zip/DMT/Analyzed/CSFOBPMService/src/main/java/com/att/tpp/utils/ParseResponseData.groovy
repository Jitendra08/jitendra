package com.att.tpp.utils

import com.att.tpp.model.Products
import com.att.tpp.model.ProductsPK
import com.att.tpp.model.ProvisioningResponseDynamic
import com.att.tpp.model.TransactionCode

import groovy.util.logging.Log4j
import groovy.xml.MarkupBuilder
import java.util.Date

@Log4j
class ParseResponseData {
	
	def ProvisioningResponseDynamic getResponseData(String inXML, TransactionCode transCode){
		def csfobpmReq = new XmlSlurper().parseText(inXML)
		def now = new Date() 
		
		return new ProvisioningResponseDynamic(	
												csfobpmReq.TaskInfo.@Task_TransID.toString(), 
												now, 
												csfobpmReq.TaskInfo.@System.toString(), 
												csfobpmReq.Order.Account.@MSISDN.toString(),
												csfobpmReq.TaskInfo.@NotificationURL.toString(), 
												inXML,
												"NEW", 
												"MRC",
												csfobpmReq.TaskInfo.@ProvisioningCarrier.toString(),
												csfobpmReq.TaskInfo.@RoutingCarrier.toString(),
												csfobpmReq.TaskInfo.@Login.toString(),
												csfobpmReq.TaskInfo.@Password.toString(),
												csfobpmReq.Products.Product.collect{
													new Products(
														new ProductsPK(
															csfobpmReq.TaskInfo.@Task_TransID.toString(), 
															it.@Id.toString(), 
															it.@Action.toString()
															), 
															now, 
															it.@Category.toString(), 
															new TransactionCode(
																transCode.majorCode, 
																transCode.description, 
																transCode.transactionCodeList
																)
														)
													}
												)			
	}
	
/*	
	def String buildProvRespXML(ProvisioningResponseDynamic provResp){
		def provRespXML = new StringWriter()
		def xml = new MarkupBuilder(provRespXML)
		
		xml.setDoubleQuotes(true)
		xml.mkp.xmlDeclaration(version: "1.0", encoding: "UTF-8")
		
		xml.ProvisioningResponse(	"xmlns:xsi":"http://www.w3.org/2001/XMLSchema-instance", 
									"xsi:noNamespaceSchemaLocation":"ProvisioningResponse.xsd", 
									System:provResp.getSystemName()
								){
									Header(TransactionId:provResp.getTransactionId(), 
										ProvisioningCarrier:provResp.getProvisioningCarrier(), 
										RoutingCarrier:provResp.getRoutingCarrier(), 
										TimeStamp:provResp.getReceivedTimeStamp()
										){
											buildTransactionCode(xml, provResp)
										}
									Order(){
												buildAccountElement(xml, provResp.getMsisdn())
												buildProductsResponseElement(xml, provResp)
											}
								}
		
		return provRespXML.toString()
	}
*/	
	
	
}


