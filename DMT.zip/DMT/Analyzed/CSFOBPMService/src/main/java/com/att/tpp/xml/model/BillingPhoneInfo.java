package com.att.tpp.xml.model;

public class BillingPhoneInfo {
	
	private String homePhone;
	private String canBeReachedPhone;
	private String workPhone;
	private String workPhoneExtension;
	
	public BillingPhoneInfo(String homePhone, String canBeReachedPhone, String workPhone, String workPhoneExtension) {
		super();
		this.homePhone = homePhone;
		this.canBeReachedPhone = canBeReachedPhone;
		this.workPhone = workPhone;
		this.workPhoneExtension = workPhoneExtension;
	}

	public String getHomePhone() {
		return homePhone;
	}

	public void setHomePhone(String homePhone) {
		this.homePhone = homePhone;
	}

	public String getCanBeReachedPhone() {
		return canBeReachedPhone;
	}

	public void setCanBeReachedPhone(String canBeReachedPhone) {
		this.canBeReachedPhone = canBeReachedPhone;
	}

	public String getWorkPhone() {
		return workPhone;
	}

	public void setWorkPhone(String workPhone) {
		this.workPhone = workPhone;
	}

	public String getWorkPhoneExtension() {
		return workPhoneExtension;
	}

	public void setWorkPhoneExtension(String workPhoneExtension) {
		this.workPhoneExtension = workPhoneExtension;
	}
	
}
