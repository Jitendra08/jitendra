/**
 * 
 */
package com.att.tpp.xml.model;

/**
 * @author rg730b
 *
 */
public class BillingAddressInfo {
	
	private String type;
	private String addressLine1;
	private String addressLine2;
	private String countryName;
	private String state;
	private String postalPlusCode;
	private String postalCode;
	private String localCompanyName;
	private String city;
	private String countryCode;
	private String geoCode;
	
	public BillingAddressInfo(String type, String addressLine1, String addressLine2, String countryName, String state,
			String postalPlusCode, String postalCode, String localCompanyName, String city, String countryCode,
			String geoCode) {
		super();
		this.type = type;
		this.addressLine1 = addressLine1;
		this.addressLine2 = addressLine2;
		this.countryName = countryName;
		this.state = state;
		this.postalPlusCode = postalPlusCode;
		this.postalCode = postalCode;
		this.localCompanyName = localCompanyName;
		this.city = city;
		this.countryCode = countryCode;
		this.geoCode = geoCode;
	}

	public String getType() {
		return type;
	}

	public void setType(String type) {
		this.type = type;
	}

	public String getAddressLine1() {
		return addressLine1;
	}

	public void setAddressLine1(String addressLine1) {
		this.addressLine1 = addressLine1;
	}

	public String getAddressLine2() {
		return addressLine2;
	}

	public void setAddressLine2(String addressLine2) {
		this.addressLine2 = addressLine2;
	}

	public String getCountryName() {
		return countryName;
	}

	public void setCountryName(String countryName) {
		this.countryName = countryName;
	}

	public String getState() {
		return state;
	}

	public void setState(String state) {
		this.state = state;
	}

	public String getPostalPlusCode() {
		return postalPlusCode;
	}

	public void setPostalPlusCode(String postalPlusCode) {
		this.postalPlusCode = postalPlusCode;
	}

	public String getPostalCode() {
		return postalCode;
	}

	public void setPostalCode(String postalCode) {
		this.postalCode = postalCode;
	}

	public String getLocalCompanyName() {
		return localCompanyName;
	}

	public void setLocalCompanyName(String localCompanyName) {
		this.localCompanyName = localCompanyName;
	}

	public String getCity() {
		return city;
	}

	public void setCity(String city) {
		this.city = city;
	}

	public String getCountryCode() {
		return countryCode;
	}

	public void setCountryCode(String countryCode) {
		this.countryCode = countryCode;
	}

	public String getGeoCode() {
		return geoCode;
	}

	public void setGeoCode(String geoCode) {
		this.geoCode = geoCode;
	}
	
}
