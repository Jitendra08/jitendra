package com.att.tpp.service;

import java.io.IOException;
import java.math.BigDecimal;
import java.net.URL;
import java.sql.Timestamp;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.Iterator;
import java.util.List;

import javax.jms.JMSException;
import javax.xml.transform.TransformerConfigurationException;
import javax.xml.transform.TransformerFactoryConfigurationError;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.att.tpp.config.InitGlobalInstance;
import com.att.tpp.config.RetryConfigElement;
import com.att.tpp.dao.CSFOBPMDao;
import com.att.tpp.jms.sender.ResponseQueueSender;
import com.att.tpp.jms.sender.WorkflowOutBoundQueueSender;
import com.att.tpp.model.CSIRetryErrors;
import com.att.tpp.model.CsfobpmMessageTracking;
import com.att.tpp.model.CsfobpmResponseData;
import com.att.tpp.model.ProvisioningResponseDynamic;
import com.att.tpp.model.RetryConfiguration;
import com.att.tpp.model.TransactionCode;
import com.att.tpp.model.TransactionCodeList;
import com.att.tpp.model.jpa.ProvisioningRequest;
import com.att.tpp.model.jpa.ProvisioningTask;
import com.att.tpp.model.jpa.Timer;
import com.att.tpp.model.jpa.TimerPK;
import com.att.tpp.model.jpa.TransCode;
import com.att.tpp.utils.ParseResponseData;
import com.att.tpp.utils.ErrorResponseXMLGenerator;
import com.att.tpp.utils.TPP_WorkflowRequestXMLGenerator;
import com.att.tpp.utils.ValidateXMLUtil;
import com.att.tpp.ws.ProcessEnterpriseProvisioningOrder;
import com.att.tpp.xml.model.CSFOBPMProvRequestData;
import com.att.tpp.xml.model.Product;


@Service("csfobpmService")
public class CSFOBPMServiceImpl implements CSFOBPMService{
	
	private static final Logger csfobpmServiceLog = Logger.getLogger(CSFOBPMServiceImpl.class);
	
	@Autowired
	private CSFOBPMDao csfobpmDao;	
	
	@Autowired
	private ProcessEnterpriseProvisioningOrder pepo;
	
	@Autowired
	private WorkflowOutBoundQueueSender workflowOutBoundQueueSender;
	
	@Autowired
	private ResponseQueueSender responseQueueSender;
	
	

   private final static String schemaDir = "//com//att//tpp//common//schemas//";
   private final static String postSuccessDesc = "HTTP Post Successful to: ";
   private final static String postFailedDesc = "HTTP Post Failed System to: ";
   private final static String postSuccessCode = "0";
   private final static String postFailedMajorCode = "70000";
   private final static String postFailedMinorCode = "70010";
   
   private final static String waitingSystemResponse = "Waiting System Response";
   private final static String waitingToResubmit = "Waiting To Resubmit";
   private final static String indicatorY = "Y";
   private final static String wfErrored = "Errored";
   private final static String taskStatusPostFailed = "Post Failed/Waiting To Resubmit";
	
   ValidateXMLUtil validateXMLUtil = new ValidateXMLUtil();  
   ParseResponseData parseResponseData = new ParseResponseData();
   
   @Override
	@Transactional("configTransactionManager")
	public void loadInitialData() throws TransformerConfigurationException, TransformerFactoryConfigurationError, JMSException {
		
		List<RetryConfiguration> retryConfigList = csfobpmDao.getRetryConfigurationList();		
		
		for (RetryConfiguration retryConfiguration : retryConfigList) {
			InitGlobalInstance.storeCurrentRetryConfig(retryConfiguration.getId().getSystemName(), (int) retryConfiguration.getId().getRetryAttemptNum(), retryConfiguration.getId().getRetryType(), retryConfiguration.getWaitTime());			
		}		
		
		csfobpmServiceLog.info("loadInitialData is completed");
	}

   @Override
	public boolean validateXML(String communicationRequestXML, String xsdName) throws IOException, Exception {
		boolean validationResult = false;
		StringBuilder schemaLocation = new StringBuilder(schemaDir);
		schemaLocation.append(xsdName);
		URL xsdPath = CSFOBPMServiceImpl.class.getResource(schemaLocation.toString());
		csfobpmServiceLog.debug("xsdPath :" + xsdPath.toString());
		validationResult = validateXMLUtil.validateWithXSD(communicationRequestXML, xsdPath.toString());
		csfobpmServiceLog.debug("validationResult :" + validationResult);
		return validationResult;
	}

	@Override
	public CsfobpmResponseData postRequest(CSFOBPMProvRequestData csfobpmRequestData, String provisioningRequestXML, String messageId) throws Exception {

		CsfobpmResponseData csfobpmResData = new CsfobpmResponseData();
		Date date = new Date();	
		
		try {
			csfobpmResData = pepo.getRequestAcknowledgementInfo(csfobpmRequestData, provisioningRequestXML, messageId);
		} catch (Exception e) {
			//e.printStackTrace();
			csfobpmServiceLog.info("Exception occured while making postRequest: " + e.getMessage());
			csfobpmResData.setCsiResponsecode("900");
			csfobpmResData.setCsiResponsedesc(e.getMessage());
			csfobpmResData.setResTimeStamp(new Timestamp(date.getTime()));
			return csfobpmResData;
		}
		
		return csfobpmResData;
	}
	
	@Transactional("dataTransactionManager")
	public boolean insertTransCodes(CSFOBPMProvRequestData csfobpmRequestData, CsfobpmResponseData postResultData) {

		// Verify if record exist in Provisioning Request
		List<ProvisioningRequest> provisioningRequestList = csfobpmDao.queryProvisioningRequest(csfobpmRequestData.getMasterTransId());
		csfobpmServiceLog.info("insertTransCode : provisioningRequestList size>>>" + provisioningRequestList.size());
		if (provisioningRequestList.size() > 0) {
			// Generate TransCode List and Insert TransCode Data
			List<TransCode> transCodeList = generateTransCodeListData(csfobpmRequestData, postResultData);
			csfobpmServiceLog.info("insertTransCode : transCodeList size>>>" + transCodeList.size());
			Boolean insertTransCodes = csfobpmDao.insertTransCodes(transCodeList);
			csfobpmServiceLog.info("insertTransCode :" + insertTransCodes);
		} else {
			csfobpmServiceLog.info("Records are not found in the Provisioning Request table, so skipping the Trans code.");
			return false;
		}

		return true;
	}



	private List<TransCode> generateTransCodeListData(CSFOBPMProvRequestData csfobpmRequestData, CsfobpmResponseData postResultData) {
		
		String majorCode;		
		String majorDesc;					
		String minorCode;			
		String minorDesc;
		Date errorDate = new Date();
		
		List<TransCode> transCodeList = new ArrayList<TransCode>();
		TransCode transCode = null;
		
		Iterator<Product> productIterator = csfobpmRequestData.getProduct().iterator();
		
		String csiResDesc = null;
		
		if(postResultData != null && postResultData.getCsiResponsedesc().length() > 140){
			csiResDesc = postResultData.getCsiResponsedesc().substring(0, 140).toString();
		}else{
			csiResDesc = postResultData.getCsiResponsedesc().toString();
		}
		
		if(postResultData.getCsiResponsecode().equals("0")){
			majorCode = postSuccessCode;
			majorDesc = postSuccessDesc+csfobpmRequestData.getTaskInfo().getSystem();
			minorCode = postSuccessCode;
			//minorDesc = postSuccessDesc+csfobpmRequestData.getTaskInfo().getSystem()+ " Status: " + postResultData.getCsiResponsecode() + " Reason: "+postResultData.getCsiResponsedesc();
			minorDesc = postSuccessDesc+csfobpmRequestData.getTaskInfo().getSystem()+ " Status: " + postResultData.getCsiResponsecode() + " Reason: "+csiResDesc;
		}else{
			majorCode = postFailedMajorCode;
			majorDesc = postFailedDesc+csfobpmRequestData.getTaskInfo().getSystem();
			minorCode = postFailedMinorCode;
			//minorDesc = postFailedDesc+csfobpmRequestData.getTaskInfo().getSystem() + " Status: " + postResultData.getCsiResponsecode() + " Reason: "+postResultData.getCsiResponsedesc();
			minorDesc = postFailedDesc+csfobpmRequestData.getTaskInfo().getSystem() + " Status: " + postResultData.getCsiResponsecode() + " Reason: "+csiResDesc;
		}
		
		while (productIterator.hasNext()) {
			csfobpmServiceLog.info("productIterator :" );
			Product products = productIterator.next();
			csfobpmServiceLog.info("products.getId() :"+products.getId());
			transCode =new TransCode();
			transCode.setAction(products.getAction());
			transCode.setProductId(products.getId());
			transCode.setTaskTransid(csfobpmRequestData.getTaskTransId());
			transCode.setMasterTransid(csfobpmRequestData.getMasterTransId());			
			transCode.setErrorTime(new Timestamp(errorDate.getTime()));
			
			transCode.setMinordesc(minorDesc);
			transCode.setMajorcode(majorCode);
			transCode.setMajordesc(majorDesc);
			transCode.setMinorcode(minorCode);
			transCodeList.add(transCode);
		}
		return transCodeList;
	}

	public  Timestamp generateTimeStamp() throws ParseException {
		Date now = new Date();
		String VPP_DATE_FORMAT = "dd-MM-yyyy hh:mm a";
		SimpleDateFormat simpleDateFormat = new SimpleDateFormat(VPP_DATE_FORMAT);
		String formatedString = simpleDateFormat.format(now);
		java.util.Date parsedDate = simpleDateFormat.parse(formatedString);
		java.sql.Timestamp timestamp = new java.sql.Timestamp(parsedDate.getTime());
		return timestamp;
	}
	
	@Transactional("dataTransactionManager")
	public boolean updateConnectivityStatus(CSFOBPMProvRequestData provRequestData, String url, CsfobpmResponseData postResultData) {
		String connectivityStatus = getConnectivityStatus(url, postResultData);
		boolean updateInterface = csfobpmDao.updateInterfaceTable(provRequestData.getTaskInfo().getSystem(),connectivityStatus);
		return updateInterface;
	}

	private String getConnectivityStatus(String url, CsfobpmResponseData postResultData) {
		String connectivityStatus="Y";		
		if (url.contains("jms_absautoresponder")) {
			connectivityStatus="P";
		}else if(postResultData.getCsiResponsecode().equals("0")){
			connectivityStatus="G";	
		}
		return connectivityStatus;
	}
	
	@Transactional("dataTransactionManager")
	public boolean verifyRetryExceeded(CSFOBPMProvRequestData csfobpmRequestData, String messageId) throws JMSException {
		boolean retryExceeded = false;
		List<ProvisioningTask> provisioningTaskList = csfobpmDao.queryProvisioningTasks(csfobpmRequestData.getTaskTransId().trim());
		  
		if(provisioningTaskList.size()>0){
			ProvisioningTask provisioningTask = provisioningTaskList.get(0);
			BigDecimal currTechRetryCount = provisioningTask.getCurrTechRetryCount();
			BigDecimal maxTechRetryCount = provisioningTask.getMaxTechRetryCount();
		
			csfobpmServiceLog.info("verifyRetryExceeded currTechRetry = " + currTechRetryCount);
			csfobpmServiceLog.info("verifyRetryExceeded maxTechRetry = " + maxTechRetryCount);
			if(currTechRetryCount !=null && maxTechRetryCount !=null ){
				if (currTechRetryCount.intValue() >= maxTechRetryCount.intValue()){
					  retryExceeded = true;
					  TPP_WorkflowRequestXMLGenerator tppWorkflowRequestXMLGenerator =  new TPP_WorkflowRequestXMLGenerator();				
					  String createWorkflowRequestXML = tppWorkflowRequestXMLGenerator.createWorkflowRequestXML(csfobpmRequestData.getMasterTransId());
					  workflowOutBoundQueueSender.sendMessage(createWorkflowRequestXML, csfobpmRequestData.getMasterTransId());
					  csfobpmServiceLog.info("Send to Outbound WorkFlow Service : "+csfobpmRequestData.getMasterTransId());
				}
			}else{
				csfobpmServiceLog.info("currentTechRetryCount : "+currTechRetryCount +"maxTechRetryCount: "+ maxTechRetryCount +"should not be null");
			}
		}
		return retryExceeded;
	}
	
	@Transactional("dataTransactionManager")
	public boolean updateTimerTable(CsfobpmResponseData postResultData, String csfobpmRequestXML, CSFOBPMProvRequestData csfobpmRequestData) {
		
		boolean updateTimerTableResult = false; 
	
		try{
		  //Query Provisioning Tasks
		  List<ProvisioningTask> provisioningTaskList = csfobpmDao.queryProvisioningTasks(csfobpmRequestData.getTaskTransId().trim());
		  
		  if(provisioningTaskList.size()>0){
			  int waitTime=0;
			  ProvisioningTask provisioningTask = provisioningTaskList.get(0);	
			  
			  List<Timer> timerList = csfobpmDao.queryTimerTable(csfobpmRequestData.getTaskTransId().trim());
			  BigDecimal currTechRetryCount = provisioningTask.getCurrTechRetryCount();  
			  csfobpmServiceLog.info("updateTimerTable currTechRetryCount :"+ currTechRetryCount);
			  if(timerList!=null && timerList.size()>0){				  
				  BigDecimal maxTechRetryCount = provisioningTask.getMaxTechRetryCount();				  
				  BigDecimal currNoRespRetryCount = provisioningTask.getCurrNoRespRetryCount();
				  BigDecimal maxNoRespRetryCount = provisioningTask.getMaxNoRespRetryCount();
				  
				  csfobpmServiceLog.info("updateTimerTable maxTechRetryCount :"+ maxTechRetryCount);
				  csfobpmServiceLog.info("updateTimerTable currNoRespRetryCount :"+ currNoRespRetryCount);
				  csfobpmServiceLog.info("updateTimerTable maxNoRespRetryCount :"+ maxNoRespRetryCount);
				  
				  if((currTechRetryCount.compareTo(maxTechRetryCount)>=0)){
					    boolean deleteFromTimerResult = csfobpmDao.deleteFromTimer(csfobpmRequestData.getTaskTransId());
					    csfobpmServiceLog.info("deleteFromTimerResult :"+ deleteFromTimerResult);	
				  }else if((currTechRetryCount.compareTo(maxTechRetryCount)==-1) || (currNoRespRetryCount.compareTo(maxNoRespRetryCount)<= 0)){					  
						waitTime = getWaitTime(provisioningTask, postResultData, true );
						String timerState = getTimerState(postResultData);
						boolean updateTimerResult = updateTimerData(csfobpmRequestXML, csfobpmRequestData, waitTime, timerState);
						csfobpmServiceLog.info("updateTimerResult :"+ updateTimerResult);				    
				  }else{
					  csfobpmServiceLog.info("No action taken for the timer table, since it did not satisified the conditions. Please check :"+csfobpmRequestData.getTaskTransId());
				  }				  
			  }else{
					Timer timer = generateTimerData(postResultData, provisioningTask, csfobpmRequestXML);					
					boolean insertTimerResult = csfobpmDao.insertTimer(timer);
					csfobpmServiceLog.info("insertTimerResult :"+insertTimerResult);	
			  }
			  if(!(postResultData.getCsiResponsecode().equals("0"))){
				    String taskStatus = getTaskStatus(provisioningTask);
				    boolean updateTaskStatus = csfobpmDao.updatePostFailedTaskStatus(csfobpmRequestData.getTaskTransId(),taskStatus, currTechRetryCount);
				    csfobpmServiceLog.info("Updated Prov Task Status to :"+ taskStatus+" with result: "+updateTaskStatus);	
			  }
			  updateTimerTableResult = true;
			  
		  }else{
			  csfobpmServiceLog.info("Records not exist for the TaskTransId : "+csfobpmRequestData.getTaskTransId());			 
		  }
		} catch (Exception e) {
			csfobpmServiceLog.error("Exception occured in the updateTimerTable method"+e.getMessage());
			//e.printStackTrace();
			return updateTimerTableResult;
		}	
		
		return updateTimerTableResult;
	}
	
	@Transactional("dataTransactionManager")
	private boolean updateTimerData(String provisioningRequestXML, CSFOBPMProvRequestData csfobpmRequestData, int waitTime, String timerState) {
		boolean updateTimerResult;
		String payLoad = null;
		String payLoadOverflow = null;
		payLoad = provisioningRequestXML;
		updateTimerResult = csfobpmDao.updateTimer(csfobpmRequestData.getTaskTransId().trim(), timerState, waitTime, payLoad,payLoadOverflow);
		return updateTimerResult;
	}


	private String getTaskStatus(ProvisioningTask provisioningTask) {
		  String taskStatus=null;
	      BigDecimal currTechRetryCount = provisioningTask.getCurrTechRetryCount(); 
		  BigDecimal maxTechRetryCount = provisioningTask.getMaxTechRetryCount();	
		  
		  csfobpmServiceLog.info("currTechRetry = " + currTechRetryCount);
		  csfobpmServiceLog.info("maxTechRetry = " + maxTechRetryCount);
		  
		  if((currTechRetryCount.compareTo(maxTechRetryCount)>=0)){
			  taskStatus=wfErrored;
		  }else{
			  taskStatus=taskStatusPostFailed;
		  }
		  return taskStatus;
	}



	private Timer generateTimerData(CsfobpmResponseData postResultData, ProvisioningTask provisioningTask, String provisioningRequestXML) {		
		int waitTime;
		Timer timer = new Timer();
		TimerPK timerPk = new TimerPK();
		Calendar currentTimeStamp = Calendar.getInstance();
		timerPk.setSystemName(provisioningTask.getSystemName().trim());
		timerPk.setTaskTransid(provisioningTask.getId().getTaskTransid());
		timerPk.setTimerState(getTimerState(postResultData));
		timer.setCreationTime(currentTimeStamp.getTime());
		waitTime = getWaitTime(provisioningTask, postResultData, false);	
		timer.setId(timerPk);
		timer.setRetryInd(indicatorY);
		timer.setTimerDuration(waitTime);
		currentTimeStamp.add(Calendar.MILLISECOND,waitTime);
		timer.setExpiryTime(currentTimeStamp.getTime());
		timer.setPayload(provisioningRequestXML); 
		return timer;
	}

	private int getWaitTime(ProvisioningTask provisioningTask, CsfobpmResponseData postResultData, boolean updateFlag) {
		int waitTime = 0;
		Integer currTechRetryCount = 1;
		Integer currNoRespRetryCount = 1;
		String key = null;		

		RetryConfigElement retryConfigElement = null;

		if (provisioningTask != null && provisioningTask.getSystemName() != null) {
			if (updateFlag) {
				currTechRetryCount = provisioningTask.getCurrTechRetryCount().intValue() + 1;
				currNoRespRetryCount = provisioningTask.getCurrNoRespRetryCount().intValue() + 1;
			}
			
			if(postResultData.getCsiResponsecode().equals("0")){
				key = provisioningTask.getSystemName() + "_"+ "no_response" + "_" + currNoRespRetryCount.intValue();
			}else{
				key = provisioningTask.getSystemName() + "_"+ "response_failure" + "_" + currTechRetryCount.intValue();
			}
			
			retryConfigElement = (RetryConfigElement) InitGlobalInstance.getRetryConfig().get(key);
			if (retryConfigElement != null) {
				waitTime = retryConfigElement.waitTime;
			}
		}
		return waitTime;
	}


	private String getTimerState(CsfobpmResponseData postResultData) {
		String timerState = null;		
		if(postResultData !=null){
			if(postResultData.getCsiResponsecode().equals("0")){
				timerState=waitingSystemResponse;
			}else{
				timerState=waitingToResubmit;
			}
		}		
		return timerState.trim();
	}
	
	
	public void generateDynamicErrorResponder(String csfobpmRequestXML, CSFOBPMProvRequestData csfobpmRequestData, CsfobpmResponseData postResultData) {
		String errorResponseXML;
		// Generate Error Response
		errorResponseXML = generatedErrorResponseXML(csfobpmRequestXML, postResultData);		
		 csfobpmServiceLog.info("autoResponseXML: "+errorResponseXML);
		 //Send the Error Response to Response service
		 sendToResponseQueue(errorResponseXML);
	}	
	
	
	
	private String generatedErrorResponseXML(String csfobpmRequestXML, CsfobpmResponseData postResultData) {
		String errorResponseXML;
		ProvisioningResponseDynamic provisioningResponseDynamic = new ProvisioningResponseDynamic();
		ErrorResponseXMLGenerator errorResponseXMLGenerator = new ErrorResponseXMLGenerator();
		
		List<TransactionCodeList> transactionCodeLists = new ArrayList<TransactionCodeList>();
		TransactionCode transactionCode = new TransactionCode();
		TransactionCodeList transactionCodeList = new TransactionCodeList();
		
		String errCode=postResultData.getCsiResponsecode();
		String errorCode="60"+errCode;
		int intErrCode=Integer.parseInt(errorCode);
		int majorcode=60000;
		transactionCodeList.setErrorCode(intErrCode);
		String description=postResultData.getCsiResponsedesc();
		if(description != null && description.length() > 200){
			transactionCodeList.setErrorMessageText(description.substring(0, 200).toString());
			transactionCode.setDescription(description.substring(0, 200).toString());
		}else{
			transactionCodeList.setErrorMessageText(description);
			transactionCode.setDescription(description);
		}
		transactionCode.setMajorCode(majorcode);
		transactionCodeLists.add(transactionCodeList);
		transactionCode.setTransactionCodeList(transactionCodeLists);
		
		provisioningResponseDynamic = parseResponseData.getResponseData(csfobpmRequestXML.toString(), transactionCode);
		errorResponseXML= errorResponseXMLGenerator.buildErrorRespXML(provisioningResponseDynamic);
		return errorResponseXML;
	}
	
	
	
	public void sendToResponseQueue(String autoResponseXML) {
		try {
			responseQueueSender.sendMessage(autoResponseXML);			
		} catch (JMSException e) {
			//e.printStackTrace();
			csfobpmServiceLog.error("Exception occured in sendToResponseQueue method : "+e.getMessage());
		}		
	}
	
	@Override
	@Transactional("configTransactionManager")
	public List<CSIRetryErrors> getCSIRetryError(String eventName) throws Exception {
		return csfobpmDao.getCSIRetryError(eventName);
	}

	public  boolean insertCsfobpmMessage(String provRequestXML, CSFOBPMProvRequestData csfobpmRequestData, CsfobpmResponseData resData) throws ParseException {
		CsfobpmMessageTracking csfobpmMsg = new CsfobpmMessageTracking();
		Date date = new Date();
		//BigDecimal bigDecimal = new BigDecimal(0);
		
		String msisdn = csfobpmRequestData.getOrder().getAccount().getMsisdn();
		String subId = csfobpmRequestData.getOrder().getAccount().getSubscriberNumber();
		String messageId = csfobpmRequestData.getTaskInfo().getTaskTransId();
		
		csfobpmMsg.setTppTransid(messageId);
		csfobpmMsg.setMsisdn(msisdn);
		csfobpmMsg.setSubid(subId);
		csfobpmMsg.setEventName(resData.getDipType());
		csfobpmMsg.setCsiResponseCode(resData.getCsiResponsecode());
		
		if(resData.getCsiResponsedesc() != null && resData.getCsiResponsedesc().length() > 199){
			csfobpmMsg.setCsiResponseDesc(resData.getCsiResponsedesc().substring(0, 199).toString());
		}else{
			csfobpmMsg.setCsiResponseDesc(resData.getCsiResponsedesc());
		}
		
		csfobpmMsg.setDbTimestamp(new Timestamp(date.getTime()));
		csfobpmMsg.setCsiRequestTime(resData.getReqTimeStamp());
		//csfobpmMsg.setCsiResponseTime(resData.getResTimeStamp());
		
		//csfobpmMsg.setLocation(location);
		//csfobpmMsg.setConvid(convid);
		csfobpmMsg.setInputXml(provRequestXML);
		//csfobpmMsg.setCsfobpmReqXml(csfobpmReqXml);
		//csfobpmMsg.setCsfobpmResXml(bigDecimal);
		//csfobpmMsg.setRetryCount(retryCount);
		
		boolean intInsertMsg = csfobpmDao.insertCsfobpmMessage(csfobpmMsg);
		return intInsertMsg;
	}
	
	public boolean updateCsfobpmMsg(CsfobpmResponseData resData) throws ParseException{
		boolean isUpdated = false;
		
		isUpdated = csfobpmDao.updateCsfobpmMsg(resData);
		
		return isUpdated;
	}

}