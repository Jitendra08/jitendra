/**
 * 
 */
package com.att.tpp.xml.model;

import java.util.List;

/**
 * @author rg730b
 *
 */
public class Forms {
	private List<FormData> formData;

	public Forms(List<FormData> formData) {
		this.formData = formData;
	}
	
	public List<FormData> getFormData() {
		return formData;
	}

	public void setFormData(List<FormData> formData) {
		this.formData = formData;
	}
	
}
