package com.att.tpp.xml.model;

public class EventTypeInfo {

    private String eventName;

    /**
	 * @param eventName
	 */
	public EventTypeInfo(String eventName) {
		this.eventName = eventName;
	}

	/**
     * Gets the value of the eventName property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getEventName() {
        return eventName;
    }

    /**
     * Sets the value of the eventName property.
     * 
     * @param eventName
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setEventName(String eventName) {
        this.eventName = eventName;
    }

}
