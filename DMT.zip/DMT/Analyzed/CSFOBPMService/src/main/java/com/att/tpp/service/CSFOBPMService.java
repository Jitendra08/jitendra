package com.att.tpp.service;

import java.io.IOException;
import java.text.ParseException;
import java.util.List;

import javax.jms.JMSException;
import javax.xml.transform.TransformerConfigurationException;
import javax.xml.transform.TransformerFactoryConfigurationError;

import com.att.tpp.model.CSIRetryErrors;
import com.att.tpp.model.CsfobpmResponseData;
import com.att.tpp.xml.model.CSFOBPMProvRequestData;

public interface CSFOBPMService {

	void loadInitialData() throws TransformerConfigurationException, TransformerFactoryConfigurationError, JMSException;

	boolean validateXML(String communicationRequestXML, String tppTransactionrequestxsd) throws IOException, Exception;
	
	CsfobpmResponseData postRequest(CSFOBPMProvRequestData csfobpmRequestData, String provisioningRequestXML, String messageId) throws Exception;

	boolean insertTransCodes(CSFOBPMProvRequestData provRequestData, CsfobpmResponseData postResultData);
	
	boolean updateTimerTable(CsfobpmResponseData postResultData, String provisioningRequestXML, CSFOBPMProvRequestData provRequestData);
	
	boolean verifyRetryExceeded(CSFOBPMProvRequestData provRequestData, String messageId) throws JMSException;
	
	boolean updateConnectivityStatus(CSFOBPMProvRequestData provRequestData, String url, CsfobpmResponseData postResultData);
	
	List<CSIRetryErrors> getCSIRetryError(String eventName) throws Exception;
	
	void generateDynamicErrorResponder(String provisioningRequestXML, CSFOBPMProvRequestData provRequestData, CsfobpmResponseData postResultData);
	
	boolean insertCsfobpmMessage(String provRequestXML, CSFOBPMProvRequestData provRequestData, CsfobpmResponseData resData) throws ParseException;
	
	boolean updateCsfobpmMsg(CsfobpmResponseData resData) throws ParseException;
}
