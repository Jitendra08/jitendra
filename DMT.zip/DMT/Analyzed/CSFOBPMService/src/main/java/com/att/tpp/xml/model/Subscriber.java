package com.att.tpp.xml.model;


public class Subscriber {

    private Subscriber.Contact contact;
    private Subscriber.Address address;
    private Subscriber.EmailInfo email;
    
    public Subscriber(Contact contact, Address address,
			EmailInfo email) {
		super();
		this.contact = contact;
		this.address = address;
		this.email = email;
	}
    
    public Subscriber(Contact contact, Address address) {
		this.contact = contact;
		this.address = address;
	}

	public static class Address {
		
    	private SubscriberAddress current;
    	private SubscriberAddress previous;
    	
    	public Address(SubscriberAddress current){
			this.current = current;
		}
		
		public Address(SubscriberAddress current,
				SubscriberAddress previous) {
			this.current = current;
			this.previous = previous;
		}
		
		public SubscriberAddress getCurrent() {
			return current;
		}
		public void setCurrent(SubscriberAddress current) {
			this.current = current;
		}
		public SubscriberAddress getPrevious() {
			return previous;
		}
		public void setPrevious(SubscriberAddress previous) {
			this.previous = previous;
		}
		
	}
	
	public static class Contact {
		
    	private SubscriberContact current;
    	private SubscriberContact previous;
    	
    	public Contact(SubscriberContact current){
			this.current = current;
		}
		
		public Contact(SubscriberContact current,
				SubscriberContact previous) {
			this.current = current;
			this.previous = previous;
		}
    	
		public SubscriberContact getCurrent() {
			return current;
		}
		public void setCurrent(SubscriberContact current) {
			this.current = current;
		}
		public SubscriberContact getPrevious() {
			return previous;
		}
		public void setPrevious(SubscriberContact previous) {
			this.previous = previous;
		}
    	
	}
	
	public static class EmailInfo {
		
    	private SubscriberEmailInfo current;
    	private SubscriberEmailInfo previous;
    	
    	public EmailInfo(SubscriberEmailInfo current) {
			this.current = current;
		}

		public EmailInfo(SubscriberEmailInfo current,
				SubscriberEmailInfo previous) {
			this.current = current;
			this.previous = previous;
		}
    	
		public SubscriberEmailInfo getCurrent() {
			return current;
		}
		public void setCurrent(SubscriberEmailInfo current) {
			this.current = current;
		}
		public SubscriberEmailInfo getPrevious() {
			return previous;
		}
		public void setPrevious(SubscriberEmailInfo previous) {
			this.previous = previous;
		}
    	
 	}

}
