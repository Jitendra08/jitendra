package com.att.tpp.utils


import javax.xml.datatype.XMLGregorianCalendar
import javax.xml.ws.Holder

import org.springframework.beans.factory.annotation.Autowired

import com.att.csi.csi.namespaces.fobpmprovisioning.types._public.commondatamodel.AddressCountyInfo
import com.att.csi.csi.namespaces.fobpmprovisioning.types._public.commondatamodel.AddressInfo
import com.att.csi.csi.namespaces.fobpmprovisioning.types._public.commondatamodel.AddressRuralRouteInfo
import com.att.csi.csi.namespaces.fobpmprovisioning.types._public.commondatamodel.AddressStateInfo
import com.att.csi.csi.namespaces.fobpmprovisioning.types._public.commondatamodel.AddressStreetInfo
import com.att.csi.csi.namespaces.fobpmprovisioning.types._public.commondatamodel.AddressTwoLineSimpleInfo
import com.att.csi.csi.namespaces.fobpmprovisioning.types._public.commondatamodel.AddressTypeInfo
import com.att.csi.csi.namespaces.fobpmprovisioning.types._public.commondatamodel.AddressZipInfo
import com.att.csi.csi.namespaces.fobpmprovisioning.types._public.commondatamodel.AppDetailsInfo
import com.att.csi.csi.namespaces.fobpmprovisioning.types._public.commondatamodel.NameInfo
import com.att.csi.csi.namespaces.fobpmprovisioning.types._public.commondatamodel.UnitInfo
import com.att.tpp.xml.model.CSFOBPMProvRequestData
import com.cingular.csi.csi.namespaces.container._public.processenterpriseprovisioningorderrequest.ProcessEnterpriseProvisioningOrderRequestInfo
import com.cingular.csi.csi.namespaces.container._public.processenterpriseprovisioningorderrequest.ProcessEnterpriseProvisioningOrderRequestInfo.ChangeRequestor
import com.cingular.csi.csi.namespaces.container._public.processenterpriseprovisioningorderrequest.ProcessEnterpriseProvisioningOrderRequestInfo.EnterpriseDetails
import com.cingular.csi.csi.namespaces.container._public.processenterpriseprovisioningorderrequest.ProcessEnterpriseProvisioningOrderRequestInfo.OfferingDetails
import com.cingular.csi.csi.namespaces.container._public.processenterpriseprovisioningorderrequest.ProcessEnterpriseProvisioningOrderRequestInfo.EnterpriseDetails.EndUserDetails
import com.cingular.csi.csi.namespaces.container._public.processenterpriseprovisioningorderrequest.ProcessEnterpriseProvisioningOrderRequestInfo.EnterpriseDetails.EnterpriseIdentifier
import com.cingular.csi.csi.namespaces.container._public.processenterpriseprovisioningorderrequest.ProcessEnterpriseProvisioningOrderRequestInfo.EnterpriseDetails.FormsFieldData
import com.cingular.csi.csi.namespaces.container._public.processenterpriseprovisioningorderrequest.ProcessEnterpriseProvisioningOrderRequestInfo.EnterpriseDetails.EndUserDetails.BillingAccountDetails
import com.cingular.csi.csi.namespaces.container._public.processenterpriseprovisioningorderrequest.ProcessEnterpriseProvisioningOrderRequestInfo.EnterpriseDetails.EndUserDetails.FoundationAccountNumber
import com.cingular.csi.csi.namespaces.container._public.processenterpriseprovisioningorderrequest.ProcessEnterpriseProvisioningOrderRequestInfo.EnterpriseDetails.EndUserDetails.SubscriberDetails
import com.cingular.csi.csi.namespaces.container._public.processenterpriseprovisioningorderrequest.ProcessEnterpriseProvisioningOrderRequestInfo.EnterpriseDetails.EndUserDetails.BillingAccountDetails.AccountNumber
import com.cingular.csi.csi.namespaces.container._public.processenterpriseprovisioningorderrequest.ProcessEnterpriseProvisioningOrderRequestInfo.EnterpriseDetails.EndUserDetails.BillingAccountDetails.Address
import com.cingular.csi.csi.namespaces.container._public.processenterpriseprovisioningorderrequest.ProcessEnterpriseProvisioningOrderRequestInfo.EnterpriseDetails.EndUserDetails.BillingAccountDetails.ContactName
import com.cingular.csi.csi.namespaces.container._public.processenterpriseprovisioningorderrequest.ProcessEnterpriseProvisioningOrderRequestInfo.EnterpriseDetails.EndUserDetails.SubscriberDetails.ContactDetails
import com.cingular.csi.csi.namespaces.container._public.processenterpriseprovisioningorderrequest.ProcessEnterpriseProvisioningOrderRequestInfo.EnterpriseDetails.EndUserDetails.SubscriberDetails.MSISDNDetails
import com.cingular.csi.csi.namespaces.fobpmprovisioning._209_0.wsdl.fobpmprovisioningcsi.ProcessEnterpriseProvisioningOrderPortType
import com.cingular.csi.csi.namespaces.fobpmprovisioning.infrastructurecommon.container._public.requestacknowledgement.RequestAcknowledgementInfo
import com.cingular.csi.csi.namespaces.fobpmprovisioning.infrastructurecommon.types._public.messageheader.MessageHeaderInfo
import com.cingular.csi.csi.namespaces.fobpmprovisioning.infrastructurecommon.types._public.messageheader.MessageHeaderInfo.SecurityMessageHeader
import com.cingular.csi.csi.namespaces.fobpmprovisioning.infrastructurecommon.types._public.messageheader.MessageHeaderInfo.SequenceMessageHeader
import com.cingular.csi.csi.namespaces.fobpmprovisioning.infrastructurecommon.types._public.messageheader.MessageHeaderInfo.TrackingMessageHeader

import groovy.util.logging.Log4j

@Log4j
class TPP_CSFOBPMRequestGenerator {
	
	@Autowired
	private ProcessEnterpriseProvisioningOrderPortType pepoDIPType;
	
	
	def ProcessEnterpriseProvisioningOrderRequestInfo generateCSFOBPMRequestData(CSFOBPMProvRequestData csfobpmRequestData){
		
		def accDetails = csfobpmRequestData?.order?.account;		
		def billingAccountDet = csfobpmRequestData?.order?.billingAccount;		
		def forms = csfobpmRequestData?.order?.forms;
		def products = csfobpmRequestData?.product
		
		/* Start - Subscriber Details  */
		
		def subscriber = csfobpmRequestData?.order?.subscriber
		/* Start - Subscriber Contact  */
		/* Start - Subscriber Contact  - CurrentContact*/
		def subscriberContact = subscriber?.contact
		
		def subscriberCurrContact = subscriber?.contact?.current
		NameInfo currSubNameInfo = new NameInfo();
		if(subscriberCurrContact?.firstName != null){
			currSubNameInfo.setFirstName(subscriberCurrContact?.firstName?.toString());
		}else{
			currSubNameInfo.setFirstName("NA");
		}
		if(subscriberCurrContact?.lastName != null){
			currSubNameInfo.setLastName(subscriberCurrContact?.lastName?.toString());
		}else{
			currSubNameInfo.setLastName("NA");
		}
		/* End - Subscriber Contact  - CurrentContact*/
		/* Start - Subscriber Contact  - PrevContact*/
		def subscriberPrevContact = subscriber?.contact?.previous
		NameInfo prevSubNameInfo = null;
		if(subscriberPrevContact != null){
			prevSubNameInfo = new NameInfo();
			if(subscriberPrevContact?.firstName != null){
				prevSubNameInfo.setFirstName(subscriberPrevContact?.firstName?.toString());
			}else{
				prevSubNameInfo.setFirstName("NA");
			}
			if(subscriberPrevContact?.lastName != null){
				prevSubNameInfo.setLastName(subscriberPrevContact?.lastName?.toString());
			}else{
				prevSubNameInfo.setLastName("NA");
			}
		}
		/* End - Subscriber Contact  - PrevContact*/
		ProcessEnterpriseProvisioningOrderRequestInfo.EnterpriseDetails.EndUserDetails.SubscriberDetails.ContactDetails.ContactName subContactName = new ProcessEnterpriseProvisioningOrderRequestInfo.EnterpriseDetails.EndUserDetails.SubscriberDetails.ContactDetails.ContactName();
		subContactName.setCurrentContact(currSubNameInfo);
		if(prevSubNameInfo!=null){
			subContactName.setPreviousContact(prevSubNameInfo);
		}
		/* End - Subscriber Contact  */
		
		/* Start - Subscriber Address  */
		def subscriberAddress = subscriber?.address
		
		/* Start - Subscriber CurrentAddress  */
		def subscriberCurrAddress = subscriber?.address?.current
		AddressTwoLineSimpleInfo addressCurrSubAddress = new AddressTwoLineSimpleInfo();
		
		if(subscriberCurrAddress?.street != null){
			addressCurrSubAddress.setAddressLine1(subscriberCurrAddress?.street?.toString());
		}else{
			addressCurrSubAddress.setAddressLine1("NA");
		}
		if(subscriberCurrAddress?.city != null){
			addressCurrSubAddress.setCity(subscriberCurrAddress?.city?.toString());
		}else{
			addressCurrSubAddress.setCity("NA");
		}
		AddressStateInfo billingAddressStateInfo = null;
		if(subscriberCurrAddress?.state != null){
			billingAddressStateInfo = AddressStateInfo.fromValue(subscriberCurrAddress?.state?.toString());
			addressCurrSubAddress.setState(billingAddressStateInfo);
		}else{
			billingAddressStateInfo = AddressStateInfo.fromValue("NA");
			addressCurrSubAddress.setState(billingAddressStateInfo);
		}
		AddressZipInfo addressZipInfo = new AddressZipInfo();
		if(subscriberCurrAddress?.postalCode != null && subscriberCurrAddress?.postalCode?.toString() != "null"){
			addressZipInfo.setZipCode(subscriberCurrAddress?.postalCode?.toString());
			if(subscriberCurrAddress?.postalPlusCode != null && subscriberCurrAddress?.postalPlusCode?.toString() != "null"){
				addressZipInfo.setZipCodeExtension(subscriberCurrAddress?.postalPlusCode?.toString());
			}
			if(subscriberCurrAddress?.geoCode != null && subscriberCurrAddress?.geoCode?.toString() != "null"){
				addressZipInfo.setZipGeoCode(subscriberCurrAddress?.geoCode?.toString());
			}
			addressCurrSubAddress.setZip(addressZipInfo);
		}else{
			addressZipInfo.setZipCode("00000");
			addressCurrSubAddress.setZip(addressZipInfo);
		}
		if(subscriberCurrAddress?.countryName != null && subscriberCurrAddress?.countryName?.toString() != "null"){
			log.info("Inside  TPP_CSFOBPMRequestGenerator >>>subscriberCurrAddress?.countryName>>>"+subscriberCurrAddress?.countryName?.toString());
			addressCurrSubAddress.setCountry(subscriberCurrAddress?.countryName?.toString());
		}
		
		
		/* End - Subscriber CurrentAddress  */
		/* Start - Subscriber PrevAddress  */
		
		def subscriberPrevAddress = subscriber?.address?.previous
		AddressTwoLineSimpleInfo addressPrevSubAddress = null;
		if(subscriberPrevAddress !=null){
			addressPrevSubAddress = new AddressTwoLineSimpleInfo();
			if(subscriberPrevAddress?.street != null){
				addressPrevSubAddress.setAddressLine1(subscriberPrevAddress?.street?.toString());
			}else{
				addressPrevSubAddress.setAddressLine1("NA");
			}
			if(subscriberPrevAddress?.city != null){
				addressPrevSubAddress.setCity(subscriberPrevAddress?.city?.toString());
			}else{
				addressPrevSubAddress.setCity("NA");
			}
			AddressStateInfo billingPrevAddressStateInfo = null;
			if(subscriberPrevAddress?.state != null){
				billingPrevAddressStateInfo = AddressStateInfo.fromValue(subscriberPrevAddress?.state?.toString());
				addressPrevSubAddress.setState(billingPrevAddressStateInfo);
			}else{
				billingPrevAddressStateInfo = AddressStateInfo.fromValue("NA");
				addressPrevSubAddress.setState(billingPrevAddressStateInfo);
			}
			AddressZipInfo addressPrevZipInfo = new AddressZipInfo();
			if(subscriberPrevAddress?.postalCode != null && subscriberPrevAddress?.postalCode?.toString() != "null"){
				addressPrevZipInfo.setZipCode(subscriberPrevAddress?.postalCode?.toString());
				if(subscriberPrevAddress?.postalPlusCode != null && subscriberPrevAddress?.postalPlusCode?.toString() != "null"){
					addressPrevZipInfo.setZipCodeExtension(subscriberPrevAddress?.postalPlusCode?.toString());
				}
				if(subscriberPrevAddress?.geoCode != null && subscriberPrevAddress?.geoCode?.toString() != "null"){
					addressPrevZipInfo.setZipGeoCode(subscriberPrevAddress?.geoCode?.toString());
				}
				addressPrevSubAddress.setZip(addressPrevZipInfo);
			}else{
				addressPrevZipInfo.setZipCode("00000");
				addressPrevSubAddress.setZip(addressPrevZipInfo);
			}
			if(subscriberPrevAddress?.countryName != null && subscriberPrevAddress?.countryName?.toString() != "null"){
				log.info("Inside  TPP_CSFOBPMRequestGenerator >>>subscriberPrevAddress?.countryName>>>"+subscriberPrevAddress?.countryName?.toString());
				addressPrevSubAddress.setCountry(subscriberPrevAddress?.countryName?.toString());
			}
		}
		/* End - Subscriber PrevAddress  */
			
		ProcessEnterpriseProvisioningOrderRequestInfo.EnterpriseDetails.EndUserDetails.SubscriberDetails.ContactDetails.Address subAddress = new ProcessEnterpriseProvisioningOrderRequestInfo.EnterpriseDetails.EndUserDetails.SubscriberDetails.ContactDetails.Address();
		subAddress.setCurrentAddress(addressCurrSubAddress);
		if(addressPrevSubAddress!=null){
			subAddress.setPreviousAddress(addressPrevSubAddress);
		}
		/* Start - Subscriber Address  */
		
		/* Start - Subscriber Email  */
		def subscriberEmail = subscriber?.email
		
		def subscriberCurrEmail = subscriber?.email?.current
		def subscriberPrevEmail = subscriber?.email?.previous
		ProcessEnterpriseProvisioningOrderRequestInfo.EnterpriseDetails.EndUserDetails.SubscriberDetails.ContactDetails.Email subEmail = null;
		if(subscriber?.email != null){
			subEmail = new ProcessEnterpriseProvisioningOrderRequestInfo.EnterpriseDetails.EndUserDetails.SubscriberDetails.ContactDetails.Email();
			if(subscriberCurrEmail != null){
				subEmail.setCurrentEmailAddress(subscriberCurrEmail.emailAddress.toString());
				if(subscriberPrevEmail != null){
					subEmail.setPreviousEmailAddress(subscriberPrevEmail.emailAddress.toString());
				}
			}
		}
		/* End - Subscriber Email  */
		
		ContactDetails contactDetails = new ContactDetails();
		contactDetails.setContactName(subContactName);
		contactDetails.setAddress(subAddress);
		if(subEmail != null){
			contactDetails.setEmail(subEmail);
		}
		
		
		/* Start - Subscriber MSISDNDetails  */
		MSISDNDetails msisdnDetails = new MSISDNDetails();
		if(accDetails?.msisdn != null){
			msisdnDetails.setMsisdn(accDetails?.msisdn.toString());
		}
		if(accDetails?.prevMSISDN != null){
			msisdnDetails.setOldMSISDN(accDetails?.prevMSISDN.toString());
		}
		/* Start - Subscriber MSISDNDetails  */
		SubscriberDetails subscriberDetails= new SubscriberDetails();
		subscriberDetails.setContactDetails(contactDetails);
		subscriberDetails.setMSISDNDetails(msisdnDetails);
		if(accDetails?.subscriberNumber != null){
			subscriberDetails.setSubscriptionId(accDetails?.subscriberNumber?.toString());
		}		
		/* End - Subscriber Details  */
		
		/* Start - BillingAccount Details  */
		
		/* Start - BillingAccountNumber : setting of BAN(Required), PrevBAN */
		AccountNumber accountNumber = new AccountNumber();
		if(accDetails?.ban != null){
			accountNumber.setBillingAccountNumber(accDetails?.ban.toString());
		}
		if(accDetails?.prevBAN != null){
			accountNumber.setOldBillingAccountNumber(accDetails?.prevBAN.toString());
		}
		/* End - BillingAccountNumber */
		
		/* Start - Contact Name : setting of CurrentContact / PrevContact  */
		
		/* Start - Contact Name : CurrentContact */
		def currBillingContact = billingAccountDet?.contact?.current
		NameInfo currBillNameInfo = null;
		if(currBillingContact != null){
			currBillNameInfo = new NameInfo();
			if(currBillingContact?.firstName != null){
				currBillNameInfo.setFirstName(currBillingContact?.firstName?.toString());
			}else{
				currBillNameInfo.setFirstName("NA");
			}
			if(currBillingContact?.lastName != null){
				currBillNameInfo.setLastName(currBillingContact?.lastName?.toString());
			}else{
				currBillNameInfo.setLastName("NA");
			}
		}
		/* End - Contact Name : CurrentContact */
		/* Start - Contact Name : PrevContact */
		def prevBillingContact = billingAccountDet?.contact?.previous
		NameInfo prevBillNameInfo = null;
		if(prevBillingContact != null){
			prevBillNameInfo = new NameInfo();
			prevBillNameInfo.setFirstName(prevBillingContact?.firstName?.toString());
			prevBillNameInfo.setLastName(prevBillingContact?.lastName?.toString());
		}
		/* End - Contact Name : PrevContact */
		
		ContactName contactName = null;
		if(currBillNameInfo != null){
			contactName = new ContactName();
			contactName.setCurrentContact(currBillNameInfo);
			if(prevBillNameInfo!=null){
				contactName.setPreviousContact(prevBillNameInfo);
			}
		}
		
		/* End - Contact Name : setting of CurrentContact / PrevContact  */
		
		/* Start - BillingAddress : setting of CurrentBillingAddress / PrevBillingAddress  */
		
		/* Start - BillingAddress : CurrentBillingAddress */
		def currBillingAddress = billingAccountDet?.address?.current;
		AddressInfo billingCurrAddress = null;
		if(currBillingAddress != null){
			billingCurrAddress = new AddressInfo();
			if(currBillingAddress?.addressLine1 != null){
				billingCurrAddress.setAddressLine1(currBillingAddress?.addressLine1?.toString());
			}
			if(currBillingAddress?.addressLine2 != null){
				billingCurrAddress.setAddressLine2(currBillingAddress?.addressLine2?.toString());
			}
			if(currBillingAddress?.type !=null){
				AddressTypeInfo addressTypeInfo = null;
				addressTypeInfo = AddressTypeInfo.fromValue(currBillingAddress?.type?.toString());
				billingCurrAddress.setAddressType(addressTypeInfo);
			}
			if(currBillingAddress?.city != null){
				billingCurrAddress.setCity(currBillingAddress?.city?.toString());
			}
			if(currBillingAddress?.countryName != null && currBillingAddress?.countryName?.toString() != "null"){
				log.info("Inside  TPP_CSFOBPMRequestGenerator >>>currBillingAddress?.countryName>>>"+currBillingAddress?.countryName?.toString());
				billingCurrAddress.setCountry(currBillingAddress?.countryName?.toString());
			}
			if(currBillingAddress?.state !=null){
				AddressStateInfo billingCurrAddressStateInfo = null;
				billingCurrAddressStateInfo = AddressStateInfo.fromValue(currBillingAddress?.state?.toString());
				billingCurrAddress.setState(billingCurrAddressStateInfo);
			}
			
			AddressZipInfo billingZip = new AddressZipInfo();
			if(currBillingAddress?.postalCode !=null && currBillingAddress?.postalCode?.toString() != "null"){
				billingZip.setZipCode(currBillingAddress?.postalCode?.toString());
				if(currBillingAddress?.postalPlusCode !=null && currBillingAddress?.postalPlusCode?.toString() != "null"){
					billingZip.setZipCodeExtension(currBillingAddress?.postalPlusCode?.toString());
				}
				if(currBillingAddress?.geoCode !=null && currBillingAddress?.geoCode?.toString() != "null"){
					billingZip.setZipGeoCode(currBillingAddress?.geoCode?.toString());
				}
			}
			if(billingZip!=null){
				billingCurrAddress.setZip(billingZip);
			}
		
		}
		/* End - BillingAddress : CurrentBillingAddress */
		
		/* Start - BillingAddress : PrevBillingAddress */
		
		def prevBillingAddress = billingAccountDet?.address?.previous;
		AddressInfo billingPrevAddress = null;
		if(prevBillingAddress != null){
			billingPrevAddress = new AddressInfo();
			if(prevBillingAddress?.addressLine1){
				billingPrevAddress.setAddressLine1(prevBillingAddress?.addressLine1?.toString());
			}
			if(prevBillingAddress?.addressLine2){
				billingPrevAddress.setAddressLine2(prevBillingAddress?.addressLine2?.toString());
			}
			if(prevBillingAddress?.type !=null){
				AddressTypeInfo addressTypeInfo = null;
				addressTypeInfo = AddressTypeInfo.fromValue(prevBillingAddress?.type?.toString());
				billingPrevAddress.setAddressType(addressTypeInfo);
			}
			if(prevBillingAddress?.city){
				billingPrevAddress.setCity(prevBillingAddress?.city?.toString());
			}
			if(prevBillingAddress?.countryName != null  && prevBillingAddress?.countryName?.toString() != "null"){
				log.info("Inside  TPP_CSFOBPMRequestGenerator >>>prevBillingAddress?.countryName>>>"+prevBillingAddress?.countryName?.toString());
				billingPrevAddress.setCountry(prevBillingAddress?.countryName?.toString());
			}
			if(prevBillingAddress?.state !=null){
				AddressStateInfo billingPrevAddressStateInfo = null;
				billingPrevAddressStateInfo = AddressStateInfo.fromValue(prevBillingAddress?.state?.toString());
				billingPrevAddress.setState(billingPrevAddressStateInfo);
			}
			AddressZipInfo prevBillingZip = new AddressZipInfo();
			if(prevBillingAddress?.postalCode !=null && prevBillingAddress?.postalCode?.toString() != "null"){
				prevBillingZip.setZipCode(prevBillingAddress?.postalCode?.toString());
				if(prevBillingAddress?.postalPlusCode !=null && prevBillingAddress?.postalPlusCode?.toString() != "null"){
					prevBillingZip.setZipCodeExtension(prevBillingAddress?.postalPlusCode?.toString());
				}
				if(prevBillingAddress?.geoCode !=null && prevBillingAddress?.geoCode?.toString() != "null"){
					prevBillingZip.setZipGeoCode(prevBillingAddress?.geoCode?.toString());
				}
			}
			if(prevBillingZip!=null){
				billingPrevAddress.setZip(prevBillingZip);
			}
		
		}
		/* End - BillingAddress : PrevBillingAddress */
		
		Address billingAddress = null;
		if(billingCurrAddress != null){
			billingAddress = new Address();
			billingAddress.setCurrentAddress(billingCurrAddress);
			if(billingPrevAddress!=null){
				billingAddress.setPreviousAddress(billingPrevAddress);
			}
		}
		/* End - BillingAddress : setting of CurrentBillingAddress / PrevBillingAddress  */
		
		BillingAccountDetails billingAccountDetails = new BillingAccountDetails();
		billingAccountDetails.setAccountNumber(accountNumber);
		if(billingAddress != null){
			billingAccountDetails.setAddress(billingAddress);
		}
		if(currBillingContact?.businessName != null){
			billingAccountDetails.setBusinessName(currBillingContact?.businessName?.toString());//Need to check with csfobpm which business name required to pass
		}
		billingAccountDetails.setContactName(contactName);
		
		/* End - BillingAccount Details  */
		
		/* Start - FoundationAccountNumber : setting of FAN(Required), PrevFAN, FAN Name  */
		FoundationAccountNumber foundationAccountNumber = new FoundationAccountNumber();
		if(billingAccountDet?.fan?.currentFAN !=null){
			foundationAccountNumber.setFoundationAccountNumber(billingAccountDet?.fan?.currentFAN?.toString());
		}else{
			foundationAccountNumber.setFoundationAccountNumber("null");
		}
		if(billingAccountDet?.fan?.previousFAN !=null){
			foundationAccountNumber.setOldFoundationAccountNumber(billingAccountDet?.fan?.previousFAN?.toString());
		}
		if(billingAccountDet?.fanName !=null){
			foundationAccountNumber.setFoundationAccountName(billingAccountDet?.fanName?.toString());
		}
		/* End - FoundationAccountNumber */
		
		EndUserDetails endUserDetails = new EndUserDetails();
		if(subscriberDetails != null){
			endUserDetails.setSubscriberDetails(subscriberDetails);
		}
		if(billingAccountDetails != null){
			endUserDetails.setBillingAccountDetails(billingAccountDetails);
		}
		if(foundationAccountNumber != null){
			endUserDetails.setFoundationAccountNumber(foundationAccountNumber);
		}
		
		EnterpriseIdentifier enterpriseIdentifier = new EnterpriseIdentifier();
		//enterpriseIdentifier.setCompanyDetails(null);
		if(csfobpmRequestData?.order?.locationId != null && csfobpmRequestData?.order?.locationId.size() > 0){
			enterpriseIdentifier.setLocationAccountId(csfobpmRequestData?.order?.locationId?.toString());
		}else{
			enterpriseIdentifier.setLocationAccountId("1-000000000");
		}

		EnterpriseDetails enterpriseDetails = new EnterpriseDetails();
		if(endUserDetails != null){
			enterpriseDetails.setEndUserDetails(endUserDetails);
		}
		if(enterpriseIdentifier != null){
			enterpriseDetails.setEnterpriseIdentifier(enterpriseIdentifier);
		}
		
		def formsData=forms?.formData;
		if(formsData != null){
			formsData?.fields*.each{fieldsdet ->
				FormsFieldData formsFieldData = new FormsFieldData();
				formsFieldData.setGroupName(fieldsdet.group.toString());
				formsFieldData.setName(fieldsdet.name.toString());
				formsFieldData.setValue(fieldsdet.value.iterator().next().toString());
				enterpriseDetails.getFormsFieldData().add(formsFieldData);
			}
		}

		AppDetailsInfo appDetailsInfo = new AppDetailsInfo();
		appDetailsInfo.setFromAppID("17753");
		appDetailsInfo.setToAppID("14269");
		
		ChangeRequestor changeRequestorTypeInfo = new ChangeRequestor();
		changeRequestorTypeInfo.setChangeSystem("3PP");
		changeRequestorTypeInfo.setChangeUser("NA");
		
		ProcessEnterpriseProvisioningOrderRequestInfo processEnterpriseProvisioningOrderRequestInfo = new ProcessEnterpriseProvisioningOrderRequestInfo();
		processEnterpriseProvisioningOrderRequestInfo.setApplicationDetails(appDetailsInfo);
		processEnterpriseProvisioningOrderRequestInfo.setChangeRequestor(changeRequestorTypeInfo);
		processEnterpriseProvisioningOrderRequestInfo.setEnterpriseDetails(enterpriseDetails);
		processEnterpriseProvisioningOrderRequestInfo.setProcessingSystem("CSFOBPM");
		
		if(products.size() > 0){
			products*.each{ prod ->
				OfferingDetails offeringDetails = new OfferingDetails();
				offeringDetails.setAction(replaceActionType(prod.action?.toString()));
				offeringDetails.setCategory(prod.category?.toString());
				//offeringDetails.setOfferingCode(it.@Id.toString()); //This is for SOC Code
				offeringDetails.setOfferingId(prod.id?.toString());
				processEnterpriseProvisioningOrderRequestInfo.getOfferingDetails().add(offeringDetails);
			}
		}
		
		log.info("Inside  TPP_CSFOBPMRequestGenerator >>>End");

		return processEnterpriseProvisioningOrderRequestInfo;
	}
	
	def String replaceActionType(value){
		log.info("InputValue:"+value);
		def outputValue = (value != null && value=="Modify") ? "Update" : value
		log.info("outputValue:"+outputValue);
		return outputValue
	}
	
	static main(args) {
		
		TPP_CSFOBPMRequestGenerator csfopbmReqGen = new TPP_CSFOBPMRequestGenerator()
		println("testTranReq --->Start " )
		def pepoReqInfo = csfopbmReqGen.generateCSFOBPMRequestData(new File("C:\\TestXML\\prov2.xml").text);
		println("testTranReq --->End " )
	}


}