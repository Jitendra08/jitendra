package com.att.tpp.model;

import java.io.Serializable;

import javax.persistence.*;


/**
 * The persistent class for the CSI_RETRY_ERRORS database table.
 * 
 */
@Entity
@Table(name="CSI_RETRY_ERRORS")
@NamedQuery(name="CSIRetryErrors.findAll", query="SELECT p FROM CSIRetryErrors p")
public class CSIRetryErrors implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@Column(name="ERROR_CODE")
	private String errorCode;

	
	@Column(name="ERROR_DESCRIPTION")
	private String errorDescription;

	@Id
	@Column(name="EVENT_NAME")
	private String eventName;

	public CSIRetryErrors() {
	}

	public String getErrorCode() {
		return this.errorCode;
	}

	public void setErrorCode(String errorCode) {
		this.errorCode = errorCode;
	}

	public String getErrorDescription() {
		return this.errorDescription;
	}

	public void setErrorDescription(String errorDescription) {
		this.errorDescription = errorDescription;
	}

	public String getEventName() {
		return this.eventName;
	}

	public void setEventName(String eventName) {
		this.eventName = eventName;
	}

}