package com.att.tpp.model;

import java.io.Serializable;

public class CsfobpmResponseData implements Serializable{
	private static final long serialVersionUID = 1L;
	private String csiResponsecode;
	private String csiResponsedesc;
	private java.sql.Timestamp reqTimeStamp;
	private java.sql.Timestamp resTimeStamp;
	private String tppTransactionid;
	private String csiConvId;
	private String errorMessage;
	private String masterTransId;
	private String dipType;
	
	public String getCsiResponsecode() {
		return csiResponsecode;
	}
	public void setCsiResponsecode(String csiResponsecode) {
		this.csiResponsecode = csiResponsecode;
	}
	public String getCsiResponsedesc() {
		return csiResponsedesc;
	}
	public void setCsiResponsedesc(String csiResponsedesc) {
		this.csiResponsedesc = csiResponsedesc;
	}
	public java.sql.Timestamp getReqTimeStamp() {
		return reqTimeStamp;
	}
	public void setReqTimeStamp(java.sql.Timestamp reqTimeStamp) {
		this.reqTimeStamp = reqTimeStamp;
	}
	public java.sql.Timestamp getResTimeStamp() {
		return resTimeStamp;
	}
	public void setResTimeStamp(java.sql.Timestamp resTimeStamp) {
		this.resTimeStamp = resTimeStamp;
	}
	public String getTppTransactionid() {
		return tppTransactionid;
	}
	public void setTppTransactionid(String tppTransactionid) {
		this.tppTransactionid = tppTransactionid;
	}
	public String getCsiConvId() {
		return csiConvId;
	}
	public void setCsiConvId(String csiConvId) {
		this.csiConvId = csiConvId;
	}
	public String getErrorMessage() {
		return errorMessage;
	}
	public void setErrorMessage(String errorMessage) {
		this.errorMessage = errorMessage;
	}
	public String getMasterTransId() {
		return masterTransId;
	}
	public void setMasterTransId(String masterTransId) {
		this.masterTransId = masterTransId;
	}
	public String getDipType() {
		return dipType;
	}
	public void setDipType(String dipType) {
		this.dipType = dipType;
	}
	
}
