/**
 * 
 */
package com.att.tpp.ws;

import java.beans.ConstructorProperties;
import java.math.BigInteger;

import javax.xml.datatype.XMLGregorianCalendar;
import javax.xml.ws.Holder;

import org.apache.log4j.Logger;

import com.att.tpp.utils.XMLDateUtil;

import com.cingular.csi.csi.namespaces.fobpmprovisioning.infrastructurecommon.types._public.messageheader.MessageHeaderInfo;
import com.cingular.csi.csi.namespaces.fobpmprovisioning.infrastructurecommon.types._public.messageheader.MessageHeaderInfo.SecurityMessageHeader;
import com.cingular.csi.csi.namespaces.fobpmprovisioning.infrastructurecommon.types._public.messageheader.MessageHeaderInfo.SequenceMessageHeader;
import com.cingular.csi.csi.namespaces.fobpmprovisioning.infrastructurecommon.types._public.messageheader.MessageHeaderInfo.TrackingMessageHeader;

/**
 * @author rg730b
 *
 */
public class CSFOBPMMessageHeaderService {
	
	private static final Logger csfopbmMessageHeaderServiceLog = Logger.getLogger(CSFOBPMMessageHeaderService.class);
	
	private String user;
	private String pass;
	private String version;
	private String csfobpmttl;

	@ConstructorProperties({"user", "pass", "version", "csfobpmttl"})
	public CSFOBPMMessageHeaderService(String user, String pass, String version, String csfobpmttl){
		this.user = user;
		this.pass = pass;
		this.version = version;
		this.csfobpmttl = csfobpmttl;
	}

	public Holder<MessageHeaderInfo> generateCSFOBPMMessageHeader(String messageId)	throws Exception {
		XMLGregorianCalendar date = null;
		date = XMLDateUtil.getNow();
		csfopbmMessageHeaderServiceLog.info("Inside CSFOBPMMessageHeaderService, messageId:"+messageId);
		//csfopbmMessageHeaderServiceLog.info("Inside CSFOBPMMessageHeaderService, date:"+date);

		MessageHeaderInfo newHeader = new MessageHeaderInfo();
		BigInteger ttl = new BigInteger(csfobpmttl);
		//BigInteger ttl = new BigInteger("65000");
		
		SecurityMessageHeader userPass = new SecurityMessageHeader();
		userPass.setUserName(user);
		userPass.setUserPassword(pass);

		SequenceMessageHeader sequence = new SequenceMessageHeader();
		sequence.setSequenceNumber("1");
		sequence.setTotalInSequence("1");

		TrackingMessageHeader tracking = new TrackingMessageHeader();
		tracking.setApplicationName("FOBPMProvisioning");
		tracking.setConversationId(messageId);
		tracking.setDateTimeStamp(date);
		tracking.setInfrastructureVersion("86");
		tracking.setMessageId(messageId);
		//tracking.setOriginalInfrastructureVersion("");
		//tracking.setOriginalVersion(version);
		tracking.setOriginatorId("3PP");
		//tracking.setResponseTo("");
		//tracking.setReturnURL("");
		tracking.setTimeToLive(ttl);
		tracking.setUniqueTransactionId(messageId);
		tracking.setVersion(version);
		
		newHeader.setSecurityMessageHeader(userPass);
		newHeader.setSequenceMessageHeader(sequence);
		newHeader.setTrackingMessageHeader(tracking);

		Holder<MessageHeaderInfo> messageHeader = new Holder<MessageHeaderInfo>(newHeader);

		return messageHeader;
	}

}
