package com.att.tpp.service;

import java.io.ByteArrayOutputStream;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.net.MalformedURLException;
import java.net.ProtocolException;
import java.net.URL;
import java.security.KeyManagementException;
import java.security.KeyStore;
import java.security.KeyStoreException;
import java.security.NoSuchAlgorithmException;
import java.security.UnrecoverableKeyException;
import java.security.cert.CertificateException;
import java.util.NoSuchElementException;
import java.util.Scanner;

import javax.net.ssl.HttpsURLConnection;
import javax.net.ssl.KeyManagerFactory;
import javax.net.ssl.SSLContext;
import javax.net.ssl.TrustManagerFactory;
import javax.xml.namespace.QName;
import javax.xml.soap.MessageFactory;
import javax.xml.soap.SOAPConnection;
import javax.xml.soap.SOAPConnectionFactory;
import javax.xml.soap.SOAPException;
import javax.xml.soap.SOAPMessage;
import javax.xml.soap.SOAPPart;
import javax.xml.transform.Source;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.stream.StreamResult;
import javax.xml.transform.stream.StreamSource;
import javax.xml.ws.Dispatch;
import javax.xml.ws.Service;
import javax.xml.ws.WebServiceException;
import javax.xml.ws.soap.SOAPBinding;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;


 public class IntradoSoapRequest {
 
		private static Logger intradoSoapRequestLog = LogManager.getLogger(IntradoSoapRequest.class);
	
	
	
//private static Logger intradoRequestLog = LogManager.getLogger(IntradoRequest.class);
	
	//Lab
	//private final static String baseTransport = "http://dh6801c1.edc.cingular.net:8006/DSL_StoredProcsWS/DSL_BaseStoredProcs";	
	//Production
	//private final static String baseTransport = "http://dsl-rome.it.att.com:31337/DSL_StoredProcsWS/DSL_BaseStoredProcs";
	//"http://www.intrado.com/namespaces/vui"
    private static String nameSpaceURI = "http://www.intrado.com/namespaces/vui";
	private static String localPort = "vuiSoap";	
	private static String localPart = "aliUpdateRequestPart";
	private static String endpointAddress="https://ilabvui2.intrado.com:443/vuiws/VuiService?wsdl";	
	
	/*private static String nameSpaceURI;	
	private static String localPart;	
	private static String localPort;	
	*/


	
	static String keystore = "/opt/app/s1tpp1m1/3pp/sites/tomcat/latest_tomcat/3pp/ssl/keystore.ImportKey";
	static String keystorepass = "femtocell";
	static String truststore = "/opt/app/s1tpp1m1/3pp/sites/tomcat/latest_tomcat/3pp/ssl/VUI_Cert_Trust.jks";
	static String truststorepass = "femtocell";
	static String httpsURL = "https://ilabvui2.intrado.com:443/vuiws/VuiService";
	static String getPost = "POST";
	
	private static String intradoTestXML="/opt/app/s1tpp1m1/3pp/sites/tomcat/latest_tomcat/3pp/ssl/intrado.xml";
	
	//private static String intradoTestXML="C:\\ANT\\test.xml";
	
	
	
/*	@ConstructorProperties({"intradoCert", "intradoCertPwd", "endpointAddress", "intradoTestXML"})
	public IntradoRequest(String intradoCert, String intradoCertPwd, String endpointAddress, String intradoTestXML){
		IntradoRequest.intradoCert = intradoCert;
		IntradoRequest.intradoCertPwd=intradoCertPwd;
		IntradoRequest.endpointAddress=endpointAddress;
		IntradoRequest.intradoTestXML=intradoTestXML;
	}	
	*/
	
	public IntradoSoapRequest() {
		// TODO Auto-generated constructor stub
	}


	public void doIntradoRequest() throws Exception {
		boolean intradoRequest = getIntradoRequest(nameSpaceURI,localPart,localPort,endpointAddress,intradoTestXML);
		//intradoRequest();
		//getIntradoResponse();
		intradoSoapRequestLog.info("intradoRequest Result -->: ");
	}
	
	
	public void getIntradoResponse() throws Exception {
		
		intradoSoapRequestLog.info("Inside the getIntradoResponse");
		HttpsURLConnection con = null;			
		
		try{	
			
			con = setup(keystore, keystorepass,		truststore, truststorepass, httpsURL, getPost);
			con.setRequestProperty("SOAPAction", "/vui/AliUpdate");
		
			// Create SOAP Connection
	        SOAPConnectionFactory soapConnectionFactory = SOAPConnectionFactory.newInstance();
	        SOAPConnection soapConnection = soapConnectionFactory.createConnection();
	        
			//Create soap message			
/*			VUISoapRequest vuiSoapRequest = new VUISoapRequest();
			SOAPMessage createSOAPRequest = vuiSoapRequest.createVUISoapMessage();	*/		
			
	        intradoSoapRequestLog.info("Generated Soap Request");
			//Creating soap request
			SOAPMessage createSOAPRequest = readSoapMessage(intradoTestXML);
			createSOAPRequest.writeTo(System.out);			
			
	        	        
	        QName portName = new QName(nameSpaceURI, localPort);	
	        
/*	        Vui_Service vuiService = new Vui_Service(new URL("https://ilabvui2.intrado.com:443/vuiws/VuiService"));
	        Dispatch<SOAPMessage> disp = vuiService.createDispatch(portName, SOAPMessage.class, javax.xml.ws.Service.Mode.MESSAGE);
	        intradoSoapRequestLog.info("After dispatch Soap Request");
	        SOAPMessage soapResponse = disp.invoke(createSOAPRequest);
	        intradoSoapRequestLog.info("After Invoke Soap Request");*/
	        
	        
	        URL wsdlURL = new URL("https://ilabvui2.intrado.com:443/vuiws/VuiService?wsdl");
	        Service service = Service.create(wsdlURL, portName);
	        Dispatch<SOAPMessage> disp = service.createDispatch(portName, SOAPMessage.class, Service.Mode.PAYLOAD);
	        intradoSoapRequestLog.info("After dispatch Soap Request");
	        SOAPMessage soapResponse = disp.invoke(createSOAPRequest);
	        intradoSoapRequestLog.info("After Invoke Soap Request");
	        
	        
	        // Process the SOAP Response
			printSOAPResponse(soapResponse);
			
			
			soapConnection.close();
			//Convert SoapMessage toInquireFanProfileContactsReponse
			
			
		}catch(Exception e){		
			intradoSoapRequestLog.info("Exception ---> "+e);
			throw e;			
		}finally {
			con.disconnect();
		}	
		

	}	
	
	
	
	
	
	public static boolean getIntradoRequest(String nameSpaceURI, String localPart, String localPort, String endpointAddress, String intradoTestXML) throws Exception {
			SOAPMessage soapResponse = null;
			boolean wsResult = true;
			
			log("getIntradoRequest -->: getIntradoRequest");
			
			HttpsURLConnection con = null;
			
			con = setup(keystore, keystorepass,		truststore, truststorepass, httpsURL, getPost);

			con.setRequestProperty("SOAPAction", "/vui/AliUpdate");
			con.setRequestProperty("accept-charset", "UTF-8");
			con.setRequestProperty("Content-Type", "text/xml");
			
/*			System.setProperty("javax.net.ssl.keyStoreType", "pkcs12");
			System.setProperty("javax.net.ssl.keyStore", intradoCert);
			System.setProperty("javax.net.ssl.keyStorePassword", intradoCertPwd);
			System.setProperty("sun.security.ssl.allowUnsafeRenegotiation", "true");
			System.setProperty("sun.net.client.defaultReadTimeout", "90000");
			System.setProperty("java.protocol.handler.pkgs", "com.sun.net.ssl.internal.www.protocol"); 
			System.setProperty("sun.security.ssl.allowUnsafeRenegotiation", "true");*/
			
			//QName serviceName = new QName("www.example.org", "example");
			QName serviceName = new QName(nameSpaceURI, localPart);

			//QName for Port As defined in wsdl.
			//QName portName = new QName("www.example.org", "exampleSOAP");
			
	        QName portName = new QName(nameSpaceURI, localPort);	

			// Create a dynamic Service instance
			Service service = Service.create(serviceName);			
	        
			// Add a port to the Service
			service.addPort(portName, SOAPBinding.SOAP11HTTP_BINDING, endpointAddress);
			
			
			
			log("Intrado Webservice After add port");
			
			//Create a dispatch instance
			Dispatch<SOAPMessage> dispatch = service.createDispatch(portName, SOAPMessage.class, Service.Mode.MESSAGE); 
			
			
			log("Intrado Webservice After dispatch");
			

/*			MessageFactory factory = MessageFactory.newInstance();
			SOAPMessage request = factory.createMessage();			
			// Object for message parts
			SOAPPart sp = request.getSOAPPart();
			StreamSource createRequestMessage = new StreamSource(new FileInputStream("C:\\ANT\\test.xml"));
			sp.setContent(createRequestMessage);
			// Save message
			request.saveChanges();
			log("Intrado Webservice After request creation -->"+createRequestMessage.toString());*/
			
			
			//Create soap message
/*			
			VUISoapRequest vuiSoapRequest = new VUISoapRequest();
			SOAPMessage soapMessage = vuiSoapRequest.createVUISoapMessage();			
*/			
			log("Generated Soap Request");
			//Creating soap request
			SOAPMessage soapMessage = readSoapMessage(intradoTestXML);
			soapMessage.writeTo(System.out);			
			
			

			//Send soap request
			//sendSoapMessage(soapMessage);

			try {
				// Invoke Endpoint Operation and read response
				soapResponse = dispatch.invoke(soapMessage);
				log("Intrado Webservice After invoke request");
				ByteArrayOutputStream out = new ByteArrayOutputStream();
				soapResponse.writeTo(out);
				printSOAPResponse(soapResponse);
				
				printErrorStream(con);
	
			} catch (WebServiceException wse) {
				wse.printStackTrace();
				wsResult = false;
				log("Intrado Webservice call failed. Exception : " + wse);
				//printErrorStream(con);
			} finally {
				con.disconnect();
			}
			return wsResult;
	
		}
	
	
	
	public static void intradoRequest() throws SOAPException, IOException, UnrecoverableKeyException, KeyManagementException, KeyStoreException, NoSuchAlgorithmException, CertificateException {
		log("getIntradoRequest -->: getIntradoRequest");		
		HttpsURLConnection con = null;		
		con = setup(keystore, keystorepass,	truststore, truststorepass, httpsURL, getPost);
		
		//Creating soap request
		SOAPMessage soapMessage = readSoapMessage(intradoTestXML);
		soapMessage.writeTo(System.out);
		
		//Send soap request
		sendSoapMessage(soapMessage);
	}
	
	
	
	public static void sendSoapMessage(SOAPMessage message) throws SOAPException, IOException {
		log("sendSoapMessage -->: sendSoapMessage");		
		// Create SOAP Connection
        SOAPConnectionFactory soapConnectionFactory = SOAPConnectionFactory.newInstance();
        SOAPConnection soapConnection = soapConnectionFactory.createConnection();

        // Send SOAP Message to SOAP Server
        String url = "https://ilabvui2.intrado.com:443/vuiws/VuiService";
        SOAPMessage soapResponse = soapConnection.call(message, url);

        // print SOAP Response
       log("Response SOAP Message:");
        soapResponse.writeTo(System.out);
        soapConnection.close();
	}
	
	
	
	
	public static SOAPMessage readSoapMessage(String filename) throws SOAPException,
			FileNotFoundException {
		SOAPMessage message = MessageFactory.newInstance().createMessage();
		SOAPPart soapPart = message.getSOAPPart();
		soapPart.setContent(new StreamSource(new FileInputStream(filename)));
		message.saveChanges();
		return message;
	}
	
	
	public static void printSOAPResponse(SOAPMessage soapResponse) throws Exception {
        TransformerFactory transformerFactory = TransformerFactory.newInstance();
        Transformer transformer = transformerFactory.newTransformer();
        Source sourceContent = soapResponse.getSOAPPart().getContent();
        intradoSoapRequestLog.info("\nResponse SOAP Message = ");
        StreamResult result = new StreamResult(System.out);
        transformer.transform(sourceContent, result);        
    }
	
	
	
	
	
	
	private static void log(Object aObject) {
		intradoSoapRequestLog.info(String.valueOf(aObject));
	}
	
	private static HttpsURLConnection setup(String keystore,
			String keystorepass, String truststore, String truststorepass,
			String httpsURL, String getPost) throws MalformedURLException,
			KeyStoreException, IOException, NoSuchAlgorithmException,
			CertificateException, FileNotFoundException,
			UnrecoverableKeyException, KeyManagementException,
			ProtocolException {
		// for HttpsURLConnection we need to set this property
		System.setProperty("java.protocol.handler.pkgs",
				"com.sun.net.ssl.internal.www.protocol");

		System.setProperty("net.debug", "ssl");

		URL url = new URL(null, httpsURL,
				new sun.net.www.protocol.https.Handler());

		// KeyStore ks = KeyStore.getInstance("pkcs12");
		KeyStore ks = KeyStore.getInstance("JKS");
		ks.load(new FileInputStream(keystore), keystorepass.toCharArray());
		KeyManagerFactory kmf = KeyManagerFactory.getInstance("SunX509");
		kmf.init(ks, keystorepass.toCharArray());

		SSLContext sslctx2 = SSLContext.getInstance("SSLv3");
		sslctx2.init(kmf.getKeyManagers(), null, null);

		KeyStore ksTrust = KeyStore.getInstance("JKS");
		ksTrust.load(new FileInputStream(truststore),
				truststorepass.toCharArray());

		// TrustManager's decide whether to allow connections.
		TrustManagerFactory tmf = TrustManagerFactory
				.getInstance("SunX509");
		tmf.init(ksTrust);

		// System.setProperty("javax.net.ssl.keyStoreType", "pkcs12");
		System.setProperty("javax.net.ssl.keyStoreType", "jks");
		System.setProperty("javax.net.ssl.trustStoreType", "jks");
		System.setProperty("javax.net.ssl.keyStore", keystore);
		System.setProperty("javax.net.ssl.trustStore", truststore);
		System.setProperty("javax.net.debug", "ssl");
		System.setProperty("javax.net.ssl.keyStorePassword", keystorepass);
		System.setProperty("javax.net.ssl.trustStorePassword",
				truststorepass);
		System.setProperty("http.keepAlive", "false");
		

		sslctx2.init(kmf.getKeyManagers(), tmf.getTrustManagers(), null);

		// ******
		HttpsURLConnection.setDefaultSSLSocketFactory(sslctx2
				.getSocketFactory());

		HttpsURLConnection con = (HttpsURLConnection) url.openConnection();
		con.setRequestMethod(getPost);
		con.setDoOutput(true);
		con.setRequestProperty("accept-charset", "UTF-8");
		con.setRequestProperty("Content-Type", "text/xml");
		
		return con;
	}
	
	
	private static void printErrorStream(HttpsURLConnection httpsConnection)
			throws IOException {
		Scanner s;
		String response = null;
		if (httpsConnection.getResponseCode() != 200) {
			s = new Scanner(httpsConnection.getErrorStream());
		} else {
			s = new Scanner(httpsConnection.getInputStream());
		}		
		s.useDelimiter("\\Z");
		try{
			response = s.next();
			log(" HTTPS ErrorStream: " + response);
			s.close();
		}catch (NoSuchElementException nse){
			s.close();
			intradoSoapRequestLog.error(" HTTPS ErrorStream: " + nse.getMessage());			
		}catch (Exception e){
			s.close();
			intradoSoapRequestLog.error(" HTTPS ErrorStream: " + e.getMessage());
		}		
		
		
	}
	
	
	@SuppressWarnings("resource")
	public static void main(String args[]) throws Exception{	
		System.out.println("Requst ---->");
		Scanner inputValues;
		
		IntradoSoapRequest intradoSoapRequest = new IntradoSoapRequest();
		intradoSoapRequest.doIntradoRequest();		

		//log("Enter the nameSpaceURI : ");
		//inputValues=new Scanner(System.in);
		//nameSpaceURI=inputValues.nextLine().trim(); 
		
		nameSpaceURI="http://www.intrado.com/namespaces/vui";
		
		log("Enter the localPart : ");
		inputValues=new Scanner(System.in);
		//localPart="aliUpdateRequestPart"; 
		localPart=inputValues.nextLine().trim(); 
		
		log("Enter the localPort : ");
		inputValues=new Scanner(System.in);
		//localPort="vuiSoap"; 
		localPort=inputValues.nextLine().trim(); 
		
		
		
		log("Enter the Cert : ");
		inputValues=new Scanner(System.in);
		String intradoCert=inputValues.nextLine().trim(); 
		
		intradoCert="test";
		
		log("Enter the CertPwd : ");
		inputValues=new Scanner(System.in);
	String 	intradoCertPwd=inputValues.nextLine().trim(); 
		intradoCertPwd="test";
		
		log("Enter the endPointAddress : ");
		inputValues=new Scanner(System.in);
		//endpointAddress="https://ilabvui2.intrado.com:443/vuiws/VuiService";
		endpointAddress=inputValues.nextLine().trim(); 
		
		log("Enter the testXmlPath : ");
		inputValues=new Scanner(System.in);
		intradoTestXML=inputValues.nextLine().trim(); 
		

		
		
	}
	
	
	

}
