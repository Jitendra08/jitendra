package com.att.tpp.service;


import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;

import javax.xml.soap.MessageFactory;
import javax.xml.soap.SOAPException;
import javax.xml.soap.SOAPMessage;
import javax.xml.soap.SOAPPart;
import javax.xml.transform.stream.StreamSource;

public class Driver {

	public Driver(){}

	/**
	 *  This is 1 quick way  
	 */
	public SOAPMessage readSoapMessage(String filename) throws SOAPException,
			FileNotFoundException {
		SOAPMessage message = MessageFactory.newInstance().createMessage();
		SOAPPart soapPart = message.getSOAPPart();
		soapPart.setContent(new StreamSource(new FileInputStream(filename)));
		message.saveChanges();
		return message;
	}

	/**
	 *    
	 */
	public void sendSoapMessage(SOAPMessage message) {
		//now have the code to send this message
	}
	
	/**
	 *    
	 */
	public static void main(String[] args) throws FileNotFoundException, SOAPException, IOException {
		// TODO Auto-generated method stub
		String filename="C:\\ANT\\test.xml";
		Driver driver = new Driver();
		SOAPMessage message= new Driver().readSoapMessage(filename);
		message.writeTo(System.out);
		driver.sendSoapMessage(message);
	}

}