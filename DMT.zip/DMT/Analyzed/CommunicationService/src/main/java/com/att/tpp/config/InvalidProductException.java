package com.att.tpp.config;

class InvalidProductException extends java.lang.Exception {

	private static final long serialVersionUID = 1L;

InvalidProductException () {
     super();
   }

   InvalidProductException ( String msg ) {
     super ( msg ) ;
   }

}
