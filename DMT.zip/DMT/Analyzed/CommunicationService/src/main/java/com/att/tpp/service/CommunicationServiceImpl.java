package com.att.tpp.service;

import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.UnsupportedEncodingException;
import java.math.BigDecimal;
import java.net.MalformedURLException;
import java.net.URL;
import java.security.InvalidKeyException;
import java.security.KeyManagementException;
import java.security.KeyStoreException;
import java.security.NoSuchAlgorithmException;
import java.security.UnrecoverableKeyException;
import java.security.cert.CertificateException;
import java.sql.Timestamp;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Properties;
import java.util.TimeZone;

import javax.jms.JMSException;
import javax.xml.transform.TransformerConfigurationException;
import javax.xml.transform.TransformerFactoryConfigurationError;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.att.tpp.config.InitGlobalInstance;
import com.att.tpp.config.InitializeSSLConnection;
import com.att.tpp.config.LoadCerts;
import com.att.tpp.config.RetryConfigElement;
import com.att.tpp.config.XSLTEngine;
import com.att.tpp.dao.CommunicationDao;
import com.att.tpp.jms.sender.CSFOBPMQueueSender;
import com.att.tpp.jms.sender.CSIQueueSender;
import com.att.tpp.jms.sender.FinalResponseQueueSender;
import com.att.tpp.jms.sender.OCEQueueSender;
import com.att.tpp.jms.sender.ResponseQueueSender;
import com.att.tpp.jms.sender.WorkflowOutBoundQueueSender;
import com.att.tpp.model.EmailRequestData;
import com.att.tpp.model.FinalResponse;
import com.att.tpp.model.IntradoWSResponseData;
import com.att.tpp.model.Products;
import com.att.tpp.model.ProvisioningResponseDynamic;
import com.att.tpp.model.RetryConfiguration;
import com.att.tpp.model.SystemConfiguration;
import com.att.tpp.model.SystemRef;
import com.att.tpp.model.TransactionCode;
import com.att.tpp.model.TransactionCodeList;
import com.att.tpp.model.TransactionRequestData;
import com.att.tpp.model.jpa.ProvisioningRequest;
import com.att.tpp.model.jpa.ProvisioningTask;
import com.att.tpp.model.jpa.Timer;
import com.att.tpp.model.jpa.TimerPK;
import com.att.tpp.model.jpa.TransCode;
import com.att.tpp.utils.FinalResponseXmlGenerator;
import com.att.tpp.utils.ParseRequestData;
import com.att.tpp.utils.ParseResponseData;
import com.att.tpp.utils.ProvisioningResponseXMLGenerator;
import com.att.tpp.utils.TPP_WorkflowRequestXMLGenerator;
import com.att.tpp.utils.ValidateXMLUtil;
import com.att.tpp.xml.vui.model.VUI;
import com.ibatis.common.resources.Resources;


@Service("communicationService")
public class CommunicationServiceImpl implements CommunicationService{
	
	private static Logger communicationServiceLog = LogManager.getLogger(CommunicationServiceImpl.class);
	
	@Autowired
	private CommunicationDao communicationDao;	
	
	@Autowired
	private ResponseQueueSender responseQueueSender;	
	
	@Autowired
	private FinalResponseQueueSender finalResponseQueueSender;
	
	@Autowired
	private WorkflowOutBoundQueueSender workflowOutBoundQueueSender;
	
	@Autowired
	private LoadCerts LoadCertsService;
	
	@Autowired
	private EmailService emailService;
	
	@Autowired
	private SQSService sqsService;
	
	@Autowired
	private CSIQueueSender csiQueueSender;
	
	@Autowired
	private CSFOBPMQueueSender csfobpmQueueSender;
	
	@Autowired
	private OCEQueueSender oceQueueSender;

	
	
   private final static String schemaDir = "//com//att//tpp//common//schemas//";
   private final static String postSuccess = "PostSuccess";
   private final static String postFailed = "PostFailed";
   private final static String postSuccessDesc = "HTTP Post Successful to: ";
   private final static String postFailedDesc = "HTTP Post Failed System to: ";
   private final static String postSuccessCode = "0";
   private final static String postFailedMajorCode = "70000";
   private final static String postFailedMinorCode = "70010";
   private final static String pikePartner = "Pike";
   private final static String balanceManagerPartner = "BalanceManager";
   
   private final static String waitingSystemResponse = "Waiting System Response";
   private final static String waitingToResubmit = "Waiting To Resubmit";
   private final static String indicatorY = "Y";
   private final static String wfErrored = "Errored";
   private final static String taskStatusPostFailed = "Post Failed/Waiting To Resubmit";
   private final static String ResponseCode = "responseCode";
   private final static String ResponseMessage = "responseMessage";
   private final static String autoResonderInd = "autoResonderInd";
   private final static String emailInd = "emailInd";
   
	private final static String VUIXSD = "VUI.xsd";
   
	
   ValidateXMLUtil validateXMLUtil = new ValidateXMLUtil();    
   ParseResponseData parseResponseData = new ParseResponseData();
	@Override
	@Transactional("configTransactionManager")
	public void loadInitialData() throws TransformerConfigurationException, TransformerFactoryConfigurationError, JMSException {
		
		XSLTEngine xsltEngine = new XSLTEngine();
		List<SystemConfiguration> systemConfigList = communicationDao.getSytemConfiguartionList();	
		
		List<RetryConfiguration> retryConfigList = communicationDao.getRetryConfigurationList();		
		
		for (RetryConfiguration retryConfiguration : retryConfigList) {
			InitGlobalInstance.storeCurrentRetryConfig(retryConfiguration.getId().getSystemName(), (int) retryConfiguration.getId().getRetryAttemptNum(), retryConfiguration.getId().getRetryType(), retryConfiguration.getWaitTime());			
		}		
		
		
		for (SystemConfiguration systemConfiguration : systemConfigList) {
			InitGlobalInstance.storeCurrentSystemConfig(systemConfiguration.getId().getSystemName(), systemConfiguration);
			xsltEngine.initializeSystemConfig(systemConfiguration.getId().getSystemName(), systemConfiguration.getXsltFile(), systemConfiguration.getId().getEventType(), systemConfiguration);			
		}		
		
		//Added this logic to load XSLT in the initial setup.
		xsltEngine.loadXSLTTemplates();
		
		List<SystemRef> systemRefList = communicationDao.getSytemRefList();		
		for (SystemRef systemRef : systemRefList) {
			InitGlobalInstance.storeCurrentSystemRef(systemRef.getSystemName(), systemRef);
		}
		
		//Added this logic to load CERTS in keystore/trustedstore in initial setup.
		LoadCertsService.loadKeyStore();
		
		//Load sslcontext
		try {
			InitializeSSLConnection.setUpSSLConnection();
		} catch (UnrecoverableKeyException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (KeyManagementException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (KeyStoreException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (NoSuchAlgorithmException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (CertificateException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		//Reroute onHold queue messages to Transaction queue.
		OnHoldQueueService.onHoldProcess();
		
		
		
		
		communicationServiceLog.info("loadInitialData is completed");
		
	}



	@Override
	public boolean validateXML(String communicationRequestXML,
			String xsdName) throws IOException, Exception {
		boolean validationResult = false;
		StringBuilder schemaLocation = new StringBuilder(schemaDir);
		schemaLocation.append(xsdName);
		URL xsdPath = CommunicationServiceImpl.class
				.getResource(schemaLocation.toString());
		communicationServiceLog.debug("xsdPath :" + xsdPath.toString());
		validationResult = validateXMLUtil.validateWithXSD(communicationRequestXML,
				xsdPath.toString());
		communicationServiceLog.debug("validationResult :" + validationResult);
		return validationResult;
	}

	@Override
	@Transactional("archiveTransactionManager")
	public boolean updateInterfaceTable(String parseSystemName, String connectivityStatus) {
		return communicationDao.updateInterfaceTable(parseSystemName, connectivityStatus);
	}

	@Override
	@Transactional("dataTransactionManager")
	public boolean updateTaskStatus(String taskTransId) {
		return communicationDao.updateTaskStatus(taskTransId);		
	}


	@Override
	@Transactional("dataTransactionManager")
	public HashMap<String, String> postRequest(TransactionRequestData transactionRequestData,
			String provisioningRequestXML, String messageId) throws Exception {

		int httpResultCode = 000;
		PostRequest postRequest = new PostRequest();
		HashMap<String, String> postResultMap = new HashMap<String, String>();
		String url = transactionRequestData.getUrl();

		//boolean updateTPPData = false;
		boolean autoResponderFlag = false;
		boolean emailFlag = false;
		

		try {
 			if (url != null && url != "") {
 				/*
				 * Added check for DCMNotification Event Type for QxP to process normally and Intrado will be processed BAU.
				 */
 				if (((transactionRequestData.getRoutingCarrier().equals("CSI")) && (!transactionRequestData.getEventType().equals("DCMNotification"))) || transactionRequestData.getSystemName().equals("IntradoSWC")) {	
					//Send the soap request	to intrado
 					communicationServiceLog.info("Sending transaction with SystemName:[" + transactionRequestData.getSystemName() + "]" +  "taskID: [" + transactionRequestData.getTaskTransId() +"]" + "to Intrado");
					callIntradoWSRequest(transactionRequestData, provisioningRequestXML);							
					return postResultMap;
					
				} else {
					 if (url.contains("jms_absautoresponder")) {
							autoResponderFlag = true;
							postResultMap.put(ResponseCode, "200");
							postResultMap.put(ResponseMessage, postSuccess);
					}else if (url.contains("@")) {
						// Send Email Request
						EmailRequestData emailRequestData = new EmailRequestData();
						autoResponderFlag = true;
						emailFlag=true;
						//Modify this value with url
						
						ParseRequestData parseRequestXML = new ParseRequestData();
						
						String emailProvreqData = parseRequestXML.parseProvisioningRequestXML(provisioningRequestXML);

						communicationServiceLog.info("Formated Email :" + emailProvreqData);
						emailRequestData.setTo(transactionRequestData.getUrl());
						emailRequestData.setProvisioningRequestData(emailProvreqData);
						
						// Send EmailRequest and put results in hashMap
						postResultMap = emailService.sendEmailRequest(emailRequestData, url);
					} else if (transactionRequestData.getSystemName().equals("CSFOBPM")) {
						//Post the csfobpmRquest to CSFOBPM Queue
	 					postResultMap=null;
	 					String csiTransactionId= transactionRequestData.getTaskTransId();
	 					csfobpmQueueSender.sendMessage(provisioningRequestXML, csiTransactionId);						
						return postResultMap;
					} else if (transactionRequestData.getSystemName().equals("OCE") || transactionRequestData.getSystemName().equals("OCEFLEX") ) {
						//Post the ocepmRquest to OCE Queue
						postResultMap=null;
						String csiTransactionId= transactionRequestData.getTaskTransId();
						oceQueueSender.sendMessage(provisioningRequestXML, csiTransactionId);
						return postResultMap;
					} else if (url.contains("http")) {
							if (url.contains("https")) {
								communicationServiceLog.info("Inside https method for testing ");
								
								if ((transactionRequestData.getSystemName().equals(pikePartner))) {
									//SQS
									String dataWithSignature = createSQSDataWithSignature(provisioningRequestXML, url);	
									communicationServiceLog.info("SQS dataWithSignature :"+dataWithSignature);
									if(dataWithSignature!=null && dataWithSignature!=""){
										provisioningRequestXML = dataWithSignature;
									}
								}							
								// Send to https
								communicationServiceLog.info("Making HTTPS Request!");
								postResultMap = postRequest.postHTTPSRequest(url, provisioningRequestXML, transactionRequestData.getSystemName(), transactionRequestData.getProxyEnabled());								
							} else {
								// Send to http
								communicationServiceLog.info("Making HTTP Request!");
								postResultMap = postRequest.postHTTPRequest(url,  provisioningRequestXML, transactionRequestData.getProxyEnabled());							
							}
	
						}
					 
					 httpResultCode = Integer.parseInt(postResultMap.get(ResponseCode));
					 communicationServiceLog.info("HTTP Result Code = " + httpResultCode);
						
					if ((transactionRequestData.getSystemName().equals(pikePartner)) || (transactionRequestData.getSystemName().equals(balanceManagerPartner))) {
						if(httpResultCode == 200){
							autoResponderFlag = true;
						}
					}
					
					
					String autoResonderIndictor = "N";
					if(autoResponderFlag){
						autoResonderIndictor = "Y";
					}
					
					
					String emailIndictor = "N";
					if(emailFlag){
						emailIndictor="Y";
					}
					
					
					
					
					postResultMap.put(autoResonderInd,autoResonderIndictor);
					postResultMap.put(emailInd,emailIndictor);
					
					
					/*perisistDataTables(transactionRequestData, provisioningRequestXML,
							messageId, httpResultCode, postResultMap, url,
							autoResponderFlag, emailFlag);*/
				}

			} else {
				communicationServiceLog.info("POST URL Should not be empty. ");
			}

		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			communicationServiceLog.error("Exception occured while making postRequest: " + e.getMessage());
			postResultMap.put(autoResonderInd, "N");
			postResultMap.put(emailInd, "N");
			postResultMap.put(ResponseCode, "0");
			postResultMap.put(ResponseMessage, e.getMessage());
			return postResultMap;
		}
		return postResultMap;
	}



	public void perisistDataTables(TransactionRequestData transactionRequestData,
			String provisioningRequestXML, String messageId,
			int httpResultCode, HashMap<String, String> postResultMap,
			String url, boolean autoResponderFlag, boolean emailFlag)
			throws Exception {
		boolean updateTPPData;
		// Persist TPPData
		updateTPPData = updateDataTables(httpResultCode,
				provisioningRequestXML, transactionRequestData,	messageId, url, postResultMap);
		
		// Generate AutoResponder and Send to Response Service
		if(autoResponderFlag){
			generateAutoResponder(provisioningRequestXML,emailFlag,httpResultCode);
			communicationServiceLog.info("Posted AutoResponder to Response Service: "
							+ transactionRequestData.getTaskTransId());				
		}
		communicationServiceLog.info("updateTPPData: " + updateTPPData);
	}

	
	
	public void callIntradoWSRequest(TransactionRequestData transactionRequestData, String provisioningRequestXML) throws IOException, Exception {
		
/*		 For testing please remove it after soap request
 *       IntradoWSResponseData intradoWSResponseData = forTesting(vuiRequestData,
				transactionRequestData, intradoRequest);*/
		
		//validate the xml with xsd		
		boolean isValidVUIRequestXML = validateXML(provisioningRequestXML, VUIXSD);
		communicationServiceLog.info("isValidVUIRequestXML: "+isValidVUIRequestXML);

		IntradoWSResponseData intradoWSResponseData = new  IntradoWSResponseData();	
		
		if(isValidVUIRequestXML){
			ParseRequestData parseRequestData = new ParseRequestData(); 
			VUI vuiRequestData = parseRequestData.parseVUIRequestxml(provisioningRequestXML, transactionRequestData.getMsisdn());
			try {
				intradoWSResponseData = PostIntradoRequest.intradoHTTPSPost(
						vuiRequestData, transactionRequestData);
	
			} catch (Exception e) {
				e.printStackTrace();
				communicationServiceLog.info("Exception occured in callIntradoWSRequest method: "+e);
				intradoWSResponseData.setTransactionId(transactionRequestData.getTaskTransId());
				intradoWSResponseData.setRc1Code("70010;");
				intradoWSResponseData.setRc1Message("Exception occured in posting request to Intrado");	
				intradoWSResponseData.setWsPostResult(postFailed);
			}
		
		}else{
			intradoWSResponseData.setTransactionId(transactionRequestData.getTaskTransId());
			intradoWSResponseData.setRc1Code("60010");
			intradoWSResponseData.setRc1Message("Invalid Intrado XML - Parsing Exception");	
			intradoWSResponseData.setWsPostResult(postFailed);
		}
		
		
		String vuiHeader="<?xml version = \"1.0\" encoding = \"UTF-8\"?> \n <vuiAliUpdateResponse rec = \"\" xmlns = \"http://www.intrado.com/namespaces/vui\" xmlns:xsi = \"http://www.w3.org/2001/XMLSchema-instance\" xsi:schemaLocation = \"http://www.intrado.com/namespaces/vui ../../TransactionService/Resources/SharedResources/VUI/VUI2.xsd\">"; 
        String rc1Message="<rc1 message="+'"'+intradoWSResponseData.getRc1Message()+'"'+">"+intradoWSResponseData.getRc1Code()+"</rc1> \n "; 
        String transactionId="<transactionId>"+transactionRequestData.getTaskTransId()+"</transactionId> </vuiAliUpdateResponse>"; 
		String intradoResponse= vuiHeader+rc1Message+transactionId;
				
		communicationServiceLog.info("Intrado Response : "+intradoResponse);
		
		//Send to the CSI service.
		String eventType = transactionRequestData.getEventType();
		
		if(eventType.equals("FCNotification")){
			eventType="NotifyFemtocellAction";
		}else if(eventType.equals("MetroNotification")){
			eventType="NotifyMetrocellAction";
		}else if(eventType.equals("SmallCellNotification")){
			eventType="NotifySmallcellAction";
		}

		String csiTransactionId= transactionRequestData.getMasterTransId();
		String actionCode = getActionCode(transactionRequestData);
		
		if (transactionRequestData.getSystemName().equals("IntradoSWC")) {
			// Generate provisiong Response
			/*
			   String provisioningResponseXML; provisioningResponseXML =
			   generatedProvisioningResponseXML(provisioningRequestXML,true,httpResultCode);
			   communicationServiceLog.info("provisioningResponseXML: "
			   +provisioningResponseXML);
			 
			finalResponseQueueSender.sendMessage(provisioningResponseXML,messageId);*/
			HashMap<String, String> intradoPostResultMap = new HashMap<String, String>();
			intradoPostResultMap.put(ResponseCode, intradoWSResponseData.getRc1Code());
			intradoPostResultMap.put(ResponseMessage, intradoWSResponseData.getRc1Message());
			insertTransCodes(transactionRequestData,intradoWSResponseData.getWsPostResult(),intradoPostResultMap);
			communicationServiceLog.info("Intrado Response for IntradoSWC : "+ intradoResponse);
			try {
				//generateAutoResponder(provisioningRequestXML, true, 200);
				communicationServiceLog.info("Setting the FinalResponseModel to Generate FinalResponse XML");
				FinalResponse finalResponseModel = new FinalResponse();								
				 					
				
				// Verify if record exist in Provisioning Request
				List<ProvisioningRequest> provisioningRequestList = communicationDao.queryProvisioningRequest(transactionRequestData.getMasterTransId());

				if (provisioningRequestList.size() > 0) {
					ProvisioningRequest proReq = provisioningRequestList.get(0);
					finalResponseModel.setProvSystemTransID(proReq.getProvSystemTransid());
					finalResponseModel.setProvCarrier(proReq.getProvisioningCarrier());
					finalResponseModel.setSystem(proReq.getRoutingCarrier());
				}
			
				
				finalResponseModel.setCurrentTechRetryCount(transactionRequestData.getCurrentTechRetryCount());
				finalResponseModel.setMasterTransID(transactionRequestData.getMasterTransId());
				finalResponseModel.setMaxTechRetryCount(transactionRequestData.getMaxTechRetryCount().toString());
				finalResponseModel.setRoutingCarrier(transactionRequestData.getRoutingCarrier().trim());
				finalResponseModel.setUrl("jms"); //for FinalReponse to send to SWC via JMS
			 	
				//Create FinalResponseXML.
				FinalResponseXmlGenerator xmlGenerator = new FinalResponseXmlGenerator();
				String finalResponseXML = xmlGenerator.createFinalResponseNotificationXML(finalResponseModel);
				communicationServiceLog.info("createdFinalResponseXML :"+finalResponseXML);
				//Validate the FinalResponse
				boolean isValidAFinalResponse = validateXML(finalResponseXML, "TPP_FinalResponseNotification.xsd");
				communicationServiceLog.info("isValid Generated FinalResponse XML :"+isValidAFinalResponse);
				//Send to the FinalResponse queue.
				if(isValidAFinalResponse){
						communicationServiceLog.info("Sending to the FinalResponse queue messageId:"+finalResponseModel.getProvSystemTransID() +" masterTransId :"+finalResponseModel.getMasterTransID());
						finalResponseQueueSender.sendMessage(finalResponseXML, finalResponseModel.getProvSystemTransID());
				}
			} catch (Exception e ) {
				communicationServiceLog.info("Exception in generating XML Response:"+ e.getMessage());
			}
		}
		else {
			
			csiQueueSender.sendMessage(intradoResponse, eventType, csiTransactionId, actionCode);
		}
		
	}



	private String getActionCode(TransactionRequestData transactionRequestData) {
		String actionCode=null;
				Iterator<Products> iterator = transactionRequestData.getProductsCollection().iterator();
				
				while(iterator.hasNext()){
					Products products = iterator.next();
					actionCode=products.getProductsPK().getAction();
				}
		return actionCode;
	}



	@SuppressWarnings("unused")
	private IntradoWSResponseData forTesting(VUI vuiRequestData,
			TransactionRequestData transactionRequestData,
			IntradoRequest intradoRequest) {
		// romove this after testing.
		boolean qbased = false;
		boolean springBased = false;
		boolean intradoHttps = true;

		IntradoWSResponseData intradoWSResponseData = null;

		if (springBased) {
			communicationServiceLog
					.info("Inside the springBased Intrado request ");
			intradoWSResponseData = intradoRequest.doIntradoRequest(
					vuiRequestData, transactionRequestData);
		} else if (qbased) {
			communicationServiceLog.info("Inside the Q based Intrado request ");
			IntradoSoapRequest intradoSoapRequest = new IntradoSoapRequest();
			try {
				intradoSoapRequest.doIntradoRequest();
				intradoWSResponseData = new IntradoWSResponseData();
				intradoWSResponseData.setRc1Code("000");
				intradoWSResponseData.setTransactionId("Test");
				intradoWSResponseData.setRc1Code("Test");
				intradoWSResponseData.setRc1Message("Test");
			} catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		} else if (intradoHttps) {

			PostIntradoRequest intradoHTTPS = new PostIntradoRequest();
			try {
				IntradoWSResponseData intradoHTTPSPost = intradoHTTPS.intradoHTTPSPost(vuiRequestData, transactionRequestData);
			} catch (FileNotFoundException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			} catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}

			intradoWSResponseData = new IntradoWSResponseData();
			intradoWSResponseData.setRc1Code("000");
			intradoWSResponseData.setTransactionId("Test");
			intradoWSResponseData.setRc1Code("Test");
			intradoWSResponseData.setRc1Message("Test");
		}
		return intradoWSResponseData;
	}
	



	private String createSQSDataWithSignature(String provisioningRequestXML,
			String url) throws Exception, MalformedURLException,
			UnsupportedEncodingException, NoSuchAlgorithmException,
			InvalidKeyException {
		String dataWithSignature = null;
		communicationServiceLog.info("Creating SQSDataWithSignature");
		try {
			String expiryTime = sqsService.iso860DateTime();
			String messageToSign = sqsService.createMessageToSign(expiryTime,
					provisioningRequestXML, url);
			String signature = sqsService.singMessage(messageToSign);
			dataWithSignature = sqsService.dataWithSignature(expiryTime,
					provisioningRequestXML, signature);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			communicationServiceLog.error("Creating SQSDataWithSignature caused an exception: " + e.getMessage());
			e.printStackTrace();
		}
		return dataWithSignature;
	}
	
	
	


	@Transactional("dataTransactionManager")
	//Check Transactionaaal
	private boolean updateDataTables(int htppStatusCode,
			String provisioningRequestXML,
			TransactionRequestData transactionRequestData, String messageId, String url, HashMap<String, String> postResultMap) throws Exception {		

		String postResult = postFailed;

		if (htppStatusCode == 200) {
			postResult = postSuccess;
		}
		

		//Insert into TransCodes
		boolean insertTransCodeResult = insertTransCodes(transactionRequestData, postResult, postResultMap);
		communicationServiceLog.info("insertTransCodeResult : "+insertTransCodeResult);
		
		
		//Todo:Update Timer Table
		boolean updateTimerTableResult = updateTimerTable(postResult,provisioningRequestXML,transactionRequestData);
		communicationServiceLog.info("updateTimerTableResult : "+updateTimerTableResult);
		
		//If Retry exceeded then call to workflow service
		boolean retryExceded = verifyRetryExceeded(transactionRequestData, messageId);
		communicationServiceLog.info("retryExceded : "+retryExceded);
		
		//UpdateInterfaceTable
		
		boolean updateInterface = updateConnectivityStatus(transactionRequestData, url,
				postResult);
		communicationServiceLog.info("updateInterface table : "+updateInterface);
		
		
		return insertTransCodeResult;
	}


	@Transactional("dataTransactionManager")
	public boolean updateConnectivityStatus(TransactionRequestData transactionRequestData,
			String url, String postResult) {
		String connectivityStatus = getConnectivityStatus(url, postResult);
		boolean updateInterface = communicationDao.updateInterfaceTable(transactionRequestData.getSystemName(),connectivityStatus);
		return updateInterface;
	}



	private String getConnectivityStatus(String url, String postResult) {
		String connectivityStatus="Y";		
		if (url.contains("jms_absautoresponder")) {
			connectivityStatus="P";
		}else if(postResult.equals(postSuccess)){
			connectivityStatus="G";	
		}
		return connectivityStatus;
	}


	@Transactional("dataTransactionManager")
	public boolean updateTimerTable(String postResult,
			String provisioningRequestXML,
			TransactionRequestData transactionRequestData) {
		
		boolean updateTimerTableResult = false; 
	
		try{
		  //Query Provisioning Tasks
		  List<ProvisioningTask> provisioningTaskList = communicationDao.queryProvisioningTasks(transactionRequestData.getTaskTransId().trim());
		  
		  if(provisioningTaskList.size()>0){
			  int waitTime=0;
			  ProvisioningTask provisioningTask = provisioningTaskList.get(0);	
			  
			  //Query Timer table
			  List<Timer> timerList = communicationDao.queryTimerTable(transactionRequestData.getTaskTransId().trim());
			  BigDecimal currTechRetryCount = provisioningTask.getCurrTechRetryCount();  
					  //.add(BigDecimal.ONE); /* commented because it updated current tech retry count without checking the value */
			  if(timerList!=null && timerList.size()>0){				  
				  //Verify Retry Exceeded
				  BigDecimal maxTechRetryCount = provisioningTask.getMaxTechRetryCount();				  
				  BigDecimal currNoRespRetryCount = provisioningTask.getCurrNoRespRetryCount();
				  BigDecimal maxNoRespRetryCount = provisioningTask.getMaxNoRespRetryCount();
				  
/* We should delete timer table entry if current tech retry is greater than or equal to Max tech rety count */				  
				  if((currTechRetryCount.compareTo(maxTechRetryCount)>=0)){
						//Delete from timer table
					    boolean deleteFromTimerResult = communicationDao.deleteFromTimer(transactionRequestData.getTaskTransId());
					    communicationServiceLog.info("deleteFromTimerResult :"+ deleteFromTimerResult);	
				  }else if((currTechRetryCount.compareTo(maxTechRetryCount)==-1) || (currNoRespRetryCount.compareTo(maxNoRespRetryCount)<= 0)){					  
					  //Update Timer
						waitTime = getWaitTime(provisioningTask, postResult, true );
						String timerState = getTimerState(postResult);
						boolean updateTimerResult = updateTimerData(provisioningRequestXML,
								transactionRequestData, waitTime, timerState);
					    communicationServiceLog.info("updateTimerResult :"+ updateTimerResult);				    
					  
				  }else{
					  communicationServiceLog.info("No action taken for the timer table, since it did not satisified the conditions. Please check :"+transactionRequestData.getTaskTransId());
				  }				  
			  }else{
					//Create Timer data
					Timer timer = generateTimerData(postResult, provisioningTask, provisioningRequestXML);					
					//Insert TimerEntry
					boolean insertTimerResult = communicationDao.insertTimer(timer);
					communicationServiceLog.info("insertTimerResult :"+insertTimerResult);	
			  }
			  
			   //Update TaskStatus when post failed
			   if((postResult.equals(postFailed))){
			    String taskStatus = getTaskStatus(provisioningTask);
			    boolean updateTaskStatus = communicationDao.updatePostFailedTaskStatus(transactionRequestData.getTaskTransId(),taskStatus, currTechRetryCount);
			    communicationServiceLog.info("Updated Prov Task Status to :"+ taskStatus+" with result: "+updateTaskStatus);	
			   }
			  updateTimerTableResult = true;
			  
		  }else{
			  communicationServiceLog.info("Records not exist for the TaskTransId : "+transactionRequestData.getTaskTransId());			 
		  }
		} catch (Exception e) {
			communicationServiceLog.error("Exception occured in the updateTimerTable method");
			e.printStackTrace();
			return updateTimerTableResult;
		}	
		
		return updateTimerTableResult;
	}

	
	@Transactional("dataTransactionManager")
	private boolean updateTimerData(String provisioningRequestXML,
			TransactionRequestData transactionRequestData, int waitTime,
			String timerState) {
		boolean updateTimerResult;
		String payLoad = null;
		String payLoadOverflow = null;

//		if (provisioningRequestXML.length() > 4000) {
//
//			payLoad = provisioningRequestXML.substring(0, 4000).trim();
//			payLoadOverflow = provisioningRequestXML.substring(4001,
//					provisioningRequestXML.length()).trim();
//		} else {
//			payLoad = provisioningRequestXML;
//			payLoadOverflow = "";
//		}

		payLoad = provisioningRequestXML; /* Payload is CLOB so no need to check size*/
		updateTimerResult = communicationDao.updateTimer(transactionRequestData
				.getTaskTransId().trim(), timerState, waitTime, payLoad,
				payLoadOverflow);
		return updateTimerResult;
	}


	private String getTaskStatus(ProvisioningTask provisioningTask) {
		  String taskStatus=null;
	      BigDecimal currTechRetryCount = provisioningTask.getCurrTechRetryCount(); 
	      //.add(BigDecimal.ONE);  /* commented because it updated current tech retry count without checking the value */
		  BigDecimal maxTechRetryCount = provisioningTask.getMaxTechRetryCount();	
		  
		  communicationServiceLog.info("currTechRetry = " + currTechRetryCount);
		  communicationServiceLog.info("maxTechRetry = " + maxTechRetryCount);
		  
		  /* We should updated task status to Errored if current tech retry is greater than or equal to Max tech retry count */		  
		  if((currTechRetryCount.compareTo(maxTechRetryCount)>=0)){
			  taskStatus=wfErrored;
		  }else{
			  taskStatus=taskStatusPostFailed;
		  }
		return taskStatus;
	}



	private Timer generateTimerData(String postResult, ProvisioningTask provisioningTask, String provisioningRequestXML) {		int waitTime;
		Timer timer = new Timer();
		TimerPK timerPk = new TimerPK();
		Calendar currentTimeStamp = Calendar.getInstance();
		timerPk.setSystemName(provisioningTask.getSystemName().trim());
		timerPk.setTaskTransid(provisioningTask.getId().getTaskTransid());
		timerPk.setTimerState(getTimerState(postResult));
		timer.setCreationTime(currentTimeStamp.getTime());
		waitTime = getWaitTime(provisioningTask, postResult, false);	
		timer.setId(timerPk);
		timer.setRetryInd(indicatorY);
		timer.setTimerDuration(waitTime);
		currentTimeStamp.add(Calendar.MILLISECOND,waitTime);
		timer.setExpiryTime(currentTimeStamp.getTime());
		
//		if (provisioningRequestXML.length() > 4000) {
//
//			timer.setPayload(provisioningRequestXML.substring(0, 4000).trim());
//			timer.setPayloadOverflow(provisioningRequestXML.substring(4001, provisioningRequestXML.length()).trim());
//		} else {
//			timer.setPayload(provisioningRequestXML);
//			timer.setPayloadOverflow("");
//		}	
		timer.setPayload(provisioningRequestXML); /* Payload is CLOB so no need to check size*/
		return timer;
	}

	


	private int getWaitTime(ProvisioningTask provisioningTask,
			String postResult, boolean updateFlag) {
		int waitTime = 0;
		Integer currTechRetryCount = 1;
		Integer currNoRespRetryCount = 1;
		String key = null;		

		RetryConfigElement retryConfigElement = null;

		if (provisioningTask != null
				&& provisioningTask.getSystemName() != null) {

			if (updateFlag) {
				currTechRetryCount = provisioningTask.getCurrTechRetryCount()
						.intValue() + 1;
				currNoRespRetryCount = provisioningTask.getCurrNoRespRetryCount()
						.intValue() + 1;
			}
			
			if(postResult.equals(postSuccess)){
				key = provisioningTask.getSystemName() + "_"
						+ "no_response" + "_" + currNoRespRetryCount.intValue();
			}else{
				key = provisioningTask.getSystemName() + "_"
						+ "response_failure" + "_" + currTechRetryCount.intValue();
			}
			
			retryConfigElement = (RetryConfigElement) InitGlobalInstance
					.getRetryConfig().get(key);

			if (retryConfigElement != null) {
				waitTime = retryConfigElement.waitTime;
			}
		}
		return waitTime;
	}


	private String getTimerState(String postResult) {
		String timerState = null;		
		if(postResult!=null && postResult.length()>0){
			if(postResult.equals(postSuccess)){
				timerState=waitingSystemResponse;
			}else{
				timerState=waitingToResubmit;
			}
		}		
		return timerState.trim();
	}




	public boolean verifyRetryExceeded(TransactionRequestData transactionRequestData, String messageId) throws JMSException {
		boolean retryExceeded = false;
		String currentTechRetryCount = transactionRequestData.getCurrentTechRetryCount();
		String maxTechRetryCount = transactionRequestData.getMaxTechRetryCount();
		
		
		if(currentTechRetryCount!=null && currentTechRetryCount!="" && maxTechRetryCount!=null && maxTechRetryCount!=""){
			int currentTechRetryCountInt= Integer.parseInt(currentTechRetryCount);
			int maxTechRetryCountInt= Integer.parseInt(maxTechRetryCount);

			/* We should update retryexceeded to True if current tech retry is greater than or equal to Max tech retry count */
			if((currentTechRetryCountInt) >= maxTechRetryCountInt){
				retryExceeded = true;
				//Create work flow request
				TPP_WorkflowRequestXMLGenerator tppWorkflowRequestXMLGenerator =  new TPP_WorkflowRequestXMLGenerator();				
				String createWorkflowRequestXML = tppWorkflowRequestXMLGenerator.createWorkflowRequestXML(transactionRequestData.getMasterTransId());
				
				//Send to Outbound WorkFlow Service
				workflowOutBoundQueueSender.sendMessage(createWorkflowRequestXML, messageId);
				communicationServiceLog.info("Send to Outbound WorkFlow Service : "+transactionRequestData.getTaskTransId());
			}
		}else{
			communicationServiceLog.info("currentTechRetryCount : "+currentTechRetryCount +"maxTechRetryCount: "+ maxTechRetryCount +"should not be null");
		}
		return retryExceeded;
	}


	@Transactional("dataTransactionManager")
	public boolean insertTransCodes(TransactionRequestData transactionRequestData,
			String postResult, HashMap<String, String> postResultMap) {

		// Verify if record exist in Provisioning Request
		List<ProvisioningRequest> provisioningRequestList = communicationDao.queryProvisioningRequest(transactionRequestData.getMasterTransId());

		if (provisioningRequestList.size() > 0) {
			// Generate TransCode List and Insert TransCode Data
			List<TransCode> transCodeList = generateTransCodeListData(postResult,transactionRequestData, postResultMap);
			Boolean insertTransCodes = communicationDao.insertTransCodes(transCodeList);
			communicationServiceLog.info("insertTransCode :" + insertTransCodes);
		} else {
			communicationServiceLog
					.info("Records are not found in the Provisioning Request table, so skipping the Trans code.");
			return false;
		}

		return true;
	}



	private List<TransCode> generateTransCodeListData(String postResult,
			TransactionRequestData transactionRequestData, HashMap<String, String> postResultMap) {
		
		String majorCode;		
		String majorDesc;					
		String minorCode;			
		String minorDesc;
		Date errorDate = new Date();
		
		List<TransCode> transCodeList = new ArrayList<TransCode>();
		TransCode transCode = null;
		
		Iterator<Products> productIterator = transactionRequestData
				.getProductsCollection().iterator();
		
		if(postResult.equals(postSuccess)){
			majorCode = postSuccessCode;
			majorDesc = postSuccessDesc+transactionRequestData.getSystemName();
			minorCode = postSuccessCode;
			minorDesc = postSuccessDesc+transactionRequestData.getSystemName()+ " Status: " + postResultMap.get(ResponseCode) + " Reason: "+postResultMap.get(ResponseMessage);
		}else{
			majorCode = postFailedMajorCode;
			majorDesc = postFailedDesc+transactionRequestData.getSystemName();
			minorCode = postFailedMinorCode;
			minorDesc = postFailedDesc+transactionRequestData.getSystemName() + " Status: " + postResultMap.get(ResponseCode) + " Reason: "+postResultMap.get(ResponseMessage);
		}
		
		while (productIterator.hasNext()) {
			Products products = productIterator.next();
			transCode =new TransCode();
			transCode.setAction(products.getProductsPK().getAction());
			transCode.setProductId(products.getProductsPK().getProductId());
			transCode.setTaskTransid(products.getProductsPK().getTransactionId());
			transCode.setMasterTransid(transactionRequestData.getMasterTransId());			
			transCode.setErrorTime(new Timestamp(errorDate.getTime()));
			
			transCode.setMinordesc(minorDesc);
			transCode.setMajorcode(majorCode);
			transCode.setMajordesc(majorDesc);
			transCode.setMinorcode(minorCode);
			transCodeList.add(transCode);
		}
		return transCodeList;
	}



	public void generateAutoResponder(String provisioningRequestXML, boolean emailFlag, int httpResultCode) {
		String provisioningResponseXML;
		// Generate provisiong Response
		 provisioningResponseXML = generatedProvisioningResponseXML(provisioningRequestXML,emailFlag,httpResultCode);		
		 communicationServiceLog.info("provisioningResponseXML: "+provisioningResponseXML);
		 //Send to Response service
		 sendToResponseQueue(provisioningResponseXML);
	}	
	
	
	
	private String generatedProvisioningResponseXML(String provisioningRequestXML, boolean emailFlag, int httpResultCode) {
		String provisioningResponseXML;
		ProvisioningResponseDynamic provisioningResponseDynamic = new ProvisioningResponseDynamic();
		ProvisioningResponseXMLGenerator provisioningResponseXMLGenerator = new ProvisioningResponseXMLGenerator();
		
		List<TransactionCodeList> transactionCodeLists = new ArrayList<TransactionCodeList>();
		TransactionCode transactionCode = new TransactionCode();
		TransactionCodeList transactionCodeList = new TransactionCodeList();
		
		int majorcode=0;
		String description=null;
		
		if(emailFlag){
			if(httpResultCode == 200){
				majorcode=0;
				description="Success";
			}else{
				majorcode=60000;
				description="Fatal Data Error";
			}
		}else{
			majorcode=0;
			description="Success";
		}
		transactionCode.setMajorCode(majorcode);
		transactionCode.setDescription(description);
		transactionCodeList.setErrorCode(majorcode);
		transactionCodeList.setErrorMessageText(description);
		transactionCodeLists.add(transactionCodeList);
		transactionCode.setTransactionCodeList(transactionCodeLists);
		
		
		provisioningResponseDynamic = parseResponseData.getResponseData(provisioningRequestXML.toString(), transactionCode);
		provisioningResponseXML= provisioningResponseXMLGenerator.buildProvRespXML(provisioningResponseDynamic);
		return provisioningResponseXML;
	}
	
	
	
	public void sendToResponseQueue(String provisioningResponseXML) {
		try {
			responseQueueSender.sendMessage(provisioningResponseXML);			
		} catch (JMSException e) {
			 communicationServiceLog.error("Error sending to Resopnose XML : "+ provisioningResponseXML + "to Response Queue. Error : " +  e.getMessage());
			e.printStackTrace();
		}		
	}
	
	
	
	public String getProperiesValue(String propertyKey) {
		Properties prop = new Properties();
		String propertyValue=null;
		try {
			prop = Resources.getResourceAsProperties("./common.properties");
			propertyValue = prop.getProperty(propertyKey);
			return propertyValue;
		} catch (IOException e) {
			e.printStackTrace();
		}
		return propertyValue;
	}


	@Override
	public boolean postFulfillmentRequest(String fulfillmentRequestXML, String url, String proxyEnabled) throws IOException {		
		boolean postResult = false;
		PostRequest postRequest = new PostRequest();
		HashMap<String, String> postResultMap = new HashMap<String, String>();

		if (url.contains("https")) {
			// Send to https
			postResultMap = postRequest.postHTTPSRequest(url, fulfillmentRequestXML, proxyEnabled);
		} else {
			// Send to http
			postResultMap = postRequest.postHTTPRequest(url, fulfillmentRequestXML, proxyEnabled);
		}
		
		 int httpResultCode= Integer.parseInt(postResultMap.get(ResponseCode));
		 
		 if(httpResultCode == 200){
			 postResult = true;
			}
		 
		 communicationServiceLog.info("Fulfillment Result HTTP Post code : "+httpResultCode + "Message :"+postResultMap.get(ResponseMessage));

		 return postResult;
	}
	
	/* This method used to get the Current TimeStamp in GMT format */
	public String getDateWithGMTFormat(){
		Calendar currentTimeStamp = Calendar.getInstance();
	    Date strCurrTime = currentTimeStamp.getTime();
	    SimpleDateFormat sdf = new SimpleDateFormat("yyyy/MM/dd HH:mm:ss z");
	    sdf.setTimeZone(TimeZone.getTimeZone("GMT"));
	    String strDate = null;
	    try {
	        strDate = sdf.format(strCurrTime);
	        communicationServiceLog.info("TimeStamp::"+strDate);
	    } catch (Exception e) {
	        e.printStackTrace();  
	    }
	    return strDate;
	}
       
	@Transactional("dataTransactionManager")
	public boolean updateInvalidSystemTaskStatus(String taskTransId, String taskStatus,
			BigDecimal currTechRetryCount) {
		boolean updateInvalidTaskStatus = communicationDao.updatePostFailedTaskStatus(taskTransId,taskStatus, currTechRetryCount);
		return updateInvalidTaskStatus;
	}
/*	@Override
	public boolean validateXML(String workFlowRequestXML,
			String xsdName) throws IOException, Exception
	{
		boolean validationResult = false;
		StringBuilder schemaLocation = new StringBuilder(schemaDir);
		schemaLocation.append(xsdName);
		URL xsdPath = WorkflowServiceImpl.class
				.getResource(schemaLocation.toString());
		workflowServiceLog.debug("xsdPath :" + xsdPath.toString());
		validationResult = validateXMLUtil.validateWithXSD(workFlowRequestXML,
				xsdPath.toString());
		workflowServiceLog.debug("validationResult :" + validationResult);
		return validationResult;
	}*/
		

	
}