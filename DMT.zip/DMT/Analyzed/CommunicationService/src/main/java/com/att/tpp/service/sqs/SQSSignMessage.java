package com.att.tpp.service.sqs;

import java.util.*;
import java.io.*;
import org.apache.commons.codec.binary.Base64;
import java.security.SignatureException;
import javax.crypto.Mac;
import javax.crypto.spec.SecretKeySpec;

public class SQSSignMessage{
/****** START SET/GET METHOD, DO NOT MODIFY *****/
	protected String mesgToSign = "";
	protected String expiryTimeIn = "";
	protected String s_Key = "";
	protected String signature = "";
	protected String expiryTimeOut = "";
	public String getmesgToSign() {
		return mesgToSign;
	}
	public void setmesgToSign(String val) {
		mesgToSign = val;
	}
	public String getexpiryTimeIn() {
		return expiryTimeIn;
	}
	public void setexpiryTimeIn(String val) {
		expiryTimeIn = val;
	}
	public String gets_Key() {
		return s_Key;
	}
	public void sets_Key(String val) {
		s_Key = val;
	}
	public String getsignature() {
		return signature;
	}
	public void setsignature(String val) {
		signature = val;
	}
	public String getexpiryTimeOut() {
		return expiryTimeOut;
	}
	public void setexpiryTimeOut(String val) {
		expiryTimeOut = val;
	}
/****** END SET/GET METHOD, DO NOT MODIFY *****/
	public SQSSignMessage() {
	}
	public void invoke() throws Exception {
/* Available Variables: DO NOT MODIFY
	In  : String mesgToSign
	In  : String expiryTimeIn
	In  : String s_Key
	Out : String signature
	Out : String expiryTimeOut
* Available Variables: DO NOT MODIFY *****/

String SKey = s_Key;

String HMAC_SHA256 = "HmacSHA256";
String HMAC_SHA1 = "HmacSHA1";
            
            // get an hmac_sha1 key from the raw key bytes
           SecretKeySpec signingKey = new SecretKeySpec(SKey.getBytes(), HMAC_SHA256);

            // get an hmac_sha1 Mac instance and initialize with the signing key
            Mac mac = Mac.getInstance(HMAC_SHA256);
            mac.init(signingKey);

            // compute the hmac on input data bytes
            byte[] rawHmac = mac.doFinal(mesgToSign.getBytes("UTF-8"));

            // base64-encode the hmac
            //signature = Base64.encodeBase64String(rawHmac);

expiryTimeOut = expiryTimeIn;}
}

