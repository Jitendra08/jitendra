package com.att.tpp.service;

import java.io.ByteArrayOutputStream;

import javax.xml.soap.MessageFactory;
import javax.xml.soap.SOAPBody;
import javax.xml.soap.SOAPElement;
import javax.xml.soap.SOAPEnvelope;
import javax.xml.soap.SOAPMessage;
import javax.xml.soap.SOAPPart;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import com.att.tpp.xml.vui.model.ALIUpdateRequest;
import com.att.tpp.xml.vui.model.HDR;
import com.att.tpp.xml.vui.model.VUI;

public class VUISoapRequest {
	
	
	private static Logger vuiRequestLog = LogManager.getLogger(VUISoapRequest.class);
	
	private final static String vuiNameSpace = "vui";
	
	public String createVUISoapMessage(VUI vuiRequestData, String vuiAccount) throws Exception {
		

		String createVUIMessage=null;
		
        try {
			MessageFactory messageFactory = MessageFactory.newInstance();
			SOAPMessage soapMessage = messageFactory.createMessage();
			SOAPPart soapPart = soapMessage.getSOAPPart();

			String serverURI = "http://www.intrado.com/namespaces/vui";
			
			// SOAP Envelope
			SOAPEnvelope envelope1 = soapPart.getEnvelope();
			envelope1.addNamespaceDeclaration(vuiNameSpace, serverURI);
			
			// SOAP Body
			SOAPBody soapBody = envelope1.getBody();
			SOAPElement vuiAliUpdateRequestElement = soapBody.addChildElement("vuiAliUpdateRequest", vuiNameSpace);
			SOAPElement externalKeyElement = vuiAliUpdateRequestElement.addChildElement("externalKey",vuiNameSpace);
			SOAPElement externalKeyType = vuiAliUpdateRequestElement.addChildElement("externalKeyType",vuiNameSpace);
			SOAPElement hnoElement = vuiAliUpdateRequestElement.addChildElement("hno",vuiNameSpace);
			SOAPElement hnsElement = vuiAliUpdateRequestElement.addChildElement("hns",vuiNameSpace);
			SOAPElement prdElement = vuiAliUpdateRequestElement.addChildElement("prd",vuiNameSpace);
			SOAPElement stnElement = vuiAliUpdateRequestElement.addChildElement("stn",vuiNameSpace);
			SOAPElement mcnElement = vuiAliUpdateRequestElement.addChildElement("mcn",vuiNameSpace);
			SOAPElement staElement = vuiAliUpdateRequestElement.addChildElement("sta",vuiNameSpace);
			SOAPElement locElement = vuiAliUpdateRequestElement.addChildElement("loc",vuiNameSpace);
			SOAPElement stsElement = vuiAliUpdateRequestElement.addChildElement("sts",vuiNameSpace);
			SOAPElement podElement = vuiAliUpdateRequestElement.addChildElement("pod",vuiNameSpace);
			SOAPElement namElement = vuiAliUpdateRequestElement.addChildElement("nam",vuiNameSpace);
			SOAPElement clsElement = vuiAliUpdateRequestElement.addChildElement("cls",vuiNameSpace);
			SOAPElement clsTypeElement = clsElement.addChildElement("typ",vuiNameSpace);
			SOAPElement tysElement = vuiAliUpdateRequestElement.addChildElement("tys",vuiNameSpace);
			SOAPElement tysTypeElement= tysElement.addChildElement("typ",vuiNameSpace);
			SOAPElement cpfElement = vuiAliUpdateRequestElement.addChildElement("cpf",vuiNameSpace);
			SOAPElement zipElement = vuiAliUpdateRequestElement.addChildElement("zip",vuiNameSpace);
			
			ALIUpdateRequest aliUpdateRequest = vuiRequestData.getPayload().getAliUpdateRequest();
			

			if((aliUpdateRequest.getLat()!=null && aliUpdateRequest.getLat().length()>0) && (aliUpdateRequest.getLon()!=null && aliUpdateRequest.getLon().length()>0)){
				SOAPElement latElement = vuiAliUpdateRequestElement.addChildElement("lat",vuiNameSpace);
				SOAPElement lonElement = vuiAliUpdateRequestElement.addChildElement("lon",vuiNameSpace);
				latElement.addTextNode(aliUpdateRequest.getLat());
				lonElement.addTextNode(aliUpdateRequest.getLon());
			}
			
			//vuiAliUpdateRequest element data
			//Mandatory field --Start
			HDR hdr = vuiRequestData.getHdr();
			vuiAliUpdateRequestElement.setAttribute("Acct", vuiAccount);
			vuiAliUpdateRequestElement.setAttribute("ClientVersion", hdr.getClientVersion());
			vuiAliUpdateRequestElement.setAttribute("rec", hdr.getRec());
			vuiAliUpdateRequestElement.setAttribute("ver", aliUpdateRequest.getVer());
			vuiAliUpdateRequestElement.setAttribute("FOC", aliUpdateRequest.getFoc());
			
			externalKeyElement.addTextNode(aliUpdateRequest.getExternalKey());
			externalKeyType.addTextNode(aliUpdateRequest.getExternalKeyType());
			hnoElement.addTextNode(aliUpdateRequest.getHno());
			hnsElement.addTextNode(aliUpdateRequest.getHns());
			prdElement.addTextNode(aliUpdateRequest.getPrd());
			stnElement.addTextNode(aliUpdateRequest.getStn());
			mcnElement.addTextNode(aliUpdateRequest.getMcn());
			staElement.addTextNode(aliUpdateRequest.getSta());
			locElement.addTextNode(aliUpdateRequest.getLoc());
			stsElement.addTextNode(aliUpdateRequest.getSts());
			podElement.addTextNode(aliUpdateRequest.getPod());
			namElement.addTextNode(aliUpdateRequest.getNam());			
			clsTypeElement.addTextNode(aliUpdateRequest.getCls().getTyp());
			tysTypeElement.addTextNode(aliUpdateRequest.getTys().getTYP());			
			cpfElement.addTextNode(aliUpdateRequest.getCpf());

			zipElement.addTextNode(aliUpdateRequest.getZip());
			//Mandatory field --End
			
			//fordebuggingData(aliUpdateRequest, hdr);
			
			soapMessage.saveChanges();

			/* Convert soap message to string  */
			ByteArrayOutputStream out = new ByteArrayOutputStream();
			soapMessage.writeTo(out);
			createVUIMessage = new String(out.toByteArray());
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			vuiRequestLog.info("Exception occured in creating vuiRequest"+e);
		}

        return createVUIMessage;
    }



	@SuppressWarnings("unused")
	private void fordebuggingData(ALIUpdateRequest aliUpdateRequest, HDR hdr) {
		vuiRequestLog.info("Acct: "+hdr.getAcct());
		vuiRequestLog.info("ClientVersion: "+hdr.getClientVersion());
		vuiRequestLog.info("rec: "+hdr.getRec());
		vuiRequestLog.info("ver: " + aliUpdateRequest.getVer());
		vuiRequestLog.info("FOC: " +aliUpdateRequest.getFoc());			
		vuiRequestLog.info("ExternalKey: " +aliUpdateRequest.getExternalKey());
		vuiRequestLog.info("ExternalKeyType: " +aliUpdateRequest.getExternalKeyType());
		vuiRequestLog.info("Hno: " +aliUpdateRequest.getHno());
		vuiRequestLog.info("Hns: " +aliUpdateRequest.getHns());
		vuiRequestLog.info("Prd: " +aliUpdateRequest.getPrd());
		vuiRequestLog.info("Stn: " +aliUpdateRequest.getStn());
		vuiRequestLog.info("Mcn: " +aliUpdateRequest.getMcn());
		vuiRequestLog.info("Sta: " +aliUpdateRequest.getSta());
		vuiRequestLog.info("Loc: " +aliUpdateRequest.getLoc());
		vuiRequestLog.info("Sts: " +aliUpdateRequest.getSts());
		vuiRequestLog.info("Pod: " +aliUpdateRequest.getPod());
		vuiRequestLog.info("Nam: " +aliUpdateRequest.getNam());			
		vuiRequestLog.info("CLS type: " +aliUpdateRequest.getCls().getTyp());
		vuiRequestLog.info("Tys type: " +aliUpdateRequest.getTys().getTYP());		
		vuiRequestLog.info("CPF: " +aliUpdateRequest.getCpf());
		vuiRequestLog.info("Lat: " +aliUpdateRequest.getLat());
		vuiRequestLog.info("Lon: " +aliUpdateRequest.getLon());
		vuiRequestLog.info("Zip: " +aliUpdateRequest.getZip());
	}
	
	
	
	public static void main( String args[]) throws Exception{
		VUISoapRequest createSoapRequest1 = new VUISoapRequest();
		String vuiRequuest = createSoapRequest1.createVUISoapMessage(null, "vuiAccount");
		System.out.println("vuiRequuest-->"+vuiRequuest);
       
	}
	

}
