package com.att.tpp.service.sqs;

import java.text.SimpleDateFormat;
import java.util.GregorianCalendar;
import java.util.TimeZone;

public class SQSiso8601DateTime{
/****** START SET/GET METHOD, DO NOT MODIFY *****/
	protected String theExpiry = "";
	public String gettheExpiry() {
		return theExpiry;
	}
	public void settheExpiry(String val) {
		theExpiry = val;
	}
/****** END SET/GET METHOD, DO NOT MODIFY *****/
	public SQSiso8601DateTime() {
	}
	public void invoke() throws Exception {
/* Available Variables: DO NOT MODIFY
	Out : String theExpiry
* Available Variables: DO NOT MODIFY *****/

        int DAY_IN_MILLISECOND = 1000 * 60 * 60 * 24;
        int SEVEN_DAYS = DAY_IN_MILLISECOND * 7;
        //String theExpiry = null;
        
        TimeZone utc = TimeZone.getTimeZone("UTC");  //Get the UTC Time Zone ID.
        
        SimpleDateFormat iso8601 = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss'Z'");  //Set the format to ISO8601 TimeStamp Format.
        
        iso8601.setTimeZone(utc);  //Set the Time Zone to UTC.
        GregorianCalendar gCal = new GregorianCalendar(utc);  //Set the calendar to UTC.
        gCal.setTimeInMillis(gCal.getTimeInMillis() + SEVEN_DAYS);  //Set the date 7 days ahead from now.
        theExpiry = iso8601.format(gCal.getTime());  //Set get the time and set the expiry date string.
}
}

