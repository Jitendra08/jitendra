package com.att.tpp.service.sqs;

import java.net.URL;
import java.net.URLEncoder;

public class SQSCreateMessageToSign{
/****** START SET/GET METHOD, DO NOT MODIFY *****/
	protected String url = "";
	protected String expiryTimeIn = "";
	protected String mesg = "";
	protected String request_method = "";
	protected String a_Key = "";
	protected String mesgToSign = "";
	protected String expiryTimeOut = "";
	public String geturl() {
		return url;
	}
	public void seturl(String val) {
		url = val;
	}
	public String getexpiryTimeIn() {
		return expiryTimeIn;
	}
	public void setexpiryTimeIn(String val) {
		expiryTimeIn = val;
	}
	public String getmesg() {
		return mesg;
	}
	public void setmesg(String val) {
		mesg = val;
	}
	public String getrequest_method() {
		return request_method;
	}
	public void setrequest_method(String val) {
		request_method = val;
	}
	public String geta_Key() {
		return a_Key;
	}
	public void seta_Key(String val) {
		a_Key = val;
	}
	public String getmesgToSign() {
		return mesgToSign;
	}
	public void setmesgToSign(String val) {
		mesgToSign = val;
	}
	public String getexpiryTimeOut() {
		return expiryTimeOut;
	}
	public void setexpiryTimeOut(String val) {
		expiryTimeOut = val;
	}
/****** END SET/GET METHOD, DO NOT MODIFY *****/
	public SQSCreateMessageToSign() {
	}
	public void invoke() throws Exception {
/* Available Variables: DO NOT MODIFY
	In  : String url
	In  : String expiryTimeIn
	In  : String mesg
	In  : String request_method
	In  : String a_Key
	Out : String mesgToSign
	Out : String expiryTimeOut
* Available Variables: DO NOT MODIFY *****/
String ENCODE_VERSION = "UTF-8";
String REQUEST_METHOD = request_method;
String expiryTime = expiryTimeIn;
String AKey = a_Key;

URL postURL = new URL(url);

mesgToSign = REQUEST_METHOD + "\n" +
                      postURL.getHost() + "\n" +
                      postURL.getPath() + "\n" +
                      "AWSAccessKeyId=" + URLEncoder.encode(AKey, ENCODE_VERSION) +
                      "&Action=" + URLEncoder.encode("SendMessage", ENCODE_VERSION) +
                 "&Expires=" + URLEncoder.encode(expiryTime, ENCODE_VERSION) +
                 "&MessageBody=" + URLEncoder.encode(mesg.trim(), ENCODE_VERSION).replace("+", "%20") +
                 //"&MessageBody=" + URLEncoder.encode(EncodeHelper.encodeToBase64(mesg.getBytes()), ENCODE_VERSION) +
                 "&SignatureMethod=" + URLEncoder.encode("HmacSHA256", ENCODE_VERSION) +
                 "&SignatureVersion=" + URLEncoder.encode("2", ENCODE_VERSION) +
                 "&Version=" + URLEncoder.encode("2011-10-01", ENCODE_VERSION);

expiryTimeOut = expiryTime;}
}

