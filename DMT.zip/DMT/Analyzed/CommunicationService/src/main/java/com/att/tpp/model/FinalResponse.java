package com.att.tpp.model;

import java.io.Serializable;


public class FinalResponse implements Serializable {
	private static final long serialVersionUID = 1L;


	private String provCarrier;
	private String provSystemTransID;
	private String routingCarrier;
	private String currentTechRetryCount;

	private String masterTransID;
	private String system;
	private String url;
	private String maxTechRetryCount;
	
	
	
	
	/**
	 * @param provCarrier
	 * @param provSystemTransID
	 * @param routingCarrier
	 * @param currentTechRetryCount
	 * @param masterTransID
	 * @param system
	 * @param url
	 * @param maxTechRetryCount
	 */
	public FinalResponse(String provCarrier, String provSystemTransID,
			String routingCarrier, String currentTechRetryCount,
			String masterTransID, String system, String url,
			String maxTechRetryCount) {
		super();
		this.provCarrier = provCarrier;
		this.provSystemTransID = provSystemTransID;
		this.routingCarrier = routingCarrier;
		this.currentTechRetryCount = currentTechRetryCount;
		this.masterTransID = masterTransID;
		this.system = system;
		this.url = url;
		this.maxTechRetryCount = maxTechRetryCount;
	}
	
	public FinalResponse() {
		// TODO Auto-generated constructor stub
	}

	/**
	 * @return the provCarrier
	 */
	public String getProvCarrier() {
		return provCarrier;
	}
	/**
	 * @param provCarrier the provCarrier to set
	 */
	public void setProvCarrier(String provCarrier) {
		this.provCarrier = provCarrier;
	}
	/**
	 * @return the provSystemTransID
	 */
	public String getProvSystemTransID() {
		return provSystemTransID;
	}
	/**
	 * @param provSystemTransID the provSystemTransID to set
	 */
	public void setProvSystemTransID(String provSystemTransID) {
		this.provSystemTransID = provSystemTransID;
	}
	/**
	 * @return the routingCarrier
	 */
	public String getRoutingCarrier() {
		return routingCarrier;
	}
	/**
	 * @param routingCarrier the routingCarrier to set
	 */
	public void setRoutingCarrier(String routingCarrier) {
		this.routingCarrier = routingCarrier;
	}
	/**
	 * @return the currentTechRetryCount
	 */
	public String getCurrentTechRetryCount() {
		return currentTechRetryCount;
	}
	/**
	 * @param currentTechRetryCount the currentTechRetryCount to set
	 */
	public void setCurrentTechRetryCount(String currentTechRetryCount) {
		this.currentTechRetryCount = currentTechRetryCount;
	}
	/**
	 * @return the masterTransID
	 */
	public String getMasterTransID() {
		return masterTransID;
	}
	/**
	 * @param masterTransID the masterTransID to set
	 */
	public void setMasterTransID(String masterTransID) {
		this.masterTransID = masterTransID;
	}
	/**
	 * @return the system
	 */
	public String getSystem() {
		return system;
	}
	/**
	 * @param system the system to set
	 */
	public void setSystem(String system) {
		this.system = system;
	}
	/**
	 * @return the url
	 */
	public String getUrl() {
		return url;
	}
	/**
	 * @param url the url to set
	 */
	public void setUrl(String url) {
		this.url = url;
	}
	/**
	 * @return the maxTechRetryCount
	 */
	public String getMaxTechRetryCount() {
		return maxTechRetryCount;
	}
	/**
	 * @param maxTechRetryCount the maxTechRetryCount to set
	 */
	public void setMaxTechRetryCount(String maxTechRetryCount) {
		this.maxTechRetryCount = maxTechRetryCount;
	}
	
	
	

}