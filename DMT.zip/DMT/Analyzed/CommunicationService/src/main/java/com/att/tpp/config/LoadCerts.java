package com.att.tpp.config;

import java.beans.ConstructorProperties;
import java.io.BufferedReader;
import java.io.File;
import java.io.IOException;
import java.io.InputStreamReader;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;


public class LoadCerts {
	
	private static Logger loadCertsLog = LogManager.getLogger(LoadCerts.class);
	
	private static String certPath;
	private static String trustoreFileName;
	private static String storePass;
	
	
	
	@ConstructorProperties({"certPath", "trustoreFileName", "trustoreStorePass"})
	public LoadCerts(String certPath, String trustoreFileName, String trustoreStorePass){
		LoadCerts.certPath = certPath;
		LoadCerts.trustoreFileName = trustoreFileName;
		LoadCerts.storePass = trustoreStorePass;
	}	
	
	
	public void loadKeyStore() {
		loadCertsLog.info("Loading the keyStore from certPath :" + certPath);
		String certFileName;
		File folder = new File(certPath);
		File[] listOfFiles = folder.listFiles();
		
		//Delete the trustoreFileName
		File trustoreFile = new File(trustoreFileName);
		if(trustoreFile.delete()){
			loadCertsLog.info("Removing existing trustoreFile : Success");
		}else{
			loadCertsLog.info("Removing existing trustoreFile : Failed");	
		}		

		for (File file : listOfFiles) {
			if (file.isFile()) {
				certFileName = file.getName();
				String certAbsolutepath = file.getAbsolutePath();
				loadCertsLog.debug("certAbsolutepath :" + certAbsolutepath);
				String aliasName = certFileName;

				if (certFileName.contains(".")) {
					aliasName = certFileName.substring(0,
							certFileName.lastIndexOf("."));
				}

				String keytoolString = "keytool -import -file "
						+ certAbsolutepath + " -alias " + aliasName
						+ " -keystore " + trustoreFileName + " -storepass "
						+ storePass + " -noprompt";
				runKeytoolCmdMethod(keytoolString);
			}
		}
	}
	
	
	private static void runKeytoolCmdMethod(String keytoolcmd) {
		try {  
		        Process p = Runtime.getRuntime().exec(keytoolcmd);  
		        BufferedReader in = new BufferedReader(  
		                            new InputStreamReader(p.getInputStream()));  
		        String line = null;  
		        while ((line = in.readLine()) != null) {  
		            loadCertsLog.info(line);
		        }  
		    } catch (IOException e) {  
		        e.printStackTrace();  
		    }
	}

}