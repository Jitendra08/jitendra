package com.att.tpp.xml.model;


public class ProductMax {
    
    private String majorCode;
    private String majorDesc;
    private String minorCode;
    private String minorDesc;
	
    
    public ProductMax() {	
    	super();	
	}
    
    /**
	 * @param majorCode
	 * @param majorDesc
	 * @param minorCode
	 * @param minorDesc
	 */
	public ProductMax(String majorCode, String majorDesc, String minorCode,
			String minorDesc) {
		super();
		this.majorCode = majorCode;
		this.majorDesc = majorDesc;
		this.minorCode = minorCode;
		this.minorDesc = minorDesc;
	}
	
	/**
	 * @return the majorCode
	 */
	public String getMajorCode() {
		return majorCode;
	}
	/**
	 * @param majorCode the majorCode to set
	 */
	public void setMajorCode(String majorCode) {
		this.majorCode = majorCode;
	}
	/**
	 * @return the majorDesc
	 */
	public String getMajorDesc() {
		return majorDesc;
	}
	/**
	 * @param majorDesc the majorDesc to set
	 */
	public void setMajorDesc(String majorDesc) {
		this.majorDesc = majorDesc;
	}
	/**
	 * @return the minorCode
	 */
	public String getMinorCode() {
		return minorCode;
	}
	/**
	 * @param minorCode the minorCode to set
	 */
	public void setMinorCode(String minorCode) {
		this.minorCode = minorCode;
	}
	/**
	 * @return the minorDesc
	 */
	public String getMinorDesc() {
		return minorDesc;
	}
	/**
	 * @param minorDesc the minorDesc to set
	 */
	public void setMinorDesc(String minorDesc) {
		this.minorDesc = minorDesc;
	}
    
    

 
    
}
