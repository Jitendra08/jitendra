package com.att.tpp.xml.model;

import java.util.Collection;


public class System {
    
    private String name;
    private Long majorCode;
    private String description;
    private String timeStamp;
    private Collection<DataItem> dataItem;
    private Products products;
    
	/**
	 * @param name
	 */
	public System(String name) {
		this.name = name;
	}
	
	/**
	 * @param name
	 * @param majorCode
	 * @param description
	 * @param timeStamp
	 */
	public System(String name, Long majorCode, String description,
			String timeStamp) {
		this.name = name;
		this.majorCode = majorCode;
		this.description = description;
		this.timeStamp = timeStamp;
	}
	
	/**
	 * @param name
	 * @param majorCode
	 * @param description
	 * @param timeStamp
	 * @param dataItem
	 */
	public System(String name, Long majorCode, String description,
			String timeStamp, Collection<DataItem> dataItem) {
		this.name = name;
		this.majorCode = majorCode;
		this.description = description;
		this.timeStamp = timeStamp;
		this.dataItem = dataItem;
	}

	/**
	 * @param name
	 * @param majorCode
	 * @param description
	 * @param timeStamp
	 * @param dataItem
	 * @param products
	 */
	public System(String name, Long majorCode, String description,
			String timeStamp, Collection<DataItem> dataItem, Products products) {
		this.name = name;
		this.majorCode = majorCode;
		this.description = description;
		this.timeStamp = timeStamp;
		this.dataItem = dataItem;
		this.products = products;
	}

	/**
	 * @return the name
	 */
	public String getName() {
		return name;
	}
	/**
	 * @param name the name to set
	 */
	public void setName(String name) {
		this.name = name;
	}
	/**
	 * @return the majorCode
	 */
	public Long getMajorCode() {
		return majorCode;
	}
	/**
	 * @param majorCode the majorCode to set
	 */
	public void setMajorCode(Long majorCode) {
		this.majorCode = majorCode;
	}
	/**
	 * @return the description
	 */
	public String getDescription() {
		return description;
	}
	/**
	 * @param description the description to set
	 */
	public void setDescription(String description) {
		this.description = description;
	}
	/**
	 * @return the timeStamp
	 */
	public String getTimeStamp() {
		return timeStamp;
	}
	/**
	 * @param timeStamp the timeStamp to set
	 */
	public void setTimeStamp(String timeStamp) {
		this.timeStamp = timeStamp;
	}
	/**
	 * @return the dataItem
	 */
	public Collection<DataItem> getDataItem() {
		return dataItem;
	}
	/**
	 * @param dataItem the dataItem to set
	 */
	public void setDataItem(Collection<DataItem> dataItem) {
		this.dataItem = dataItem;
	}
	/**
	 * @return the products
	 */
	public Products getProducts() {
		return products;
	}
	/**
	 * @param products the products to set
	 */
	public void setProducts(Products products) {
		this.products = products;
	}
  
}
