package com.att.tpp.model;

import java.io.Serializable;
import java.util.Collection;



public class TransactionRequestData implements Serializable {

	private static final long serialVersionUID = 1L;
	
	private String taskTransId;
	private String masterTransId;
	private String systemName;
	private String eventType;
	private String payload;
	private String url;
	private String proxyEnabled;
	private String routingCarrier;
	private String currentTechRetryCount;
	private String maxTechRetryCount;
	Collection<Products> productsCollection;
	private String msisdn;
	private String imei;
	private String imsi;
	private String iccid;
	private String subscriberNumber;	
	private String currentNoResponseRetryCount;
	private String maxNoResponseRetryCount; 

	
	public TransactionRequestData() {
	}


	public String getSystemName() {
		return systemName;
	}

	public void setSystemName(String systemName) {
		this.systemName = systemName;
	}

	public String getEventType() {
		return eventType;
	}

	public void setEventType(String eventType) {
		this.eventType = eventType;
	}

	public String getPayload() {
		return payload;
	}

	public void setPayload(String payload) {
		this.payload = payload;
	}


	public String getTaskTransId() {
		return taskTransId;
	}


	public void setTaskTransId(String taskTransId) {
		this.taskTransId = taskTransId;
	}


	public String getUrl() {
		return url;
	}


	public void setUrl(String url) {
		this.url = url;
	}


	public String getRoutingCarrier() {
		return routingCarrier;
	}


	public void setRoutingCarrier(String routingCarrier) {
		this.routingCarrier = routingCarrier;
	}


	public Collection<Products> getProductsCollection() {
		return productsCollection;
	}


	public void setProductsCollection(Collection<Products> productsCollection) {
		this.productsCollection = productsCollection;
	}


	public String getCurrentTechRetryCount() {
		return currentTechRetryCount;
	}


	public void setCurrentTechRetryCount(String currentTechRetryCount) {
		this.currentTechRetryCount = currentTechRetryCount;
	}


	public String getMaxTechRetryCount() {
		return maxTechRetryCount;
	}


	public void setMaxTechRetryCount(String maxTechRetryCount) {
		this.maxTechRetryCount = maxTechRetryCount;
	}


	public String getMasterTransId() {
		return masterTransId;
	}


	public void setMasterTransId(String masterTransId) {
		this.masterTransId = masterTransId;
	}


	public String getMsisdn() {
		return msisdn;
	}


	public void setMsisdn(String msisdn) {
		this.msisdn = msisdn;
	}


	/**
	 * @return the proxyEnabled
	 */
	public String getProxyEnabled() {
		return proxyEnabled;
	}


	/**
	 * @param proxyEnabled the proxyEnabled to set
	 */
	public void setProxyEnabled(String proxyEnabled) {
		this.proxyEnabled = proxyEnabled;
	}


	public String getImei() {
		return imei;
	}


	public void setImei(String imei) {
		this.imei = imei;
	}


	public String getImsi() {
		return imsi;
	}


	public void setImsi(String imsi) {
		this.imsi = imsi;
	}


	public String getIccid() {
		return iccid;
	}


	public void setIccid(String iccid) {
		this.iccid = iccid;
	}


	public String getSubscriberNumber() {
		return subscriberNumber;
	}


	public void setSubscriberNumber(String subscriberNumber) {
		this.subscriberNumber = subscriberNumber;
	}


	/**
	 * @return the maxNoResponseRetryCount
	 */
	public String getMaxNoResponseRetryCount() {
		return maxNoResponseRetryCount;
	}


	/**
	 * @param maxNoResponseRetryCount the maxNoResponseRetryCount to set
	 */
	public void setMaxNoResponseRetryCount(String maxNoResponseRetryCount) {
		this.maxNoResponseRetryCount = maxNoResponseRetryCount;
	}


	/**
	 * @return the currentNoResponseRetryCount
	 */
	public String getCurrentNoResponseRetryCount() {
		return currentNoResponseRetryCount;
	}


	/**
	 * @param currentNoResponseRetryCount the currentNoResponseRetryCount to set
	 */
	public void setCurrentNoResponseRetryCount(String currentNoResponseRetryCount) {
		this.currentNoResponseRetryCount = currentNoResponseRetryCount;
	}

	
}
