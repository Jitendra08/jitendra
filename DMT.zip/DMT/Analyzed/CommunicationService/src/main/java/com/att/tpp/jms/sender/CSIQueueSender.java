package com.att.tpp.jms.sender;

import javax.jms.JMSException;
import javax.jms.Message;
import javax.jms.Queue;
import javax.jms.Session;
import javax.jms.TextMessage;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.jms.core.JmsTemplate;
import org.springframework.jms.core.MessageCreator;

/**
 * 
 * The CSIQueueSender class uses the injected JMSTemplate to send a message
 * to dualFlowRequestQueue. 
 */
public class CSIQueueSender
{
	private JmsTemplate jmsTemplate;
	private Queue csiRequestQueue; 
	private static final Logger dualFlowRequestSenderLog = LogManager.getLogger(CSIQueueSender.class);
	private final static String eventName = "eventName";
	private final static String csiTransactionId = "csiTransactionId";
	private final static String ActionCode = "ActionCode";
	
	/**
	 * Sends message to CSIQueueSender using JMS Template.
	 * @param actionCode 
	 * @param csiTransactionId 
	 * @param provReqXML the message_p
	 * @throws JMSException the jms exception
	 */
	public void sendMessage(final String requestXML, final String inputEventName, final String csiTrxId, final String actionCode) throws JMSException
	{
		
		dualFlowRequestSenderLog.info("Sending ProvisioningResponse Message From Communication Service to CSI Service");

		jmsTemplate.send(this.csiRequestQueue, new MessageCreator(){

			@Override
			public Message createMessage(Session session) throws JMSException {
				TextMessage message = session.createTextMessage(requestXML.toString());
				message.setStringProperty(eventName,inputEventName.toString());
				message.setStringProperty(csiTransactionId,csiTrxId.toString());
				message.setStringProperty(ActionCode,actionCode.toString());
				return message;
			}
			
		});		
		
	}
	/**
	 * Sets the jms template.
	 *
	 * @param template the jms template
	 */
	public void setJmsTemplate(JmsTemplate tmpl)
	{
		this.jmsTemplate = tmpl;
	}
	
	
	public void setCsiRequestQueue(Queue csiRequestQueue) {
		this.csiRequestQueue = csiRequestQueue;
	}
	
	

	
}