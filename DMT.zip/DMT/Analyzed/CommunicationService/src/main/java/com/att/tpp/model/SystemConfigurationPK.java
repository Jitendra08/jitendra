package com.att.tpp.model;

import java.io.Serializable;
import javax.persistence.*;

/**
 * The primary key class for the SYSTEM_CONFIGURATION database table.
 * 
 */
@Embeddable
public class SystemConfigurationPK implements Serializable {
	//default serial version id, required for serializable classes.
	private static final long serialVersionUID = 1L;

	@Column(name="SYSTEM_NAME", insertable=false, updatable=false)
	private String systemName;

	@Column(name="EVENT_TYPE")
	private String eventType;

	public SystemConfigurationPK() {
	}
	public String getSystemName() {
		return this.systemName;
	}
	public void setSystemName(String systemName) {
		this.systemName = systemName;
	}
	public String getEventType() {
		return this.eventType;
	}
	public void setEventType(String eventType) {
		this.eventType = eventType;
	}

	public boolean equals(Object other) {
		if (this == other) {
			return true;
		}
		if (!(other instanceof SystemConfigurationPK)) {
			return false;
		}
		SystemConfigurationPK castOther = (SystemConfigurationPK)other;
		return 
			this.systemName.equals(castOther.systemName)
			&& this.eventType.equals(castOther.eventType);
	}

	public int hashCode() {
		final int prime = 31;
		int hash = 17;
		hash = hash * prime + this.systemName.hashCode();
		hash = hash * prime + this.eventType.hashCode();
		
		return hash;
	}
}