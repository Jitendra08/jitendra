package com.att.tpp.jms.sender;

import javax.jms.JMSException;
import javax.jms.Message;
import javax.jms.Queue;
import javax.jms.Session;
import javax.jms.TextMessage;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.jms.core.JmsTemplate;
import org.springframework.jms.core.MessageCreator;

/**
 * 
 * The FinalTransRequestQueueSender class uses the injected JMSTemplate to send a message
 * to finalTransRequestQueue. 
 */
public class WorkflowOutBoundQueueSender
{
	private JmsTemplate jmsTemplate;
	private Queue workflowOutBoundQueue;
	
	private static final Logger WorkflowOutBoundQueueSenderLog = LogManager.getLogger(WorkflowOutBoundQueueSender.class);
	private final static String swcTransactionId = "swcTransactionId";
	
	/**
	 * Sends message to workflowRequestQueue using JMS Template.
	 * @param swcTransId 
	 * @param workflowRequestXML the message_p
	 * @throws JMSException the jms exception
	 */
	public void sendMessage(final String tppWorkflowRequestXML, final String swcTransId) throws JMSException
	{
		
		WorkflowOutBoundQueueSenderLog.info("Sending TPP_WorkflowRequest Message From Communication Service to Workflow Service");

		jmsTemplate.send(this.workflowOutBoundQueue, new MessageCreator(){

			@Override
			public Message createMessage(Session session) throws JMSException {
				TextMessage message = session.createTextMessage(tppWorkflowRequestXML.toString());
				message.setStringProperty(swcTransactionId,swcTransId);	
				WorkflowOutBoundQueueSenderLog.debug("Message sent: " + message);
				return message;
			}
			
		});		
		
	}
	/**
	 * Sets the jms template.
	 *
	 * @param template the jms template
	 */
	public void setJmsTemplate(JmsTemplate tmpl)
	{
		this.jmsTemplate = tmpl;
	}

	/**
	 * Sets the test queue.
	 *
	 * @param finalTransRequestQueue the new test queue
	 */
	public void setWorkflowOutBoundQueue(Queue workflowOutBoundQueue) {
		this.workflowOutBoundQueue = workflowOutBoundQueue;
	}
}