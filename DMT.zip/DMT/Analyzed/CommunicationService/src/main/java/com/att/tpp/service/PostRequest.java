package com.att.tpp.service;

import java.io.DataOutputStream;
import java.io.IOException;
import java.io.PrintStream;
import java.net.HttpURLConnection;
import java.net.InetSocketAddress;
import java.net.MalformedURLException;
import java.net.Proxy;
import java.net.SocketTimeoutException;
import java.net.URL;
import java.net.URLEncoder;
import java.net.UnknownHostException;
import java.util.HashMap;
import java.util.NoSuchElementException;
import java.util.Scanner;

import javax.net.ssl.HttpsURLConnection;
import javax.net.ssl.SSLContext;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import com.att.tpp.config.InitializeSSLConnection;


public class PostRequest {
	 private static Logger postRequestLog = LogManager.getLogger(PostRequest.class);
	 
		private final static String ResponseCode = "responseCode";
		private final static String ResponseMessage = "responseMessage";
	 
	 
	public PostRequest() {
		}

	public HashMap<String, String> postHTTPRequest(String notificationURL, String provisioningRequestXML, String proxyEnabled){		
		int httpResponseCode=000;
		String httpResponseMessage="";
	    HashMap<String, String> httpResultMap = new HashMap<String, String>();
		HttpURLConnection httpConnection=null;
		try {			
			
			URL url= new URL(notificationURL); // Get the URL to which the post has to be made.
			postRequestLog.info("Trying to post XML to"+ notificationURL);
			
			//Inserting logic to turn on or off the proxy setting
			if(InitializeSSLConnection.getUseProxy().equalsIgnoreCase("Y") || InitializeSSLConnection.getUseProxy().equalsIgnoreCase("TRUE")){
				if(proxyEnabled.equalsIgnoreCase("Y")){
					Proxy proxy = new Proxy(Proxy.Type.HTTP, new InetSocketAddress(InitializeSSLConnection.getProxyHost(), Integer.valueOf(InitializeSSLConnection.getProxyPort()).intValue()));
					httpConnection = (HttpURLConnection)url.openConnection(proxy);// Open connection to the given URL.
				}
				else{
					httpConnection = (HttpURLConnection)url.openConnection();// Open connection to the given URL.
				}
			}
			else{
				httpConnection = (HttpURLConnection)url.openConnection();// Open connection to the given URL.
			}
			
			
			httpConnection.setDoInput(true);
			httpConnection.setDoOutput(true);
			httpConnection.setRequestMethod("POST");
			//httpConnection.setReadTimeout(2000000000);
			httpConnection.setReadTimeout(90000);
			httpConnection.setUseCaches(false);
			httpConnection.setDefaultUseCaches(false);
			httpConnection.setRequestProperty("accept-charset", "UTF-8");
			httpConnection.setRequestProperty("Content-Type", "text/xml");
			httpConnection.setConnectTimeout(120000);			
			//Todo: Check the connection timeout value and confirm
			//connection.setConnectTimeout(90000);
			//Writes the XML to given URL using DataOutputStream.
			DataOutputStream outputWriter = new DataOutputStream(httpConnection.getOutputStream());
			if(outputWriter!=null){
				outputWriter.writeBytes(provisioningRequestXML);
				outputWriter.flush();
				outputWriter.close();
			}
			httpResponseCode=httpConnection.getResponseCode();
			httpResponseMessage = httpConnection.getResponseMessage();
					

		}catch (MalformedURLException e){
			postRequestLog.info("HTTP Post failed  to: "+ notificationURL);
			httpResponseMessage = e.getMessage();
			postRequestLog.error(e.getMessage());
		}catch(Exception e){
			postRequestLog.info("HTTP Post failed  to: "+ notificationURL);
			httpResponseMessage = e.getMessage();
			postRequestLog.error(e.getMessage());					
		}finally{
			httpConnection.disconnect();
			postRequestLog.info(" Post XML to "+ notificationURL+ "HTTP Post Response Code: "+httpResponseCode + " HTTP Post Response Message:"+httpResponseMessage);
		}
		
		httpResultMap.put(ResponseCode, Integer.toString(httpResponseCode));
		httpResultMap.put(ResponseMessage, httpResponseMessage);		
		return httpResultMap;
	}
	
	
	
	public HashMap<String, String> postHTTPSRequest(String notificationURL,	String provisioningRequestXML, String proxyEnabled) throws IOException {
		int httpsResponseCode = 000;
		String httpsResponseMessage = "";
	    HashMap<String, String> httpsResultMap = new HashMap<String, String>();
	    HttpsURLConnection httpsConnection = null;
	    
	    postRequestLog.info("Inside postHTTPSRequest method");
		try {
			System.setProperty("java.protocol.handler.pkgs", "com.sun.net.ssl.internal.www.protocol");

			URL url = new URL(null, notificationURL, new sun.net.www.protocol.https.Handler());

			// Setting the SSL connection			
			SSLContext sslContext = InitializeSSLConnection.getSslContext();
			HttpsURLConnection.setDefaultSSLSocketFactory(sslContext.getSocketFactory());
			
			//Inserting logic to turn on or off the proxy setting
			if(InitializeSSLConnection.getUseProxy().equalsIgnoreCase("Y") || InitializeSSLConnection.getUseProxy().equalsIgnoreCase("TRUE")){
				if(proxyEnabled.equalsIgnoreCase("Y")){
					Proxy proxy = new Proxy(Proxy.Type.HTTP, new InetSocketAddress(InitializeSSLConnection.getProxyHost(), Integer.valueOf(InitializeSSLConnection.getProxyPort()).intValue()));
					httpsConnection = (HttpsURLConnection)url.openConnection(proxy);
				}
				else{
					httpsConnection = (HttpsURLConnection)url.openConnection();
				}
			}
			else{
				httpsConnection = (HttpsURLConnection)url.openConnection();
			}			
			
			//Commented this out because we are putting in the if/else clause.  This should be deleted post testing of proxy on and off use cases.
			//httpsConnection = (HttpsURLConnection) url.openConnection();
			
/*			if (!(InitializeSSLConnection.isHostnameVerifierFlag())) {
				httpsConnection.setHostnameVerifier(new HostnameVerifier() {
					@Override
					public boolean verify(String arg0, SSLSession arg1) {
						return true;
					}
				});
			}*/
			
			byte[] buffer = provisioningRequestXML.getBytes("UTF-8");
			
			httpsConnection.setRequestMethod("POST");
			httpsConnection.setDoOutput(true);
			httpsConnection.setReadTimeout(90000);
			httpsConnection.setRequestProperty("accept-charset", "UTF-8");
			httpsConnection.setRequestProperty("Content-Type", "text/xml");
		
			PrintStream printStream = new PrintStream(httpsConnection.getOutputStream());
			printStream.write(buffer, 0, buffer.length);
			printStream.close();
			
			httpsConnection.connect();			
			httpsResponseCode=httpsConnection.getResponseCode();
			httpsResponseMessage = httpsConnection.getResponseMessage();			
			printErrorStream(httpsConnection);

			httpsResultMap.put(ResponseCode, Integer.toString(httpsResponseCode));
			httpsResultMap.put(ResponseMessage, httpsResponseMessage);			
			httpsConnection.disconnect();
			
			postRequestLog.info("HTTPS POST is returning httpsResultMap!");
			return httpsResultMap;
			
		} catch (MalformedURLException mue){
			postRequestLog.info("MalformedURLException HTTP Post failed  to: "+ notificationURL);
			httpsResponseMessage = mue.getMessage();
			postRequestLog.error(mue.getMessage());
			printErrorStream(httpsConnection);	
			httpsResultMap.put(ResponseCode, Integer.toString(httpsResponseCode));
			httpsResultMap.put(ResponseMessage, httpsResponseMessage);
			httpsConnection.disconnect();
			return httpsResultMap;
		} catch (SocketTimeoutException ste){
			postRequestLog.info("SocketTimeoutException HTTP Post failed  to: "+ notificationURL);
			httpsResponseMessage = ste.getMessage();
			postRequestLog.error(ste.getMessage());
			printErrorStream(httpsConnection);
			httpsResultMap.put(ResponseCode, Integer.toString(httpsResponseCode));
			httpsResultMap.put(ResponseMessage, httpsResponseMessage);
			httpsConnection.disconnect();
			return httpsResultMap;
		} catch (UnknownHostException uhe){
			postRequestLog.info("UnknownHostException HTTP Post failed  to: "+ notificationURL);
			httpsResponseMessage = uhe.getMessage();
			postRequestLog.error(uhe.getMessage());
			printErrorStream(httpsConnection);
			httpsResultMap.put(ResponseCode, Integer.toString(httpsResponseCode));
			httpsResultMap.put(ResponseMessage, "UnknownHostException: " + httpsResponseMessage);
			httpsConnection.disconnect();
			return httpsResultMap;
		} catch(Exception e){
			httpsResponseMessage = e.getMessage();
			postRequestLog.error(e.getMessage());
			printErrorStream(httpsConnection);	
			httpsResultMap.put(ResponseCode, Integer.toString(httpsResponseCode));
			httpsResultMap.put(ResponseMessage, httpsResponseMessage);
			httpsConnection.disconnect();
			return httpsResultMap;
		}finally{			
			httpsConnection.disconnect();
			postRequestLog.info("Post XML to: " + notificationURL);
			postRequestLog.info("HTTP Post Response Code: " + httpsResponseCode);
			postRequestLog.info("HTTP Post Response Message: "+httpsResponseMessage);			
//			httpsResultMap.put(ResponseCode, Integer.toString(httpsResponseCode));
//			httpsResultMap.put(ResponseMessage, httpsResponseMessage);			
//			return httpsResultMap;
		}
		//httpsConnection.disconnect();
		//httpsResultMap.put(ResponseCode, Integer.toString(httpsResponseCode));
		//httpsResultMap.put(ResponseMessage, httpsResponseMessage);
		
		//return httpsResultMap;

	}
	
	
	public HashMap<String, String> postHTTPSRequest(String notificationURL,	String provisioningRequestXML, String systemName, String proxyEnabled) throws IOException {
		int httpsResponseCode = 000;
		String httpsResponseMessage = "";
	    HashMap<String, String> httpsResultMap = new HashMap<String, String>();
	    HttpsURLConnection httpsConnection = null;
	    
	    postRequestLog.info("Inside postHTTPSRequest method");
		try {
			System.setProperty("java.protocol.handler.pkgs", "com.sun.net.ssl.internal.www.protocol");

			URL url = new URL(null, notificationURL, new sun.net.www.protocol.https.Handler());

			// Setting the SSL connection			
			SSLContext sslContext = InitializeSSLConnection.getSslContext();
			HttpsURLConnection.setDefaultSSLSocketFactory(sslContext.getSocketFactory());
			
			//Inserting logic to turn on or off the proxy setting
			if(InitializeSSLConnection.getUseProxy().equalsIgnoreCase("Y") || InitializeSSLConnection.getUseProxy().equalsIgnoreCase("TRUE")){
				if(proxyEnabled.equalsIgnoreCase("Y")){
					Proxy proxy = new Proxy(Proxy.Type.HTTP, new InetSocketAddress(InitializeSSLConnection.getProxyHost(), Integer.valueOf(InitializeSSLConnection.getProxyPort()).intValue()));
					httpsConnection = (HttpsURLConnection)url.openConnection(proxy);
				}
				else{
					httpsConnection = (HttpsURLConnection)url.openConnection();
				}
			}
			else{
				httpsConnection = (HttpsURLConnection)url.openConnection();
			}
			
			
/*			if (!(InitializeSSLConnection.isHostnameVerifierFlag())) {
				httpsConnection.setHostnameVerifier(new HostnameVerifier() {
					@Override
					public boolean verify(String arg0, SSLSession arg1) {
						return true;
					}
				});
			}*/
			
			//Log the System Name Coming into the Post Request Class.
			postRequestLog.info("SystemName = " + systemName);
			
			//byte[] buffer = provisioningRequestXML.getBytes("UTF-8");
			
			//New logic to determine how to generate the byte[] for AlliedDS vs. other systems.
			//This is in support of 285427 - Roadside Assistance.
			
			byte[] buffer;
			
			//Creating a REST envelope needed by AlliedDS to consume the ProvisioningRequest message by its endpoint.
			//This is in support of 285427 - Roadside Assistance.
			if(systemName.equals("AlliedDS")){
				String restMsg = "<request><message>" + URLEncoder.encode(provisioningRequestXML, "UTF-8") + "</message></request>";
				postRequestLog.info("Created REST Envelope for PovisioningRequest: " + restMsg);
				
				buffer = restMsg.getBytes("UTF-8");
			}
			else{
				buffer = provisioningRequestXML.getBytes("UTF-8");				
			}			
			
			httpsConnection.setRequestMethod("POST");
			httpsConnection.setDoOutput(true);
			httpsConnection.setReadTimeout(90000);
			
			//Decrease the default connectionTimout to 1 second
			if(InitializeSSLConnection.getTurbo().equalsIgnoreCase("ON")){
				httpsConnection.setConnectTimeout(1000);
			}			 
			
			httpsConnection.setRequestProperty("accept-charset", "UTF-8");
			
			//New Logic to allow transactions to be accepted for Allied DS in support of 
			//285427 - Roadside Assistance since that system needs to leverage Content-Type=application/xml
			if(systemName.equals("AlliedDS")){
				httpsConnection.setRequestProperty("Content-Type", "application/xml");				
			}
			else{
				httpsConnection.setRequestProperty("Content-Type", "text/xml");
			}
			
			//New Logic to allow transactions to be accepted for Mobile Identity Toolkit / BlackFlag
			//Added Allied DS in support of 285427 - Roadside Assistance since that system also needs to leverage Accept=application/xml
			if(systemName.equals("BlackFlag") || systemName.equals("AlliedDS")){
				httpsConnection.setRequestProperty("Accept", "application/xml");
			}			
			//End New Logic
	
			PrintStream printStream = new PrintStream(httpsConnection.getOutputStream());			
			printStream.write(buffer, 0, buffer.length);			
			printStream.close();
			
			httpsConnection.connect();			
			httpsResponseCode=httpsConnection.getResponseCode();
			httpsResponseMessage = httpsConnection.getResponseMessage();			
			printErrorStream(httpsConnection);

			httpsResultMap.put(ResponseCode, Integer.toString(httpsResponseCode));
			httpsResultMap.put(ResponseMessage, httpsResponseMessage);			
			httpsConnection.disconnect();
			
			postRequestLog.info("HTTPS POST is returning httpsResultMap!");
			return httpsResultMap;
			
		} catch (MalformedURLException mue){
			postRequestLog.info("MalformedURLException HTTP Post failed  to: "+ notificationURL);
			httpsResponseMessage = mue.getMessage();
			postRequestLog.error(mue.getMessage());
			printErrorStream(httpsConnection);	
			httpsResultMap.put(ResponseCode, Integer.toString(httpsResponseCode));
			httpsResultMap.put(ResponseMessage, httpsResponseMessage);
			httpsConnection.disconnect();
			return httpsResultMap;
		} catch (SocketTimeoutException ste){
			postRequestLog.info("SocketTimeoutException HTTP Post failed  to: "+ notificationURL);
			httpsResponseMessage = ste.getMessage();
			postRequestLog.error(ste.getMessage());
			printErrorStream(httpsConnection);
			httpsResultMap.put(ResponseCode, Integer.toString(httpsResponseCode));
			httpsResultMap.put(ResponseMessage, httpsResponseMessage);
			httpsConnection.disconnect();
			return httpsResultMap;
		} catch (UnknownHostException uhe){
			postRequestLog.info("UnknownHostException HTTP Post failed  to: "+ notificationURL);
			httpsResponseMessage = uhe.getMessage();
			postRequestLog.error(uhe.getMessage());
			printErrorStream(httpsConnection);
			httpsResultMap.put(ResponseCode, Integer.toString(httpsResponseCode));
			httpsResultMap.put(ResponseMessage, "UnknownHostException: " + httpsResponseMessage);
			httpsConnection.disconnect();
			return httpsResultMap;
		} catch(Exception e){
			httpsResponseMessage = e.getMessage();
			postRequestLog.error(e.getMessage());
			printErrorStream(httpsConnection);	
			httpsResultMap.put(ResponseCode, Integer.toString(httpsResponseCode));
			httpsResultMap.put(ResponseMessage, httpsResponseMessage);
			httpsConnection.disconnect();
			return httpsResultMap;
		}finally{			
			httpsConnection.disconnect();
			postRequestLog.info("Post XML to: " + notificationURL);
			postRequestLog.info("HTTP Post Response Code: " + httpsResponseCode);
			postRequestLog.info("HTTP Post Response Message: "+httpsResponseMessage);			
//			httpsResultMap.put(ResponseCode, Integer.toString(httpsResponseCode));
//			httpsResultMap.put(ResponseMessage, httpsResponseMessage);			
//			return httpsResultMap;
		}
		//httpsConnection.disconnect();
		//httpsResultMap.put(ResponseCode, Integer.toString(httpsResponseCode));
		//httpsResultMap.put(ResponseMessage, httpsResponseMessage);
		
		//return httpsResultMap;

	}
	


	private void printErrorStream(HttpsURLConnection httpsConnection)
			throws IOException {
		Scanner s;
		String response = null;
		if (httpsConnection.getResponseCode() != 200) {
			s = new Scanner(httpsConnection.getErrorStream());
		} else {
			s = new Scanner(httpsConnection.getInputStream());
		}
		s.useDelimiter("\\Z");
		try{
			response = s.next();
			postRequestLog.info(" HTTPS ErrorStream: " + response);
			s.close();
		}catch (NoSuchElementException nse){
			s.close();
			postRequestLog.error(" HTTPS ErrorStream: " + nse.getMessage());			
		}catch (Exception e){
			s.close();
			postRequestLog.error(" HTTPS ErrorStream: " + e.getMessage());
		}		
	}

}