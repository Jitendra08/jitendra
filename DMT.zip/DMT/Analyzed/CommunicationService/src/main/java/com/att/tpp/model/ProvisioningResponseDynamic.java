package  com.att.tpp.model;

import java.util.Collection;
import java.util.Date;


public class ProvisioningResponseDynamic {


	private String transactionId;
	private Date receivedTimeStamp;
	private String systemName;
	private String msisdn;
	private String url;
	private String payload;
	private String processingStatus;
	private String transaction_type;
	private String provisioningCarrier;
	private String routingCarrier;
	private String login;
	private String password;
	private Collection<Products> productsCollection;
	

	public ProvisioningResponseDynamic() {
	}
	
	

	/**
	 * @param transactionId
	 * @param receivedTimeStamp
	 * @param systemName
	 * @param msisdn
	 * @param provisioningCarrier
	 * @param routingCarrier
	 * @param productsCollection
	 */
	public ProvisioningResponseDynamic(String transactionId,
			Date receivedTimeStamp, String systemName, String msisdn,
			String provisioningCarrier, String routingCarrier,
			Collection<Products> productsCollection) {
		this.transactionId = transactionId;
		this.receivedTimeStamp = receivedTimeStamp;
		this.systemName = systemName;
		this.msisdn = msisdn;
		this.provisioningCarrier = provisioningCarrier;
		this.routingCarrier = routingCarrier;
		this.productsCollection = productsCollection;
	}



	public ProvisioningResponseDynamic(String transactionId, Date receivedTimeStamp,
			String systemName, String msisdn, String url, String payload,
			String processingStatus, String transaction_type, String provisioningCarrier,
			String routingCarrier, String login, String password,Collection<Products> productsCollection) {
		this.transactionId = transactionId;
		this.setReceivedTimeStamp(receivedTimeStamp);
		this.systemName = systemName;
		this.msisdn = msisdn;
		this.url = url;
		this.payload = payload;
		this.transaction_type=transaction_type;
		this.processingStatus = processingStatus;
		this.provisioningCarrier = provisioningCarrier;
		this.routingCarrier = routingCarrier;
		this.login = login;
		this.password = password;
		this.productsCollection=productsCollection;
	}

	public String getTransaction_type() {
		return transaction_type;
	}

	public void setTransaction_type(String transaction_type) {
		this.transaction_type = transaction_type;
	}

	public String getTransactionId() {
		return this.transactionId;
	}

	public void setTransactionId(String transactionId) {
		this.transactionId = transactionId;
	}

	public String getUrl() {
		return url;
	}

	public void setUrl(String url) {
		this.url = url;
	}

	public String getMsisdn() {
		return this.msisdn;
	}

	public void setMsisdn(String msisdn) {
		this.msisdn = msisdn;
	}

	public String getPayload() {
		return this.payload;
	}

	public void setPayload(String payload) {
		this.payload = payload;
	}

	public String getProcessingStatus() {
		return this.processingStatus;
	}

	public void setProcessingStatus(String processingStatus) {
		this.processingStatus = processingStatus;
	}

	public String getSystemName() {
		return this.systemName;
	}

	public void setSystemName(String systemName) {
		this.systemName = systemName;
	}

	public Date getReceivedTimeStamp() {
		return receivedTimeStamp;
	}

	public void setReceivedTimeStamp(Date receivedTimeStamp) {
		this.receivedTimeStamp = receivedTimeStamp;
	}

	public String getProvisioningCarrier() {
		return provisioningCarrier;
	}

	public void setProvisioningCarrier(String provisioningCarrier) {
		this.provisioningCarrier = provisioningCarrier;
	}

	public String getRoutingCarrier() {
		return routingCarrier;
	}

	public void setRoutingCarrier(String routingCarrier) {
		this.routingCarrier = routingCarrier;
	}

	public String getLogin() {
		return login;
	}

	public void setLogin(String login) {
		this.login = login;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public Collection<Products> getProductsCollection() {
		return productsCollection;
	}

	public void setProductsCollection(Collection<Products> productsCollection) {
		this.productsCollection = productsCollection;
	}

}
