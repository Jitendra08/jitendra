package com.att.tpp.config;


public class ProductRefElement {

	private String productId;
	private String productDsc;

	ProductRefElement(String productId, String productDsc) {
		this.productId = productId;
		this.productDsc = productDsc;
	}

	public String toString() {
		return productId + "," + productDsc;
	}

	public String getProductId() {
		return productId;
	}

	public void setProductId(String productId) {
		this.productId = productId;
	}

	public String getProductDsc() {
		return productDsc;
	}

	public void setProductDsc(String productDsc) {
		this.productDsc = productDsc;
	}


}
