package com.att.tpp.config;

class URIConfigElement {
  public String system;
  public String URI;
  public String synchTransIND;

  URIConfigElement ( String systemX,
                     String URIX,
                     String synchTransINDX) {
      system = systemX;
      URI = URIX;
      synchTransIND = synchTransINDX;
  }

 public String toString() {
   return system + "," + URI + "," + synchTransIND ;
 }
}
