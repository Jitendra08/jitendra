package com.att.tpp.config;

import java.beans.ConstructorProperties;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.security.KeyManagementException;
import java.security.KeyStore;
import java.security.KeyStoreException;
import java.security.NoSuchAlgorithmException;
import java.security.UnrecoverableKeyException;
import java.security.cert.CertificateException;

import javax.net.ssl.KeyManagerFactory;
import javax.net.ssl.SSLContext;
import javax.net.ssl.TrustManagerFactory;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

public class InitializeSSLConnection {
	
	 private static Logger initializeSSLConnectionLog = LogManager.getLogger(InitializeSSLConnection.class);

	private static String trustoreFileName;
	private static String keystoreFileName;
	private static String storePass;
	private static String keystorepass;
	private static String useProxy;
	private static String proxyHost;
	private static String proxyPort;
	private static String useTLS12;
	private static String turbo;
	

	@ConstructorProperties({"trustoreFileName", "keystoreFileName","trustoreStorePass", "keystorepass", "useProxy", "proxyHost", "proxyPort", "useTLS12", "turbo"})
	public InitializeSSLConnection(String trustoreFileName, String keystoreFileName, String trustoreStorePass, String keystorepass, String useProxy, String proxyHost, String proxyPort, String useTLS12, String turbo) {
		InitializeSSLConnection.trustoreFileName = trustoreFileName;
		InitializeSSLConnection.keystoreFileName = keystoreFileName;
		InitializeSSLConnection.storePass = trustoreStorePass;
		InitializeSSLConnection.keystorepass = keystorepass;
		InitializeSSLConnection.useProxy = useProxy;
		InitializeSSLConnection.proxyHost = proxyHost;
		InitializeSSLConnection.proxyPort = proxyPort;
		InitializeSSLConnection.useTLS12 = useTLS12;
		InitializeSSLConnection.turbo = turbo;
		
		initializeSSLConnectionLog.info(".... Communication Additional Configuration Parameters configuring ....");
		initializeSSLConnectionLog.info("useProxy = " + useProxy);
		initializeSSLConnectionLog.info("proxyHost = " + proxyHost);
		initializeSSLConnectionLog.info("proxyPort = " + proxyPort);
		initializeSSLConnectionLog.info("useTLS12 = " + useTLS12);
		initializeSSLConnectionLog.info("turbo = " + turbo);
		initializeSSLConnectionLog.info(".... Communication Additional Configuration Parameters configured!!!!!");
	}
	
	
	public InitializeSSLConnection() {
		// TODO Auto-generated constructor stub
	}
	
	
	private static SSLContext sslContext;
	

	public static void setUpSSLConnection() throws KeyStoreException, IOException,
			NoSuchAlgorithmException, CertificateException,
			FileNotFoundException, UnrecoverableKeyException,
			KeyManagementException {
		
		initializeSSLConnectionLog.info("Setting the SSL Context");
		
		KeyStore keyStore = KeyStore.getInstance("JKS");
		keyStore.load(new FileInputStream(keystoreFileName),
				keystorepass.toCharArray());
		KeyManagerFactory keyManagerFactory = KeyManagerFactory
				.getInstance("SunX509");
		keyManagerFactory.init(keyStore, keystorepass.toCharArray());

		//sslContext = SSLContext.getInstance("SSLv3");
		//sslContext = SSLContext.getInstance("TLS");
		sslContext = SSLContext.getInstance("TLSv1.2");
		sslContext.init(keyManagerFactory.getKeyManagers(), null, null);

		KeyStore trustedStore = KeyStore.getInstance("JKS");
		trustedStore.load(new FileInputStream(trustoreFileName),
				storePass.toCharArray());

		// TrustManager's decide whether to allow connections.
		TrustManagerFactory trustMangerFactory = TrustManagerFactory
				.getInstance("SunX509");
		trustMangerFactory.init(trustedStore);

		System.setProperty("javax.net.ssl.keyStoreType", "jks");
		System.setProperty("javax.net.ssl.trustStoreType", "jks");
		// Need to comment this after debug
		//System.setProperty("javax.net.debug", "ssl");
		System.setProperty("javax.net.ssl.keyStore", keystoreFileName);
		System.setProperty("javax.net.ssl.trustStore", trustoreFileName);
		System.setProperty("javax.net.ssl.keyStorePassword", keystorepass);
		System.setProperty("javax.net.ssl.trustStorePassword", storePass);
		//System.setProperty("https.protocols", "TLSv1");
		
//		if(useProxy.equalsIgnoreCase("Y") || useProxy.equalsIgnoreCase("TRUE")){
//			System.setProperty("https.proxyHost", proxyHost);
//			System.setProperty("https.proxyPort", proxyPort);
//			
//		}
		
		if(useTLS12.equalsIgnoreCase("Y") || useTLS12.equalsIgnoreCase("TRUE")){
			System.setProperty("https.protocols", "TLSv1.2");
			//System.setProperty("javax.net.debug", "all");
		}
		else{
			System.setProperty("https.protocols", "TLSv1,TLSv1.1,TLSv1.2");
		}

		sslContext.init(keyManagerFactory.getKeyManagers(),
				trustMangerFactory.getTrustManagers(), null);
		
		//return sslContext;
	}

	
	public static SSLContext getSslContext() {
		return sslContext;
	}

	
	public static void setSslContext(SSLContext sslContext) {
		InitializeSSLConnection.sslContext = sslContext;
		
	}

	/**
	 * @return the useProxy
	 */
	public static String getUseProxy() {
		return useProxy;
	}


	/**
	 * @return the proxyHost
	 */
	public static String getProxyHost() {
		return proxyHost;
	}


	/**
	 * @return the proxyPort
	 */
	public static String getProxyPort() {
		return proxyPort;
	}


	/**
	 * @return the useTLS12
	 */
	public static String getUseTLS12() {
		return useTLS12;
	}


	/**
	 * @return the turbo
	 */
	public static String getTurbo() {
		return turbo;
	}
	

}
