package com.att.tpp.jms.sender;

import javax.jms.JMSException;
import javax.jms.Message;
import javax.jms.Queue;
import javax.jms.Session;
import javax.jms.TextMessage;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.jms.core.JmsTemplate;
import org.springframework.jms.core.MessageCreator;

/**
 * 
 * The GatewayQueueSender class uses the injected JMSTemplate to send a message
 * to gatewayProvisioningRequestQueue. 
 */
public class ResponseQueueSender
{
	private JmsTemplate jmsTemplate;
	private Queue responseQueue; 
	private static final Logger responseQueueSender = LogManager.getLogger(ResponseQueueSender.class);
	
	/**
	 * Sends message to gatewayProvisioningRequestQueue using JMS Template.
	 * @param parseSystemName 
	 * @param provReqXML the message_p
	 * @throws JMSException the jms exception
	 */
	public void sendMessage(final String provisioningResponseXML) throws JMSException	
	{
		
		responseQueueSender.info("Sending TPP_ProvisioningRequest Message From Communication Service to Response Queue");

		jmsTemplate.send(this.responseQueue, new MessageCreator(){

			@Override
			public Message createMessage(Session session) throws JMSException {
				TextMessage message = session.createTextMessage(provisioningResponseXML.toString());
				return message;
			}
			
		});		
		
	}
	/**
	 * Sets the jms template.
	 *
	 * @param template the jms template
	 */
	public void setJmsTemplate(JmsTemplate tmpl)
	{
		this.jmsTemplate = tmpl;
	}
	public void setResponseQueue(Queue responseQueue) {
		this.responseQueue = responseQueue;
	}


	
	

	
}