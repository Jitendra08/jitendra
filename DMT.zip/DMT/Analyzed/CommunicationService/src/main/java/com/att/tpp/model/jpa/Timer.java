package com.att.tpp.model.jpa;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.EmbeddedId;
import javax.persistence.Entity;
import javax.persistence.Lob;
import javax.persistence.NamedQuery;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;


/**
 * The persistent class for the TIMER database table.
 * 
 */
@Entity
@NamedQuery(name="Timer.findAll", query="SELECT t FROM Timer t")
public class Timer implements Serializable {
	private static final long serialVersionUID = 1L;

	@EmbeddedId
	private TimerPK id;

	@Temporal(TemporalType.TIMESTAMP)
	@Column(name="CREATION_TIME")
	private Date creationTime;

	@Temporal(TemporalType.TIMESTAMP)
	@Column(name="EXPIRY_TIME")
	private Date expiryTime;

	@Lob
	@Column(name="PAYLOAD")
	private String payload;

	@Column(name="PAYLOAD_OVERFLOW")
	private String payloadOverflow;

	@Column(name="RETRY_IND")
	private String retryInd;

	@Column(name="TIMER_DURATION")
	private int timerDuration;

	public Timer() {
	}

	public TimerPK getId() {
		return this.id;
	}

	public void setId(TimerPK id) {
		this.id = id;
	}

	public Date getCreationTime() {
		return this.creationTime;
	}

	public void setCreationTime(Date creationTime) {
		this.creationTime = creationTime;
	}

	public Date getExpiryTime() {
		return this.expiryTime;
	}

	public void setExpiryTime(Date expiryTime) {
		this.expiryTime = expiryTime;
	}

	public String getPayload() {
		return this.payload;
	}

	public void setPayload(String payload) {
		this.payload = payload;
	}

	public String getPayloadOverflow() {
		return this.payloadOverflow;
	}

	public void setPayloadOverflow(String payloadOverflow) {
		this.payloadOverflow = payloadOverflow;
	}

	public String getRetryInd() {
		return this.retryInd;
	}

	public void setRetryInd(String retryInd) {
		this.retryInd = retryInd;
	}

	public int getTimerDuration() {
		return timerDuration;
	}

	public void setTimerDuration(int timerDuration) {
		this.timerDuration = timerDuration;
	}



}