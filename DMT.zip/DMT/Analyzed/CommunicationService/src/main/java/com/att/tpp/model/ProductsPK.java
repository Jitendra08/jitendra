/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.att.tpp.model;

/**
 *
 * @author SC9833
 */

public class ProductsPK {
    private String transactionId;
    private String productId;
    private String action;

    public ProductsPK() {
    }

    public ProductsPK(String transactionId, String productId, String action) {
        this.transactionId = transactionId;
        this.productId = productId;
        this.action = action;
    }

    public String getTransactionId() {
        return transactionId;
    }

    public void setTransactionId(String transactionId) {
        this.transactionId = transactionId;
    }

    public String getProductId() {
        return productId;
    }

    public void setProductId(String productId) {
        this.productId = productId;
    }

    public String getAction() {
        return action;
    }

    public void setAction(String action) {
        this.action = action;
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (transactionId != null ? transactionId.hashCode() : 0);
        hash += (productId != null ? productId.hashCode() : 0);
        hash += (action != null ? action.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof ProductsPK)) {
            return false;
        }
        ProductsPK other = (ProductsPK) object;
        if ((this.transactionId == null && other.transactionId != null) || (this.transactionId != null && !this.transactionId.equals(other.transactionId))) {
            return false;
        }
        if ((this.productId == null && other.productId != null) || (this.productId != null && !this.productId.equals(other.productId))) {
            return false;
        }
        if ((this.action == null && other.action != null) || (this.action != null && !this.action.equals(other.action))) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "javaandslurp.model.ProductsPK[ transactionId=" + transactionId + ", productId=" + productId + ", action=" + action + " ]";
    }

}
