package com.att.tpp.model;

import java.io.Serializable;
import javax.persistence.*;


/**
 * The persistent class for the URI_CONFIGURATION database table.
 * 
 */
@Entity
@Table(name="URI_CONFIGURATION")
@NamedQuery(name="UriConfiguration.findAll", query="SELECT u FROM UriConfiguration u")
public class UriConfiguration implements Serializable {
	private static final long serialVersionUID = 1L;

	@Column(name="SYNCH_TRANSACTION_IND")
	private String synchTransactionInd;

	@Id
	@Column(name="SYSTEM_NAME")
	private String systemName;

	@Column(name="URI_TEXT")
	private String uriText;

	public UriConfiguration() {
	}

	public String getSynchTransactionInd() {
		return this.synchTransactionInd;
	}

	public void setSynchTransactionInd(String synchTransactionInd) {
		this.synchTransactionInd = synchTransactionInd;
	}

	public String getSystemName() {
		return this.systemName;
	}

	public void setSystemName(String systemName) {
		this.systemName = systemName;
	}

	public String getUriText() {
		return this.uriText;
	}

	public void setUriText(String uriText) {
		this.uriText = uriText;
	}

}