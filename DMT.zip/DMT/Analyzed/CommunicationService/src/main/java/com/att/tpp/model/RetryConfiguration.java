package com.att.tpp.model;

import java.io.Serializable;
import javax.persistence.*;
import java.math.BigDecimal;


/**
 * The persistent class for the RETRY_CONFIGURATION database table.
 * 
 */
@Entity
@Table(name="RETRY_CONFIGURATION")
@NamedQuery(name="RetryConfiguration.findAll", query="SELECT r FROM RetryConfiguration r")
public class RetryConfiguration implements Serializable {
	private static final long serialVersionUID = 1L;

	@EmbeddedId
	private RetryConfigurationPK id;

	@Column(name="WAIT_TIME")
	private int waitTime;

	public RetryConfiguration() {
	}

	public RetryConfigurationPK getId() {
		return this.id;
	}

	public void setId(RetryConfigurationPK id) {
		this.id = id;
	}

	public int getWaitTime() {
		return waitTime;
	}

	public void setWaitTime(int waitTime) {
		this.waitTime = waitTime;
	}

	
}