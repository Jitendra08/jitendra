package com.att.tpp.xml.model;

public class AttributeInfo {

    private String attributeName;
    private String attributeValue;

    /**
	 * @param attributeName
	 * @param attributeValue
	 */
	public AttributeInfo(String attributeName, String attributeValue) {
		this.attributeName = attributeName;
		this.attributeValue = attributeValue;
	}

	/**
     * Gets the value of the attributeName property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getAttributeName() {
        return attributeName;
    }

    /**
     * Sets the value of the attributeName property.
     * 
     * @param attributeName
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setAttributeName(String attributeName) {
        this.attributeName = attributeName;
    }

    /**
     * Gets the value of the attributeValue property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getAttributeValue() {
        return attributeValue;
    }

    /**
     * Sets the value of the attributeValue property.
     * 
     * @param attributeValue
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setAttributeValue(String attributeValue) {
        this.attributeValue = attributeValue;
    }

}
