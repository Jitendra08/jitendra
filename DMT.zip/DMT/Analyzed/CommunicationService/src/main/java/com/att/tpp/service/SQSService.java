package com.att.tpp.service;

import java.beans.ConstructorProperties;
import java.io.UnsupportedEncodingException;
import java.net.MalformedURLException;
import java.net.URL;
import java.net.URLEncoder;
import java.security.InvalidKeyException;
import java.security.NoSuchAlgorithmException;
import java.text.SimpleDateFormat;
import java.util.GregorianCalendar;
import java.util.TimeZone;

import javax.crypto.Mac;
import javax.crypto.spec.SecretKeySpec;

import org.apache.commons.codec.binary.Base64;

public class SQSService {
	
	private static String pikeAKey;
	private static String pikeSKey;
	
	
	@ConstructorProperties({"pikeAKey", "pikeSKey" })
	public SQSService(String pikeAKey, String pikeSKey){
		SQSService.pikeAKey = pikeAKey;
		SQSService.pikeSKey=pikeSKey;
	}	
	
	

	public String iso860DateTime() throws Exception{		
		String theExpiry =  null;
		try {
			int DAY_IN_MILLISECOND = 1000 * 60 * 60 * 24;
			int SEVEN_DAYS = DAY_IN_MILLISECOND * 7;
			TimeZone utc = TimeZone.getTimeZone("UTC");  //Get the UTC Time Zone ID.
			SimpleDateFormat iso8601 = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss'Z'");  //Set the format to ISO8601 TimeStamp Format.
			iso8601.setTimeZone(utc);  //Set the Time Zone to UTC.
			GregorianCalendar gCal = new GregorianCalendar(utc);  //Set the calendar to UTC.
			gCal.setTimeInMillis(gCal.getTimeInMillis() + SEVEN_DAYS);  //Set the date 7 days ahead from now.
			theExpiry = iso8601.format(gCal.getTime());  //Set get the time and set the expiry date string.
		} catch (Exception e) {
			e.printStackTrace();
		}
        return theExpiry;
	}
	
	
	public String createMessageToSign(String expiryTime,
			String provisioningRequestXML, String url)
			throws MalformedURLException, UnsupportedEncodingException {
		String ENCODE_VERSION = "UTF-8";
		String REQUEST_METHOD = "POST";
		String messageToSign = null;
		// String REQUEST_METHOD = request_method;
		// String expiryTime = expiryTimeIn;
		// String AKey = a_Key;
		try {
			URL postURL = new URL(url);
			messageToSign = REQUEST_METHOD
					+ "\n"
					+ postURL.getHost()
					+ "\n"
					+ postURL.getPath()
					+ "\n"
					+ "AWSAccessKeyId="
					+ URLEncoder.encode(pikeAKey, ENCODE_VERSION)
					+ "&Action="
					+ URLEncoder.encode("SendMessage", ENCODE_VERSION)
					+ "&Expires="
					+ URLEncoder.encode(expiryTime, ENCODE_VERSION)
					+ "&MessageBody="
					+ URLEncoder.encode(provisioningRequestXML.trim(),
							ENCODE_VERSION).replace("+", "%20")
					+
					// "&MessageBody=" +
					// URLEncoder.encode(EncodeHelper.encodeToBase64(provisioningRequestXML.getBytes()),
					// ENCODE_VERSION) +
					"&SignatureMethod="
					+ URLEncoder.encode("HmacSHA256", ENCODE_VERSION)
					+ "&SignatureVersion="
					+ URLEncoder.encode("2", ENCODE_VERSION) + "&Version="
					+ URLEncoder.encode("2011-10-01", ENCODE_VERSION);
		} catch (Exception e) {
			e.printStackTrace();
		}
		return messageToSign;
	}
	
	
	public String singMessage(String messageToSign)
			throws NoSuchAlgorithmException, InvalidKeyException,
			UnsupportedEncodingException {
		/*
		 * Available Variables: DO NOT MODIFY In : String mesgToSign In : String
		 * expiryTimeIn In : String s_Key Out : String signature Out : String
		 * expiryTimeOut Available Variables: DO NOT MODIFY ****
		 */
		// String SKey = s_Key;
		// String HMAC_SHA1 = "HmacSHA1";

		String HMAC_SHA256 = "HmacSHA256";
		String signature = null;

		try {
			// get an hmac_sha1 key from the raw key bytes
			SecretKeySpec signingKey = new SecretKeySpec(pikeSKey.getBytes(),
					HMAC_SHA256);

			// get an hmac_sha1 Mac instance and initialize with the signing key
			Mac mac = Mac.getInstance(HMAC_SHA256);
			mac.init(signingKey);

			// compute the hmac on input data bytes
			byte[] rawHmac = mac.doFinal(messageToSign.getBytes("UTF-8"));
			// base64-encode the hmac
			// signature = Base64.encodeBase64String(rawHmac);
			signature = Base64.encodeBase64(rawHmac).toString();
		} catch (IllegalStateException e) {
			e.printStackTrace();
		}
		
		return signature;
	}
	
	public String dataWithSignature(String expiryTime, String provisioningRequestXML, String signature) throws UnsupportedEncodingException {
		
		String ENCODE_VERSION = "UTF-8";
		String HMAC_SHA256 = "HmacSHA256";
		String postContent = null;
		
		try {
			postContent = "Action=" + URLEncoder.encode("SendMessage", ENCODE_VERSION) + 
			                "&MessageBody=" + URLEncoder.encode(provisioningRequestXML.trim(), ENCODE_VERSION).replace("+", "%20") +
			                //"&MessageBody=" + URLEncoder.encode(EncodeHelper.encodeToBase64(mesg.getBytes()), ENCODE_VERSION) +
			                "&AWSAccessKeyId=" + URLEncoder.encode(pikeAKey, ENCODE_VERSION) +                 
			                "&Version=" + URLEncoder.encode("2011-10-01", ENCODE_VERSION) + 
			                "&Expires=" + URLEncoder.encode(expiryTime, ENCODE_VERSION) +
			                "&SignatureVersion=" + URLEncoder.encode("2", ENCODE_VERSION) +
			                "&SignatureMethod=" + URLEncoder.encode(HMAC_SHA256, ENCODE_VERSION) +
			                "&Signature=" + URLEncoder.encode(signature, ENCODE_VERSION);
		} catch (Exception e) {
			e.printStackTrace();
		}
		
		return postContent;
	}
	
	


}
