package com.att.tpp.model;

import java.io.Serializable;
import javax.persistence.*;


/**
 * The persistent class for the SYSTEM_CONFIGURATION database table.
 * 
 */
@Entity
@Table(name="SYSTEM_CONFIGURATION")
@NamedQuery(name="SystemConfiguration.findAll", query="SELECT s FROM SystemConfiguration s")
public class SystemConfiguration implements Serializable {
	private static final long serialVersionUID = 1L;

	@EmbeddedId
	private SystemConfigurationPK id;

	@Column(name="BULK_IND")
	private String bulkInd;

	@Column(name="CSISOAP_SRVS")
	private String csisoapSrvs;

	@Column(name="EVAL_FINAL_RSP_IND")
	private String evalFinalRspInd;

	@Column(name="FULFILLMENT_NOTICE_IND")
	private String fulfillmentNoticeInd;

	@Column(name="ISEC_SPLIT_FLAG")
	private String isecSplitFlag;

	@Column(name="LOGIN_NAME")
	private String loginName;

	@Column(name="NON_CRITICAL_IND")
	private String nonCriticalInd;

	@Column(name="NOTIFICATION_URL")
	private String notificationUrl;

	@Column(name="PASSWORD_TEXT")
	private String passwordText;

	@Column(name="SEND_SMS")
	private String sendSms;

	@Column(name="SMS_SHORTCODE")
	private String smsShortcode;

	@Column(name="XSLT_FILE")
	private String xsltFile;

	public SystemConfiguration() {
	}

	public SystemConfigurationPK getId() {
		return this.id;
	}

	public void setId(SystemConfigurationPK id) {
		this.id = id;
	}

	public String getBulkInd() {
		return this.bulkInd;
	}

	public void setBulkInd(String bulkInd) {
		this.bulkInd = bulkInd;
	}

	public String getCsisoapSrvs() {
		return this.csisoapSrvs;
	}

	public void setCsisoapSrvs(String csisoapSrvs) {
		this.csisoapSrvs = csisoapSrvs;
	}

	public String getEvalFinalRspInd() {
		return this.evalFinalRspInd;
	}

	public void setEvalFinalRspInd(String evalFinalRspInd) {
		this.evalFinalRspInd = evalFinalRspInd;
	}

	public String getFulfillmentNoticeInd() {
		return this.fulfillmentNoticeInd;
	}

	public void setFulfillmentNoticeInd(String fulfillmentNoticeInd) {
		this.fulfillmentNoticeInd = fulfillmentNoticeInd;
	}

	public String getIsecSplitFlag() {
		return this.isecSplitFlag;
	}

	public void setIsecSplitFlag(String isecSplitFlag) {
		this.isecSplitFlag = isecSplitFlag;
	}

	public String getLoginName() {
		return this.loginName;
	}

	public void setLoginName(String loginName) {
		this.loginName = loginName;
	}

	public String getNonCriticalInd() {
		return this.nonCriticalInd;
	}

	public void setNonCriticalInd(String nonCriticalInd) {
		this.nonCriticalInd = nonCriticalInd;
	}

	public String getNotificationUrl() {
		return this.notificationUrl;
	}

	public void setNotificationUrl(String notificationUrl) {
		this.notificationUrl = notificationUrl;
	}

	public String getPasswordText() {
		return this.passwordText;
	}

	public void setPasswordText(String passwordText) {
		this.passwordText = passwordText;
	}

	public String getSendSms() {
		return this.sendSms;
	}

	public void setSendSms(String sendSms) {
		this.sendSms = sendSms;
	}

	public String getSmsShortcode() {
		return this.smsShortcode;
	}

	public void setSmsShortcode(String smsShortcode) {
		this.smsShortcode = smsShortcode;
	}

	public String getXsltFile() {
		return this.xsltFile;
	}

	public void setXsltFile(String xsltFile) {
		this.xsltFile = xsltFile;
	}

}