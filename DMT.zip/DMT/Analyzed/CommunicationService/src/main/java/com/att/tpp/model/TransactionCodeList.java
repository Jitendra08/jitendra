/**
 * 
 */
package com.att.tpp.model;

import java.io.Serializable;

/**
 * @author SC9833
 *
 */
public class TransactionCodeList implements Serializable {

	/**
	 * Use this to generate the ErrorCode and ErrorMessage in the
	 * ProvisioningResponse.
	 */
	
	private static final long serialVersionUID = 1L;
	
	private long errorCode;
	private String errorMessageText;
	
	public TransactionCodeList() {
		// TODO Auto-generated constructor stub
	}	

	/**
	 * @param errorCode
	 * @param errorMessageText
	 */
	public TransactionCodeList(long errorCode, String errorMessageText) {
		this.errorCode = errorCode;
		this.errorMessageText = errorMessageText;
	}

	/**
	 * @return the errorCode
	 */
	public long getErrorCode() {
		return errorCode;
	}

	/**
	 * @param errorCode the errorCode to set
	 */
	public void setErrorCode(long errorCode) {
		this.errorCode = errorCode;
	}

	/**
	 * @return the errorMessageText
	 */
	public String getErrorMessageText() {
		return errorMessageText;
	}

	/**
	 * @param errorMessageText the errorMessageText to set
	 */
	public void setErrorMessageText(String errorMessageText) {
		this.errorMessageText = errorMessageText;
	}

	/* (non-Javadoc)
	 * @see java.lang.Object#hashCode()
	 */
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + (int) (errorCode ^ (errorCode >>> 32));
		result = prime
				* result
				+ ((errorMessageText == null) ? 0 : errorMessageText.hashCode());
		return result;
	}

	/* (non-Javadoc)
	 * @see java.lang.Object#equals(java.lang.Object)
	 */
	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		TransactionCodeList other = (TransactionCodeList) obj;
		if (errorCode != other.errorCode)
			return false;
		if (errorMessageText == null) {
			if (other.errorMessageText != null)
				return false;
		} else if (!errorMessageText.equals(other.errorMessageText))
			return false;
		return true;
	}

}
