package com.att.tpp.controller;

import java.io.IOException;
import java.math.BigDecimal;
import java.util.HashMap;

import javax.jms.JMSException;
import javax.xml.transform.TransformerConfigurationException;
import javax.xml.transform.TransformerFactoryConfigurationError;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.att.tpp.config.InitGlobalInstance;
import com.att.tpp.config.XSLTEngine;
import com.att.tpp.dao.CommunicationDao;
import com.att.tpp.jms.sender.OnHoldQueueSender;
import com.att.tpp.model.ProcessingResult;
import com.att.tpp.model.SystemRef;
import com.att.tpp.model.TransactionRequestData;
import com.att.tpp.service.CommunicationService;
import com.att.tpp.utils.ParseRequestData;


@Service("communicationController")
public class CommunicationController {
	
	@Autowired
	private CommunicationService communicationService;
	
	@Autowired
	private OnHoldQueueSender onHoldQueueSender;
	
	
	
	@Autowired
	private CommunicationDao communicationDao;
	
	private static final Logger communicationControllerLog = LogManager.getLogger(CommunicationController.class);


	private final static String TPP_TransactionRequestXSD = "TPP_TransactionRequest.xsd";
	
	   private final static String ResponseCode = "responseCode";	
	   private final static String autoResonderInd = "autoResonderInd";
	   private final static String emailInd = "emailInd";
	   private final static String postSuccess = "PostSuccess";
	   private final static String postFailed = "PostFailed";
	
	String messageId=null;
	String masterTransid=null;
	
	ParseRequestData parseRequestData = new ParseRequestData(); 
	
	public ProcessingResult processRequest(String communicationRequestXML, String messageId) 	
			throws IOException, Exception {
		ProcessingResult processingResult = new ProcessingResult();
		communicationControllerLog.info("Started");
		BigDecimal currTechRetryCount = new BigDecimal(0);
		
		//boolean isValidRequestXML = true;
		//Validate the request XML		
		boolean isValidRequestXML = communicationService.validateXML(communicationRequestXML, TPP_TransactionRequestXSD);
		communicationControllerLog.info("isValidRequestXML: "+isValidRequestXML);
		
		if(isValidRequestXML){
			//Parse XML
			String parseSystemName = parseRequestData.parseSystemName(communicationRequestXML);
			processingResult.setSystemName(parseSystemName);
			communicationControllerLog.info("System Name : "+parseSystemName);
			
			
			
			if (parseSystemName != null && parseSystemName != "") {
				SystemRef systemRef = InitGlobalInstance.getSystemRef().get(parseSystemName);
				String status=systemRef.getStatus();
				String provisioningRequestXML = null;
				
				if(status.equalsIgnoreCase("onhold")){
					//Send to OnHoldQueue
					onHoldQueueSender.sendMessage(communicationRequestXML, messageId, parseSystemName);
					//Update Interface table
					boolean updateInterface = communicationService.updateInterfaceTable(parseSystemName,"R");
					communicationControllerLog.info("updateInterface table : "+updateInterface);
					
				}else{
					//Call Main process
					TransactionRequestData transactionRequestData = new TransactionRequestData();					
					transactionRequestData= parseRequestData.parseRequestXML(communicationRequestXML);

					provisioningRequestXML = getProvisoningRequestXML(communicationRequestXML, transactionRequestData);
					communicationControllerLog.info("provisioningRequestXML : "+provisioningRequestXML);
					/*Added for WR */
					if(provisioningRequestXML != null && !provisioningRequestXML.equals("")){
					//Update Provisoning Task					
					boolean updateTaskStatusResult = communicationService.updateTaskStatus(transactionRequestData.getTaskTransId());
					communicationControllerLog.info("updateTaskStatus Result : "+updateTaskStatusResult);
					processingResult.setTppProvReq(transactionRequestData.getTaskTransId());
					
					//PostProcess
					HashMap<String, String> postResultMap = communicationService.postRequest(transactionRequestData,  provisioningRequestXML, messageId);
					
					//if (!(transactionRequestData.getRoutingCarrier().equals("CSI"))) {
					/*
					 * Added check for DCMNotification Event Type for QxP to process normally and Intrado will be processed BAU.
					 * If Vendor is Intrado (through CSI) or IntradoSWC (through SWC), no need for retry logic below. 
					 */
					if ((!(transactionRequestData.getRoutingCarrier().equals("CSI") || transactionRequestData.getSystemName().equals("IntradoSWC"))) || (transactionRequestData.getEventType().equals("DCMNotification"))) {	
	 					
	 					//TO-DO: When there is an exception it seems that a NumberFormatException occurse because the ResponseCode = null.
	 					//Need to add new logic to support when the responseCode = null.  This can be because of an error or no response code sent back when posting.
	 					//The ResponseCode is part of the HashMap postResultMap.
	 					//System.out.println("============> RESPONSE CODE FROM CONTROLLER -------> " + postResultMap.get(ResponseCode));
		 				if(postResultMap != null && postResultMap.get(ResponseCode) != null){
							int httpResultCode= Integer.parseInt(postResultMap.get(ResponseCode));						
							String postResult = postFailed;
							if (httpResultCode == 200) {
								postResult = postSuccess;
							}
							
							//Insert into TransCodes
							boolean insertTransCodeResult = communicationService.insertTransCodes(transactionRequestData, postResult, postResultMap);
							communicationControllerLog.info("insertTransCodeResult : "+insertTransCodeResult);
							
							//Todo:Update Timer Table
							boolean updateTimerTableResult = communicationService.updateTimerTable(postResult,provisioningRequestXML,transactionRequestData);
							communicationControllerLog.info("updateTimerTableResult : "+updateTimerTableResult);
							
							//If Retry exceeded then call to workflow service
							boolean retryExceded = communicationService.verifyRetryExceeded(transactionRequestData, messageId);
							communicationControllerLog.info("retryExceded : "+retryExceded);
							
							//UpdateInterfaceTable					
							boolean updateInterface = communicationService.updateConnectivityStatus(transactionRequestData, transactionRequestData.getUrl(),
									postResult);
							communicationControllerLog.info("updateInterface table : "+updateInterface);
							
							// Generate AutoResponder and Send to Response Service
							
							String autoResponderInd = postResultMap.get(autoResonderInd);
							String emailIndc = postResultMap.get(emailInd);
							
							if(autoResponderInd.equalsIgnoreCase("Y")){
								boolean emailFlag = false;
								if(emailIndc.equalsIgnoreCase("Y")){
									emailFlag = true;
								}
								communicationService.generateAutoResponder(provisioningRequestXML,emailFlag,httpResultCode);
								communicationControllerLog.info("Posted AutoResponder to Response Service: "
												+ transactionRequestData.getTaskTransId());				
							}
		 				}else{
	 						communicationControllerLog.info("Response Code is null");
	 					}
	 			  }else{
	 				 communicationControllerLog.info("Since its CSI route or SWC Route for Intrado, ending the transaction for system:" + transactionRequestData.getSystemName());
	 			  }
										
				}else{
                    communicationControllerLog.info("Xslt Transformation Event Type Mismatch");
                    boolean taskComplete = communicationService.updateInvalidSystemTaskStatus(transactionRequestData.getTaskTransId(),"Complete",currTechRetryCount);
                    communicationControllerLog.info("Updated taskStatus to Complete :: "+taskComplete);
                    processingResult.setTppProvReq(transactionRequestData.getTaskTransId());
                    }
				
				}
				
			}else{
				communicationControllerLog.info("SystemName not found, so dropping the transaction");
			}
			
		}else{
			communicationControllerLog.info("RequestXML is not valid, so dropping the transaciton");
		}
		

		return processingResult;
	}


	private String getProvisoningRequestXML(String communicationRequestXML,
			TransactionRequestData transactionRequestData) throws Exception {
		String provisioningRequestXML = null;
		
		if(transactionRequestData.getPayload()!=null && transactionRequestData.getPayload().length()>0){
			//Retry Route
			provisioningRequestXML = transactionRequestData.getPayload().toString();
			communicationControllerLog.info("System Payload Exist and Its Retry Route");
		}else{
			//XSLT transformation route
			XSLTEngine xsltEngine = new XSLTEngine();
			String key = transactionRequestData.getSystemName()+"_"+transactionRequestData.getEventType();						
			provisioningRequestXML = xsltEngine.transform(communicationRequestXML, key);
			communicationControllerLog.info("XSLT Transformation path - Completed");
		}
		return provisioningRequestXML;
	}


	public void loadInitialData() throws TransformerConfigurationException, TransformerFactoryConfigurationError, JMSException {
		communicationService.loadInitialData();
	}


	public ProcessingResult processFulfillmentResultRequest(
			String communicationRequestXML, String messageId)
			throws IOException, Exception {
		ProcessingResult processingResult = new ProcessingResult();
		communicationControllerLog.info("Started");

		// Validate the request XML
		boolean isValidRequestXML = communicationService.validateXML(
				communicationRequestXML, TPP_TransactionRequestXSD);
		communicationControllerLog.info("isValidRequestXML: "
				+ isValidRequestXML);

		if (isValidRequestXML) {

			// parse xml and get the url and systemPayload
			TransactionRequestData transactionRequestData = new TransactionRequestData();
			transactionRequestData = parseRequestData
					.parseFulfillmentRequestXML(communicationRequestXML);

			String postURL = transactionRequestData.getUrl();
			String postXML = transactionRequestData.getPayload();
			
			communicationControllerLog.info("Payload for Fulfillment Response: " + postXML);
			
			if (postXML != null && postXML != "") {

				//Post request
				boolean postResult = communicationService
						.postFulfillmentRequest(postXML, postURL, transactionRequestData.getProxyEnabled());
				communicationControllerLog
						.info("Post Result of Fullfillment validation request : "
								+ postResult);

			} else {
				communicationControllerLog
						.info("postXML is empty, so dropping fulfillment transaction : "
								+ transactionRequestData.getTaskTransId());
			}

		}

		return processingResult;
	}
	
	
	

	
	
		

}
