package com.att.tpp.utils


import com.att.tpp.model.IntradoWSResponseData
import com.att.tpp.model.Products
import com.att.tpp.model.ProductsPK
import com.att.tpp.model.ProvisioningRequestData
import com.att.tpp.model.TransactionRequestData
import com.att.tpp.xml.vui.model.ALIUpdateRequest
import com.att.tpp.xml.vui.model.CLS
import com.att.tpp.xml.vui.model.HDR
import com.att.tpp.xml.vui.model.Payload
import com.att.tpp.xml.vui.model.TYS
import com.att.tpp.xml.vui.model.VUI



class ParseRequestData {		
	
	def String parseSystemName(String requestXML){		
		def transactionRequest = new XmlSlurper().parseText(requestXML)
		def systemName = transactionRequest.TaskInfo.@System.toString()
		return systemName;	
	}

	public TransactionRequestData parseRequestXML(String requestXML) {
		def today = new Date()  //Set today to NOW		
		
		def transactionRequest = new XmlSlurper().parseText(requestXML)
		TransactionRequestData transactionRequestData = new TransactionRequestData();
		def transId = transactionRequest.TaskInfo.@Task_TransID.toString();
		
		transactionRequestData.systemName=transactionRequest.TaskInfo.@System.toString();
		transactionRequestData.eventType=transactionRequest.TaskInfo.@EventType.toString();
		transactionRequestData.taskTransId=transactionRequest.TaskInfo.@Task_TransID.toString();
 		transactionRequestData.payload = transactionRequest.SystemPayload?.toString();
		transactionRequestData.url = transactionRequest.TaskInfo.@URL.toString();
		transactionRequestData.proxyEnabled = transactionRequest.TaskInfo.@ProxyEnabled.toString();
		transactionRequestData.routingCarrier = transactionRequest.TaskInfo?.@RoutingCarrier?.toString();
		transactionRequestData.currentTechRetryCount = transactionRequest.TaskInfo.@CurrentTechRetryCount.toString();
		transactionRequestData.maxTechRetryCount = transactionRequest.TaskInfo.@MaxTechRetryCount.toString();
		transactionRequestData.msisdn = transactionRequest.Order?.Account?.@MSISDN.toString();

		transactionRequestData.productsCollection = transactionRequest.Products.Product.collect{
			new Products(
			new ProductsPK(transId.toString(), it.@Id.toString(), it.@Action.toString()), 
			today, it.@Category.toString())}
				
		transactionRequestData.masterTransId =transId.substring(0,transId.indexOf("_"));
		
		 
		return transactionRequestData;
		
	}
	
	public IntradoWSResponseData parseIntradoResponse(String intradoRespXML)
	{
		
		def intradoResponse = new XmlSlurper().parseText(intradoRespXML)
		IntradoWSResponseData intradoWSResponseData = new IntradoWSResponseData();
		
		intradoWSResponseData.externalKey = intradoResponse?.Body?.vuiAliUpdateResponse?.externalKey.toString()		
		intradoWSResponseData.rc1Code = intradoResponse?.Body?.vuiAliUpdateResponse?.rc1.toString()
		intradoWSResponseData.rc1Message= intradoResponse?.Body?.vuiAliUpdateResponse?.rc1?.@message.toString()
		
		
		return intradoWSResponseData;
	}
	
	public String parseProvisioningRequestXML(String provReqXML) {
		def now = new Date()
		
		def provisioningRequest = new XmlSlurper().parseText(provReqXML)
		ProvisioningRequestData provisioningRequestData = new ProvisioningRequestData();
		
		def transId = provisioningRequest.Header.@TransactionId.toString();
		provisioningRequestData.transactionId = transId;
		provisioningRequestData.msisdn = provisioningRequest.Order.Account.@MSISDN.toString();
		provisioningRequestData.prevMsisdn = provisioningRequest.Order.Account?.@PrevMSISDN.toString();
		provisioningRequestData.subscriberNumber = provisioningRequest.Order.Account?.@SubscriberNumber.toString();
		provisioningRequestData.ban = provisioningRequest.Order.Account?.@BAN.toString();
		provisioningRequestData.prevBan = provisioningRequest.Order.Account?.@prevBAN.toString();
		provisioningRequestData.fan = provisioningRequest.Order.BillingAccount?.FAN?.@currentFAN.toString();
		provisioningRequestData.prevFan = provisioningRequest.Order.BillingAccount?.FAN?.@previousFAN.toString();
		provisioningRequestData.lastName = provisioningRequest.Order.BillingAccount?.Name?.current?.@LastName.toString();
		provisioningRequestData.firstName = provisioningRequest.Order.BillingAccount?.Name?.current?.@FirstName.toString();		
		provisioningRequestData.productsCollection = provisioningRequest.Products.Product.collect{
			new Products(
			new ProductsPK(transId.toString(), it.@Id.toString(), it.@Action.toString()),
			now, it.@Category.toString())}		
		
		def email  = new StringBuffer()
        def productAction = new StringBuffer()
		
		provisioningRequest.Order.Products.Product.each{ prod ->
			
			productAction << prod.@Action.toString() + "-" + prod.@Id.toString()  + ","
				}
		println(productAction.toString())
		
		email << "________________________________\n"
		email << 'Transaction Id'.padRight(19) + '= ' + transId + '\n'
		
		email << 'Action - Product Id'.padRight(19) + '= ' + productAction.toString() + '\n'

		
		email << 'Timestamp'.padRight(19) + '= ' + now + '\n'
		
		email << 'MSISDN'.padRight(19) + '= ' + provisioningRequestData.getMsisdn() + '\n'
		if(provisioningRequestData.getPrevMsisdn().length()>0)
		email << 'PrevMSISDN'.padRight(19) + '= ' + provisioningRequestData.getPrevMsisdn() + '\n'
		
		email << 'Subscriber Number'.padRight(19) + '= ' + provisioningRequestData.getSubscriberNumber() + '\n'
		
		email << 'BAN'.padRight(19) + '= ' + provisioningRequestData.getBan() + '\n'		
		if(provisioningRequestData.getPrevBan().length()>0)
		email << 'PrevBAN'.padRight(19) + '= ' + provisioningRequestData.getPrevBan() + '\n'
		
		email << 'FAN'.padRight(19) + '= ' + provisioningRequestData.getFan() + '\n'
		if(provisioningRequestData.getPrevBan().length()>0)
		email << 'PrevFAN'.padRight(19) + '= ' + provisioningRequestData.getPrevBan() + '\n'
		
		email << 'LastName'.padRight(19) + '= ' + provisioningRequestData.getLastName() + '\n'
		email << 'FirstName'.padRight(19) + '= ' + provisioningRequestData.getFirstName() + '\n'
		
		email << "________________________________\n"
		


		
		
		 
		return email.toString();
		
	}
	
	public VUI parseVUIRequestxml (String provReqXML, String msisdn)
	{
		def vuiRequest = new XmlSlurper().parseText(provReqXML)
		
		VUI vui = new VUI();
		HDR hdr = new HDR();
		Payload payload = new Payload();
		ALIUpdateRequest aliUpdateRequest = new ALIUpdateRequest();
		
		String cpn = vuiRequest.Payload.ALIUpdateRequest?.@CPN.toString();
		if(cpn.length()>0)
		 aliUpdateRequest.cpn = cpn;
		else
		aliUpdateRequest.cpn = msisdn;
		aliUpdateRequest.externalKey=vuiRequest.Payload.ALIUpdateRequest?.ExternalKey.toString();
		aliUpdateRequest.externalKeyType=vuiRequest.Payload.ALIUpdateRequest?.ExternalKeyType.toString();
		aliUpdateRequest.hno=vuiRequest.Payload.ALIUpdateRequest.HNO.toString();
		aliUpdateRequest.hns=vuiRequest.Payload.ALIUpdateRequest?.HNS.toString();
		aliUpdateRequest.prd=vuiRequest.Payload.ALIUpdateRequest?.PRD.toString();
		aliUpdateRequest.stn=vuiRequest.Payload.ALIUpdateRequest.STN.toString();
		aliUpdateRequest.mcn=vuiRequest.Payload.ALIUpdateRequest.MCN.toString();
		aliUpdateRequest.sta=vuiRequest.Payload.ALIUpdateRequest.STA.toString();
		aliUpdateRequest.loc=vuiRequest.Payload.ALIUpdateRequest?.LOC.toString();
		aliUpdateRequest.sts=vuiRequest.Payload.ALIUpdateRequest?.STS.toString();
		aliUpdateRequest.pod=vuiRequest.Payload.ALIUpdateRequest?.POD.toString();
		aliUpdateRequest.nam=vuiRequest.Payload.ALIUpdateRequest.NAM.toString();
		aliUpdateRequest.lnam=vuiRequest.Payload.ALIUpdateRequest?.Lnam.toString();
		aliUpdateRequest.extn=vuiRequest.Payload.ALIUpdateRequest?.Extn.toString();
		aliUpdateRequest.exc=vuiRequest.Payload.ALIUpdateRequest?.EXC.toString();
		aliUpdateRequest.esn=vuiRequest.Payload.ALIUpdateRequest?.ESN.toString();
		aliUpdateRequest.mtn=vuiRequest.Payload.ALIUpdateRequest?.MTN.toString();
		aliUpdateRequest.ord=vuiRequest.Payload.ALIUpdateRequest?.ORD.toString();
		aliUpdateRequest.cpd=vuiRequest.Payload.ALIUpdateRequest?.CPD.toString();
		aliUpdateRequest.coi=vuiRequest.Payload.ALIUpdateRequest?.COI.toString();
		aliUpdateRequest.cpf=vuiRequest.Payload.ALIUpdateRequest.CPF.toString();
		aliUpdateRequest.cps=vuiRequest.Payload.ALIUpdateRequest?.CPS.toString();
		aliUpdateRequest.zip=vuiRequest.Payload.ALIUpdateRequest?.ZIP.toString();
		aliUpdateRequest.cus=vuiRequest.Payload.ALIUpdateRequest?.CUS.toString();
		aliUpdateRequest.cmt=vuiRequest.Payload.ALIUpdateRequest?.CMT.toString();
		aliUpdateRequest.lon=vuiRequest.Payload.ALIUpdateRequest?.LON.toString();
		aliUpdateRequest.lat=vuiRequest.Payload.ALIUpdateRequest?.LAT.toString();
		aliUpdateRequest.elv=vuiRequest.Payload.ALIUpdateRequest?.ELV.toString();
		aliUpdateRequest.tar=vuiRequest.Payload.ALIUpdateRequest?.TAR.toString();
		aliUpdateRequest.alt=vuiRequest.Payload.ALIUpdateRequest?.ALT.toString();
		aliUpdateRequest.subscriberID= vuiRequest.Payload.ALIUpdateRequest?.SubscriberID.toString();
		aliUpdateRequest.ver= vuiRequest.Payload.ALIUpdateRequest.@ver.toString();
		aliUpdateRequest.foc= vuiRequest.Payload.ALIUpdateRequest.@FOC.toString();
		aliUpdateRequest.recordLimit = vuiRequest.Payload.ALIUpdateRequest?.@recordLimit.toString();
		aliUpdateRequest.continuation = vuiRequest.Payload.ALIUpdateRequest?.@continuation.toString();
		
		CLS cls = new CLS();
		cls.typ=vuiRequest.Payload.ALIUpdateRequest.CLS.TYP.toString();
		cls.des=vuiRequest.Payload.ALIUpdateRequest.CLS?.DES.toString();
		aliUpdateRequest.cls= cls;
		
		TYS tys = new TYS();		
		tys.typ=vuiRequest.Payload.ALIUpdateRequest.TYS.TYP.toString();
		tys.des=vuiRequest.Payload.ALIUpdateRequest.TYS?.DES.toString();
		aliUpdateRequest.tys=tys;	
		
		payload.aliUpdateRequest=aliUpdateRequest;
		vui.payload=payload;
		
		hdr.acct="VUI-101401";
		//Need to verify and correct it
/*		hdr.rec= vuiRequest.HDR.@REC.toString();		
		hdr.clientVersion= vuiRequest.HDR.@ClientVersion.toString();*/
		hdr.rec= "1";
		hdr.clientVersion= "1.1";

		vui.hdr =hdr;
		return vui;
	}
	
	static void main(String args){
		def email = new StringBuffer()
		
		email << 'Transaction Id'.padRight(5) + '=' + 'TransID12345' + '\n'
		email << 'BAN'.padRight(5) + '=' + 'BAN1234' + '\n'
		
		println(email.toString())
	}

	public TransactionRequestData parseFulfillmentRequestXML(
			String requestXML) {
		def today = new Date()  //Set today to NOW		
		
		def transactionRequest = new XmlSlurper().parseText(requestXML)
		TransactionRequestData transactionRequestData = new TransactionRequestData();
		def transId = transactionRequest.TaskInfo.@Task_TransID.toString();
		
		transactionRequestData.systemName=transactionRequest.TaskInfo.@System.toString();
		transactionRequestData.taskTransId=transactionRequest.TaskInfo.@Task_TransID.toString();
 		transactionRequestData.payload = transactionRequest.SystemPayload?.toString();
		transactionRequestData.proxyEnabled = transactionRequest.TaskInfo.@ProxyEnabled.toString();
		transactionRequestData.url = transactionRequest.TaskInfo.@URL.toString();				
		transactionRequestData.masterTransId =transId.substring(0,transId.indexOf("_"));
		
		return transactionRequestData;
	}
	
}





