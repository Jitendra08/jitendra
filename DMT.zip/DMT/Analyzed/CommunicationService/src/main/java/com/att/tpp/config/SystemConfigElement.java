package com.att.tpp.config;

public class SystemConfigElement {
   public String system;
   public String login;
   public String passwd;
   public String bulkInd;
   public String evalFinalRespInd;
   public String nonCriticalInd;
   public String xsltFile;
   public String notifURL;
   public String sms;
   public String smsShortCode;
 
   SystemConfigElement ( String systemX ,
                         String loginX,
                         String passwdX,
                         String bulkIndX,
                         String evalFinalRespIndX,
                         String nonCriticalIndX,
                         String xsltFileX , 
                         String notifURLX,
                         String smsX,
                         String smsShortCodeX) {
       system  = systemX;
       login = loginX;
       passwd = passwdX;
       bulkInd = bulkIndX;
       evalFinalRespInd = evalFinalRespIndX;
       nonCriticalInd = nonCriticalIndX;
       xsltFile = xsltFileX ;
       notifURL = notifURLX ;
       sms = smsX ;
       smsShortCode = smsShortCodeX ;
 }

}
