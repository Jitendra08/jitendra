package com.att.tpp.service;

import java.io.IOException;
import java.math.BigDecimal;
import java.util.HashMap;

import javax.jms.JMSException;
import javax.xml.transform.TransformerConfigurationException;
import javax.xml.transform.TransformerFactoryConfigurationError;

import com.att.tpp.model.TransactionRequestData;




public interface CommunicationService {

	void loadInitialData() throws TransformerConfigurationException, TransformerFactoryConfigurationError, JMSException;

	boolean validateXML(String communicationRequestXML,
			String tppTransactionrequestxsd) throws IOException, Exception;

	
	boolean updateTaskStatus(String taskTransId);

	HashMap<String, String> postRequest(TransactionRequestData transactionRequestData, String provisioningRequestXML, String messageId) throws Exception;

	boolean insertTransCodes(TransactionRequestData transactionRequestData,
			String postResult, HashMap<String, String> postResultMap);

	boolean updateTimerTable(String postResult, String provisioningRequestXML,
			TransactionRequestData transactionRequestData);

	boolean verifyRetryExceeded(TransactionRequestData transactionRequestData,
			String messageId) throws JMSException;

	boolean updateConnectivityStatus(TransactionRequestData transactionRequestData,
			String url, String postResult);

	boolean updateInterfaceTable(String parseSystemName, String connectivityStatus);

	void generateAutoResponder(String provisioningRequestXML,
			boolean emailFlag, int httpResultCode);

	boolean postFulfillmentRequest(String postXML, String postURL, String proxyEnabled) throws IOException;
	
	boolean updateInvalidSystemTaskStatus(String taskTransId, String taskStatus,
			BigDecimal currTechRetryCount);
	
	


	
	
	
	

	
}
