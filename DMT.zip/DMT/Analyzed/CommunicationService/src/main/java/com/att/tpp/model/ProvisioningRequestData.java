package com.att.tpp.model;

import java.io.Serializable;
import java.util.Collection;



public class ProvisioningRequestData implements Serializable {

	private static final long serialVersionUID = 1L;
	
	private String transactionId;	
	private String msisdn;
	private String prevMsisdn;
	private String subscriberNumber;
	private String ban;	
	private String prevBan;	
	private String fan;
	private String prevFan;
	private String lastName;
	private String firstName;
	Collection<Products> productsCollection;
	
	
	public ProvisioningRequestData() {
	}


	/**
	 * @return the transactionId
	 */
	public String getTransactionId() {
		return transactionId;
	}


	/**
	 * @param transactionId the transactionId to set
	 */
	public void setTransactionId(String transactionId) {
		this.transactionId = transactionId;
	}


	/**
	 * @return the msisdn
	 */
	public String getMsisdn() {
		return msisdn;
	}


	/**
	 * @param msisdn the msisdn to set
	 */
	public void setMsisdn(String msisdn) {
		this.msisdn = msisdn;
	}


	/**
	 * @return the prevMsisdn
	 */
	public String getPrevMsisdn() {
		return prevMsisdn;
	}


	/**
	 * @param prevMsisdn the prevMsisdn to set
	 */
	public void setPrevMsisdn(String prevMsisdn) {
		this.prevMsisdn = prevMsisdn;
	}


	/**
	 * @return the subscriberNumber
	 */
	public String getSubscriberNumber() {
		return subscriberNumber;
	}


	/**
	 * @param subscriberNumber the subscriberNumber to set
	 */
	public void setSubscriberNumber(String subscriberNumber) {
		this.subscriberNumber = subscriberNumber;
	}


	/**
	 * @return the ban
	 */
	public String getBan() {
		return ban;
	}


	/**
	 * @param ban the ban to set
	 */
	public void setBan(String ban) {
		this.ban = ban;
	}


	/**
	 * @return the prevBan
	 */
	public String getPrevBan() {
		return prevBan;
	}


	/**
	 * @param prevBan the prevBan to set
	 */
	public void setPrevBan(String prevBan) {
		this.prevBan = prevBan;
	}


	/**
	 * @return the fan
	 */
	public String getFan() {
		return fan;
	}


	/**
	 * @param fan the fan to set
	 */
	public void setFan(String fan) {
		this.fan = fan;
	}


	/**
	 * @return the prevFan
	 */
	public String getPrevFan() {
		return prevFan;
	}


	/**
	 * @param prevFan the prevFan to set
	 */
	public void setPrevFan(String prevFan) {
		this.prevFan = prevFan;
	}


	/**
	 * @return the lastName
	 */
	public String getLastName() {
		return lastName;
	}


	/**
	 * @param lastName the lastName to set
	 */
	public void setLastName(String lastName) {
		this.lastName = lastName;
	}


	/**
	 * @return the firstName
	 */
	public String getFirstName() {
		return firstName;
	}


	/**
	 * @param firstName the firstName to set
	 */
	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}


	/**
	 * @return the productsCollection
	 */
	public Collection<Products> getProductsCollection() {
		return productsCollection;
	}


	/**
	 * @param productsCollection the productsCollection to set
	 */
	public void setProductsCollection(Collection<Products> productsCollection) {
		this.productsCollection = productsCollection;
	}




	
}
