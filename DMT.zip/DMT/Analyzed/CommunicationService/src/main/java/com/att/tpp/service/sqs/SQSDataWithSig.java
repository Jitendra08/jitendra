package com.att.tpp.service.sqs;

import java.net.URLEncoder;

public class SQSDataWithSig{
/****** START SET/GET METHOD, DO NOT MODIFY *****/
	protected String mesg = "";
	protected String expiryTime = "";
	protected String signature = "";
	protected String a_Key = "";
	protected String postContent = "";
	public String getmesg() {
		return mesg;
	}
	public void setmesg(String val) {
		mesg = val;
	}
	public String getexpiryTime() {
		return expiryTime;
	}
	public void setexpiryTime(String val) {
		expiryTime = val;
	}
	public String getsignature() {
		return signature;
	}
	public void setsignature(String val) {
		signature = val;
	}
	public String geta_Key() {
		return a_Key;
	}
	public void seta_Key(String val) {
		a_Key = val;
	}
	public String getpostContent() {
		return postContent;
	}
	public void setpostContent(String val) {
		postContent = val;
	}
/****** END SET/GET METHOD, DO NOT MODIFY *****/
	public SQSDataWithSig() {
	}
	public void invoke() throws Exception {
/* Available Variables: DO NOT MODIFY
	In  : String mesg
	In  : String expiryTime
	In  : String signature
	In  : String a_Key
	Out : String postContent
* Available Variables: DO NOT MODIFY *****/

String AKey = a_Key;

String ENCODE_VERSION = "UTF-8";

postContent = "Action=" + URLEncoder.encode("SendMessage", ENCODE_VERSION) + 
                "&MessageBody=" + URLEncoder.encode(mesg.trim(), ENCODE_VERSION).replace("+", "%20") +
                //"&MessageBody=" + URLEncoder.encode(EncodeHelper.encodeToBase64(mesg.getBytes()), ENCODE_VERSION) +
                "&AWSAccessKeyId=" + URLEncoder.encode(AKey, ENCODE_VERSION) +                 
                "&Version=" + URLEncoder.encode("2011-10-01", ENCODE_VERSION) + 
                "&Expires=" + URLEncoder.encode(expiryTime, ENCODE_VERSION) +
                "&SignatureVersion=" + URLEncoder.encode("2", ENCODE_VERSION) +
                "&SignatureMethod=" + URLEncoder.encode("HmacSHA256", ENCODE_VERSION) +
                "&Signature=" + URLEncoder.encode(signature, ENCODE_VERSION);}
}

