package com.att.tpp.service;

import java.beans.ConstructorProperties;
import java.io.IOException;
import java.io.OutputStreamWriter;
import java.net.ConnectException;
import java.net.InetSocketAddress;
import java.net.MalformedURLException;
import java.net.Proxy;
import java.net.SocketTimeoutException;
import java.net.URL;
import java.net.UnknownHostException;
import java.util.Scanner;

import javax.net.ssl.HttpsURLConnection;
import javax.net.ssl.SSLContext;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import com.att.tpp.config.InitializeSSLConnection;
import com.att.tpp.model.IntradoWSResponseData;
import com.att.tpp.model.TransactionRequestData;
import com.att.tpp.utils.ParseRequestData;
import com.att.tpp.xml.vui.model.VUI;

public class PostIntradoRequest {

	private static Logger intradoHTTPSLog = LogManager.getLogger(PostIntradoRequest.class);

	public PostIntradoRequest() {
	}

	private static String httpsURL;
	private static String vuiAccount;
	private static int intradoConnTimeout;
	
	
	
	
	@ConstructorProperties({"httpsURL", "vuiAccount", "intradoConnTimeout" })
	public PostIntradoRequest(String httpsURL, String vuiAccount, int intradoConnTimeout ){
		PostIntradoRequest.httpsURL=httpsURL;
		PostIntradoRequest.vuiAccount=vuiAccount;
		PostIntradoRequest.intradoConnTimeout=intradoConnTimeout;
	}	
	

	public static IntradoWSResponseData intradoHTTPSPost(VUI vuiRequestData, TransactionRequestData transactionRequestData) throws Exception {
		IntradoWSResponseData intradoWSResponseData = new IntradoWSResponseData();
		String intradoRequestXML=null;
		
		intradoHTTPSLog.info("Intrado URL to connect : " + httpsURL);
		HttpsURLConnection httpsconnection = null;
		String responseMessage = "Success";
		String proxyEnabled = transactionRequestData.getProxyEnabled();

		try {			
			// Setting the SSL connection			
			SSLContext sslContext = InitializeSSLConnection.getSslContext();

			// Setting Intrado URL
			URL url = new URL(null, httpsURL, new sun.net.www.protocol.https.Handler());
			HttpsURLConnection.setDefaultSSLSocketFactory(sslContext.getSocketFactory());
			intradoHTTPSLog.debug("Opening Connection:");

			// Setting the https parameters
			//httpsconnection = (HttpsURLConnection) url.openConnection();
			
			//Inserting logic to turn on or off the proxy setting
			if(InitializeSSLConnection.getUseProxy().equalsIgnoreCase("Y") || InitializeSSLConnection.getUseProxy().equalsIgnoreCase("TRUE")){
				if(proxyEnabled != null && proxyEnabled.equalsIgnoreCase("Y")){
					Proxy proxy = new Proxy(Proxy.Type.HTTP, new InetSocketAddress(InitializeSSLConnection.getProxyHost(), Integer.valueOf(InitializeSSLConnection.getProxyPort()).intValue()));
					httpsconnection = (HttpsURLConnection)url.openConnection(proxy);
				}
				else{
					httpsconnection = (HttpsURLConnection)url.openConnection();
				}
			}
			else{
				httpsconnection = (HttpsURLConnection)url.openConnection();
			}
			
/*			if (!(InitializeSSLConnection.isHostnameVerifierFlag())) {
				httpsconnection.setHostnameVerifier(new HostnameVerifier() {
					@Override
					public boolean verify(String arg0, SSLSession arg1) {
						return true;
					}
				});
			}*/
			//intradoHTTPSLog.info("intradoConnTimeout: " + intradoConnTimeout);
			httpsconnection.setDoInput(true);
			httpsconnection.setDoOutput(true);
			httpsconnection.setRequestMethod("POST");
			//httpsconnection.setConnectTimeout(120000); /* Commented this line as the ConnectionTimeout is hard coded and configured this value in server.properties to modify when required */
			httpsconnection.setConnectTimeout(intradoConnTimeout);
			httpsconnection.setRequestProperty("accept-charset", "UTF-8");
			httpsconnection.setRequestProperty("Content-Type", "text/xml");
			httpsconnection.setRequestProperty("SOAPAction", "/vui/AliUpdate");
			
			// create soap request xml
			VUISoapRequest vuiSoapRequest = new VUISoapRequest();
			intradoRequestXML = vuiSoapRequest.createVUISoapMessage(vuiRequestData,vuiAccount);
			intradoHTTPSLog.info("Created Intrdo Request XML : "+ intradoRequestXML);
			
			intradoHTTPSLog.info("Posting Intrado Request");
			OutputStreamWriter outputStreamWriter = new OutputStreamWriter(
					httpsconnection.getOutputStream());
			outputStreamWriter.write(intradoRequestXML);
			outputStreamWriter.flush();
			// Closes output stream only.
			outputStreamWriter.close();
			intradoHTTPSLog.debug("Post Complete!!!!");
			// Get the response code.
			int httpResponseCode = httpsconnection.getResponseCode(); 
			intradoHTTPSLog.info("HTTP Code : " + httpResponseCode);

			// Get response message.
			String responseMsg = httpsconnection.getResponseMessage();
			intradoHTTPSLog.info("HTTP Message : " + responseMsg);

			//Get Error and Input Stream Details for response
			intradoWSResponseData = getIntradoResponseData(httpsconnection, httpResponseCode, responseMessage);
			
		} catch (MalformedURLException mue){
			intradoHTTPSLog.info("MalformedURLException HTTP Post failed  to: "+ httpsURL + " with exception " +mue.getMessage());
			int httpResponseCode = 70010;
			responseMessage = mue.getMessage();
			intradoWSResponseData = getIntradoResponseData(httpsconnection, httpResponseCode, responseMessage);
		} catch (ConnectException ce){
			intradoHTTPSLog.info("ConnectException in HTTP Post failed  to Intrado : "+ ce.getMessage());
			int httpResponseCode = 70010;
			responseMessage = ce.getMessage();
			intradoWSResponseData = getIntradoResponseData(httpsconnection, httpResponseCode, responseMessage);
		} catch (SocketTimeoutException ste){
			intradoHTTPSLog.info("SocketTimeoutException in HTTP Post failed  to Intrado : "+ ste.getMessage());
			int httpResponseCode = 70010;
			responseMessage = ste.getMessage();
			intradoWSResponseData = getIntradoResponseData(httpsconnection, httpResponseCode, responseMessage);
		} catch (UnknownHostException uhe){
			intradoHTTPSLog.info("UnknownHostException in HTTP Post failed  to Intrado : "+uhe.getMessage());
			int httpResponseCode = 70010;
			responseMessage = uhe.getMessage();
			intradoWSResponseData = getIntradoResponseData(httpsconnection, httpResponseCode, responseMessage);
		} catch (Exception e) {
			intradoHTTPSLog.info("Exception in the Intrado request : " + e);
			int httpResponseCode = 70010;
			responseMessage = e.getMessage();
			intradoWSResponseData = getIntradoResponseData(httpsconnection, httpResponseCode, responseMessage);
		} finally {
			// This closes the actual connection to the server
			httpsconnection.disconnect();
			intradoHTTPSLog.info("Disconnected the connection");
		}
		
		  intradoWSResponseData.setTransactionId(transactionRequestData.getTaskTransId());
		  return intradoWSResponseData;
	}
	
	
	@SuppressWarnings("resource")
	private static IntradoWSResponseData getIntradoResponseData(HttpsURLConnection httpsconnection,
			int httpResponseCode, String responseMessage) throws IOException {
		
		String postSuccess = "PostSuccess";
		String postFailed = "PostFailed";
		IntradoWSResponseData intradoWSResponseData = new IntradoWSResponseData();
		ParseRequestData parseRequestData = new ParseRequestData();
		intradoHTTPSLog.info("Intrado Error httpResponseCode : " + httpResponseCode);
		Scanner scanner;
		String intradoResponseXML = null;

		if (httpResponseCode == 200) {
			scanner = new Scanner(httpsconnection.getInputStream());
			scanner.useDelimiter("\\Z");
			intradoResponseXML = scanner.next();
			intradoHTTPSLog.info("Intrado Response Stream: " + intradoResponseXML);					
			intradoWSResponseData = parseRequestData.parseIntradoResponse(intradoResponseXML);		
			intradoWSResponseData.setWsPostResult(postSuccess);
			
		} else {
			if(httpsconnection != null && httpsconnection.getErrorStream()!=null){
				scanner = new Scanner(httpsconnection.getErrorStream());
				scanner.useDelimiter("\\Z");
				intradoResponseXML = scanner.next();
			}
			intradoHTTPSLog.info("Intrado Error Response Stream : " + intradoResponseXML);
			//intradoWSResponseData.setRc1Code("70010");
			//intradoWSResponseData.setRc1Message("HTTP Post Failure");
			intradoWSResponseData.setRc1Code(String.valueOf(httpResponseCode));
			intradoWSResponseData.setRc1Message(responseMessage);
			intradoWSResponseData.setWsPostResult(postFailed);
		}
		
		
		return intradoWSResponseData;

	}



}