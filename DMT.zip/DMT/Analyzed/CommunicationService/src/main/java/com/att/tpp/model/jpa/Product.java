package com.att.tpp.model.jpa;

import java.io.Serializable;

import javax.persistence.*;

import java.math.BigDecimal;


/**
 * The persistent class for the PRODUCT database table.
 * 
 */
@Entity
@NamedQuery(name="Product.findAll", query="SELECT p FROM Product p")
public class Product implements Serializable {
	private static final long serialVersionUID = 1L;
	
	@Id
	@Column(name="\"ACTION\"")
	private String action;

	@Column(name="NUM_ATTRIBUTES")
	private BigDecimal numAttributes;
	
	@Id
	@Column(name="PRODUCT_ID")
	private String productId;
	
	@Id
	@Column(name="TASK_TRANSID")
	private String taskTransid;

	public Product() {
	}

	public String getAction() {
		return this.action;
	}

	public void setAction(String action) {
		this.action = action;
	}

	public BigDecimal getNumAttributes() {
		return this.numAttributes;
	}

	public void setNumAttributes(BigDecimal numAttributes) {
		this.numAttributes = numAttributes;
	}

	public String getProductId() {
		return this.productId;
	}

	public void setProductId(String productId) {
		this.productId = productId;
	}

	public String getTaskTransid() {
		return this.taskTransid;
	}

	public void setTaskTransid(String taskTransid) {
		this.taskTransid = taskTransid;
	}

}