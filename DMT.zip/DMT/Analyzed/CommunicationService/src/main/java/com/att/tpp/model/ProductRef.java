package com.att.tpp.model;

import java.io.Serializable;
import javax.persistence.*;
import java.util.Date;


/**
 * The persistent class for the PRODUCT_REF database table.
 * 
 */
@Entity
@Table(name="PRODUCT_REF")
@NamedQuery(name="ProductRef.findAll", query="SELECT p FROM ProductRef p")
public class ProductRef implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@Column(name="PRODUCT_ID")
	private String productId;

	@Column(name="APPID_FILTRATION_FLAG")
	private String appidFiltrationFlag;

	@Temporal(TemporalType.DATE)
	@Column(name="INSERT_DATE")
	private Date insertDate;

	private String kintana;

	@Column(name="LBS_IND")
	private String lbsInd;

	@Column(name="PRODUCT_DSC")
	private String productDsc;

	@Column(name="ROUTING_FLAG")
	private String routingFlag;

	@Column(name="WORK_REQ")
	private String workReq;

	public ProductRef() {
	}

	public String getProductId() {
		return this.productId;
	}

	public void setProductId(String productId) {
		this.productId = productId;
	}

	public String getAppidFiltrationFlag() {
		return this.appidFiltrationFlag;
	}

	public void setAppidFiltrationFlag(String appidFiltrationFlag) {
		this.appidFiltrationFlag = appidFiltrationFlag;
	}

	public Date getInsertDate() {
		return this.insertDate;
	}

	public void setInsertDate(Date insertDate) {
		this.insertDate = insertDate;
	}

	public String getKintana() {
		return this.kintana;
	}

	public void setKintana(String kintana) {
		this.kintana = kintana;
	}

	public String getLbsInd() {
		return this.lbsInd;
	}

	public void setLbsInd(String lbsInd) {
		this.lbsInd = lbsInd;
	}

	public String getProductDsc() {
		return this.productDsc;
	}

	public void setProductDsc(String productDsc) {
		this.productDsc = productDsc;
	}

	public String getRoutingFlag() {
		return this.routingFlag;
	}

	public void setRoutingFlag(String routingFlag) {
		this.routingFlag = routingFlag;
	}

	public String getWorkReq() {
		return this.workReq;
	}

	public void setWorkReq(String workReq) {
		this.workReq = workReq;
	}

}