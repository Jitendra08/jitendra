
package com.att.tpp.jms.listener;

import java.io.IOException;

import javax.annotation.PostConstruct;
import javax.jms.JMSException;
import javax.jms.Message;
import javax.jms.MessageListener;
import javax.jms.TextMessage;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;

import com.att.tpp.controller.CommunicationController;
import com.att.tpp.model.ProcessingResult;

/**
 * CommunicationQueueListener consume messages from transaction request queue and validate the request
 * if valid post to the partner.
 */

public class CommunicationQueueListener implements MessageListener
{

	private static final Logger communicationQueueListenerLog = LogManager.getLogger(CommunicationQueueListener.class);

	@Autowired
	private CommunicationController communicationController;
	
	@PostConstruct
	public void loadInitialData() throws Exception {
	  communicationQueueListenerLog.info("Setting Initial Configurations: Started. It will take few minutes.... please wait");
	  communicationController.loadInitialData();
	  communicationQueueListenerLog.info("Setting Initial Configurations: Completed");
	}


	/**
	 * Method implements JMS onMessage and acts as the entry
	 * point for messages consumed by Springs DefaultMessageListenerContainer.
	 * When DefaultMessageListenerContainer picks a message from the queue it
	 * invokes this method with the message payload.
	 */

	public void onMessage(Message communicationMessage)
	{
		communicationQueueListenerLog.debug("Received message from communication Queue [" + communicationMessage +"]");
		
		/* The message must be of type TextMessage */
		if (communicationMessage instanceof TextMessage)
		{
			try
			{
				String requestXML = ((TextMessage) communicationMessage).getText();
				
				communicationQueueListenerLog.info("WorkFlow request XML received : " + requestXML);				
				
				String messageId = communicationMessage.getStringProperty("swcTransactionId");		
				
				String fulfillmentIndicator = communicationMessage.getStringProperty("fulfillmentIndicator");
				
				if(fulfillmentIndicator!=null && fulfillmentIndicator!="" && fulfillmentIndicator.equals("YES")){			
					
					communicationQueueListenerLog.info("Inside the fulfillment Route.");
					ProcessingResult processingResult =communicationController.processFulfillmentResultRequest(requestXML, messageId);
				}else{						
					ProcessingResult processingResult =communicationController.processRequest(requestXML, messageId);
					communicationQueueListenerLog.info("MessageId :"+processingResult.getTppProvReq());
				}
				
				
			}
			catch (JMSException jmsException)
			{
				String errorMsg = "Error occurred while extracting message in TransformationListener ";
				communicationQueueListenerLog.error(errorMsg, jmsException);
				
			} catch (IOException e) {
				e.printStackTrace();
			} catch (Exception e) {
				e.printStackTrace();
			}
		}
		else
		{
			String errorMsg = "Message is not of expected type TextMessage in TransformationListener";
			communicationQueueListenerLog.error(errorMsg);
			throw new RuntimeException(errorMsg);
		}
	}


}