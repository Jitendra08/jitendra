package com.att.tpp.model;

import java.io.Serializable;

import javax.persistence.*;

import java.math.BigDecimal;


/**
 * The persistent class for the SYSTEM_REF database table.
 * 
 */
@Entity
@Table(name="SYSTEM_REF")
@NamedQuery(name="SystemRef.findAll", query="SELECT s FROM SystemRef s")
public class SystemRef implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@Column(name="SYSTEM_NAME")
	private String systemName;

	@Column(name="MAX_RETRY_CYCLE_COUNT")
	private BigDecimal maxRetryCycleCount;

	private String status;

	@Column(name="SYSTEM_DESC")
	private String systemDesc;

	@Column(name="USER_ID")
	private String userId;

	public SystemRef() {
	}

	public String getSystemName() {
		return this.systemName;
	}

	public void setSystemName(String systemName) {
		this.systemName = systemName;
	}

	public BigDecimal getMaxRetryCycleCount() {
		return this.maxRetryCycleCount;
	}

	public void setMaxRetryCycleCount(BigDecimal maxRetryCycleCount) {
		this.maxRetryCycleCount = maxRetryCycleCount;
	}

	public String getStatus() {
		return this.status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public String getSystemDesc() {
		return this.systemDesc;
	}

	public void setSystemDesc(String systemDesc) {
		this.systemDesc = systemDesc;
	}

	public String getUserId() {
		return this.userId;
	}

	public void setUserId(String userId) {
		this.userId = userId;
	}





}