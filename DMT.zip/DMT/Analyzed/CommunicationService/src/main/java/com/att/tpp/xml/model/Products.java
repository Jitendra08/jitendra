/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.att.tpp.xml.model;

import java.io.Serializable;
import java.util.Date;

/**
 *
 * @author SC9833
 */

public class Products implements Serializable{

	private static final long serialVersionUID = 1L;

	protected ProductsPK productsPK;
    private Date eventTimestamp;
    private String category;
    private TransactionCode transactionCode;

    public Products() {
    }

    public Products(ProductsPK productsPK) {
        this.productsPK = productsPK;
    }

    public Products(ProductsPK productsPK, Date eventTimestamp) {
        this.productsPK = productsPK;
        this.eventTimestamp = eventTimestamp;
    }

    public Products(String transactionId, String productId, String action) {
        this.productsPK = new ProductsPK(transactionId, productId, action);
    }

    public Products(ProductsPK productsPK, Date eventTimestamp, String category) {
        this.productsPK = productsPK;
        this.eventTimestamp = eventTimestamp;
        this.category = category;
    }

    /**
	 * @param productsPK
	 * @param eventTimestamp
	 * @param category
	 * @param transactionCode
	 */
	public Products(ProductsPK productsPK, Date eventTimestamp,
			String category, TransactionCode transactionCode) {
		this.productsPK = productsPK;
		this.eventTimestamp = eventTimestamp;
		this.category = category;
		this.transactionCode = transactionCode;
	}
	
	

	/**
	 * @param productsPK
	 * @param category
	 * @param transactionCode
	 */
	public Products(ProductsPK productsPK, String category, TransactionCode transactionCode) {
		this.productsPK = productsPK;
		this.category = category;
		this.transactionCode = transactionCode;
	}

	public ProductsPK getProductsPK() {
        return productsPK;
    }

    public void setProductsPK(ProductsPK productsPK) {
        this.productsPK = productsPK;
    }

    public Date getEventTimestamp() {
        return eventTimestamp;
    }

    public void setEventTimestamp(Date eventTimestamp) {
        this.eventTimestamp = eventTimestamp;
    }

    public String getCategory() {
        return category;
    }

    public void setCategory(String category) {
        this.category = category;
    }

  
    /**
	 * @return the transactionCode
	 */
	public TransactionCode getTransactionCode() {
		return transactionCode;
	}

	/**
	 * @param transactionCode the transactionCode to set
	 */
	public void setTransactionCode(TransactionCode transactionCode) {
		this.transactionCode = transactionCode;
	}

	
    /* (non-Javadoc)
	 * @see java.lang.Object#hashCode()
	 */
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result
				+ ((category == null) ? 0 : category.hashCode());
		result = prime * result
				+ ((eventTimestamp == null) ? 0 : eventTimestamp.hashCode());
		result = prime * result
				+ ((productsPK == null) ? 0 : productsPK.hashCode());
		result = prime * result
				+ ((transactionCode == null) ? 0 : transactionCode.hashCode());
		return result;
	}

	/* (non-Javadoc)
	 * @see java.lang.Object#equals(java.lang.Object)
	 */
	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Products other = (Products) obj;
		if (category == null) {
			if (other.category != null)
				return false;
		} else if (!category.equals(other.category))
			return false;
		if (eventTimestamp == null) {
			if (other.eventTimestamp != null)
				return false;
		} else if (!eventTimestamp.equals(other.eventTimestamp))
			return false;
		if (productsPK == null) {
			if (other.productsPK != null)
				return false;
		} else if (!productsPK.equals(other.productsPK))
			return false;
		if (transactionCode == null) {
			if (other.transactionCode != null)
				return false;
		} else if (!transactionCode.equals(other.transactionCode))
			return false;
		return true;
	}

	@Override
    public String toString() {
        return "javaandslurp.model.Products[ productsPK=" + productsPK + " ]";
    }

}
