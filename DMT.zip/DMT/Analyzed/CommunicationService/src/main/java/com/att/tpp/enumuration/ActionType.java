package com.att.tpp.enumuration;

public enum ActionType {

	 Add, Modify, Suspend, Resume, Cancel, None
}
