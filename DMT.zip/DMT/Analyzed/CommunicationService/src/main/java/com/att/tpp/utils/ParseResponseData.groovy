package com.att.tpp.utils

import com.att.tpp.model.Products
import com.att.tpp.model.ProductsPK
import com.att.tpp.model.ProvisioningResponseDynamic
import com.att.tpp.model.TransactionCode
import groovy.xml.MarkupBuilder
import java.util.Date





class ParseResponseData {
	
	def ProvisioningResponseDynamic getResponseData(String inXML, TransactionCode transCode){
		def provReq = new XmlSlurper().parseText(inXML)
		def now = new Date()  //Set today to NOW
		
		return new ProvisioningResponseDynamic(provReq.Header.@TransactionId.toString(), now, provReq.@System.toString(), provReq.Order.Account.@MSISDN.toString(),
			provReq.Header.Notification.@URL.toString(), inXML,"NEW", "MRC",provReq.Header.@ProvisioningCarrier.toString(),provReq.Header.@RoutingCarrier.toString(),
			provReq.Header.Sender.@Login.toString(),provReq.Header.Sender.@Password.toString(),
			provReq.Order.Products.Product.collect{new Products(new ProductsPK(provReq.Header.@TransactionId.toString(), it.@Id.toString(), it.@Action.toString()), now, it.@Category.toString(), new TransactionCode(transCode.majorCode, transCode.description, transCode.transactionCodeList))})			
	}
	
	
	def String buildProvRespXML(ProvisioningResponseDynamic provResp){
		def provRespXML = new StringWriter()
		def xml = new MarkupBuilder(provRespXML)
		
		xml.setDoubleQuotes(true)
		xml.mkp.xmlDeclaration(version: "1.0", encoding: "UTF-8")
		
		xml.ProvisioningResponse("xmlns:xsi":"http://www.w3.org/2001/XMLSchema-instance", "xsi:noNamespaceSchemaLocation":"ProvisioningResponse.xsd", System:provResp.getSystemName()){
			Header(TransactionId:provResp.getTransactionId(), ProvisioningCarrier:provResp.getProvisioningCarrier(), RoutingCarrier:provResp.getRoutingCarrier(), TimeStamp:provResp.getReceivedTimeStamp()){
				buildTransactionCode(xml, provResp)
			}
			Order(){
				buildAccountElement(xml, provResp.getMsisdn())
				buildProductsResponseElement(xml, provResp)
			}
		}
		
		return provRespXML.toString()
	}
	
	
	
}


