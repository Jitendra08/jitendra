package com.att.tpp.model;

import java.io.Serializable;

public class IntradoWSResponseData implements Serializable {

	private static final long serialVersionUID = 1L;

	private String transactionId;
	private String rc1Message;
	private String rc1Code;
	private String externalKey;
	private String wsPostResult;
	
	public String getTransactionId() {
		return transactionId;
	}
	public void setTransactionId(String transactionId) {
		this.transactionId = transactionId;
	}
	public String getRc1Message() {
		return rc1Message;
	}
	public void setRc1Message(String rc1Message) {
		this.rc1Message = rc1Message;
	}
	public String getRc1Code() {
		return rc1Code;
	}
	public void setRc1Code(String rc1Code) {
		this.rc1Code = rc1Code;
	}
	public String getExternalKey() {
		return externalKey;
	}
	public void setExternalKey(String externalKey) {
		this.externalKey = externalKey;
	}
	public String getWsPostResult() {
		return wsPostResult;
	}
	public void setWsPostResult(String wsPostResult) {
		this.wsPostResult = wsPostResult;
	}
	

}
