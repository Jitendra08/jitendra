package com.att.tpp.service;

import java.beans.ConstructorProperties;
import java.util.Enumeration;

import javax.jms.Connection;
import javax.jms.DeliveryMode;
import javax.jms.Destination;
import javax.jms.JMSException;
import javax.jms.MessageConsumer;
import javax.jms.MessageProducer;
import javax.jms.Queue;
import javax.jms.QueueBrowser;
import javax.jms.Session;
import javax.jms.TextMessage;

import org.apache.activemq.ActiveMQConnectionFactory;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;



public class OnHoldQueueService {

	private static Logger onHoldQueueServiceLog = LogManager.getLogger(OnHoldQueueService.class);
	
	private static String connectionTcpUrl; 
	private static String onHoldQueue;
	private static String transactionQueue;
		
	@ConstructorProperties({"connectionTcpUrl", "onHoldQueue", "transactionQueue" })
	public OnHoldQueueService(String connectionTcpUrl, String onHoldQueue, String transactionQueue){
			  this.connectionTcpUrl = connectionTcpUrl;
			  this.onHoldQueue = onHoldQueue; 
			  this.transactionQueue = transactionQueue; 
	}
	

	
	
	public static void onHoldProcess() throws JMSException {
		
		onHoldQueueServiceLog.info("Inside onHold Process started" + "Connection URL: "+connectionTcpUrl + " onHoldQueue:"+onHoldQueue);
		ActiveMQConnectionFactory factory = new ActiveMQConnectionFactory(connectionTcpUrl);
		Connection connection = factory.createConnection();
		connection.start();
		Session session = connection.createSession(false, Session.AUTO_ACKNOWLEDGE);

		Queue queue = session.createQueue(onHoldQueue);

		QueueBrowser queueBrowser = session.createBrowser(queue);
		Enumeration<?> e = queueBrowser.getEnumeration();
		int noOfMessageToConsume = 0;

		// count number of messages
		while (e.hasMoreElements()) {
			e.nextElement();
			noOfMessageToConsume++;
		}

		onHoldQueueServiceLog.info("No of messages in onHold queue " + noOfMessageToConsume +" of server :"+ connectionTcpUrl);
		
		if (noOfMessageToConsume > 0) {
			MessageConsumer consumer = session.createConsumer(queue);
			int messages = 0;
			do {
				//Read message from onHold queue.
				TextMessage tppRequestXML = (TextMessage) consumer.receive();
				String swcTransId = tppRequestXML.getStringProperty("swcTransactionId");
				
				String requestXML = ((TextMessage) tppRequestXML).getText();
				
				//Read message from onHold queue.
				onHoldQueueServiceLog.debug("onHold message #" + tppRequestXML.getText());				
				// Create the destination (QueueName)
				Destination destination = session.createQueue(transactionQueue);
				// Create a MessageProducer from the Session to the Queue
				MessageProducer producer = session.createProducer(destination);
				producer.setDeliveryMode(DeliveryMode.PERSISTENT);
				// Create a messages.
				TextMessage message = session.createTextMessage(requestXML.toString());
				message.setStringProperty("swcTransactionId", swcTransId);
				producer.send(message);	
				onHoldQueueServiceLog.info("Message succesfully processed from onhold queue to communcation queue :"+swcTransId);
				messages++;
				
			} while (messages < noOfMessageToConsume);
		}
		// Clean up
		session.close();
		connection.stop();
	}
	
	
	
}
