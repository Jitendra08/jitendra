package com.att.tpp.jms.sender;

import javax.jms.JMSException;
import javax.jms.Message;
import javax.jms.Queue;
import javax.jms.Session;
import javax.jms.TextMessage;

import org.apache.log4j.Logger;
import org.springframework.jms.core.JmsTemplate;
import org.springframework.jms.core.MessageCreator;

/**
 * 
 * The FinalResponseQueueSender class uses the injected JMSTemplate to send a message
 * to finalResponseQueue. 
 */
public class FinalResponseQueueSender
{
	private JmsTemplate jmsTemplate;
	private Queue finalResponseQueue;
	private static final Logger finalResponseSenderLog = Logger.getLogger(FinalResponseQueueSender.class);
	private final static String swcTransactionId = "swcTransactionId";
	
	/**
	 * Sends message to finalResponseQueue using JMS Template.
	 * @param provReqXML the message_p
	 * @throws JMSException the jms exception
	 */
	public void sendMessage(final String finalResponseXML, final String messageId) throws JMSException
	{
		
		finalResponseSenderLog.info("Sending FinalResponseNotification Message From Communication Service to FinalResponse Service");

		jmsTemplate.send(this.finalResponseQueue, new MessageCreator(){

			@Override
			public Message createMessage(Session session) throws JMSException {
				TextMessage message = session.createTextMessage(finalResponseXML.toString());
				message.setStringProperty(swcTransactionId,messageId.toString());				
				return message;
			}
			
		});		
		
	}
	/**
	 * Sets the jms template.
	 *
	 * @param template the jms template
	 */
	public void setJmsTemplate(JmsTemplate tmpl)
	{
		this.jmsTemplate = tmpl;
	}

	/**
	 * @param finalResponseQueue the finalResponseQueue to set
	 */
	public void setFinalResponseQueue(Queue finalResponseQueue) {
		this.finalResponseQueue = finalResponseQueue;
	}

	
}