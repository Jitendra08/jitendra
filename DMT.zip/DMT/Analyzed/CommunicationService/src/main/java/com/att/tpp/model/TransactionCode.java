/**
 * 
 */
package com.att.tpp.model;

import java.io.Serializable;
import java.util.Collection;

/**
 * @author SC9833
 *
 */
public class TransactionCode implements Serializable {

	/**
	 * Use this to generate the TransactionCode with a Collection of TransactionCodeList in the
	 * Provisioning Response.
	 */
	
	private static final long serialVersionUID = 1L;
	
	private long majorCode;
	private String description;
	private Collection<TransactionCodeList> transactionCodeList;
	
	public TransactionCode() {
		// TODO Auto-generated constructor stub
	}

	/**
	 * @param majorCode
	 * @param description
	 * @param transactionCodeList
	 */
	public TransactionCode(long majorCode, String description,
			Collection<TransactionCodeList> transactionCodeList) {
		this.majorCode = majorCode;
		this.description = description;
		this.transactionCodeList = transactionCodeList;
	}
	
	/**
	 * @param majorCode
	 * @param description
	 */
	public TransactionCode(long majorCode, String description) {
		this.majorCode = majorCode;
		this.description = description;
	}

	/**
	 * @return the majorCode
	 */
	public long getMajorCode() {
		return majorCode;
	}

	/**
	 * @param majorCode the majorCode to set
	 */
	public void setMajorCode(long majorCode) {
		this.majorCode = majorCode;
	}

	/**
	 * @return the description
	 */
	public String getDescription() {
		return description;
	}

	/**
	 * @param description the description to set
	 */
	public void setDescription(String description) {
		this.description = description;
	}

	/**
	 * @return the transactionCodeList
	 */
	public Collection<TransactionCodeList> getTransactionCodeList() {
		return transactionCodeList;
	}

	/**
	 * @param transactionCodeList the transactionCodeList to set
	 */
	public void setTransactionCodeList(
			Collection<TransactionCodeList> transactionCodeList) {
		this.transactionCodeList = transactionCodeList;
	}

	/* (non-Javadoc)
	 * @see java.lang.Object#hashCode()
	 */
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result
				+ ((description == null) ? 0 : description.hashCode());
		result = prime * result + (int) (majorCode ^ (majorCode >>> 32));
		result = prime
				* result
				+ ((transactionCodeList == null) ? 0 : transactionCodeList
						.hashCode());
		return result;
	}

	/* (non-Javadoc)
	 * @see java.lang.Object#equals(java.lang.Object)
	 */
	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		TransactionCode other = (TransactionCode) obj;
		if (description == null) {
			if (other.description != null)
				return false;
		} else if (!description.equals(other.description))
			return false;
		if (majorCode != other.majorCode)
			return false;
		if (transactionCodeList == null) {
			if (other.transactionCodeList != null)
				return false;
		} else if (!transactionCodeList.equals(other.transactionCodeList))
			return false;
		return true;
	}

}
