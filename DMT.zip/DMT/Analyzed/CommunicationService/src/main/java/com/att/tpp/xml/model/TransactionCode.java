package com.att.tpp.xml.model;

import java.util.Collection;

public class TransactionCode {

    private boolean tcFinal;  //This is the "final" attribute in the transactionCode element.  Can't use "final" since it is a java keyword.
    private long majorCode;
    private String description;
    private Collection<TransactionCodeList> transactionCodeList;   
        
    /**
	 * @param majorCode
	 * @param description
	 */
	public TransactionCode(long majorCode, String description) {
		this.majorCode = majorCode;
		this.description = description;
	}

	/**
	 * @param majorCode
	 * @param description
	 * @param transactionCodeList
	 */
	public TransactionCode(long majorCode, String description,
			Collection<TransactionCodeList> transactionCodeList) {
		this.majorCode = majorCode;
		this.description = description;
		this.transactionCodeList = transactionCodeList;
	}

	/**
	 * @param tcFinal  This is the final attribute in the transactionCode element.  Can't use "final" since it is a java keyword.
	 * @param majorCode
	 * @param description
	 * @param transactionCodeList
	 */
	public TransactionCode(boolean tcFinal, long majorCode, String description,
			Collection<TransactionCodeList> transactionCodeList) {
		this.tcFinal = tcFinal;
		this.majorCode = majorCode;
		this.description = description;
		this.transactionCodeList = transactionCodeList;
	}

	public TransactionCode() {
		// TODO Auto-generated constructor stub
	}

	/**
	 * @return the tcFinal
	 */
	public boolean isTcFinal() {
		return tcFinal;
	}

	/**
	 * @param tcFinal the tcFinal to set
	 */
	public void setTcFinal(boolean tcFinal) {
		this.tcFinal = tcFinal;
	}

	/**
	 * @return the majorCode
	 */
	public long getMajorCode() {
		return majorCode;
	}

	/**
	 * @param majorCode the majorCode to set
	 */
	public void setMajorCode(long majorCode) {
		this.majorCode = majorCode;
	}

	/**
	 * @return the description
	 */
	public String getDescription() {
		return description;
	}

	/**
	 * @param description the description to set
	 */
	public void setDescription(String description) {
		this.description = description;
	}

	/**
	 * @return the transactionCodeList
	 */
	public Collection<TransactionCodeList> getTransactionCodeList() {
		return transactionCodeList;
	}

	/**
	 * @param transactionCodeList the transactionCodeList to set
	 */
	public void setTransactionCodeList(Collection<TransactionCodeList> transactionCodeList) {
		this.transactionCodeList = transactionCodeList;
	}

}
