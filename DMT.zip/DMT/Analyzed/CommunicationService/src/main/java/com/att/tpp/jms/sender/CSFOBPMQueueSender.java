package com.att.tpp.jms.sender;

import javax.jms.JMSException;
import javax.jms.Message;
import javax.jms.Queue;
import javax.jms.Session;
import javax.jms.TextMessage;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.jms.core.JmsTemplate;
import org.springframework.jms.core.MessageCreator;

/**
 * 
 * The CSFOBPMQueueSender class uses the injected JMSTemplate to send a message
 * to CSFOBPMQueue. 
 */
public class CSFOBPMQueueSender
{
	private JmsTemplate jmsTemplate;
	private Queue csfobpmRequestQueue; 
	private static final Logger csfobpmRequestSenderLog = LogManager.getLogger(CSFOBPMQueueSender.class);
	private final static String csfobpmTransactionId = "csfobpmTransactionId";
	
	/**
	 * Sends message to CSFOBPMQueueSender using JMS Template.
	 * @param csiTransactionId 
	 * @param provReqXML the message_p
	 * @throws JMSException the jms exception
	 */
	public void sendMessage(final String requestXML, final String csfobpmTrxId) throws JMSException
	{
		
		csfobpmRequestSenderLog.info("Sending ProvisioningResponse Message From Communication Service to CSFOBPM Service");

		jmsTemplate.send(this.csfobpmRequestQueue, new MessageCreator(){

			@Override
			public Message createMessage(Session session) throws JMSException {
				TextMessage message = session.createTextMessage(requestXML.toString());
				message.setStringProperty(csfobpmTransactionId,csfobpmTrxId.toString());
				return message;
			}
			
		});		
		
	}
	/**
	 * Sets the jms template.
	 *
	 * @param template the jms template
	 */
	public void setJmsTemplate(JmsTemplate tmpl)
	{
		this.jmsTemplate = tmpl;
	}
	
	
	public void setCsfobpmRequestQueue(Queue csfobpmRequestQueue) {
		this.csfobpmRequestQueue = csfobpmRequestQueue;
	}
	
	

	
}