package com.att.tpp.model;

import java.io.Serializable;

/**
 *
 * @author sg625m
 */

public class EmailRequestData implements Serializable  {
	
	private static final long serialVersionUID = 1L;
	
    String to;
    String from;
    String host;
    String subject;
    String provisioningRequestData;
    
	public String getTo() {
		return to;
	}
	public void setTo(String to) {
		this.to = to;
	}
	public String getFrom() {
		return from;
	}
	public void setFrom(String from) {
		this.from = from;
	}
	public String getHost() {
		return host;
	}
	public void setHost(String host) {
		this.host = host;
	}
	public String getSubject() {
		return subject;
	}
	public void setSubject(String subject) {
		this.subject = subject;
	}
	public String getProvisioningRequestData() {
		return provisioningRequestData;
	}
	public void setProvisioningRequestData(String provisioningRequestData) {
		this.provisioningRequestData = provisioningRequestData;
	}
    
}
