package com.att.tpp.config;



class ProvisionSeqElement 
{
    public String prodId;
    public String action;
    public String system;
    public int batch;
    public String isOnAutoResponder;
    public String carrier;
    


    /**
     * The <code>ProvisionSeqElement</code> method is a constructor.
     *
     */
    public ProvisionSeqElement(String prodIdX ,String actionX ,String systemNameX, int batchNumX , String isOnAutoResponderX , String carrierNameX) {
       prodId = prodIdX;
       action = actionX;
       system = systemNameX;
       batch = batchNumX;
       isOnAutoResponder = isOnAutoResponderX;
       carrier = carrierNameX;
    }


   public String toString () {
      return( "prodId " +  prodId + 
              ", action " +  action +
              ", system " + system +
              ", batch " +  batch +
              ", isOnAutoResponder " +  isOnAutoResponder +
              ", carrier " +  carrier );

   }
}



 
