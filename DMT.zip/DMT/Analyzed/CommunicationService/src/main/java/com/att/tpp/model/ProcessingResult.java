package com.att.tpp.model;

import java.io.Serializable;
import java.util.List;

/**
 *
 * @author sg625m
 */

public class ProcessingResult implements Serializable  {
	
	private static final long serialVersionUID = 1L;
	
    String systemName;
	boolean isPersisted=false;
	boolean isValidRequest=false;
	private String messageId;
	private String masterTransId;
	private String subscriberNumber;
	private List<String> invalidFeatures;	
	private String tppProvReq;
	boolean isValidTPPProvReq=false;

	
	//WorkFlow
	boolean isValidProductExist=false;
	boolean isCompleteNotification=false;
	boolean isValidCompleteNotification=false;
	String completeNotificaitonXML;
	
	public boolean isValidRequest() {
		return isValidRequest;
	}
	public void setValidRequest(boolean isValidRequest) {
		this.isValidRequest = isValidRequest;
	}
	public String getSubscriberNumber() {
		return subscriberNumber;
	}
	public void setSubscriberNumber(String subscriberNumber) {
		this.subscriberNumber = subscriberNumber;
	}
	public List<String> getInvalidFeatures() {
		return invalidFeatures;
	}
	public void setInvalidFeatures(List<String> invalidFeatures) {
		this.invalidFeatures = invalidFeatures;
	}
	public String getTppProvReq() {
		return tppProvReq;
	}
	public void setTppProvReq(String tppProvReq) {
		this.tppProvReq = tppProvReq;
	}
	public boolean isValidTPPProvReq() {
		return isValidTPPProvReq;
	}
	public void setValidTPPProvReq(boolean isValidTPPProvReq) {
		this.isValidTPPProvReq = isValidTPPProvReq;
	}
	public String getMessageId() {
		return messageId;
	}
	public void setMessageId(String messageId) {
		this.messageId = messageId;
	}
	public boolean isPersisted() {
		return isPersisted;
	}
	public void setPersisted(boolean isPersisted) {
		this.isPersisted = isPersisted;
	}
	public boolean isValidProductExist() {
		return isValidProductExist;
	}
	public void setValidProductExist(boolean isValidProductExist) {
		this.isValidProductExist = isValidProductExist;
	}
	public boolean isCompleteNotification() {
		return isCompleteNotification;
	}
	public void setCompleteNotification(boolean isCompleteNotification) {
		this.isCompleteNotification = isCompleteNotification;
	}
	public static long getSerialversionuid() {
		return serialVersionUID;
	}
	public boolean isValidCompleteNotification() {
		return isValidCompleteNotification;
	}
	public void setValidCompleteNotification(boolean isValidCompleteNotification) {
		this.isValidCompleteNotification = isValidCompleteNotification;
	}
	public String getMasterTransId() {
		return masterTransId;
	}
	public void setMasterTransId(String masterTransId) {
		this.masterTransId = masterTransId;
	}
	public String getCompleteNotificaitonXML() {
		return completeNotificaitonXML;
	}
	public void setCompleteNotificaitonXML(String completeNotificaitonXML) {
		this.completeNotificaitonXML = completeNotificaitonXML;
	}
	public String getSystemName() {
		return systemName;
	}
	public void setSystemName(String systemName) {
		this.systemName = systemName;
	}
}
