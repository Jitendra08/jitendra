package com.att.tpp.dao;

import java.math.BigDecimal;
import java.sql.Timestamp;
import java.util.Calendar;
import java.util.Iterator;
import java.util.List;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.hibernate.HibernateException;
import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.type.StandardBasicTypes;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.att.tpp.model.RetryConfiguration;
import com.att.tpp.model.SystemConfiguration;
import com.att.tpp.model.SystemRef;
import com.att.tpp.model.jpa.ProvisioningRequest;
import com.att.tpp.model.jpa.ProvisioningTask;
import com.att.tpp.model.jpa.Timer;
import com.att.tpp.model.jpa.TransCode;



@Repository("communicationDao")
public class CommunicationDaoImpl implements CommunicationDao {
	
	private static final Logger communicationDaoImpl = LogManager.getLogger(CommunicationDaoImpl.class);
	
	private static String postSuccessful = "Post Successful / Waiting System Response";

	@Autowired
	private SessionFactory sessionFactoryConfig;
	
	@Autowired
	private SessionFactory sessionFactoryData;
	
	@Autowired
	private SessionFactory sessionFactoryArchive;

	@SuppressWarnings("unchecked")
	@Override
	public List<SystemConfiguration> getSytemConfiguartionList() {
		communicationDaoImpl.debug("Inside the getSytemConfiguartionList");
		List<SystemConfiguration> systemConfigurationList=null;
		systemConfigurationList = (List<SystemConfiguration>) sessionFactoryConfig
				//.openSession()
				.getCurrentSession()
				.createQuery("from SystemConfiguration")
				.list();			
		//sessionFactoryConfig.close();
		return systemConfigurationList;
	}
	
	@SuppressWarnings("unchecked")
	@Override
	public List<RetryConfiguration> getRetryConfigurationList() {
		communicationDaoImpl.debug("Inside the getRetryConfiguartionList");
		List<RetryConfiguration> retryConfigurationList=null;
		retryConfigurationList = (List<RetryConfiguration>) sessionFactoryConfig
				//.openSession()
				.getCurrentSession()
				.createQuery("from RetryConfiguration")
				.list();			
		//sessionFactoryConfig.close();
		return retryConfigurationList;
	}


	
	@SuppressWarnings("unchecked")
	@Override
	public List<SystemRef> getSytemRefList() {
		communicationDaoImpl.debug("Inside the getSytemRefList");
		List<SystemRef> systemRef=null;
		systemRef = (List<SystemRef>) sessionFactoryConfig
				//.openSession()
				.getCurrentSession()
				.createQuery("from SystemRef")
				.list();			
		//sessionFactoryConfig.close();
		return systemRef;
	}


	@Override
	public boolean updateInterfaceTable(String interfaceName, String connectivityStatus) {
		communicationDaoImpl.debug("Inside communicationDaoImpl updateInterfaceForOnHold method");		
		int success = 0;
		Query queryUpdateInterface = sessionFactoryArchive.getCurrentSession()
				.createQuery("update Interface i set i.connectivityStatus = :connectivityStatus where i.interfaceName = :interfaceName");
		queryUpdateInterface.setParameter("connectivityStatus", connectivityStatus);
		queryUpdateInterface.setParameter("interfaceName",interfaceName.trim());		
		try{
			success = queryUpdateInterface.executeUpdate();	
			sessionFactoryData.getCurrentSession().flush();
		}
		catch(HibernateException he){
			communicationDaoImpl.error("Hibernate Exception occured in updateInterfaceTable method: " + he.getMessage());
		}
		
		return isSuccess(success);	
	}
	
	
	@SuppressWarnings("unchecked")
	@Override
	public boolean updateTaskStatus(String taskTansId) {
		int result = 0;
		try {

			List<ProvisioningTask> provisioningTaskList = null;
			provisioningTaskList = (List<ProvisioningTask>) sessionFactoryData
					.getCurrentSession()
					.createQuery(
							"from ProvisioningTask pt where pt.id.taskTransid  = :taskTransid")
					.setParameter("taskTransid", taskTansId).list();

			if (provisioningTaskList.size() > 0) {
/* Scenario of Prov task status being updated multiple times from Errored to post successful due to backlog in Comm. svc *
 * This scenario should not happen now because we moved Tech retry count update to retry service  */				
//				ProvisioningTask provisioningTask = provisioningTaskList.get(0); /* debug */
//				communicationDaoImpl.info("Inside Comm. svc update task status: "+provisioningTask.getTaskStatus());
//				if(provisioningTask.getTaskStatus().equals("Errored")){communicationDaoImpl.info("Prov Task with status: "+provisioningTask.getTaskStatus()+" DoNot update task to post successful"); /* debug */ }
//				else{ /* debug */
//					communicationDaoImpl.info("Prov Task with status: "+provisioningTask.getTaskStatus()+" updating task to post successful");
					result = sessionFactoryData
						.getCurrentSession()
						.createQuery(
								"update ProvisioningTask pt set pt.taskStatus = :taskStatus where "
										+ "pt.id.taskTransid = :taskTransid")
						.setParameter("taskTransid", taskTansId)
						.setParameter("taskStatus", postSuccessful)
						.executeUpdate();
				sessionFactoryData.getCurrentSession().flush();
//				} /* debug */
			}

			return isSuccess(result);
		} catch (HibernateException he) {
			communicationDaoImpl
					.error("Hibernate Exception occured occured updating ProvisioningTask Table: "
							+ he.getMessage());
			return isSuccess(result);
		}

	}
	
	private Boolean isSuccess(int success){
		if (success > 0) {
			return true;
		} 
		else {
			return false;
		}		
	}


	@SuppressWarnings("unchecked")
	@Override
	public List<ProvisioningRequest> queryProvisioningRequest(String masterTransId) {
		communicationDaoImpl.debug("Inside the getProvisoningRequestList");
		List<ProvisioningRequest> provisioningRequestList=null;
		provisioningRequestList = (List<ProvisioningRequest>) sessionFactoryData
				.getCurrentSession()
				.createQuery("from ProvisioningRequest pr where pr.masterTransid = :masterTransId")
		        .setParameter("masterTransId", masterTransId)
				.list();			
		  
		return provisioningRequestList;
	}


/*	@Override
	public Boolean insertTransCodes(List<TransCode> transCodeList) {
		communicationDaoImpl.debug("Inside the insertTransCodes");
		try {
			for (TransCode transCode : transCodeList) {			
				sessionFactoryData.getCurrentSession().saveOrUpdate(transCode);
				sessionFactoryData.getCurrentSession().flush();					
			}
			return true;
			
		} catch (HibernateException he) {
			communicationDaoImpl
					.error("Hibernate Exception occured occured inserting into TransCodes Table: "
							+ he.getMessage());
			return false;
		}
	}*/
	
	
	@Override
	public Boolean insertTransCodes(List<TransCode> transCodeList) {
		
			
			Session session = sessionFactoryData.openSession();
			//Transaction tx = session.beginTransaction();
			try {
				Iterator<TransCode> transCodesForInsertIterator = transCodeList.iterator();
				while (transCodesForInsertIterator.hasNext()) {
					TransCode transCode = transCodesForInsertIterator.next();
					sessionFactoryData.getCurrentSession().save(transCode);
				}
				session.flush();
				session.clear();				
			//	tx.commit();
			//	session.close();
			} catch (HibernateException he) {
				communicationDaoImpl
				.error("Hibernate Exception occured occured inserting into TransCodes Table: "
						+ he.getMessage());
				he.printStackTrace();
				return false;
			}
			return true;
		
	}


	@SuppressWarnings("unchecked")
	@Override
	public List<ProvisioningTask> queryProvisioningTasks(String taskTransId) {
		communicationDaoImpl.debug("Inside the queryProvisioningTasks");
		List<ProvisioningTask> provisioningTaskList=null;
		provisioningTaskList = (List<ProvisioningTask>) sessionFactoryData
				.getCurrentSession()
				.createQuery("from ProvisioningTask pt where pt.id.taskTransid = :taskTransId")
		        .setParameter("taskTransId", taskTransId)
				.list();			
		  
		return provisioningTaskList;
	}


	@SuppressWarnings("unchecked")
	@Override
	public List<Timer> queryTimerTable(String taskTransId) {
		communicationDaoImpl.debug("Inside the queryTimerTable");
		List<Timer> TimerList=null;
		TimerList = (List<Timer>) sessionFactoryData
				.getCurrentSession()
				.createQuery("from Timer t where t.id.taskTransid = :taskTransId")
		        .setParameter("taskTransId", taskTransId)
				.list();			
		  
		return TimerList;
	}


	@Override
	public boolean updateTimer(String taskTransId, String timerState, int timerDuration, String payLoad, String payLoadOverflow) {

		communicationDaoImpl.debug("Inside communicationDaoImpl updateTimer method");		
		int success = 0;

		Calendar expiryTime = getCalendarTimeStamp();
		expiryTime.add(Calendar.MILLISECOND,timerDuration);		
		Calendar currentTimeStamp = getCalendarTimeStamp();	
		
		
		Query queryUpdateTimer = sessionFactoryData.getCurrentSession()
				.createQuery("update Timer t set t.id.timerState = :timerState, t.timerDuration = :timerDuration, t.retryInd = :retryInd, t.expiryTime = :expiryTime, t.creationTime = :creationTime, t.payload = :payload, t.payloadOverflow = :payloadOverflow"
						+ " where t.id.taskTransid = :taskTransId");
		queryUpdateTimer.setParameter("taskTransId", taskTransId);
		queryUpdateTimer.setParameter("timerState",timerState);
		queryUpdateTimer.setParameter("timerDuration",timerDuration);
		queryUpdateTimer.setParameter("retryInd","Y");
		queryUpdateTimer.setParameter("expiryTime",expiryTime.getTime());		
		queryUpdateTimer.setParameter("creationTime",currentTimeStamp.getTime());
		queryUpdateTimer.setParameter("payload",payLoad);		
		queryUpdateTimer.setParameter("payloadOverflow",payLoadOverflow);
		try{
			success = queryUpdateTimer.executeUpdate();		
			sessionFactoryData.getCurrentSession().flush();
			sessionFactoryData.getCurrentSession().clear();
			communicationDaoImpl.info("Inside communicationDaoImpl updateTimer method, taskTransId: "+taskTransId+" timerState : "+timerState+" timerDuration : "+timerDuration);
		}
		catch(HibernateException he){
			communicationDaoImpl.error("Hibernate Exception occured in updateTimer method: " + he.getMessage());
			return false;
		}
		
		return isSuccess(success);	
	}
	
	

	@Override
	public boolean deleteFromTimer(String taskTransId) {
	    int success = 0;
	    if(taskTransId!=null){
			Query deleteTimerQuery = sessionFactoryData.getCurrentSession()
	                   .createQuery("delete from Timer t where t.id.taskTransid = :taskTransid");
			deleteTimerQuery.setParameter("taskTransid",taskTransId);
		
		try{
			success = deleteTimerQuery.executeUpdate();		
			sessionFactoryData.getCurrentSession().flush();
			sessionFactoryData.getCurrentSession().clear();
		}
		catch(HibernateException he){
			communicationDaoImpl.error("Hibernate Exception occured in the responseDaoImpl deleteFromTimer method :"+he);
			return false;
		}
	}
	return isSuccess(success);	
	
	}
	
	
	public Calendar getCalendarTimeStamp() {
		communicationDaoImpl.debug("Inside the getCurrentTimeStamp");
		Calendar calendar = Calendar.getInstance();
		try {
			@SuppressWarnings("deprecation")
			Timestamp timestamp = (Timestamp) sessionFactoryData
					.getCurrentSession()
					.createSQLQuery("select sysdate param from dual")
					.addScalar("param", StandardBasicTypes.TIMESTAMP).uniqueResult();

			calendar.setTimeInMillis(timestamp.getTime());
		} catch (Exception e) {
			communicationDaoImpl
					.info("Exception occured in getCalendarTimeStamp method");
		}
		return calendar;
	}


	@Override
	public boolean insertTimer(Timer timer) {
		communicationDaoImpl.debug("Inside communicationDaoImpl insertTimer method");
		try {
			sessionFactoryData.getCurrentSession().saveOrUpdate(timer);				
			sessionFactoryData.getCurrentSession().flush();
			sessionFactoryData.getCurrentSession().clear();
			communicationDaoImpl.info("Inside communicationDaoImpl updateTimer method, taskTransId: "+timer.getId().getTaskTransid()+" timerState : "+timer.getId().getTimerState()+" timerDuration : "+timer.getTimerDuration());
			return true;
		}catch (HibernateException e) {
			communicationDaoImpl.error("Exception occured in the communicationDaoImpl insertTimer method :"+e);
			e.printStackTrace();
			return false;
		}
	}


	@Override
	public boolean updatePostFailedTaskStatus(String taskTransId,
			String taskStatus, BigDecimal currTechRetryCount) {
		int success = 0;
		try {
			
			success = sessionFactoryData
					.getCurrentSession()
					.createQuery(
							"update ProvisioningTask pt set pt.taskStatus = :taskStatus, pt.currTechRetryCount = :currTechRetryCount"
							+ " where pt.id.taskTransid = :taskTransId")
					.setParameter("taskTransId", taskTransId)
					.setParameter("taskStatus", taskStatus)
					.setParameter("currTechRetryCount", currTechRetryCount)
					.executeUpdate();
			sessionFactoryData.getCurrentSession().flush();
			sessionFactoryData.getCurrentSession().clear();
			communicationDaoImpl.info("ProvTask : "+taskTransId+" Status updated to : "+taskStatus);
			return isSuccess(success);
		} catch (HibernateException he) {
			communicationDaoImpl.error("Hibernate Exception occured in updatePostFailedTaskStatus method: "
							+ he.getMessage());
			return isSuccess(success);
		}
	}










	
	

}
	