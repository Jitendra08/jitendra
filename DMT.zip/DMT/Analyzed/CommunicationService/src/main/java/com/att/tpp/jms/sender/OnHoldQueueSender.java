package com.att.tpp.jms.sender;

import javax.jms.JMSException;
import javax.jms.Message;
import javax.jms.Queue;
import javax.jms.Session;
import javax.jms.TextMessage;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.jms.core.JmsTemplate;
import org.springframework.jms.core.MessageCreator;

/**
 * 
 * The GatewayQueueSender class uses the injected JMSTemplate to send a message
 * to gatewayProvisioningRequestQueue. 
 */
public class OnHoldQueueSender
{
	private JmsTemplate jmsTemplate;
	private Queue onHoldRequestQueue; 
	private static final Logger onHoldRequestSenderLog = LogManager.getLogger(OnHoldQueueSender.class);
	private final static String swcTransactionId = "swcTransactionId";
	private final static String systemName = "system_name";
	
	/**
	 * Sends message to gatewayProvisioningRequestQueue using JMS Template.
	 * @param parseSystemName 
	 * @param provReqXML the message_p
	 * @throws JMSException the jms exception
	 */
	public void sendMessage(final String tppTransactionRequestXML, final String messageId, final String parseSystemName) throws JMSException
	{
		
		onHoldRequestSenderLog.info("Sending TPP_ProvisioningRequest Message From Communciation Service to OnHold Queue");

		jmsTemplate.send(this.onHoldRequestQueue, new MessageCreator(){

			@Override
			public Message createMessage(Session session) throws JMSException {
				TextMessage message = session.createTextMessage(tppTransactionRequestXML.toString());
				message.setStringProperty(swcTransactionId,messageId.toString());
				message.setStringProperty(systemName,parseSystemName.toString());				
				return message;
			}
			
		});		
		
	}
	/**
	 * Sets the jms template.
	 *
	 * @param template the jms template
	 */
	public void setJmsTemplate(JmsTemplate tmpl)
	{
		this.jmsTemplate = tmpl;
	}
	
	public void setOnHoldRequestQueue(Queue onHoldRequestQueue) {
		this.onHoldRequestQueue = onHoldRequestQueue;
	}

	
	

	
}