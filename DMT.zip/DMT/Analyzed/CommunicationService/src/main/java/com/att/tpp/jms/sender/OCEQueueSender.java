package com.att.tpp.jms.sender;


import javax.jms.JMSException;
import javax.jms.Message;
import javax.jms.Queue;
import javax.jms.Session;
import javax.jms.TextMessage;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.jms.core.JmsTemplate;
import org.springframework.jms.core.MessageCreator;

/**
 * 
 * The OCEQueueSender class uses the injected JMSTemplate to send a message
 * to OCEQueue. 
 */
public class OCEQueueSender
{
	private JmsTemplate jmsTemplate;
	private Queue oceRequestQueue; 
	private static final Logger oceRequestSenderLog = LogManager.getLogger(OCEQueueSender.class);
	private final static String oceTransactionId = "oceTransactionId";
	
	/**
	 * Sends message to CSFOBPMQueueSender using JMS Template.
	 * @param csiTransactionId 
	 * @param provReqXML the message_p
	 * @throws JMSException the jms exception
	 */
	public void sendMessage(final String requestXML, final String oceTrxId) throws JMSException
	{
		
		oceRequestSenderLog.info("Sending ProvisioningResponse Message From Communication Service to OCE Service");

		jmsTemplate.send(this.oceRequestQueue, new MessageCreator(){

			@Override
			public Message createMessage(Session session) throws JMSException {
				TextMessage message = session.createTextMessage(requestXML.toString());
				message.setStringProperty(oceTransactionId,oceTrxId.toString());
				return message;
			}
			
		});		
		
	}
	/**
	 * Sets the jms template.
	 *
	 * @param template the jms template
	 */
	public void setJmsTemplate(JmsTemplate tmpl)
	{
		this.jmsTemplate = tmpl;
	}
	
	
	public void setOCERequestQueue(Queue oceRequestQueue) {
		this.oceRequestQueue = oceRequestQueue;
	}
	
	

	
}