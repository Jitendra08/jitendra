package com.att.tpp.xml.vui.model;

import java.io.Serializable;


public class ALIUpdateRequest implements Serializable{

	private static final long serialVersionUID = 1L;
	
	private String cpn;
    private String externalKey;
    private String externalKeyType;
    private String hno;
    private String hns;
    private String prd;
    private String stn;
    private String mcn;
    private String sta;
    private String loc;
    private String sts;
    private String pod;
    private String nam;
    private String lnam;
    private String extn;
    private CLS cls;
    private TYS tys;
    private String exc;
    private String esn;
    private String mtn;
    private String ord;
    private String cpd;
    private String coi;
    private String cpf;
    private String cps;
    private String zip;
    private String cus;
    private String cmt;
    private String lon;
    private String lat;
    private String elv;
    private String tar;
    private String alt;
    private String subscriberID;
    private String ver;
    private String foc;
    private String recordLimit;
    private String continuation;
	public String getCpn() {
		return cpn;
	}
	public void setCpn(String cpn) {
		this.cpn = cpn;
	}
	public String getExternalKey() {
		return externalKey;
	}
	public void setExternalKey(String externalKey) {
		this.externalKey = externalKey;
	}
	public String getExternalKeyType() {
		return externalKeyType;
	}
	public void setExternalKeyType(String externalKeyType) {
		this.externalKeyType = externalKeyType;
	}
	public String getHno() {
		return hno;
	}
	public void setHno(String hno) {
		this.hno = hno;
	}
	public String getHns() {
		return hns;
	}
	public void setHns(String hns) {
		this.hns = hns;
	}
	public String getPrd() {
		return prd;
	}
	public void setPrd(String prd) {
		this.prd = prd;
	}
	public String getStn() {
		return stn;
	}
	public void setStn(String stn) {
		this.stn = stn;
	}
	public String getMcn() {
		return mcn;
	}
	public void setMcn(String mcn) {
		this.mcn = mcn;
	}
	public String getSta() {
		return sta;
	}
	public void setSta(String sta) {
		this.sta = sta;
	}
	public String getLoc() {
		return loc;
	}
	public void setLoc(String loc) {
		this.loc = loc;
	}
	public String getSts() {
		return sts;
	}
	public void setSts(String sts) {
		this.sts = sts;
	}
	public String getPod() {
		return pod;
	}
	public void setPod(String pod) {
		this.pod = pod;
	}
	public String getNam() {
		return nam;
	}
	public void setNam(String nam) {
		this.nam = nam;
	}
	public String getLnam() {
		return lnam;
	}
	public void setLnam(String lnam) {
		this.lnam = lnam;
	}
	public String getExtn() {
		return extn;
	}
	public void setExtn(String extn) {
		this.extn = extn;
	}
	public CLS getCls() {
		return cls;
	}
	public void setCls(CLS cls) {
		this.cls = cls;
	}
	public TYS getTys() {
		return tys;
	}
	public void setTys(TYS tys) {
		this.tys = tys;
	}
	public String getExc() {
		return exc;
	}
	public void setExc(String exc) {
		this.exc = exc;
	}
	public String getEsn() {
		return esn;
	}
	public void setEsn(String esn) {
		this.esn = esn;
	}
	public String getMtn() {
		return mtn;
	}
	public void setMtn(String mtn) {
		this.mtn = mtn;
	}
	public String getOrd() {
		return ord;
	}
	public void setOrd(String ord) {
		this.ord = ord;
	}
	public String getCpd() {
		return cpd;
	}
	public void setCpd(String cpd) {
		this.cpd = cpd;
	}
	public String getCoi() {
		return coi;
	}
	public void setCoi(String coi) {
		this.coi = coi;
	}
	public String getCpf() {
		return cpf;
	}
	public void setCpf(String cpf) {
		this.cpf = cpf;
	}
	public String getCps() {
		return cps;
	}
	public void setCps(String cps) {
		this.cps = cps;
	}
	public String getZip() {
		return zip;
	}
	public void setZip(String zip) {
		this.zip = zip;
	}
	public String getCus() {
		return cus;
	}
	public void setCus(String cus) {
		this.cus = cus;
	}
	public String getCmt() {
		return cmt;
	}
	public void setCmt(String cmt) {
		this.cmt = cmt;
	}
	public String getLon() {
		return lon;
	}
	public void setLon(String lon) {
		this.lon = lon;
	}
	public String getLat() {
		return lat;
	}
	public void setLat(String lat) {
		this.lat = lat;
	}
	public String getElv() {
		return elv;
	}
	public void setElv(String elv) {
		this.elv = elv;
	}
	public String getTar() {
		return tar;
	}
	public void setTar(String tar) {
		this.tar = tar;
	}
	public String getAlt() {
		return alt;
	}
	public void setAlt(String alt) {
		this.alt = alt;
	}
	public String getSubscriberID() {
		return subscriberID;
	}
	public void setSubscriberID(String subscriberID) {
		this.subscriberID = subscriberID;
	}

	public String getFoc() {
		return foc;
	}
	public void setFoc(String foc) {
		this.foc = foc;
	}

	public String getContinuation() {
		return continuation;
	}
	public void setContinuation(String continuation) {
		this.continuation = continuation;
	}
	public String getVer() {
		return ver;
	}
	public void setVer(String ver) {
		this.ver = ver;
	}
	public String getRecordLimit() {
		return recordLimit;
	}
	public void setRecordLimit(String recordLimit) {
		this.recordLimit = recordLimit;
	}

    

}
