package com.att.tpp.config;

public class RetryConfigElement  {
 public String system;
 public int retryAttempt;
 public String retryType;
 public int waitTime;
  
 RetryConfigElement (String systemX , int retryAttemptX , int waitTimeX, String retryTypeX) {
    system = systemX;
    retryAttempt = retryAttemptX;
    retryType = retryTypeX;
    waitTime = waitTimeX;
 }

 
}
