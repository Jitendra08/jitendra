package com.att.tpp.service;

import javax.xml.soap.MessageFactory;
import javax.xml.soap.SOAPBody;
import javax.xml.soap.SOAPElement;
import javax.xml.soap.SOAPEnvelope;
import javax.xml.soap.SOAPMessage;
import javax.xml.soap.SOAPPart;

public class CreateSoapRequest {
	
	private String user;
	private String pass;
	private String transport;
	
/*	*//**
	 * @param user
	 * @param pass
	 *//*
	@ConstructorProperties({"username", "password", "transport"})
	public CreateSoapRequest(String username, String password, String transport) {
		this.user = username;
		this.pass = password;
		this.transport = transport;
	}*/
	
	public CreateSoapRequest() {
		// TODO Auto-generated constructor stub
	}

	public String getBaseUrl(){
		return transport;		
	}

	public SOAPMessage createVUIRequest() throws Exception {
        MessageFactory messageFactory = MessageFactory.newInstance();
        SOAPMessage soapMessage = messageFactory.createMessage();
        SOAPPart soapPart = soapMessage.getSOAPPart();

        String serverURI = "http://www.intrado.com/namespaces/vui";
        //"http://www.intrado.com/namespaces/vui"
        String xsdPath ="http://www.intrado.com/namespaces/vui/VUI2.xsd";
      //"http://www.intrado.com/namespaces/vui/VUI2.xsd"
        
        
        // SOAP Envelope
        SOAPEnvelope envelope = soapPart.getEnvelope();
        envelope.addNamespaceDeclaration("vui", serverURI);
        
        // SOAP Body
        SOAPBody soapBody = envelope.getBody();
        SOAPElement vuiAliUpdateRequestElement = soapBody.addChildElement("vuiAliUpdateRequest", "vui");
        vuiAliUpdateRequestElement.setAttribute("Acct", "VUI-100781");
        vuiAliUpdateRequestElement.setAttribute("ClientVersion", "1.1");
        vuiAliUpdateRequestElement.setAttribute("rec", "1");
        vuiAliUpdateRequestElement.setAttribute("ver", "1.0");
        vuiAliUpdateRequestElement.setAttribute("FOC", "I");
        
        

       /* // SOAP Envelope
        SOAPEnvelope envelope = soapPart.getEnvelope();
        envelope.addNamespaceDeclaration("vui", serverURI);
       // envelope.addNamespaceDeclaration("inq", xsdPath);
        
        // SOAP Body
        SOAPBody soapBody = envelope.getBody();
        SOAPElement vuiAliUpdateRequestElement = soapBody.addChildElement("vuiAliUpdateRequest", "vui");
        vuiAliUpdateRequestElement.setAttribute("Acct", "VUI-100781");
        vuiAliUpdateRequestElement.setAttribute("ClientVersion", "1.1");
        vuiAliUpdateRequestElement.setAttribute("rec", "1");
        vuiAliUpdateRequestElement.setAttribute("ver", "1.0");
        vuiAliUpdateRequestElement.setAttribute("FOC", "I");
        
        SOAPElement externalKeyElement = vuiAliUpdateRequestElement.addChildElement("externalKey","vui");
        externalKeyElement.addTextNode("3104106452536750");
        SOAPElement externalKeyType = vuiAliUpdateRequestElement.addChildElement("externalKeyType","vui");
        externalKeyType.addTextNode("Other");
        SOAPElement hnoElement = vuiAliUpdateRequestElement.addChildElement("hno","vui");
        SOAPElement stnElement = vuiAliUpdateRequestElement.addChildElement("stn","vui");
        SOAPElement mcnElement = vuiAliUpdateRequestElement.addChildElement("mcn","vui");
        SOAPElement staElement = vuiAliUpdateRequestElement.addChildElement("sta","vui");
        SOAPElement locElement = vuiAliUpdateRequestElement.addChildElement("loc","vui");
        SOAPElement namElement = vuiAliUpdateRequestElement.addChildElement("nam","vui");
        SOAPElement clsElement = vuiAliUpdateRequestElement.addChildElement("cls","vui");
        SOAPElement typElement = clsElement.addChildElement("typ","vui");
        SOAPElement tysElement = vuiAliUpdateRequestElement.addChildElement("tys","vui");
        SOAPElement tysTypeElement= tysElement.addChildElement("typ","vui");
        SOAPElement cpfElement = vuiAliUpdateRequestElement.addChildElement("cpf","vui");
        SOAPElement zipElement = vuiAliUpdateRequestElement.addChildElement("zip","vui");
        SOAPElement lonElement = vuiAliUpdateRequestElement.addChildElement("lon","vui");
        SOAPElement latElement = vuiAliUpdateRequestElement.addChildElement("lat","vui");
        
        hnoElement.addTextNode("211");
        stnElement.addTextNode("S AKARD ST");
        mcnElement.addTextNode("City Nam");
        staElement.addTextNode("TX");
        locElement.addTextNode("1");
        namElement.addTextNode("FIXED ATTMO 8006356840 OPT4");
        typElement.addTextNode("J");
        tysTypeElement.addTextNode("0");
        cpfElement.addTextNode("ATTMO");
        zipElement.addTextNode("75202");
        lonElement.addTextNode("-96.800014");
        latElement.addTextNode("32.779295");*/
        
        
        
/*        SOAPHeader header = envelope.getHeader();

        SOAPElement security =
                header.addChildElement("Security", "wsse", "http://docs.oasis-open.org/wss/2004/01/oasis-200401-wss-wssecurity-secext-1.0.xsd");

        SOAPElement usernameToken =
                security.addChildElement("UsernameToken", "wsse");
        usernameToken.addAttribute(new QName("xmlns:wsu"), "http://docs.oasis-open.org/wss/2004/01/oasis-200401-wss-wssecurity-utility-1.0.xsd");

        SOAPElement username =
                usernameToken.addChildElement("Username", "wsse");
        username.addTextNode("3pp");

        SOAPElement password =
                usernameToken.addChildElement("Password", "wsse");
        password.setAttribute("Type", "http://docs.oasis-open.org/wss/2004/01/oasis-200401-wss-username-token-profile-1.0#PasswordText");
        password.addTextNode("femtocell");
*/
        soapMessage.saveChanges();

        /* Print the request message */
        System.out.print("Request SOAP Message = ");
      //  soapMessage.writeTo(System.out);
        System.out.println();

        return soapMessage;
    }
	



	
	
	
	

}
