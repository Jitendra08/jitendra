package com.att.tpp.xml.vui.model;



public class Payload {



    private ALIUpdateRequest aliUpdateRequest;

	/**
	 * @return the aliUpdateRequest
	 */
	public ALIUpdateRequest getAliUpdateRequest() {
		return aliUpdateRequest;
	}

	/**
	 * @param aliUpdateRequest the aliUpdateRequest to set
	 */
	public void setAliUpdateRequest(ALIUpdateRequest aliUpdateRequest) {
		this.aliUpdateRequest = aliUpdateRequest;
	}
    
    
}
