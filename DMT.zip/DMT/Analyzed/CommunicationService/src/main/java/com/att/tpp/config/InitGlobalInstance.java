package com.att.tpp.config;
import java.util.ArrayList;
import java.util.Hashtable;
import java.util.Map;

import com.att.tpp.model.ProductRef;
import com.att.tpp.model.SystemConfiguration;
import com.att.tpp.model.SystemRef;

public class InitGlobalInstance {
	
	private static Hashtable<String, SystemConfiguration> systemConfig = new Hashtable<String, SystemConfiguration>();
	private static Hashtable<String, SystemRef> systemRefConfig = new Hashtable<String, SystemRef>();
	
  private static Hashtable<String, ArrayList<ProvisionSeqElement>> provSeqConfig = new Hashtable<String, ArrayList<ProvisionSeqElement>>();
  private static Hashtable<String, RetryConfigElement> retryConfig = new Hashtable<String, RetryConfigElement>();
  private static Hashtable<String, URIConfigElement> uriConfig = new Hashtable<String, URIConfigElement>();
  private static Hashtable<String, ProductRefElement> productRefConfig = new Hashtable<String, ProductRefElement>();
  
  
  
  private static Object lock = new Object();

  private static org.apache.logging.log4j.Logger logger =       org.apache.logging.log4j.LogManager.getLogger("bw.logger");   


   

	public static void storeCurrentSystemConfig(String systemName,	SystemConfiguration systemConfiguration) {
	    try {
	        systemConfig.put ( systemName , systemConfiguration );
	      } catch (Exception e ) {
	        //e.printStackTrace();
	    	  logger.error("Exception in InitGlobalInstance storeCurrentSystemConfig : "+e.getMessage());
	      }  		
	}
	
	
   public static  Map<String, SystemConfiguration> getSystemConfig () {
      return systemConfig;
   }
   
   
   
	public static void storeCurrentSystemRef(String systemName, SystemRef systemRef) {
	    try {
	    	systemRefConfig.put ( systemName , systemRef );
	      } catch (Exception e ) {
	        //e.printStackTrace();
	        logger.error("Exception in InitGlobalInstance storeCurrentSystemRef : "+e.getMessage());
	      } 
		
	}
	
	
	
	public static Hashtable<String, SystemRef> getSystemRef() {
		return systemRefConfig;
	}


	public static void setSystemRef(Hashtable<String, SystemRef> systemRef) {
		InitGlobalInstance.systemRefConfig = systemRef;
	}

	

   
   
/*old code*/
   
   
   public static  void  storeCurrentProvSeq ( String prodId , String action , String systemName, int batchNum , String autoRespInd, String provCarrier) {
       
	    try {
	     String key = provCarrier + "_" + prodId + "_" + action;

	     ArrayList obj = null;

	     if  ( provSeqConfig.containsKey(key)) {
	       logger.debug("Hashtable already has this key " + key);
	     
	       obj = ( ArrayList ) provSeqConfig.get(key);
	     } else  {
	       logger.debug("Creating New ArrayList for Key : " + key);
	       obj = new ArrayList();
	      }
	      logger.debug ("Adding new Provisioning Sequence Element , key " + key  + "system " + systemName);

	      ProvisionSeqElement element = new ProvisionSeqElement (prodId, action, systemName ,  batchNum , autoRespInd , provCarrier);
	     obj.add ( element );

	     provSeqConfig.put ( key , obj );
	    } catch (Exception e ) {
	      //e.printStackTrace();
	    	logger.error("Exception in InitGlobalInstance storeCurrentProvSeq : "+e.getMessage());
	    }     
	  }

	   public static  Map getProvSeqHashTable () {
	      return provSeqConfig;
	   }


  public static  void storeCurrentURIConfig ( String system, String URI ,String synchTransInd ){ 
       
    try {

      URIConfigElement uriConfigElem = new URIConfigElement (system , URI , synchTransInd  ); 

      logger.debug ( "Adding system : " + system + " Value : " + uriConfigElem + " to uriConfig HashTable");
      uriConfig.put ( system , uriConfigElem );

    } catch (Exception e ) {
      //e.printStackTrace();
    	logger.error("Exception in InitGlobalInstance storeCurrentURIConfig : "+e.getMessage());
    }     
  }

   public static  Map getURIConfig () {
      return uriConfig;
   }


  public static  void storeCurrentRetryConfig ( String system, int retryAttempt , String retryType, int waitTime) {
       
    try {

      RetryConfigElement retryConfigElement = new RetryConfigElement (system , retryAttempt , waitTime , retryType); 
      String key = system + "_" + retryType +"_"+retryAttempt;
   //   Object value = new Integer ( retryAttempt );
      //logger.debug ("Storing  key : " + key + " value : " + value);
      retryConfig.put( key , retryConfigElement );

    } catch (Exception e ) {
      //e.printStackTrace();
    	logger.error("Exception in InitGlobalInstance storeCurrentRetryConfig : "+e.getMessage());
    }     
  }

   public static  Map getRetryConfig () {
      return retryConfig;
   }
   



   public static void emptyConfigTables () {
     logger.debug("emptyConfigTables invoked"); 
      synchronized  ( lock ) {
        provSeqConfig.clear();
        retryConfig.clear();
        uriConfig.clear();
        systemConfig.clear();
      }
   }
   
   
	public static void storeProductRef(ProductRef productRef) {

		try {

			ProductRefElement productRefElement = new ProductRefElement(
					productRef.getProductId(), productRef.getProductDsc());

			logger.debug("Adding productId : " + productRef.getProductId()
					+ " productDsc : " + productRef.getProductDsc()
					+ " to productRef HashTable");
			
			productRefConfig.put(productRef.getProductId(), productRefElement);

		} catch (Exception e) {
			//e.printStackTrace();
			logger.error("Exception in InitGlobalInstance storeProductRef : "+e.getMessage());
		}
	}
	
	
	   public static Map<String, ProductRefElement> getProductRefDesc () {
		      return productRefConfig;
		   }










   
}



