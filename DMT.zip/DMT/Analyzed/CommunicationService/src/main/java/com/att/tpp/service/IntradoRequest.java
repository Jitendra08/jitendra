package com.att.tpp.service;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.math.BigDecimal;
import java.net.MalformedURLException;
import java.net.ProtocolException;
import java.net.URL;
import java.security.KeyManagementException;
import java.security.KeyStore;
import java.security.KeyStoreException;
import java.security.NoSuchAlgorithmException;
import java.security.UnrecoverableKeyException;
import java.security.cert.CertificateException;
import java.util.Scanner;

import javax.net.ssl.HttpsURLConnection;
import javax.net.ssl.KeyManagerFactory;
import javax.net.ssl.SSLContext;
import javax.net.ssl.TrustManagerFactory;
import javax.xml.datatype.DatatypeConfigurationException;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;

import com.att.tpp.jms.sender.CSIQueueSender;
import com.att.tpp.model.IntradoWSResponseData;
import com.att.tpp.model.TransactionRequestData;
import com.att.tpp.xml.vui.model.VUI;
import com.intrado.namespaces.vui.AliUpdateRequestType;
import com.intrado.namespaces.vui.AliUpdateResponseType;
import com.intrado.namespaces.vui.CLS;
import com.intrado.namespaces.vui.FOCtype;
import com.intrado.namespaces.vui.TYS;
import com.intrado.namespaces.vui.Vui;

public class IntradoRequest {
	
	private static Logger intradoRequestLog = LogManager.getLogger(IntradoRequest.class);
		
	@Autowired 
	private Vui vui;	
	
	
	
	@Autowired
	private CSIQueueSender csiQueueSender;
	
	
	   private final static String postSuccess = "PostSuccess";
	   private final static String postFailed = "PostFailed";
	   
		String keystore = "/opt/app/s1tpp1m1/3pp/sites/tomcat/latest_tomcat/3pp/ssl/keystore.ImportKey";
		String keystorepass = "femtocell";
		String truststore = "/opt/app/s1tpp1m1/3pp/sites/tomcat/latest_tomcat/3pp/ssl/VUI_Cert_Trust.jks";
		String truststorepass = "femtocell";
		String httpsURL = "https://ilabvui2.intrado.com:443/vuiws/VuiService?wsdl";
		String getPost = "POST";
		//String strBuffer = prop.getProperty("stringToSend");
	   
	   
/*		private static String intradoCert;
		private static String intradoCertPwd;
		private static String endpointAddress;	
		private static String trustoreFileName;	
		private static String trustoreStorePass;	
		
		
		@ConstructorProperties({"intradoCert", "intradoCertPwd", "endpointAddress", "trustoreFileName", "trustoreStorePass"})
		public IntradoRequest(String intradoCert, String intradoCertPwd, String endpointAddress,  String trustoreFileName, String trustoreStorePass){
			IntradoRequest.intradoCert = intradoCert;
			IntradoRequest.intradoCertPwd=intradoCertPwd;
			IntradoRequest.endpointAddress=endpointAddress;
			IntradoRequest.trustoreFileName=trustoreFileName;
			IntradoRequest.trustoreStorePass=trustoreStorePass;
		}	
	   */
	   
	   
/*		public static void main(String args[]) {
			
			SendHTTPS sendHTTPS = new SendHTTPS();
			sendHTTPS.postHTTPS(args);
			
		}*/
	
	public IntradoRequest() {
			// TODO Auto-generated constructor stub
		}


	public IntradoWSResponseData doIntradoRequest(VUI vuiRequestData, TransactionRequestData transactionRequestData){
		
		IntradoWSResponseData intradoWSResponseData = new IntradoWSResponseData();
		
		String wsPostResult=postFailed;
		
		String taskTrasId=transactionRequestData.getTaskTransId();
		HttpsURLConnection con = null;
		intradoRequestLog.info("Inside doIntradoRequest");	
		String externalKey="TestKEy";
		String rcCode ="09";
		String rcMessage="TestMsg";
			try {
				con = setup(keystore, keystorepass,
						truststore, truststorepass, httpsURL, getPost);
				intradoRequestLog.info("Trying to Connect -------");
				con.connect();
				intradoRequestLog.info("Connected");
				
			//	AliUpdateRequestType aliUpdateRequestType = generateVuiUpdateRequestData(vuiRequestData);

			AliUpdateRequestType aliUpdateRequestType = new AliUpdateRequestType();

			aliUpdateRequestType.setAcct("VUI-100781");
			aliUpdateRequestType.setClientVersion("1.1");
			aliUpdateRequestType.setRec(1);
			// BigDecimal version = new BigDecimal(1.0);
			aliUpdateRequestType.setVer(BigDecimal.ONE);
			// Need to modify
				aliUpdateRequestType.setFOC(FOCtype.I);
				aliUpdateRequestType.setExternalKey("GK989946G67784ER");
				aliUpdateRequestType.setExternalKeyType("Other");

				
				aliUpdateRequestType.setHno("210");
				aliUpdateRequestType.setStn("CARRIAGE");
						
				aliUpdateRequestType.setMcn("WAKE FOREST");
				aliUpdateRequestType.setSta("NC");
				aliUpdateRequestType.setSts("WAY");
				aliUpdateRequestType.setNam("FEMTOCELL SUB5");
				//Need to Check
						CLS cls = new CLS();		
						cls.setDes("test");
						cls.setTyp("J");		
						//If Condition
						aliUpdateRequestType.setCls(cls);

						TYS tys = new TYS();
						tys.setDes("test");
						tys.setTyp("0");		
				aliUpdateRequestType.setTys(tys);
				aliUpdateRequestType.setCpf("ATTMO");
				aliUpdateRequestType.setZip("27587-9029");
				
				intradoRequestLog.info("After the creating data... ");
				
				AliUpdateResponseType vuiAliUpdate = vui.vuiAliUpdate(aliUpdateRequestType);
				intradoRequestLog.info("After Making  data call... ");
				
				//String rcMessage = vuiAliUpdate.getRc1().getMessage();
				rcCode = vuiAliUpdate.getRc1().getValue();
				intradoRequestLog.info("After geting the rcCode  ... ");
/*				String externalKey =vuiAliUpdate.getExternalKey();*/
				wsPostResult = postSuccess;
				
/*				intradoWSResponseData.setTransactionId(taskTrasId);
				intradoWSResponseData.setRc1Code(rcCode);
				intradoWSResponseData.setRc1Message(rcMessage);
				intradoWSResponseData.setWsPostResult(wsPostResult);*/
				
				//printErrorStream(con);
				
				intradoRequestLog.info("Response message :"+rcMessage +" value:"+rcCode +"Externalkey: "+externalKey);
			} catch (Exception e) {				
				intradoWSResponseData.setTransactionId(taskTrasId);
				intradoWSResponseData.setRc1Code("70010");
				intradoWSResponseData.setRc1Message("HTTP Post Failure");				
				intradoWSResponseData.setWsPostResult(wsPostResult);	
				intradoRequestLog.info("Intrado Webservice call failed. Exception : "+e);
				intradoRequestLog.info("Response message :"+rcMessage +" value:"+rcCode +"Externalkey: "+externalKey);
				try {
					printErrorStream(con);
				} catch (IOException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
				e.printStackTrace();				
			}finally{
				con.disconnect();
			}
			
			
			
			return intradoWSResponseData;
	}


	private AliUpdateRequestType generateVuiUpdateRequestData(VUI vuiRequestData) throws DatatypeConfigurationException {
		String arg0="Test";
		AliUpdateRequestType aliUpdateRequestType = new AliUpdateRequestType();
		
		aliUpdateRequestType.setAcct("VUI-100781");
		aliUpdateRequestType.setClientVersion("1.1");
		aliUpdateRequestType.setRec(1);
		//BigDecimal version = new BigDecimal(1.0);
		aliUpdateRequestType.setVer( BigDecimal.ONE);
		//Need to modify
		aliUpdateRequestType.setFOC(FOCtype.I);
		aliUpdateRequestType.setExternalKey("GK989946G67784ER");
		aliUpdateRequestType.setExternalKeyType("Other");

		
		aliUpdateRequestType.setHno("210");
		aliUpdateRequestType.setStn("CARRIAGE");
				
		aliUpdateRequestType.setMcn("WAKE FOREST");
		aliUpdateRequestType.setSta("NC");
		aliUpdateRequestType.setSts("WAY");
		aliUpdateRequestType.setNam("FEMTOCELL SUB5");
		//Need to Check
				CLS cls = new CLS();		
				cls.setDes("test");
				cls.setTyp("J");		
				//If Condition
				aliUpdateRequestType.setCls(cls);

				TYS tys = new TYS();
				tys.setDes("test");
				tys.setTyp("0");		
		aliUpdateRequestType.setTys(tys);
		aliUpdateRequestType.setCpf("ATTMO");
		aliUpdateRequestType.setZip("27587-9029");
		
		
/*		aliUpdateRequestType.setRecordLimit(vuiRequestData.getPayload().getAliUpdateRequest().getRecordLimit());
		aliUpdateRequestType.setContinuation(vuiRequestData.getPayload().getAliUpdateRequest().getContinuation());
		aliUpdateRequestType.setCpn(vuiRequestData.getPayload().getAliUpdateRequest().getCpn());
		aliUpdateRequestType.setExternalKey(vuiRequestData.getPayload().getAliUpdateRequest().getExternalKey());
		aliUpdateRequestType.setExternalKeyType(vuiRequestData.getPayload().getAliUpdateRequest().getExternalKeyType());
		aliUpdateRequestType.setHns(vuiRequestData.getPayload().getAliUpdateRequest().getHns());
		aliUpdateRequestType.setPrd(vuiRequestData.getPayload().getAliUpdateRequest().getPrd());
		aliUpdateRequestType.setStn(vuiRequestData.getPayload().getAliUpdateRequest().getStn());
		
				
		aliUpdateRequestType.setLoc(vuiRequestData.getPayload().getAliUpdateRequest().getLoc());
		aliUpdateRequestType.setSts(vuiRequestData.getPayload().getAliUpdateRequest().getSts());
		aliUpdateRequestType.setPod(vuiRequestData.getPayload().getAliUpdateRequest().getPod());		
				
		aliUpdateRequestType.setLnam(vuiRequestData.getPayload().getAliUpdateRequest().getLnam());
		aliUpdateRequestType.setExtn(vuiRequestData.getPayload().getAliUpdateRequest().getExtn());
		
		
		
		
		aliUpdateRequestType.setExc(vuiRequestData.getPayload().getAliUpdateRequest().getExc());
		aliUpdateRequestType.setEsn(vuiRequestData.getPayload().getAliUpdateRequest().getEsn());
		aliUpdateRequestType.setMtn(vuiRequestData.getPayload().getAliUpdateRequest().getMtn());
		aliUpdateRequestType.setOrd(vuiRequestData.getPayload().getAliUpdateRequest().getOrd());
		
		GregorianCalendar gregory = new GregorianCalendar();
		gregory.setTimeInMillis(new Date().getTime());
		
		XMLGregorianCalendar gregorianCalendarDate = null;
		
		gregorianCalendarDate = DatatypeFactory.newInstance()
			        .newXMLGregorianCalendar(
			            gregory);		
		aliUpdateRequestType.setCpd(gregorianCalendarDate);
		
		aliUpdateRequestType.setCoi(vuiRequestData.getPayload().getAliUpdateRequest().getCoi());
		
		aliUpdateRequestType.setCps(vuiRequestData.getPayload().getAliUpdateRequest().getCps());
		aliUpdateRequestType.setZip(vuiRequestData.getPayload().getAliUpdateRequest().getZip());
		aliUpdateRequestType.setCus(vuiRequestData.getPayload().getAliUpdateRequest().getCus());
		aliUpdateRequestType.setCmt(vuiRequestData.getPayload().getAliUpdateRequest().getCmt());*/
/*		aliUpdateRequestType.setLon(vuiRequestData.getPayload().getAliUpdateRequest().getLon());
		aliUpdateRequestType.setLat(vuiRequestData.getPayload().getAliUpdateRequest().getLat());		
		aliUpdateRequestType.setElv(vuiRequestData.getPayload().getAliUpdateRequest().getElv());*/
/*		aliUpdateRequestType.setTar(vuiRequestData.getPayload().getAliUpdateRequest().getTar());
		aliUpdateRequestType.setAlt(vuiRequestData.getPayload().getAliUpdateRequest().getAlt());
		aliUpdateRequestType.setSubscriberId(vuiRequestData.getPayload().getAliUpdateRequest().getSubscriberID());
		aliUpdateRequestType.setDriveDir(arg0);*/
		
		return aliUpdateRequestType;
	}
	
	private static HttpsURLConnection setup(String keystore,
			String keystorepass, String truststore, String truststorepass,
			String httpsURL, String getPost) throws MalformedURLException,
			KeyStoreException, IOException, NoSuchAlgorithmException,
			CertificateException, FileNotFoundException,
			UnrecoverableKeyException, KeyManagementException,
			ProtocolException {
		// for HttpsURLConnection we need to set this property
		System.setProperty("java.protocol.handler.pkgs",
				"com.sun.net.ssl.internal.www.protocol");

		System.setProperty("net.debug", "ssl");

		URL url = new URL(null, httpsURL,
				new sun.net.www.protocol.https.Handler());

		// KeyStore ks = KeyStore.getInstance("pkcs12");
		KeyStore ks = KeyStore.getInstance("JKS");
		ks.load(new FileInputStream(keystore), keystorepass.toCharArray());
		KeyManagerFactory kmf = KeyManagerFactory.getInstance("SunX509");
		kmf.init(ks, keystorepass.toCharArray());

		SSLContext sslctx2 = SSLContext.getInstance("SSLv3");
		sslctx2.init(kmf.getKeyManagers(), null, null);

		KeyStore ksTrust = KeyStore.getInstance("JKS");
		ksTrust.load(new FileInputStream(truststore),
				truststorepass.toCharArray());

		// TrustManager's decide whether to allow connections.
		TrustManagerFactory tmf = TrustManagerFactory
				.getInstance("SunX509");
		tmf.init(ksTrust);

		// System.setProperty("javax.net.ssl.keyStoreType", "pkcs12");
		System.setProperty("javax.net.ssl.keyStoreType", "jks");
		System.setProperty("javax.net.ssl.trustStoreType", "jks");
		System.setProperty("javax.net.ssl.keyStore", keystore);
		System.setProperty("javax.net.ssl.trustStore", truststore);
		System.setProperty("javax.net.debug", "ssl");
		System.setProperty("javax.net.ssl.keyStorePassword", keystorepass);
		System.setProperty("javax.net.ssl.trustStorePassword",
				truststorepass);
		System.setProperty("http.keepAlive", "false");

		sslctx2.init(kmf.getKeyManagers(), tmf.getTrustManagers(), null);

		// ******
		HttpsURLConnection.setDefaultSSLSocketFactory(sslctx2
				.getSocketFactory());

		HttpsURLConnection con = (HttpsURLConnection) url.openConnection();
		con.setRequestMethod(getPost);
		con.setDoOutput(true);
		con.setRequestProperty("accept-charset", "UTF-8");
		con.setRequestProperty("Content-Type", "text/xml");
		return con;
	}

	
	@SuppressWarnings({ "resource" })
	private void printErrorStream(HttpsURLConnection httpsConnection)
			throws IOException {
		Scanner s;
		if (httpsConnection.getResponseCode() != 200) {
			s = new Scanner(httpsConnection.getErrorStream());
		} else {
			s = new Scanner(httpsConnection.getInputStream());
		}
		s.useDelimiter("\\Z");
		String response = s.next();

		intradoRequestLog.info(" HTTPS ErrorStream : " + response);
	}


	
	
}
