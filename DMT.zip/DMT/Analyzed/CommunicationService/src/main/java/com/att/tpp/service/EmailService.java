package com.att.tpp.service;

import java.beans.ConstructorProperties;
import java.util.HashMap;
import java.util.Properties;

import javax.mail.Message;
import javax.mail.MessagingException;
import javax.mail.Session;
import javax.mail.Transport;
import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeMessage;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import com.att.tpp.model.EmailRequestData;

public class EmailService {

	private static Logger emailServiceLog = LogManager.getLogger(EmailService.class);

	private final static String ResponseCode = "responseCode";
	private final static String ResponseMessage = "responseMessage";

	private static String emailFrom;
	private static String emailHost;
	
	
	@ConstructorProperties({"emailFrom", "emailHost" })
	public EmailService(String emailFrom, String emailHost){
		EmailService.emailFrom = emailFrom;
		EmailService.emailHost=emailHost;
	}	
	
	
	public HashMap<String, String> sendEmailRequest(EmailRequestData emailRequestData, String url) {
		
		HashMap<String, String> emailResultMap = new HashMap<String, String>();
		emailServiceLog.info("Inside the sendEmailRequest method.......");
		int emailResponseCode=000;
		String emailResponseMessage="";
		
		   // Get system properties
		   Properties properties = System.getProperties();
		
		   // Setup mail server
		   properties.setProperty("mail.smtp.host", emailHost);
		
		   // Get the default Session object.
		   Session session = Session.getDefaultInstance(properties);
		
		   try{
		      // Create a default MimeMessage object.
		      MimeMessage message = new MimeMessage(session);
		
		      // Set From: header field of the header.
		      message.setFrom(new InternetAddress(emailFrom));
		
		      // Set To: header field of the header.
/*		      message.addRecipient(Message.RecipientType.TO,
		                               new InternetAddress(emailRequestData.getTo()));*/
		      
				message.setRecipients(Message.RecipientType.TO,
						InternetAddress.parse(emailRequestData.getTo()));
		
		      // Set Subject: header field
		      message.setSubject("3PP Provisioning Request");
		
		      // Now set the actual message
		      message.setText(emailRequestData.getProvisioningRequestData());
		
		      // Send message
		      Transport.send(message);
		      emailResponseCode=200;
		      emailResponseMessage="Email Sent Successfully to "+emailRequestData.getTo();
		      emailServiceLog.info("Sent Email message successfully.");
		   }catch (MessagingException mex) {
		      emailResponseCode=000;
		      emailResponseMessage="Email Request From "+ emailFrom+ " Email Failed to "+emailRequestData.getTo() +" Error Msge: "+ mex.getMessage();
		      mex.printStackTrace();
		   }
		   
		   emailServiceLog.info(" Email Request From "+ emailFrom+ " Email Request to "+ emailRequestData.getTo()+ " Email Post Response Code: "+emailResponseCode + " Email Post Response Message:"+emailResponseMessage);
		   emailResultMap.put(ResponseCode, Integer.toString(emailResponseCode));
		   emailResultMap.put(ResponseMessage, emailResponseMessage);
		   return emailResultMap;
	}

}
