package com.att.tpp.xml.vui.model;



public class VUI {


    private HDR hdr;
    private Payload payload;
	/**
	 * @return the hdr
	 */
	public HDR getHdr() {
		return hdr;
	}
	/**
	 * @param hdr the hdr to set
	 */
	public void setHdr(HDR hdr) {
		this.hdr = hdr;
	}
	/**
	 * @return the payload
	 */
	public Payload getPayload() {
		return payload;
	}
	/**
	 * @param payload the payload to set
	 */
	public void setPayload(Payload payload) {
		this.payload = payload;
	}

 

}
