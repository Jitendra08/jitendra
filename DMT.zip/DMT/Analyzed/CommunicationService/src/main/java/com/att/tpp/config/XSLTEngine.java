package com.att.tpp.config;

import java.io.ByteArrayInputStream;
import java.io.File;
import java.io.IOException;
import java.util.Enumeration;
import java.util.Hashtable;
import java.util.Properties;

import javax.xml.transform.Source;
import javax.xml.transform.Templates;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerConfigurationException;
import javax.xml.transform.TransformerException;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.TransformerFactoryConfigurationError;
import javax.xml.transform.stream.StreamSource;

import org.jdom.Document;
import org.jdom.JDOMException;
import org.jdom.input.SAXBuilder;
import org.jdom.output.XMLOutputter;
import org.jdom.transform.JDOMResult;
import org.jdom.transform.JDOMSource;
import org.xml.sax.InputSource;

import com.att.tpp.model.SystemConfiguration;

/**
 * @author Sasi Panja
 */
public class XSLTEngine
{

    public static Properties xslTemplateCache = new Properties();
    public static Hashtable<String, SystemConfigElement> systemConfigHashTable = new Hashtable<String, SystemConfigElement>();
   // public static Hashtable<String, SystemConfiguration> systemConfigHashTable = new Hashtable<String, SystemConfiguration>();
    public static boolean VALIDATE = false;
    public String xmlschemaName;
    private static org.apache.logging.log4j.Logger xsltLogger =       org.apache.logging.log4j.LogManager.getLogger("bw.logger");

    static
    {
        System.setProperty("javax.xml.transform.TransformerFactory", "org.apache.xalan.processor.TransformerFactoryImpl");
    }

    public XSLTEngine()
    {
    }

    public void initializeSystemConfig(String systemName, String xsltFile, String eventType, SystemConfiguration systemConfiguration) throws TransformerConfigurationException, TransformerFactoryConfigurationError
    {
        SystemConfigElement systemConfigElement = new SystemConfigElement();
        systemConfigElement.system   = systemName;
        systemConfigElement.xsltFile = xsltFile;        
        systemConfigElement.eventType = eventType;
        
        if ( eventType != null && eventType.length() != 0)
        {
        	xsltLogger.debug("Adding " + systemName+"_"+eventType +  " as the Key" );
        	systemConfigHashTable.put(systemName+"_"+eventType, systemConfigElement);
        //	systemConfigHashTable.put(systemName+"_"+eventType, systemConfiguration);
        }
        else
        {
        	xsltLogger.debug("Adding " + systemName+ " as the Key" );
        	systemConfigHashTable.put(systemName, systemConfigElement);
        	//systemConfigHashTable.put(systemName, systemConfiguration);
        }
       
/*        //Satish: Added this logic to load XSLT in the initial setup. 
        loadXSLTTemplates();*/
        
    }

    public void loadXSLTTemplates() throws TransformerFactoryConfigurationError,TransformerConfigurationException

    {
        Properties xsltTemplateProps = new Properties();
        try
        {

            TransformerFactory transformerFactory = TransformerFactory.newInstance();

            Enumeration<String> keys = systemConfigHashTable.keys();
            while (keys.hasMoreElements())
            {
                String systemName = (String) keys.nextElement();                                
                
             String xsltFileName = ((SystemConfigElement) systemConfigHashTable.get(systemName)).xsltFile;
             //   String xsltFileName = ((SystemConfiguration) systemConfigHashTable.get(systemName)).getXsltFile();
                xsltLogger.debug("The xsltFilename retrived for " + systemName + " is " + xsltFileName);
                if (xsltFileName != null && xsltFileName.length() > 0)
                {
                    Source xslSource = new StreamSource(new File(xsltFileName));
                    xsltTemplateProps.put(systemName, transformerFactory.newTemplates(xslSource));
                    xsltLogger.debug("Caching " + systemName  + " for  " + xsltFileName);
                }
            }
        }
        catch (TransformerFactoryConfigurationError tFactoryConfigurationError)
        {
            xsltLogger.error("TransformerFactoryConfigurationError:  " + tFactoryConfigurationError.getMessage());
            throw tFactoryConfigurationError;
        }
        catch (TransformerConfigurationException transformerConfigurationException)
        {
            xsltLogger.error("TransformerConfigurationException :  " + transformerConfigurationException.getMessage());
            throw transformerConfigurationException;
        }
        xslTemplateCache = xsltTemplateProps;
    }

    //Outputs the xml after the transformation and validation
    synchronized public String transform(String xmlString, String systemName) throws Exception
    {
        String xmlOutputString = null;

        try
        {
            InputSource inputSource = new InputSource(new ByteArrayInputStream(xmlString.getBytes()));
            SAXBuilder builder = new SAXBuilder("org.apache.xerces.parsers.SAXParser");
            Document xmlDocument = builder.build(inputSource);

            JDOMSource xmlInput = new JDOMSource(xmlDocument);
            JDOMResult xmlOutput = new JDOMResult();
            
            System.out.println("SystemName----->"+systemName);  
           

            Templates xslTemplate = (Templates) xslTemplateCache.get(systemName);
            Transformer transformer = xslTemplate.newTransformer();
            xsltLogger.debug("Transforming xml using the Cached Template");
            transformer.transform(xmlInput, xmlOutput);

            Document xmlResult = xmlOutput.getDocument();
            xmlOutputString = new XMLOutputter().outputString(xmlResult);
            xmlOutputString = xmlOutputString.trim();
            if ( (xmlOutputString != null)  && ( xmlOutputString.equalsIgnoreCase("") ))
            {
            	throw new Exception("XSLTEngine Exception : The output from transformed xml is empty");
            	
            }

            if (VALIDATE)
            {
                //need to get the xml schema for the respective partner
                if (validate(xmlOutputString))
                {
                    xsltLogger.debug("Validation of the Output partner XML is Sucessful");
                }
                else
                {
                    xsltLogger.debug("Validation of the Output partner XML from the translation has failed  ");
                }
            }
        }
        catch (TransformerException te)
        {

            xsltLogger.error("XSLT Transformation failed" + te.getMessage());
            throw te;
        }

        catch (Exception e)
        {
            xsltLogger.error("Caught Exception " + e.getMessage());
            //throw e; /* Commented to catch the exception in Controller */

        }
        return xmlOutputString;
    }

    synchronized private boolean validate(String xmlString)
    {
        try
        {
            InputSource inputSource = new InputSource(new ByteArrayInputStream(xmlString.getBytes()));
            SAXBuilder builder = new SAXBuilder("org.apache.xerces.parsers.SAXParser", true);
            builder.setFeature("http://apache.org/xml/features/validation/schema", true);
            builder.build(inputSource);
            xsltLogger.debug(xmlString + " is valid.");
            return true;
        }
        catch (JDOMException jdomException)
        {
            xsltLogger.error("JDOMException because : " + jdomException.getMessage());
            return false;
        }
        catch (IOException ioException)
        {
            xsltLogger.error("IOEXception because : " + ioException.getMessage());
            return false;
        }
        catch (Exception e)
        {
            xsltLogger.error("Exception because : " + e.getMessage());
            return false;
        }
    }

    public class SystemConfigElement
    {
        public String xsltFile;
        
		public String system;

        public String xmlSchemaname;
        
        public String eventType;        
        
    }
    
/*    public static void main(String [] args) throws TransformerConfigurationException, TransformerFactoryConfigurationError 
    {
    	String[] systemNames = {"Sendia","Vettro","GoodTech"};
    	String[] xsltFiles = {"Sendiaxslt","Vettroxslt","GoodTechxslt"};
    	String[] eventTypes= {null,null,"GoodTechEventType"};
    	
    	XSLTEngine xsltEngine = new XSLTEngine();
    	
    	for ( int i = 0 ; i < 3;i++)    	    	
    		xsltEngine.initializeSystemConfig(systemNames[i],eventTypes[i],xsltFiles[i]);    	
    	xsltEngine.loadXSLTTemplates();    	
    	
    }*/
}