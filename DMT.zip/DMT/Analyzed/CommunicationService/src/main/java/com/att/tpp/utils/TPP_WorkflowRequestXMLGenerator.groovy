package com.att.tpp.utils

import groovy.xml.MarkupBuilder


class TPP_WorkflowRequestXMLGenerator {

	public TPP_WorkflowRequestXMLGenerator() {
	}


	def String createWorkflowRequestXML(String masterTransid){
		def workflowRequestXML = new StringWriter()
		def xml = new MarkupBuilder(workflowRequestXML)

		xml.setDoubleQuotes(true)
		xml.mkp.xmlDeclaration(version: "1.0", encoding: "UTF-8")

		xml.WorkflowRequest("xmlns:xsi":"http://www.w3.org/2001/XMLSchema-instance",
			MasterTransactionId:masterTransid)

		return workflowRequestXML.toString()
	}
}

