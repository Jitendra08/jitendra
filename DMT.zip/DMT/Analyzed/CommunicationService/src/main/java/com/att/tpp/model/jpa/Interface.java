package com.att.tpp.model.jpa;

import java.io.Serializable;
import javax.persistence.*;
import java.math.BigDecimal;


/**
 * The persistent class for the "INTERFACE" database table.
 * 
 */
@Entity
@Table(name="\"INTERFACE\"")
@NamedQuery(name="Interface.findAll", query="SELECT i FROM Interface i")
public class Interface implements Serializable {
	private static final long serialVersionUID = 1L;

	@Column(name="ALARM_OVERRIDE_IND")
	private String alarmOverrideInd;

	@Column(name="CARRIER_NAME")
	private String carrierName;

	private String category;

	@Column(name="CONNECTIVITY_STATUS")
	private String connectivityStatus;

	@Column(name="END_HOUR")
	private String endHour;

	@Column(name="HI_EMAIL_IND")
	private String hiEmailInd;

	@Column(name="HI_THRESHOLD")
	private String hiThreshold;

	@Column(name="INTERFACE_ID")
	private BigDecimal interfaceId;

	@Id
	@Column(name="INTERFACE_NAME")
	private String interfaceName;

	@Column(name="INTERFACE_TYPE")
	private String interfaceType;

	@Column(name="LO_EMAIL_IND")
	private String loEmailInd;

	@Column(name="LO_THRESHOLD")
	private String loThreshold;

	private String location;

	@Column(name="START_HOUR")
	private String startHour;

	public Interface() {
	}

	public String getAlarmOverrideInd() {
		return this.alarmOverrideInd;
	}

	public void setAlarmOverrideInd(String alarmOverrideInd) {
		this.alarmOverrideInd = alarmOverrideInd;
	}

	public String getCarrierName() {
		return this.carrierName;
	}

	public void setCarrierName(String carrierName) {
		this.carrierName = carrierName;
	}

	public String getCategory() {
		return this.category;
	}

	public void setCategory(String category) {
		this.category = category;
	}

	public String getConnectivityStatus() {
		return this.connectivityStatus;
	}

	public void setConnectivityStatus(String connectivityStatus) {
		this.connectivityStatus = connectivityStatus;
	}

	public String getEndHour() {
		return this.endHour;
	}

	public void setEndHour(String endHour) {
		this.endHour = endHour;
	}

	public String getHiEmailInd() {
		return this.hiEmailInd;
	}

	public void setHiEmailInd(String hiEmailInd) {
		this.hiEmailInd = hiEmailInd;
	}

	public String getHiThreshold() {
		return this.hiThreshold;
	}

	public void setHiThreshold(String hiThreshold) {
		this.hiThreshold = hiThreshold;
	}

	public BigDecimal getInterfaceId() {
		return this.interfaceId;
	}

	public void setInterfaceId(BigDecimal interfaceId) {
		this.interfaceId = interfaceId;
	}

	public String getInterfaceName() {
		return this.interfaceName;
	}

	public void setInterfaceName(String interfaceName) {
		this.interfaceName = interfaceName;
	}

	public String getInterfaceType() {
		return this.interfaceType;
	}

	public void setInterfaceType(String interfaceType) {
		this.interfaceType = interfaceType;
	}

	public String getLoEmailInd() {
		return this.loEmailInd;
	}

	public void setLoEmailInd(String loEmailInd) {
		this.loEmailInd = loEmailInd;
	}

	public String getLoThreshold() {
		return this.loThreshold;
	}

	public void setLoThreshold(String loThreshold) {
		this.loThreshold = loThreshold;
	}

	public String getLocation() {
		return this.location;
	}

	public void setLocation(String location) {
		this.location = location;
	}

	public String getStartHour() {
		return this.startHour;
	}

	public void setStartHour(String startHour) {
		this.startHour = startHour;
	}

}