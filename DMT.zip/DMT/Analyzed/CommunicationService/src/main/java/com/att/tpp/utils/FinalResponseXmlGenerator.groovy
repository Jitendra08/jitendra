package com.att.tpp.utils

import com.att.tpp.xml.model.Product;

import java.util.List;

import com.att.tpp.model.FinalResponse
import com.att.tpp.model.jpa.ProductAttribute;
import com.att.tpp.model.jpa.ProvisioningRequest;
import com.att.tpp.model.jpa.ProvisioningTask;
import com.att.tpp.xml.model.Products;

import groovy.util.logging.Log4j;
import groovy.xml.MarkupBuilder

@Log4j
class FinalResponseXmlGenerator {

	public FinalResponseXmlGenerator() {
	}


	def String createCompleteNotificationXML(String messageId, String masterTransactionId){
		def complNotifXML = new StringWriter()
		def xml = new MarkupBuilder(complNotifXML)

		//def completionNotification= complNotif.getCompletionNotification()
		xml.setDoubleQuotes(true)
		xml.mkp.xmlDeclaration(version: "1.0", encoding: "UTF-8")

		xml.CompletionNotification("xmlns:xsi":"http://www.w3.org/2001/XMLSchema-instance",
			Prov_System_TransID:messageId, Master_TransID:masterTransactionId)


		return complNotifXML.toString()
	}
	
	def String createArchiveRequestXML(String masterTransId){
		def archiveRequestXML = new StringWriter()
		def xml = new MarkupBuilder(archiveRequestXML)

		xml.setDoubleQuotes(true)
		xml.mkp.xmlDeclaration(version: "1.0", encoding: "UTF-8")

		xml.ArchiveRequest("xmlns:xsi":"http://www.w3.org/2001/XMLSchema-instance",
			MasterTransactionId:masterTransId)

		return archiveRequestXML.toString()
	}


	
	def String createFinalResponseNotificationXML(FinalResponse finalResponse){
		def finalRespNotifXML = new StringWriter()
		def xml = new MarkupBuilder(finalRespNotifXML)

		xml.setDoubleQuotes(true)
		xml.mkp.xmlDeclaration(version: "1.0", encoding: "UTF-8")

		xml.FinalResponseNotification("xmlns:xsi":"http://www.w3.org/2001/XMLSchema-instance",
			ProvCarrier:finalResponse.provCarrier, ProvSystemTransID:finalResponse.provSystemTransID,
			RoutingCarrier:finalResponse.routingCarrier, CurrentTechRetryCount:finalResponse.currentTechRetryCount,
			MasterTransID: finalResponse.masterTransID, System:finalResponse.system,
			 URL:finalResponse.url, MaxTechRetryCount:finalResponse.maxTechRetryCount)


		return finalRespNotifXML.toString()
	}


	def String createErrorRequestXML(Products products,
			ProvisioningRequest provRequest,
			List<ProvisioningTask> provisioningTasks, List<ProductAttribute> productAttribute) {
		log.debug("Inside createErrorRequestXML");
		def errorRequestXML = new StringWriter()
		def xml = new MarkupBuilder(errorRequestXML)
		def now = new Date()
		xml.setDoubleQuotes(true)
		xml.mkp.xmlDeclaration(version: "1.0", encoding: "UTF-8")
		xml.ErrorRequest("xmlns:xsi":"http://www.w3.org/2001/XMLSchema-instance")
		{
			ErrorInfo( Location: provRequest.location, SystemURL:provisioningTasks.get(0).systemUri,
					   ResponseCapable:false, SystemName:provisioningTasks.get(0).systemName,
					   Master_TransID:provRequest.masterTransid)
			Header(TransactionId:provRequest.provSystemTransid,
				ProvisioningCarrier:provRequest.provisioningCarrier.trim(),
				RoutingCarrier:provRequest.routingCarrier.trim(),
				TimeStamp:now,
				Atlas_Event_Type:provRequest.eventType
				//TODO Map TransCode Major and Minor
				){	TransactionCode(MajorCode: products.product[0].productMax.majorCode , Description:products.product[0].productMax.majorDesc) }
				

			if(provRequest!=null && provRequest.payload!=null && provRequest.payload.length()>0)
			{
				if(provRequest.payloadOverflow!=null && provRequest?.payloadOverflow?.length()>0)
				{
					def payloadFull = provRequest.payload + provRequest.payloadOverflow
					xml.mkp.yieldUnescaped(payloadFull)
				}

				else
				{

					xml.mkp.yieldUnescaped(provRequest.payload)
				}
			}
				
			buildProducts(xml, products.product, productAttribute)
				
/*			if(provRequest!=null && provRequest.payload!=null && provRequest.payload.length()>0)
			{
				if(provRequest?.payloadOverflow!=null && provRequest?.payloadOverflow?.length()>0)
				provRequest.payload.toString() + provRequest.payloadOverflow.toString()
				else
				provRequest.payload.toString()
			}*/
			
		}
		
		return errorRequestXML		
	
    }
			def buildProducts(MarkupBuilder mBuilder, List<Product> product, List<ProductAttribute> productAttribute){
			 
			 
			 mBuilder.Products(){
				 product*.each { prod ->
					 
					 Product(Category:"3PP", Id:prod.id, Action:prod.action){
						 log.debug("Inside Product>>>");
						 productAttribute*.each{ attrib ->
							 log.debug("attrib.productId.toString()>>>"+attrib.productId.toString());
							 if(attrib.productId.toString().equalsIgnoreCase(prod.id) && attrib.action.toString().equalsIgnoreCase(prod.action) )
							 {
								 Attribute(Name:attrib.attributeName.toString(), Value:attrib.attributeValue.toString())
							 }
						 }

						 //TODO Map transcodes
						 TransactionCode(MajorCode: prod.productMax.majorCode , Description:prod.productMax.majorDesc){						 
							 prod.transactionCode.transactionCodeList.collect{							 
								 TransactionCodeList(ErrorCode: prod.productMax.minorCode, ErrorMessageText:prod.productMax.minorDesc)
							 }
						 }
						 }
					 }
				 }	
			 
			}
		 
			
	
}


