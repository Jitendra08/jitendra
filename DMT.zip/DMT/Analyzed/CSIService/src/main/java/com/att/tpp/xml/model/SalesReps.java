package com.att.tpp.xml.model;

public class SalesReps {

    protected NameInfoCSIDP name;
    protected String salesRepresentative;
    protected String affiliateSalesRepCode;
    protected DealerInfo dealerCode;
    protected String position;
    protected String territory;
    protected String jobTitle;

    /**
	 * @param name
	 * @param dealerCode
	 * @param position
	 * @param territory
	 * @param jobTitle
	 */
	public SalesReps(NameInfoCSIDP name, DealerInfo dealerCode,
			String position, String territory, String jobTitle) {
		super();
		this.name = name;
		this.dealerCode = dealerCode;
		this.position = position;
		this.territory = territory;
		this.jobTitle = jobTitle;
	}

	/**
	 * @param name
	 * @param salesRepresentative
	 * @param affiliateSalesRepCode
	 * @param dealerCode
	 * @param position
	 * @param territory
	 * @param jobTitle
	 */
	public SalesReps(NameInfoCSIDP name, String salesRepresentative,
			String affiliateSalesRepCode, DealerInfo dealerCode,
			String position, String territory, String jobTitle) {
		this.name = name;
		this.salesRepresentative = salesRepresentative;
		this.affiliateSalesRepCode = affiliateSalesRepCode;
		this.dealerCode = dealerCode;
		this.position = position;
		this.territory = territory;
		this.jobTitle = jobTitle;
	}

	/**
     * Gets the value of the name property.
     * 
     * @return
     *     possible object is
     *     {@link NameInfoCSIDP }
     *     
     */
    public NameInfoCSIDP getName() {
        return name;
    }

    /**
     * Sets the value of the name property.
     * 
     * @param name
     *     allowed object is
     *     {@link NameInfoCSIDP }
     *     
     */
    public void setName(NameInfoCSIDP name) {
        this.name = name;
    }

    /**
     * Gets the value of the salesRepresentative property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getSalesRepresentative() {
        return salesRepresentative;
    }

    /**
     * Sets the value of the salesRepresentative property.
     * 
     * @param salesRepresentative
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setSalesRepresentative(String salesRepresentative) {
        this.salesRepresentative = salesRepresentative;
    }

    /**
     * Gets the value of the affiliateSalesRepCode property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getAffiliateSalesRepCode() {
        return affiliateSalesRepCode;
    }

    /**
     * Sets the value of the affiliateSalesRepCode property.
     * 
     * @param affiliateSalesRepCode
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setAffiliateSalesRepCode(String affiliateSalesRepCode) {
        this.affiliateSalesRepCode = affiliateSalesRepCode;
    }

    /**
     * Gets the value of the dealerCode property.
     * 
     * @return
     *     possible object is
     *     {@link DealerInfo }
     *     
     */
    public DealerInfo getDealerCode() {
        return dealerCode;
    }

    /**
     * Sets the value of the dealerCode property.
     * 
     * @param dealerCode
     *     allowed object is
     *     {@link DealerInfo }
     *     
     */
    public void setDealerCode(DealerInfo dealerCode) {
        this.dealerCode = dealerCode;
    }

    /**
     * Gets the value of the position property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getPosition() {
        return position;
    }

    /**
     * Sets the value of the position property.
     * 
     * @param position
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setPosition(String position) {
        this.position = position;
    }

    /**
     * Gets the value of the territory property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getTerritory() {
        return territory;
    }

    /**
     * Sets the value of the territory property.
     * 
     * @param territory
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setTerritory(String territory) {
        this.territory = territory;
    }

    /**
     * Gets the value of the jobTitle property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getJobTitle() {
        return jobTitle;
    }

    /**
     * Sets the value of the jobTitle property.
     * 
     * @param jobTitle
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setJobTitle(String jobTitle) {
        this.jobTitle = jobTitle;
    }

}
