package com.att.tpp.ws;

import java.math.BigInteger;
import java.sql.Timestamp;
import java.util.Date;

import javax.xml.ws.Holder;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.att.tpp.enumuration.CSIEventType;
import com.att.tpp.model.CSIResponseKeys;
import com.att.tpp.model.WebServiceResponseData;
import com.att.tpp.utils.CSIServiceMessageParser;
import com.att.tpp.utils.CSITransactionIDGenerator;
import com.cingular.csi.csi.namespaces.container._public.add3ppordernotesrequest.Add3PPOrderNotesRequestInfo;
import com.cingular.csi.csi.namespaces.container._public.add3ppordernotesresponse.Add3PPOrderNotesResponseInfo;
import com.cingular.csi.csi.namespaces.types._public.cingulardatamodel.OrderDocumentInfo;
import com.cingular.csi.csi.namespaces.types._public.messageheader.MessageHeaderInfo;
import com.cingular.csi.csi.namespaces.v118.wsdl.cingularwirelesscsi.Add3PPOrderNotesPortType;
import com.cingular.csi.csi.namespaces.v118.wsdl.cingularwirelesscsi.CSIApplicationException;

@Transactional
@Service("addOrderNotesNotification")
public class AddOrderNotesNotificationImpl implements AddOrderNotesNotification {
	
	private static Logger addOrderNotesNotificationLog = Logger.getLogger(AddOrderNotesNotificationImpl.class);
	
	@Autowired
	private CSIMessageHeaderService csiMessageHeaderService;
		
	@Autowired 
	private Add3PPOrderNotesPortType add3PPOrderNotesPortType;

	@Override
	public WebServiceResponseData doAdd3PPOrderNotesRequest(
			CSIResponseKeys csiResponseKeys, String requestXML) throws CSIApplicationException, Exception {
						
		addOrderNotesNotificationLog.info("[doAdd3PPOrderNotesRequest] Executing Add3PPOrderNotesRequest with OrderId: " + csiResponseKeys.getConcatOrderID());
		
		
		//Generating Message Header
		Holder<MessageHeaderInfo> messageHeader = null;
		String csiTransactionId = null;
		CSITransactionIDGenerator csiIDGen = new CSITransactionIDGenerator();
		csiTransactionId = csiIDGen.generateCSITransactionId("");  //passing blank to get generated transactionId for CSI Service call
		
		//Generate the WebresponseData.
		WebServiceResponseData webServiceResponseData = new WebServiceResponseData();
		webServiceResponseData.setTppcsiTransactionid(csiTransactionId);			
		webServiceResponseData.setTppTransactionid(csiResponseKeys.getMessageTransactionID());
		webServiceResponseData.setOrderid(csiResponseKeys.getConcatOrderID());
		webServiceResponseData.setInputXml(requestXML);
		webServiceResponseData.setCarrierName(csiResponseKeys.getProvisioningCarrier());
		webServiceResponseData.setRoutingCarrier(csiResponseKeys.getRoutingCarrier());
		webServiceResponseData.setInterfaceName(CSIEventType.AddOrderNotes.toString());
		Date date = new Date();			
		webServiceResponseData.setTimeStamp(new Timestamp(date.getTime()));

		
		try {
			
			messageHeader = csiMessageHeaderService.generateCSIMessageHeader(csiTransactionId);
			
		} catch (Exception e) {
			
			addOrderNotesNotificationLog.info("Exception occured while generating CSIMessageHeader, MessageId: " + csiTransactionId);
			addOrderNotesNotificationLog.info("Exception occured while generating CSIMessageHeader, OrderId: " + csiResponseKeys.getConcatOrderID());
			e.printStackTrace();
			throw e;
		}
		
		//Create Web Service request
		OrderDocumentInfo orderId = new OrderDocumentInfo();
		orderId.setLocation(csiResponseKeys.getOrderId().getLocation());
		orderId.setActivity(csiResponseKeys.getOrderId().getActivity());
		orderId.setOrderId(new BigInteger(csiResponseKeys.getOrderId().getOrderId()));
		
		Add3PPOrderNotesRequestInfo add3PPOrderNotesRequestData = new Add3PPOrderNotesRequestInfo();
		add3PPOrderNotesRequestData.setOrderId(orderId);
		add3PPOrderNotesRequestData.setReasonCode(csiResponseKeys.getReasonCode());
		add3PPOrderNotesRequestData.setComment(csiResponseKeys.getComment());
		
		Add3PPOrderNotesResponseInfo add3PPOrderNotesResponseInfo = null;
		
		try{
			
			add3PPOrderNotesResponseInfo = add3PPOrderNotesPortType.add3PPOrderNotes(messageHeader, add3PPOrderNotesRequestData);
			//TODO Need to persist response

			//Pass the Response code information
			webServiceResponseData.setCsiResponsecode(add3PPOrderNotesResponseInfo.getResponse().getCode());
			webServiceResponseData.setCsiResponsedesc(add3PPOrderNotesResponseInfo.getResponse().getDescription());	
			webServiceResponseData.setSkuStatus("S");
			
			
		} catch (CSIApplicationException csiae){
			
			addOrderNotesNotificationLog.info("[doAdd3PPOrderNotesRequest] Add3PPOrderNotes Web Service call Failed!");
			addOrderNotesNotificationLog.info("[doAdd3PPOrderNotesRequest] Error Code: " + csiae.getFaultInfo().getResponse().getCode());
			addOrderNotesNotificationLog.info("[doAdd3PPOrderNotesRequest] Error Description: " + csiae.getFaultInfo().getResponse().getDescription());
			addOrderNotesNotificationLog.info("[doAdd3PPOrderNotesRequest] Error Message: " + csiae.getMessage());
			webServiceResponseData.setSkuStatus("F");
			webServiceResponseData.setCsiResponsecode(csiae.getFaultInfo().getResponse().getCode());
			webServiceResponseData.setCsiResponsedesc(csiae.getFaultInfo().getResponse().getDescription());
			webServiceResponseData.setErrorMessage(csiae.getMessage());
			
			//throw csiae;
		} catch (Exception e){
			addOrderNotesNotificationLog.info("[doAdd3PPOrderNotesRequest] Exception :: Error Message: " + e.getMessage());
			webServiceResponseData.setSkuStatus("F");
			webServiceResponseData.setCsiResponsecode("900");
			webServiceResponseData.setCsiResponsedesc("Exception thrown in doAdd3PPOrderNotesRequest Response");
			webServiceResponseData.setErrorMessage(e.getMessage());
		}
		
		addOrderNotesNotificationLog.info("[doAdd3PPOrderNotesRequest] Add3PPOrderNotes Web Service call completed with Success!");
		addOrderNotesNotificationLog.info("[doAdd3PPOrderNotesRequest] Add3PPOrderNotes Web Service call made with OrderId: " + csiResponseKeys.getConcatOrderID());
		
		return webServiceResponseData;
	}

	@Override
	public WebServiceResponseData invokeAddOrderNotes(String requestXML,
			String eventType, String methodName,
			WebServiceResponseData webServiceResponseData,
			CSIServiceMessageParser csiMessageParser)
			throws CSIApplicationException, Exception {
		//String result;
		try {								
			addOrderNotesNotificationLog.info(methodName + "Invoking add3PPOrderNotes Web Service");				
			CSIResponseKeys csiResponseKeys = csiMessageParser.parseAddOrderNotes(requestXML, eventType);
			webServiceResponseData = doAdd3PPOrderNotesRequest(csiResponseKeys, requestXML);				
			addOrderNotesNotificationLog.info(methodName + "Completed invoking add3PPOrderNotes Web Service");
			
		} catch (CSIApplicationException csiApplicationException){				
			addOrderNotesNotificationLog.info(methodName + "Exception occured when invoking add3PPOrderNotes Web Service");
			addOrderNotesNotificationLog.info(methodName + "Error Code: " + csiApplicationException.getFaultInfo().getResponse().getCode());
			addOrderNotesNotificationLog.info(methodName + "Error Description: "  + csiApplicationException.getFaultInfo().getResponse().getDescription());
			addOrderNotesNotificationLog.info(methodName + "Error Message: " + csiApplicationException.getMessage());				
			//result = csiApplicationException.getFaultInfo().getResponse().getCode() + " - " + csiApplicationException.getFaultInfo().getResponse().getDescription() + "-" + csiApplicationException.getMessage();				
			//throw csiApplicationException;				
		} 
		return webServiceResponseData;
	}
	

}
