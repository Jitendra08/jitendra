package com.att.tpp.xml.model;

public class TPPProvisioningRequest {

    private Header header;
    private Order order;
    private Products products;    
    
    /**
	 * @param header
	 * @param order
	 * @param products
	 */
	public TPPProvisioningRequest(Header header, Order order,
			Products products) {
		this.header = header;
		this.order = order;
		this.products = products;
	}
	

	public TPPProvisioningRequest() {
		// TODO Auto-generated constructor stub
	}


	/**
	 * @return the header
	 */
	public Header getHeader() {
		return header;
	}


	/**
	 * @param header the header to set
	 */
	public void setHeader(Header header) {
		this.header = header;
	}

	
	/**
	 * @return the order
	 */
	public Order getOrder() {
		return order;
	}

	
	/**
	 * @param order the order to set
	 */
	public void setOrder(Order order) {
		this.order = order;
	}

	
	/**
	 * @return the products
	 */
	public Products getProducts() {
		return products;
	}


	/**
	 * @param products the products to set
	 */
	public void setProducts(Products products) {
		this.products = products;
	}

	
	

}
