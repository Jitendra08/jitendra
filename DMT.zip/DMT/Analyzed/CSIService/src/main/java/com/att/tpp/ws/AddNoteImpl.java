package com.att.tpp.ws;

import java.sql.Timestamp;
import java.util.Date;
import java.util.Iterator;
import java.util.List;

import javax.xml.ws.Holder;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.att.tpp.enumuration.CSIEventType;
import com.att.tpp.model.CSIResponseKeys;
import com.att.tpp.model.WebServiceResponseData;
import com.att.tpp.utils.CSIServiceMessageParser;
import com.att.tpp.utils.CSITransactionIDGenerator;
import com.cingular.csi.csi.namespaces.container._public.addnoterequest.AddNoteRequestInfo;
import com.cingular.csi.csi.namespaces.container._public.addnoteresponse.AddNoteResponseInfo;
import com.cingular.csi.csi.namespaces.types._public.cingulardatamodel.AccountSubscriberSelector;
import com.cingular.csi.csi.namespaces.types._public.cingulardatamodel.AccountSubscriberSelector.BillingAccountInformation;
import com.cingular.csi.csi.namespaces.types._public.cingulardatamodel.AddNoteAccountTypeInfo;
import com.cingular.csi.csi.namespaces.types._public.cingulardatamodel.FoundationAccountSubscriberSelectorInfo;
import com.cingular.csi.csi.namespaces.types._public.cingulardatamodel.NotesInfo;
import com.cingular.csi.csi.namespaces.types._public.messageheader.MessageHeaderInfo;
import com.cingular.csi.csi.namespaces.v118.wsdl.cingularwirelesscsi.AddNotePortType;
import com.cingular.csi.csi.namespaces.v118.wsdl.cingularwirelesscsi.CSIApplicationException;

@Transactional
@Service("addNote")
public class AddNoteImpl implements AddNote {
	
	private static final String methodName = "[doAddNote] ";
	
	private static final String SKU_MSISDN = "00000000000";
	private static final String DLIFE_MSISDN = "44444444444";	
	
	private static final String NOTE_TYPE = "R";
	private static final String PRIORITY = "P";
	
	private static Logger addNoteLog = Logger.getLogger(AddNoteImpl.class);
	
	@Autowired
	private CSIMessageHeaderService csiMessageHeaderService;
		
	@Autowired 
	private AddNotePortType addNotePortType;
	
	@Override
	public WebServiceResponseData doAddNote(CSIResponseKeys csiResponseKeys, String requestXML, String transId)
			throws CSIApplicationException, Exception {

		addNoteLog.info(methodName + "Executing AddNotes");
		
		//Generating Message Header
		Holder<MessageHeaderInfo> messageHeader = null;
		String csiTransactionId = null;
		CSITransactionIDGenerator csiIDGen = new CSITransactionIDGenerator();
		//csiTransactionId = csiIDGen.generateCSITransactionId("3PP");  //passing blank to get generated transactionId for CSI Service call	
		addNoteLog.info("doAddNote outside check :: csiTransactionId: " + csiResponseKeys.getTppCSITransactionID());
		if(transId==null || transId.equals(""))
		{
		addNoteLog.info("doAddNote inside null :: csiTransactionId: " + transId);
		csiTransactionId = csiIDGen.generateCSITransactionId(""); //passing blank to get generated transactionId for CSI Service call
		}else{
		csiTransactionId=transId;
		addNoteLog.info("doAddNote inside else :: csiTransactionId: " + csiTransactionId);
		}
		addNoteLog.info("doAddNote csiTransactionId: " + csiTransactionId);
		
		
		//Generate the WebresponseData.
		WebServiceResponseData webServiceResponseData = new WebServiceResponseData();
		webServiceResponseData.setTppcsiTransactionid(csiTransactionId);			
		webServiceResponseData.setTppTransactionid(csiResponseKeys.getMessageTransactionID());
		webServiceResponseData.setInputXml(requestXML);
		webServiceResponseData.setCarrierName(csiResponseKeys.getProvisioningCarrier());
		webServiceResponseData.setRoutingCarrier(csiResponseKeys.getRoutingCarrier());
		webServiceResponseData.setInterfaceName(CSIEventType.AddNote.toString());
		Date date = new Date();			
		webServiceResponseData.setTimeStamp(new Timestamp(date.getTime()));
		
		try {
			
			messageHeader = csiMessageHeaderService.generateCSIMessageHeader(csiTransactionId);
			
		} catch (Exception e) {
			
			addNoteLog.info(methodName + "Exception occured while generating CSIMessageHeader, MessageId: " + csiTransactionId);			
			e.printStackTrace();
			throw e;
		}
		
		//Create Web Service request
		
		AccountSubscriberSelector accountSubscriberSelector = new AccountSubscriberSelector();		
		
		
		
		if(csiResponseKeys.getCtn().equals(SKU_MSISDN) || csiResponseKeys.getCtn().equals(DLIFE_MSISDN)){
		
			BillingAccountInformation ban = new BillingAccountInformation();
			ban.setBillingAccountNumber(csiResponseKeys.getBan());
			accountSubscriberSelector.setBillingAccountInformation(ban);		
		
		}
		else{
		
			accountSubscriberSelector.setSubscriberNumber(csiResponseKeys.getCtn());
			
		}
		
		FoundationAccountSubscriberSelectorInfo foundationAccountSubscriberSelectorInfo = new FoundationAccountSubscriberSelectorInfo();		
		foundationAccountSubscriberSelectorInfo.setAccountSubscriberSelector(accountSubscriberSelector);
		
		NotesInfo notesInfo = new NotesInfo();		
		notesInfo.setNoteType(NOTE_TYPE);
		notesInfo.setPriority(PRIORITY);
		/*
		 * WR #2999975 - 3PP limitation: AddNote CSI call not supported for Multiple APP Ids
		 * Modified below code to add multiple Notes to the Notes tag for AddNote service.
		 */
		String noteTextDetails = "";
		List<String> listNotesInfo = csiResponseKeys.getNoteTextList();
		Iterator<String> noteTextIterator = listNotesInfo.iterator();
		while(noteTextIterator.hasNext())
		{
			noteTextDetails=noteTextIterator.next().toString();
			notesInfo.getNoteText().add(noteTextDetails);
		}
	
		
		AddNoteRequestInfo addNoteRequestInfo = new AddNoteRequestInfo();
		addNoteRequestInfo.setAccountType(AddNoteAccountTypeInfo.BILLING);
		addNoteRequestInfo.setAccountSelector(foundationAccountSubscriberSelectorInfo);		
		addNoteRequestInfo.setNotes(notesInfo);				
		
		AddNoteResponseInfo addNoteResponseInfo = null;
		
		try{
			
			addNoteResponseInfo = addNotePortType.addNote(messageHeader, addNoteRequestInfo);			
			//TODO Need to persist response
			
			//Pass the Response code information
			webServiceResponseData.setCsiResponsecode(addNoteResponseInfo.getResponse().getCode());
			webServiceResponseData.setCsiResponsedesc(addNoteResponseInfo.getResponse().getDescription());		
			webServiceResponseData.setSkuStatus("S");
			
		} catch (CSIApplicationException csiApplicationException){
			
			addNoteLog.info(methodName + "AddNotes Web Service call Failed!");
			addNoteLog.info(methodName + "Error Code: " + csiApplicationException.getFaultInfo().getResponse().getCode());
			addNoteLog.info(methodName + "Error Description: " + csiApplicationException.getFaultInfo().getResponse().getDescription());
			addNoteLog.info(methodName + "Error Message: " + csiApplicationException.getMessage());
			
			webServiceResponseData.setSkuStatus("F");
			webServiceResponseData.setCsiResponsecode(csiApplicationException.getFaultInfo().getResponse().getCode());
			webServiceResponseData.setCsiResponsedesc(csiApplicationException.getFaultInfo().getResponse().getDescription());
			webServiceResponseData.setErrorMessage(csiApplicationException.getMessage());
		}catch(Exception e){
			addNoteLog.info(methodName + "Exception in AddNotes Web Service call >>>>"+e.getMessage());
			webServiceResponseData.setSkuStatus("F");
			webServiceResponseData.setCsiResponsecode("900");
			webServiceResponseData.setCsiResponsedesc("Exception thrown in AddNotes Response");
			webServiceResponseData.setErrorMessage(e.getMessage());
		}
		
		addNoteLog.info(methodName + "AddNotes Web Service call completed with Success!");
		addNoteLog.info(methodName + "AddNotes Web Service call made with CTN: " + csiResponseKeys.getCtn());
		addNoteLog.info(methodName + "AddNotes Web Service call made with MessageID: " + csiTransactionId);
		
		return webServiceResponseData;
	}

	@Override
	public WebServiceResponseData invokeAddNote(String requestXML,
			String eventType, String methodName,
			WebServiceResponseData webServiceResponseData,
			CSIServiceMessageParser csiMessageParser)
			throws CSIApplicationException, Exception {
		try{
			addNoteLog.info(methodName + "Invoking AddNote Web Service");
			CSIResponseKeys csiResponseKeys = csiMessageParser.parseAddNote(requestXML, eventType);
			webServiceResponseData = doAddNote(csiResponseKeys, requestXML,webServiceResponseData.getTppcsiTransactionid());
			addNoteLog.info(methodName + "Completed invoking AddNote Web Service");
		
		} catch (CSIApplicationException csiApplicationException){
			
			addNoteLog.info(methodName + "Exception occured when invoking AddNote Web Service");
			addNoteLog.info(methodName + "Error Code: " + csiApplicationException.getFaultInfo().getResponse().getCode());
			addNoteLog.info(methodName + "Error Description: "  + csiApplicationException.getFaultInfo().getResponse().getDescription());
			addNoteLog.info(methodName + "Error Message: " + csiApplicationException.getMessage());				
			//throw csiApplicationException;
			
		} 
		
		return webServiceResponseData;
	}

}
