package com.att.tpp.model;

import java.io.Serializable;
import javax.persistence.*;
import java.math.BigDecimal;
import java.util.Date;


/**
 * The persistent class for the TIMER database table. 
 * 
 */
@Entity
@NamedQuery(name="Timer.findAll", query="SELECT t FROM Timer t")
public class Timer implements Serializable {
	private static final long serialVersionUID = 1L;

	@EmbeddedId
	private TimerPK id;

	@Temporal(TemporalType.TIMESTAMP)
	@Column(name="CREATION_TIME")
	private Date creationTime;

	@Temporal(TemporalType.TIMESTAMP)
	@Column(name="EXPIRY_TIME")
	private Date expiryTime;

	@Lob
	@Column(name="PAYLOAD")
	private String payload;

	@Column(name="PAYLOAD_OVERFLOW")
	private String payloadOverflow;

	@Column(name="RETRY_IND")
	private String retryInd;

	@Column(name="TIMER_DURATION")
	private BigDecimal timerDuration;

	public Timer() {
	}

	public TimerPK getId() {
		return this.id;
	}

	public void setId(TimerPK id) {
		this.id = id;
	}

	public Date getCreationTime() {
		return this.creationTime;
	}

	public void setCreationTime(Date creationTime) {
		this.creationTime = creationTime;
	}

	public Date getExpiryTime() {
		return this.expiryTime;
	}

	public void setExpiryTime(Date expiryTime) {
		this.expiryTime = expiryTime;
	}

	public String getPayload() {
		return this.payload;
	}

	public void setPayload(String payload) {
		this.payload = payload;
	}

	public String getPayloadOverflow() {
		return this.payloadOverflow;
	}

	public void setPayloadOverflow(String payloadOverflow) {
		this.payloadOverflow = payloadOverflow;
	}

	public String getRetryInd() {
		return this.retryInd;
	}

	public void setRetryInd(String retryInd) {
		this.retryInd = retryInd;
	}

	public BigDecimal getTimerDuration() {
		return this.timerDuration;
	}

	public void setTimerDuration(BigDecimal timerDuration) {
		this.timerDuration = timerDuration;
	}

}