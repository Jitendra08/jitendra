package com.att.tpp.utils

import java.util.List;

import com.att.tpp.model.ProvisioningRequest;
import com.att.tpp.model.ProvisioningTask;
import com.att.tpp.xml.model.Product;
import com.att.tpp.xml.model.Products;

import groovy.xml.MarkupBuilder


class XMLGenerator {

	XMLGenerator() {}

	String createArchiveRequestXML(String masterTransId){
		
		def archiveRequestXML = new StringWriter()
		def xml = new MarkupBuilder(archiveRequestXML)

		xml.setDoubleQuotes(true)
		xml.mkp.xmlDeclaration(version: "1.0", encoding: "UTF-8")

		xml.ArchiveRequest("xmlns:xsi":"http://www.w3.org/2001/XMLSchema-instance", "xsi:noNamespaceSchemaLocation":"TPP_ArchiveRequest.xsd", 
			MasterTransactionId:masterTransId)

		return archiveRequestXML.toString()
		
	}
	
	
	String createErrorRequestXML(Products products, ProvisioningRequest provRequest, List<ProvisioningTask> provisioningTasks) {
		
		def errorRequestXML = new StringWriter()
		def xml = new MarkupBuilder(errorRequestXML)
		def now = new Date()
		xml.setDoubleQuotes(true)
		xml.mkp.xmlDeclaration(version: "1.0", encoding: "UTF-8")
		xml.ErrorRequest("xmlns:xsi":"http://www.w3.org/2001/XMLSchema-instance")
		{
			ErrorInfo( Location: provRequest.location, SystemURL:provisioningTasks.get(0).systemUri,
					   ResponseCapable:false, SystemName:provisioningTasks.get(0).systemName,
					   Master_TransID:provRequest.masterTransid)
			Header(TransactionId:provRequest.provSystemTransid,
				ProvisioningCarrier:provRequest.provisioningCarrier,
				RoutingCarrier:provRequest.routingCarrier,
				TimeStamp:now,
				Atlas_Event_Type:provRequest.eventType
				//TODO Map TransCode Major and Minor
				){	TransactionCode(MajorCode: products.product[0].productMax.majorCode , Description:products.product[0].productMax.majorDesc) }
				

			if(provRequest!=null && provRequest.payload!=null && provRequest.payload.length()>0)
			{
				if(provRequest.payloadOverflow!=null && provRequest?.payloadOverflow?.length()>0)
				{
					def payloadFull = provRequest.payload + provRequest.payloadOverflow
					xml.mkp.yieldUnescaped(payloadFull)
				}

				else
				{

					xml.mkp.yieldUnescaped(provRequest.payload)
				}
			}
				
			buildProducts(xml, products.product)
				
/*			if(provRequest!=null && provRequest.payload!=null && provRequest.payload.length()>0)
			{
				if(provRequest?.payloadOverflow!=null && provRequest?.payloadOverflow?.length()>0)
				provRequest.payload.toString() + provRequest.payloadOverflow.toString()
				else
				provRequest.payload.toString()
			}*/
			
		}
		
		return errorRequestXML		
	
    }
	
	def buildProducts(MarkupBuilder mBuilder, List<Product> product){
		
		
		mBuilder.Products(){
			product*.each { prod ->
				
				Product(Category:"3PP", Id:prod.id, Action:prod.action){
					//TODO Map transcodes
					TransactionCode(MajorCode: prod.productMax.majorCode , Description:prod.productMax.majorDesc){
					prod.transactionCode.transactionCodeList.collect{
						
						TransactionCodeList(ErrorCode: prod.productMax.minorCode, ErrorMessageText:prod.productMax.minorDesc)
						
					}
					}
					}
				}
			}
		
	   }
}

