package com.att.tpp.xml.model;

public class AccountTypeInfo {

    private String accountTypeCSIIAPDip;
    private String accountSubTypeCSIIAPDip;

    /**
	 * @param accountTypeCSIIAPDip
	 * @param accountSubTypeCSIIAPDip
	 */
	public AccountTypeInfo(String accountTypeCSIIAPDip,
			String accountSubTypeCSIIAPDip) {
		this.accountTypeCSIIAPDip = accountTypeCSIIAPDip;
		this.accountSubTypeCSIIAPDip = accountSubTypeCSIIAPDip;
	}

	/**
     * Gets the value of the accountTypeCSIIAPDip property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getAccountTypeCSIIAPDip() {
        return accountTypeCSIIAPDip;
    }

    /**
     * Sets the value of the accountTypeCSIIAPDip property.
     * 
     * @param accountTypeCSIIAPDip
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setAccountTypeCSIIAPDip(String accountTypeCSIIAPDip) {
        this.accountTypeCSIIAPDip = accountTypeCSIIAPDip;
    }

    /**
     * Gets the value of the accountSubTypeCSIIAPDip property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getAccountSubTypeCSIIAPDip() {
        return accountSubTypeCSIIAPDip;
    }

    /**
     * Sets the value of the accountSubTypeCSIIAPDip property.
     * 
     * @param accountSubTypeCSIIAPDip
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setAccountSubTypeCSIIAPDip(String accountSubTypeCSIIAPDip) {
        this.accountSubTypeCSIIAPDip = accountSubTypeCSIIAPDip;
    }

}
