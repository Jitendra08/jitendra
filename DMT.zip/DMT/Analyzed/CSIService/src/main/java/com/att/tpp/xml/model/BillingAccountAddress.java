package com.att.tpp.xml.model;

public class BillingAccountAddress {

    private String type;
    private String addressLine1;
    private String addressLine2;
    private String city;
    private String state;
    private String postalCode;
    private String internationalPostalCode;
    private String internationalAddressLine;
    private String postalPlusCode;
    private String countryName;
    private String countryCode;
    private String localCompanyName;
    private String geoCode;

    /**
	 * @param type
	 * @param addressLine1
	 * @param addressLine2
	 * @param city
	 * @param state
	 * @param postalCode
	 * @param internationalPostalCode
	 * @param internationalAddressLine
	 * @param postalPlusCode
	 * @param countryName
	 * @param countryCode
	 * @param localCompanyName
	 * @param geoCode
	 */
	public BillingAccountAddress(String type, String addressLine1,
			String addressLine2, String city, String state, String postalCode,
			String internationalPostalCode, String internationalAddressLine,
			String postalPlusCode, String countryName, String countryCode,
			String localCompanyName, String geoCode) {
		this.type = type;
		this.addressLine1 = addressLine1;
		this.addressLine2 = addressLine2;
		this.city = city;
		this.state = state;
		this.postalCode = postalCode;
		this.internationalPostalCode = internationalPostalCode;
		this.internationalAddressLine = internationalAddressLine;
		this.postalPlusCode = postalPlusCode;
		this.countryName = countryName;
		this.countryCode = countryCode;
		this.localCompanyName = localCompanyName;
		this.geoCode = geoCode;
	}

	/**
     * Gets the value of the type property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getType() {
        return type;
    }

    /**
     * Sets the value of the type property.
     * 
     * @param type
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setType(String type) {
        this.type = type;
    }

    /**
     * Gets the value of the addressLine1 property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getAddressLine1() {
        return addressLine1;
    }

    /**
     * Sets the value of the addressLine1 property.
     * 
     * @param addressLine1
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setAddressLine1(String addressLine1) {
        this.addressLine1 = addressLine1;
    }

    /**
     * Gets the value of the addressLine2 property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getAddressLine2() {
        return addressLine2;
    }

    /**
     * Sets the value of the addressLine2 property.
     * 
     * @param addressLine2
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setAddressLine2(String addressLine2) {
        this.addressLine2 = addressLine2;
    }

    /**
     * Gets the value of the city property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCity() {
        return city;
    }

    /**
     * Sets the value of the city property.
     * 
     * @param city
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCity(String city) {
        this.city = city;
    }

    /**
     * Gets the value of the state property.
     * 
     * @return
     *     possible object is
     *     {@link State }
     *     
     */
    public String getState() {
        return state;
    }

    /**
     * Sets the value of the state property.
     * 
     * @param state
     *     allowed object is
     *     {@link State }
     *     
     */
    public void setState(String state) {
        this.state = state;
    }

    /**
     * Gets the value of the postalCode property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getPostalCode() {
        return postalCode;
    }

    /**
     * Sets the value of the postalCode property.
     * 
     * @param postalCode
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setPostalCode(String postalCode) {
        this.postalCode = postalCode;
    }

    /**
     * Gets the value of the internationalPostalCode property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getInternationalPostalCode() {
        return internationalPostalCode;
    }

    /**
     * Sets the value of the internationalPostalCode property.
     * 
     * @param internationalPostalCode
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setInternationalPostalCode(String internationalPostalCode) {
        this.internationalPostalCode = internationalPostalCode;
    }

    /**
     * Gets the value of the internationalAddressLine property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getInternationalAddressLine() {
        return internationalAddressLine;
    }

    /**
     * Sets the value of the internationalAddressLine property.
     * 
     * @param internationalAddressLine
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setInternationalAddressLine(String internationalAddressLine) {
        this.internationalAddressLine = internationalAddressLine;
    }

    /**
     * Gets the value of the postalPlusCode property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getPostalPlusCode() {
        return postalPlusCode;
    }

    /**
     * Sets the value of the postalPlusCode property.
     * 
     * @param postalPlusCode
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setPostalPlusCode(String postalPlusCode) {
        this.postalPlusCode = postalPlusCode;
    }

    /**
     * Gets the value of the countryName property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCountryName() {
        return countryName;
    }

    /**
     * Sets the value of the countryName property.
     * 
     * @param countryName
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCountryName(String countryName) {
        this.countryName = countryName;
    }

    /**
     * Gets the value of the countryCode property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCountryCode() {
        return countryCode;
    }

    /**
     * Sets the value of the countryCode property.
     * 
     * @param countryCode
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCountryCode(String countryCode) {
        this.countryCode = countryCode;
    }

    /**
     * Gets the value of the localCompanyName property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getLocalCompanyName() {
        return localCompanyName;
    }

    /**
     * Sets the value of the localCompanyName property.
     * 
     * @param localCompanyName
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setLocalCompanyName(String localCompanyName) {
        this.localCompanyName = localCompanyName;
    }

    /**
     * Gets the value of the geoCode property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getGeoCode() {
        return geoCode;
    }

    /**
     * Sets the value of the geoCode property.
     * 
     * @param geoCode
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setGeoCode(String geoCode) {
        this.geoCode = geoCode;
    }

}
