package com.att.tpp.xml.model;

public class PhoneInfo {

    private String homePhone;
    private String workPhone;
    private String workPhoneExtension;
    private String canBeReachedPhone;

    /**
	 * @param canBeReachedPhone
	 */
	public PhoneInfo(String canBeReachedPhone) {
		this.canBeReachedPhone = canBeReachedPhone;
	}

	/**
	 * @param homePhone
	 * @param workPhone
	 * @param workPhoneExtension
	 * @param canBeReachedPhone
	 */
	public PhoneInfo(String homePhone, String workPhone,
			String workPhoneExtension, String canBeReachedPhone) {
		this.homePhone = homePhone;
		this.workPhone = workPhone;
		this.workPhoneExtension = workPhoneExtension;
		this.canBeReachedPhone = canBeReachedPhone;
	}

	/**
     * Gets the value of the homePhone property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getHomePhone() {
        return homePhone;
    }

    /**
     * Sets the value of the homePhone property.
     * 
     * @param homePhone
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setHomePhone(String homePhone) {
        this.homePhone = homePhone;
    }

    /**
     * Gets the value of the workPhone property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getWorkPhone() {
        return workPhone;
    }

    /**
     * Sets the value of the workPhone property.
     * 
     * @param workPhone
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setWorkPhone(String workPhone) {
        this.workPhone = workPhone;
    }

    /**
     * Gets the value of the workPhoneExtension property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getWorkPhoneExtension() {
        return workPhoneExtension;
    }

    /**
     * Sets the value of the workPhoneExtension property.
     * 
     * @param workPhoneExtension
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setWorkPhoneExtension(String workPhoneExtension) {
        this.workPhoneExtension = workPhoneExtension;
    }

    /**
     * Gets the value of the canBeReachedPhone property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCanBeReachedPhone() {
        return canBeReachedPhone;
    }

    /**
     * Sets the value of the canBeReachedPhone property.
     * 
     * @param canBeReachedPhone
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCanBeReachedPhone(String canBeReachedPhone) {
        this.canBeReachedPhone = canBeReachedPhone;
    }

}
