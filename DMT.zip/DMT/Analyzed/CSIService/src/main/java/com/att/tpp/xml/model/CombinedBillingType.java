package com.att.tpp.xml.model;

public class CombinedBillingType {

    private String billingTelephoneNumber;
    private String rao;
    private String hybridAgent;
    private String combinedBillingStatus;
    private String combinedBillingEnrollmentDate;

    /**
	 * @param billingTelephoneNumber
	 * @param rao
	 * @param hybridAgent
	 * @param combinedBillingStatus
	 * @param combinedBillingEnrollmentDate
	 */
	public CombinedBillingType(String billingTelephoneNumber, String rao,
			String hybridAgent, String combinedBillingStatus,
			String combinedBillingEnrollmentDate) {
		this.billingTelephoneNumber = billingTelephoneNumber;
		this.rao = rao;
		this.hybridAgent = hybridAgent;
		this.combinedBillingStatus = combinedBillingStatus;
		this.combinedBillingEnrollmentDate = combinedBillingEnrollmentDate;
	}

	/**
     * Gets the value of the billingTelephoneNumber property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getBillingTelephoneNumber() {
        return billingTelephoneNumber;
    }

    /**
     * Sets the value of the billingTelephoneNumber property.
     * 
     * @param billingTelephoneNumber
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setBillingTelephoneNumber(String billingTelephoneNumber) {
        this.billingTelephoneNumber = billingTelephoneNumber;
    }

    /**
     * Gets the value of the rao property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getRAO() {
        return rao;
    }

    /**
     * Sets the value of the rao property.
     * 
     * @param rao
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setRAO(String rao) {
        this.rao = rao;
    }

    /**
     * Gets the value of the hybridAgent property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getHybridAgent() {
        return hybridAgent;
    }

    /**
     * Sets the value of the hybridAgent property.
     * 
     * @param hybridAgent
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setHybridAgent(String hybridAgent) {
        this.hybridAgent = hybridAgent;
    }

    /**
     * Gets the value of the combinedBillingStatus property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCombinedBillingStatus() {
        return combinedBillingStatus;
    }

    /**
     * Sets the value of the combinedBillingStatus property.
     * 
     * @param combinedBillingStatus
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCombinedBillingStatus(String combinedBillingStatus) {
        this.combinedBillingStatus = combinedBillingStatus;
    }

    /**
     * Gets the value of the combinedBillingEnrollmentDate property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCombinedBillingEnrollmentDate() {
        return combinedBillingEnrollmentDate;
    }

    /**
     * Sets the value of the combinedBillingEnrollmentDate property.
     * 
     * @param combinedBillingEnrollmentDate
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCombinedBillingEnrollmentDate(String combinedBillingEnrollmentDate) {
        this.combinedBillingEnrollmentDate = combinedBillingEnrollmentDate;
    }

}
