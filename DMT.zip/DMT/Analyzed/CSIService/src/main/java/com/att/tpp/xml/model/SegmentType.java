package com.att.tpp.xml.model;

public class SegmentType {

    private String segmentCode;
    private String segmentDescription;
    private String subsegmentCode;
    private String subsegmentDescription;

    /**
	 * @param segmentCode
	 * @param segmentDescription
	 * @param subsegmentCode
	 * @param subsegmentDescription
	 */
	public SegmentType(String segmentCode, String segmentDescription,
			String subsegmentCode, String subsegmentDescription) {
		this.segmentCode = segmentCode;
		this.segmentDescription = segmentDescription;
		this.subsegmentCode = subsegmentCode;
		this.subsegmentDescription = subsegmentDescription;
	}

	/**
     * Gets the value of the segmentCode property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getSegmentCode() {
        return segmentCode;
    }

    /**
     * Sets the value of the segmentCode property.
     * 
     * @param segmentCode
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setSegmentCode(String segmentCode) {
        this.segmentCode = segmentCode;
    }

    /**
     * Gets the value of the segmentDescription property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getSegmentDescription() {
        return segmentDescription;
    }

    /**
     * Sets the value of the segmentDescription property.
     * 
     * @param segmentDescription
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setSegmentDescription(String segmentDescription) {
        this.segmentDescription = segmentDescription;
    }

    /**
     * Gets the value of the subsegmentCode property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getSubsegmentCode() {
        return subsegmentCode;
    }

    /**
     * Sets the value of the subsegmentCode property.
     * 
     * @param subsegmentCode
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setSubsegmentCode(String subsegmentCode) {
        this.subsegmentCode = subsegmentCode;
    }

    /**
     * Gets the value of the subsegmentDescription property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getSubsegmentDescription() {
        return subsegmentDescription;
    }

    /**
     * Sets the value of the subsegmentDescription property.
     * 
     * @param subsegmentDescription
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setSubsegmentDescription(String subsegmentDescription) {
        this.subsegmentDescription = subsegmentDescription;
    }

}
