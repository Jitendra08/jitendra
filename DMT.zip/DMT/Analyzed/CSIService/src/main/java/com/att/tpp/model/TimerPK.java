package com.att.tpp.model;

import java.io.Serializable;
import javax.persistence.*;

/**
 * The primary key class for the TIMER database table. 
 * 
 */
@Embeddable
public class TimerPK implements Serializable {
	//default serial version id, required for serializable classes.
	private static final long serialVersionUID = 1L;

	@Column(name="TASK_TRANSID")
	private String taskTransid;

	@Column(name="SYSTEM_NAME")
	private String systemName;

	@Column(name="TIMER_STATE")
	private String timerState;

	public TimerPK() {
	}
	public String getTaskTransid() {
		return this.taskTransid;
	}
	public void setTaskTransid(String taskTransid) {
		this.taskTransid = taskTransid;
	}
	public String getSystemName() {
		return this.systemName;
	}
	public void setSystemName(String systemName) {
		this.systemName = systemName;
	}
	public String getTimerState() {
		return this.timerState;
	}
	public void setTimerState(String timerState) {
		this.timerState = timerState;
	}
}