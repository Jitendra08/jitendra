package com.att.tpp.model;

import java.io.Serializable;
import javax.persistence.*;
import java.math.BigDecimal;
import java.util.Date;


/**
 * The persistent class for the CSI_MESSAGE_ARCHIVE database table.
 * 
 */
@Entity
@Table(name="CSI_MESSAGE_ARCHIVE")
public class CSI_MESSAGE_ARCHIVE implements Serializable {
	private static final long serialVersionUID = 1L;
	
    @Id
    @Column(name="TPP_TRANSACTIONID", nullable=false)
	private String tppTransactionid;

	@Column(name="CARRIER_NAME")
	private String carrierName;

	@Column(name="CLEARED_BY")
	private String clearedBy;

	@Temporal(TemporalType.DATE)
	@Column(name="CLEARED_TIMESTAMP")
	private Date clearedTimestamp;

	@Column(name="CSI_RESPONSECODE")
	private String csiResponsecode;

	@Column(name="CSI_RESPONSEDESC")
	private String csiResponsedesc;

	@Column(name="ERROR_CLEARED_IND")
	private String errorClearedInd;

	@Lob
	@Column(name="INPUT_XML")
	private String inputXml;

	@Column(name="INTERFACE_NAME")
	private String interfaceName;

	@Column(name="LOCATION")
	private String location;

	@Column(name="ORDERID")
	private String orderid;

	@Column(name="RETRY_COUNT")
	private BigDecimal retryCount;

	@Column(name="RETRY_STATUS")
	private String retryStatus;

	@Column(name="ROUTING_CARRIER")
	private String routingCarrier;

	@Column(name="SKU_STATUS")
	private String skuStatus;

	@Temporal(TemporalType.TIMESTAMP)
	@Column(name="TIME_STAMP")
	private Date timeStamp;


	@Column(name="TPPCSI_TRANSACTIONID")
	private String tppcsiTransactionid;

	@Column(name="VENDOR_NAME")
	private String vendorName;

	public CSI_MESSAGE_ARCHIVE() {
	}

	public String getCarrierName() {
		return this.carrierName;
	}

	public void setCarrierName(String carrierName) {
		this.carrierName = carrierName;
	}

	public String getClearedBy() {
		return this.clearedBy;
	}

	public void setClearedBy(String clearedBy) {
		this.clearedBy = clearedBy;
	}

	public Date getClearedTimestamp() {
		return this.clearedTimestamp;
	}

	public void setClearedTimestamp(Date clearedTimestamp) {
		this.clearedTimestamp = clearedTimestamp;
	}

	public String getCsiResponsecode() {
		return this.csiResponsecode;
	}

	public void setCsiResponsecode(String csiResponsecode) {
		this.csiResponsecode = csiResponsecode;
	}

	public String getCsiResponsedesc() {
		return this.csiResponsedesc;
	}

	public void setCsiResponsedesc(String csiResponsedesc) {
		this.csiResponsedesc = csiResponsedesc;
	}

	public String getErrorClearedInd() {
		return this.errorClearedInd;
	}

	public void setErrorClearedInd(String errorClearedInd) {
		this.errorClearedInd = errorClearedInd;
	}

	public String getInputXml() {
		return this.inputXml;
	}

	public void setInputXml(String inputXml) {
		this.inputXml = inputXml;
	}

	public String getInterfaceName() {
		return this.interfaceName;
	}

	public void setInterfaceName(String interfaceName) {
		this.interfaceName = interfaceName;
	}

	public String getLocation() {
		return this.location;
	}

	public void setLocation(String location) {
		this.location = location;
	}

	public String getOrderid() {
		return this.orderid;
	}

	public void setOrderid(String orderid) {
		this.orderid = orderid;
	}

	public BigDecimal getRetryCount() {
		return this.retryCount;
	}

	public void setRetryCount(BigDecimal retryCount) {
		this.retryCount = retryCount;
	}

	public String getRetryStatus() {
		return this.retryStatus;
	}

	public void setRetryStatus(String retryStatus) {
		this.retryStatus = retryStatus;
	}

	public String getRoutingCarrier() {
		return this.routingCarrier;
	}

	public void setRoutingCarrier(String routingCarrier) {
		this.routingCarrier = routingCarrier;
	}

	public String getSkuStatus() {
		return this.skuStatus;
	}

	public void setSkuStatus(String skuStatus) {
		this.skuStatus = skuStatus;
	}

	public Date getTimeStamp() {
		return this.timeStamp;
	}

	public void setTimeStamp(Date timeStamp) {
		this.timeStamp = timeStamp;
	}

	public String getTppTransactionid() {
		return this.tppTransactionid;
	}

	public void setTppTransactionid(String tppTransactionid) {
		this.tppTransactionid = tppTransactionid;
	}

	public String getTppcsiTransactionid() {
		return this.tppcsiTransactionid;
	}

	public void setTppcsiTransactionid(String tppcsiTransactionid) {
		this.tppcsiTransactionid = tppcsiTransactionid;
	}

	public String getVendorName() {
		return this.vendorName;
	}

	public void setVendorName(String vendorName) {
		this.vendorName = vendorName;
	}

}