package com.att.tpp.config;
import java.util.Map;
import java.util.Hashtable;

import org.apache.log4j.Logger;

public class InitGlobalInstance {  
  private static Hashtable<String, SystemConfigElement> systemConfig = new Hashtable<String, SystemConfigElement>();  
  private static Hashtable<String, URIConfigElement> uriConfig = new Hashtable<String, URIConfigElement>();
  private static Object lock = new Object();

  
  private static Logger logger = Logger.getLogger(InitGlobalInstance.class);
  //private static org.apache.log4j.Logger logger = org.apache.log4j.Logger.getLogger("bw.logger");

  public static  void  storeCurrentSystemConfig ( String system  , String login, String passwd, String bulkInd ,  String evalFinalRespInd , String nonCriticalInd, String xsltFile, String notifURL) {
       
    try {

      SystemConfigElement sysConfig = new SystemConfigElement (system ,  login , passwd, bulkInd,  evalFinalRespInd , nonCriticalInd , xsltFile  , notifURL);
      
      logger.debug ( "Adding system : " + system + " Value : " + sysConfig + " to systemConfig HashTable");
      systemConfig.put(system, sysConfig);
    } catch (Exception e ) {
      e.printStackTrace();
    }     
  }

   public static Map<String, SystemConfigElement> getSystemConfig () {
      return systemConfig;
   }


  public static  void storeCurrentURIConfig (String system, String URI ,String synchTransInd, String proxyEnabled){ 
       
    try {

      URIConfigElement uriConfigElem = new URIConfigElement (system, URI, synchTransInd, proxyEnabled); 

      logger.debug ("Adding system : " + system + " Value : " + uriConfigElem + " to uriConfig HashTable");
      uriConfig.put(system , uriConfigElem);

    } catch (Exception e ) {
      e.printStackTrace();
    }     
  }

   public static Map<String, URIConfigElement> getURIConfig () {
      return uriConfig;
   }

   public static void emptyConfigTables () {
     logger.debug("emptyConfigTables invoked"); 
      synchronized  ( lock ) {
    	  uriConfig.clear();
    	  systemConfig.clear();
      }
   }
}



