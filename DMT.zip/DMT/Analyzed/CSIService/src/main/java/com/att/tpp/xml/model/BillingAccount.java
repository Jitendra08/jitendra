package com.att.tpp.xml.model;

import java.util.Collection;

public class BillingAccount {

	private BillingAccount.FAN fan;
	private String fanName;
	private String contractId;
	private String contractType;
	private BillingAccount.BillingCycle billingCycle;
	private BillingAccount.Name name;
	private BillingAccount.Address address;
	private BillingAccount.Phone phone;
	private BillingAccount.Email email;
	private BillingAccount.BANEmail banEmail;
	private BillingAccount.BillingMarket billingMarket;

    /**
	 * @param fan
	 * @param fanName
	 * @param contractId
	 * @param contractType
	 * @param billingCycle
	 * @param name
	 * @param address
	 * @param phone
	 * @param email
	 * @param banEmail
	 * @param billingMarket
	 */
	public BillingAccount(FAN fan, String fanName, String contractId,
			String contractType, BillingCycle billingCycle, Name name,
			Address address, Phone phone, Email email, BANEmail banEmail,
			BillingMarket billingMarket) {
		this.fan = fan;
		this.fanName = fanName;
		this.contractId = contractId;
		this.contractType = contractType;
		this.billingCycle = billingCycle;
		this.name = name;
		this.address = address;
		this.phone = phone;
		this.email = email;
		this.banEmail = banEmail;
		this.billingMarket = billingMarket;
	}

	/**
     * Gets the value of the fan property.
     * 
     * @return
     *     possible object is
     *     {@link BillingAccount.FAN }
     *     
     */
    public BillingAccount.FAN getFAN() {
        return fan;
    }

    /**
     * Sets the value of the fan property.
     * 
     * @param value
     *     allowed object is
     *     {@link BillingAccount.FAN }
     *     
     */
    public void setFAN(BillingAccount.FAN value) {
        this.fan = value;
    }

    /**
     * Gets the value of the fanName property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getFANName() {
        return fanName;
    }

    /**
     * Sets the value of the fanName property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setFANName(String value) {
        this.fanName = value;
    }

    /**
     * Gets the value of the contractId property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getContractId() {
        return contractId;
    }

    /**
     * Sets the value of the contractId property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setContractId(String value) {
        this.contractId = value;
    }

    /**
     * Gets the value of the contractType property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getContractType() {
        return contractType;
    }

    /**
     * Sets the value of the contractType property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setContractType(String value) {
        this.contractType = value;
    }

    /**
     * Gets the value of the billingCycle property.
     * 
     * @return
     *     possible object is
     *     {@link BillingAccount.BillingCycle }
     *     
     */
    public BillingAccount.BillingCycle getBillingCycle() {
        return billingCycle;
    }

    /**
     * Sets the value of the billingCycle property.
     * 
     * @param value
     *     allowed object is
     *     {@link BillingAccount.BillingCycle }
     *     
     */
    public void setBillingCycle(BillingAccount.BillingCycle value) {
        this.billingCycle = value;
    }

    /**
     * Gets the value of the name property.
     * 
     * @return
     *     possible object is
     *     {@link BillingAccount.Name }
     *     
     */
    public BillingAccount.Name getName() {
        return name;
    }

    /**
     * Sets the value of the name property.
     * 
     * @param value
     *     allowed object is
     *     {@link BillingAccount.Name }
     *     
     */
    public void setName(BillingAccount.Name value) {
        this.name = value;
    }

    /**
     * Gets the value of the address property.
     * 
     * @return
     *     possible object is
     *     {@link BillingAccount.Address }
     *     
     */
    public BillingAccount.Address getAddress() {
        return address;
    }

    /**
     * Sets the value of the address property.
     * 
     * @param value
     *     allowed object is
     *     {@link BillingAccount.Address }
     *     
     */
    public void setAddress(BillingAccount.Address value) {
        this.address = value;
    }

    /**
     * Gets the value of the phone property.
     * 
     * @return
     *     possible object is
     *     {@link BillingAccount.Phone }
     *     
     */
    public BillingAccount.Phone getPhone() {
        return phone;
    }

    /**
     * Sets the value of the phone property.
     * 
     * @param value
     *     allowed object is
     *     {@link BillingAccount.Phone }
     *     
     */
    public void setPhone(BillingAccount.Phone value) {
        this.phone = value;
    }

    /**
     * Gets the value of the email property.
     * 
     * @return
     *     possible object is
     *     {@link BillingAccount.Email }
     *     
     */
    public BillingAccount.Email getEmail() {
        return email;
    }

    /**
     * Sets the value of the email property.
     * 
     * @param value
     *     allowed object is
     *     {@link BillingAccount.Email }
     *     
     */
    public void setEmail(BillingAccount.Email value) {
        this.email = value;
    }

    /**
     * Gets the value of the banEmail property.
     * 
     * @return
     *     possible object is
     *     {@link BillingAccount.BANEmail }
     *     
     */
    public BillingAccount.BANEmail getBANEmail() {
        return banEmail;
    }

    /**
     * Sets the value of the banEmail property.
     * 
     * @param value
     *     allowed object is
     *     {@link BillingAccount.BANEmail }
     *     
     */
    public void setBANEmail(BillingAccount.BANEmail value) {
        this.banEmail = value;
    }

    /**
     * Gets the value of the billingMarket property.
     * 
     * @return
     *     possible object is
     *     {@link BillingAccount.BillingMarket }
     *     
     */
    public BillingAccount.BillingMarket getBillingMarket() {
        return billingMarket;
    }

    /**
     * Sets the value of the billingMarket property.
     * 
     * @param value
     *     allowed object is
     *     {@link BillingAccount.BillingMarket }
     *     
     */
    public void setBillingMarket(BillingAccount.BillingMarket value) {
        this.billingMarket = value;
    }


    public static class Address {

    	private BillingAccountAddress current;
    	private BillingAccountAddress previous;

        /**
		 * @param current
		 */
		public Address(BillingAccountAddress current) {
			this.current = current;
		}

		/**
		 * @param current
		 * @param previous
		 */
		public Address(BillingAccountAddress current,
				BillingAccountAddress previous) {
			this.current = current;
			this.previous = previous;
		}

		/**
         * Gets the value of the current property.
         * 
         * @return
         *     possible object is
         *     {@link BillingAccountAddress }
         *     
         */
        public BillingAccountAddress getCurrent() {
            return current;
        }

        /**
         * Sets the value of the current property.
         * 
         * @param value
         *     allowed object is
         *     {@link BillingAccountAddress }
         *     
         */
        public void setCurrent(BillingAccountAddress current) {
            this.current = current;
        }

        /**
         * Gets the value of the previous property.
         * 
         * @return
         *     possible object is
         *     {@link BillingAccountAddress }
         *     
         */
        public BillingAccountAddress getPrevious() {
            return previous;
        }

        /**
         * Sets the value of the previous property.
         * 
         * @param value
         *     allowed object is
         *     {@link BillingAccountAddress }
         *     
         */
        public void setPrevious(BillingAccountAddress previous) {
            this.previous = previous;
        }

    }


    public static class BANEmail {

    	private String banEmailType;
    	private String banEmailAddress;

        /**
		 * @param banEmailType
		 * @param banEmailAddress
		 */
		public BANEmail(String banEmailType, String banEmailAddress) {
			this.banEmailType = banEmailType;
			this.banEmailAddress = banEmailAddress;
		}

		/**
         * Gets the value of the banEmailType property.
         * 
         * @return
         *     possible object is
         *     {@link String }
         *     
         */
        public String getBANEmailType() {
            return banEmailType;
        }

        /**
         * Sets the value of the banEmailType property.
         * 
         * @param banEmailType
         *     allowed object is
         *     {@link String }
         *     
         */
        public void setBANEmailType(String banEmailType) {
            this.banEmailType = banEmailType;
        }

        /**
         * Gets the value of the banEmailAddress property.
         * 
         * @return
         *     possible object is
         *     {@link String }
         *     
         */
        public String getBANEmailAddress() {
            return banEmailAddress;
        }

        /**
         * Sets the value of the banEmailAddress property.
         * 
         * @param banEmailAddress
         *     allowed object is
         *     {@link String }
         *     
         */
        public void setBANEmailAddress(String banEmailAddress) {
            this.banEmailAddress = banEmailAddress;
        }

    }


    public static class BillingCycle {

    	private String current;
    	private String previous;
 
		/**
		 * @param current
		 */
		public BillingCycle(String current) {
			this.current = current;
		}

       /**
		 * @param current
		 * @param previous
		 */
		public BillingCycle(String current, String previous) {
			this.current = current;
			this.previous = previous;
		}

		
		/**
         * Gets the value of the current property.
         * 
         * @return
         *     possible object is
         *     {@link String }
         *     
         */
        public String getCurrent() {
            return current;
        }

        /**
         * Sets the value of the current property.
         * 
         * @param value
         *     allowed object is
         *     {@link String }
         *     
         */
        public void setCurrent(String value) {
            this.current = value;
        }

        /**
         * Gets the value of the previous property.
         * 
         * @return
         *     possible object is
         *     {@link String }
         *     
         */
        public String getPrevious() {
            return previous;
        }

        /**
         * Sets the value of the previous property.
         * 
         * @param value
         *     allowed object is
         *     {@link String }
         *     
         */
        public void setPrevious(String value) {
            this.previous = value;
        }

    }


    public static class BillingMarket {

    	private String current;
    	private String previous;

        /**
		 * @param current
		 */
		public BillingMarket(String current) {
			this.current = current;
		}

		/**
		 * @param current
		 * @param previous
		 */
		public BillingMarket(String current, String previous) {
			this.current = current;
			this.previous = previous;
		}

		/**
         * Gets the value of the current property.
         * 
         * @return
         *     possible object is
         *     {@link String }
         *     
         */
        public String getCurrent() {
            return current;
        }

        /**
         * Sets the value of the current property.
         * 
         * @param current
         *     allowed object is
         *     {@link String }
         *     
         */
        public void setCurrent(String current) {
            this.current = current;
        }

        /**
         * Gets the value of the previous property.
         * 
         * @return
         *     possible object is
         *     {@link String }
         *     
         */
        public String getPrevious() {
            return previous;
        }

        /**
         * Sets the value of the previous property.
         * 
         * @param value
         *     allowed object is
         *     {@link String }
         *     
         */
        public void setPrevious(String previous) {
            this.previous = previous;
        }

    }

    
    public static class Email {

    	private Collection<BillingAccountEmail> current;
    	private Collection<BillingAccountEmail> previous;
    	
        /**
		 * @param current
		 */
		public Email(Collection<BillingAccountEmail> current) {
			this.current = current;
		}


		/**
		 * @param current
		 * @param previous
		 */
		public Email(Collection<BillingAccountEmail> current,
				Collection<BillingAccountEmail> previous) {
			this.current = current;
			this.previous = previous;
		}


		/**
		 * @return the currentEmail
		 */
		public Collection<BillingAccountEmail> getCurrent() {
			return current;
		}


		/**
		 * @param currentEmail the currentEmail to set
		 */
		public void setCurrent1(Collection<BillingAccountEmail> current) {
			this.current = current;
		}


		/**
		 * @return the previousEmail
		 */
		public Collection<BillingAccountEmail> getPrevious() {
			return previous;
		}


		/**
		 * @param previousEmail the previousEmail to set
		 */
		public void setPrevious1(Collection<BillingAccountEmail> previous) {
			this.previous = previous;
		}

    }


    
    public static class FAN {

    	private String currentFAN;
    	private String previousFAN;

        /**
		 * @param currentFAN
		 */
		public FAN(String currentFAN) {
			this.currentFAN = currentFAN;
		}

		/**
		 * @param currentFAN
		 * @param previousFAN
		 */
		public FAN(String currentFAN, String previousFAN) {
			this.currentFAN = currentFAN;
			this.previousFAN = previousFAN;
		}

		/**
         * Gets the value of the currentFAN property.
         * 
         * @return
         *     possible object is
         *     {@link String }
         *     
         */
        public String getCurrentFAN() {
            return currentFAN;
        }

        /**
         * Sets the value of the currentFAN property.
         * 
         * @param value
         *     allowed object is
         *     {@link String }
         *     
         */
        public void setCurrentFAN(String value) {
            this.currentFAN = value;
        }

        /**
         * Gets the value of the previousFAN property.
         * 
         * @return
         *     possible object is
         *     {@link String }
         *     
         */
        public String getPreviousFAN() {
            return previousFAN;
        }

        /**
         * Sets the value of the previousFAN property.
         * 
         * @param value
         *     allowed object is
         *     {@link String }
         *     
         */
        public void setPreviousFAN(String value) {
            this.previousFAN = value;
        }

    }


    
    public static class Name {

    	private BillingAccountName current;
    	private BillingAccountName previous;

        /**
		 * @param current
		 */
		public Name(BillingAccountName current) {
			this.current = current;
		}

		/**
		 * @param current
		 * @param previous
		 */
		public Name(BillingAccountName current, BillingAccountName previous) {
			this.current = current;
			this.previous = previous;
		}

		/**
         * Gets the value of the current property.
         * 
         * @return
         *     possible object is
         *     {@link BillingAccountName }
         *     
         */
        public BillingAccountName getCurrent() {
            return current;
        }

        /**
         * Sets the value of the current property.
         * 
         * @param value
         *     allowed object is
         *     {@link BillingAccountName }
         *     
         */
        public void setCurrent(BillingAccountName value) {
            this.current = value;
        }

        /**
         * Gets the value of the previous property.
         * 
         * @return
         *     possible object is
         *     {@link BillingAccountName }
         *     
         */
        public BillingAccountName getPrevious() {
            return previous;
        }

        /**
         * Sets the value of the previous property.
         * 
         * @param value
         *     allowed object is
         *     {@link BillingAccountName }
         *     
         */
        public void setPrevious(BillingAccountName value) {
            this.previous = value;
        }

    }


   
    public static class Phone {

        private BillingAccountPhone current;
        private BillingAccountPhone previous;

        /**
		 * @param current
		 */
		public Phone(BillingAccountPhone current) {
			this.current = current;
		}

		/**
		 * @param current
		 * @param previous
		 */
		public Phone(BillingAccountPhone current, BillingAccountPhone previous) {
			this.current = current;
			this.previous = previous;
		}

		/**
         * Gets the value of the current property.
         * 
         * @return
         *     possible object is
         *     {@link BillingAccountPhone }
         *     
         */
        public BillingAccountPhone getCurrent() {
            return current;
        }

        /**
         * Sets the value of the current property.
         * 
         * @param current
         *     allowed object is
         *     {@link BillingAccountPhone }
         *     
         */
        public void setCurrent(BillingAccountPhone current) {
            this.current = current;
        }

        /**
         * Gets the value of the previous property.
         * 
         * @return
         *     possible object is
         *     {@link BillingAccountPhone }
         *     
         */
        public BillingAccountPhone getPrevious() {
            return previous;
        }

        /**
         * Sets the value of the previous property.
         * 
         * @param previous
         *     allowed object is
         *     {@link BillingAccountPhone }
         *     
         */
        public void setPrevious(BillingAccountPhone previous) {
            this.previous = previous;
        }

    }

}
