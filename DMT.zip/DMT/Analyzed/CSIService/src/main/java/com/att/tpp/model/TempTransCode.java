package com.att.tpp.model;

import java.io.Serializable;

public class TempTransCode implements Serializable{

	private static final long serialVersionUID = 1L;
	
	private String majorCode;
	private String majorDesc;
	private String action;
	private String minorCode;
	private String minorDesc;
	
	
	public String getMajorCode() {
		return majorCode;
	}
	public void setMajorCode(String majorCode) {
		this.majorCode = majorCode;
	}
	public String getMajorDesc() {
		return majorDesc;
	}
	public void setMajorDesc(String majorDesc) {
		this.majorDesc = majorDesc;
	}
	public String getAction() {
		return action;
	}
	public void setAction(String action) {
		this.action = action;
	}

	public String getMinorCode() {
		return minorCode;
	}
	public void setMinorCode(String minorCode) {
		this.minorCode = minorCode;
	}
	public String getMinorDesc() {
		return minorDesc;
	}
	public void setMinorDesc(String minorDesc) {
		this.minorDesc = minorDesc;
	}

}
