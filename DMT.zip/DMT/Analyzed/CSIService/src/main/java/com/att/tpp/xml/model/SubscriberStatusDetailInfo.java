package com.att.tpp.xml.model;

public class SubscriberStatusDetailInfo {

	private String subscriberStatus;
	private String statusReasonCode;
	private Boolean isSuspensionVoluntary;
		
	/**
	 * @param subscriberStatus
	 * @param statusReasonCode
	 * @param isSuspensionVoluntary
	 */
	public SubscriberStatusDetailInfo(String subscriberStatus,
			String statusReasonCode, Boolean isSuspensionVoluntary) {
		this.subscriberStatus = subscriberStatus;
		this.statusReasonCode = statusReasonCode;
		this.isSuspensionVoluntary = isSuspensionVoluntary;
	}
	
	/**
	 * @return the subscriberStatus
	 */
	public String getSubscriberStatus() {
		return subscriberStatus;
	}
	
	/**
	 * @param subscriberStatus the subscriberStatus to set
	 */
	public void setSubscriberStatus(String subscriberStatus) {
		this.subscriberStatus = subscriberStatus;
	}
	
	/**
	 * @return the statusReasonCode
	 */
	public String getStatusReasonCode() {
		return statusReasonCode;
	}
	
	/**
	 * @param statusReasonCode the statusReasonCode to set
	 */
	public void setStatusReasonCode(String statusReasonCode) {
		this.statusReasonCode = statusReasonCode;
	}
	
	/**
	 * @return the isSuspensionVoluntary
	 */
	public Boolean getIsSuspensionVoluntary() {
		return isSuspensionVoluntary;
	}
	
	/**
	 * @param isSuspensionVoluntary the isSuspensionVoluntary to set
	 */
	public void setIsSuspensionVoluntary(Boolean isSuspensionVoluntary) {
		this.isSuspensionVoluntary = isSuspensionVoluntary;
	}		
	
}
