package com.att.tpp.utils;

import groovy.util.slurpersupport.NodeChildren;

import java.util.Collection;

import com.att.tpp.xml.model.BillingAccount.Address;







import com.att.tpp.model.CSIDipKeys
import com.att.tpp.xml.model.BillingAccount.BANEmail;
import com.att.tpp.xml.model.BillingAccount.BillingCycle;
import com.att.tpp.xml.model.BillingAccount.BillingMarket;
import com.att.tpp.xml.model.BillingAccount.Email;
import com.att.tpp.xml.model.BillingAccount.FAN;
import com.att.tpp.xml.model.BillingAccount.Name;
import com.att.tpp.xml.model.BillingAccount.Phone;
import com.att.tpp.xml.model.Attribute
import com.att.tpp.xml.model.BillingAccountAddress
import com.att.tpp.xml.model.BillingAccountEmail
import com.att.tpp.xml.model.BillingAccountName
import com.att.tpp.xml.model.BillingAccountPhone
import com.att.tpp.xml.model.DealerInfo;
import com.att.tpp.xml.model.NameInfoCSIDP;
import com.att.tpp.xml.model.Product
import com.att.tpp.xml.model.SubscriberStatusInfo;
//import com.att.tpp.xml.model.Address;
import com.att.tpp.xml.model.Contact;
import com.att.tpp.xml.model.Account;
import com.att.tpp.xml.model.AccountType;
import com.att.tpp.xml.model.AccountTypeInfo;
import com.att.tpp.xml.model.BillingAccount;
import com.att.tpp.xml.model.CombinedBillingType;
import com.att.tpp.xml.model.CustRegContactInfoBASE;
import com.att.tpp.xml.model.Device
import com.att.tpp.xml.model.Equipment;
import com.att.tpp.xml.model.EventTypeInfo;
import com.att.tpp.xml.model.FinancialNotificationType;
import com.att.tpp.xml.model.ImmutableKeyInfo;
import com.att.tpp.xml.model.MarketInfo;
import com.att.tpp.xml.model.MarketingOption
import com.att.tpp.xml.model.MarketingOptions;
import com.att.tpp.xml.model.ParentalControlsSettingInfo;
import com.att.tpp.xml.model.SIM
import com.att.tpp.xml.model.SalesReps;
import com.att.tpp.xml.model.SegmentType;
import com.att.tpp.xml.model.ServiceInfo;
import com.att.tpp.xml.model.Subscriber;
import com.att.tpp.xml.model.TNAddress
import com.att.tpp.xml.model.TNInfo
import com.att.tpp.xml.model.SubscriberStatusDetailInfo;
import com.att.tpp.xml.model.TNUpdateInfo;
import com.att.tpp.xml.model.TPPSKUOrder;
import com.att.tpp.xml.model.Header;
import com.att.tpp.xml.model.Notification;
import com.att.tpp.xml.model.Order;
import com.att.tpp.xml.model.ProvisioningCarrier;
import com.att.tpp.xml.model.RoutingCarrier;
import com.att.tpp.xml.model.Sender;
import com.att.tpp.xml.model.Products;
import com.att.tpp.xml.model.SubscriberStatusDetailInfo;
import com.att.tpp.xml.model.TPPProvisioningRequest;
import com.cingular.base.interfaces.inquirefanprofilecontactsresponse.InquireFANProfileContactsResponse;
import com.cingular.csi.csi.namespaces.container._public.inquireaccountprofileresponse.InquireAccountProfileResponseInfo;
import com.cingular.csi.csi.namespaces.container._public.inquirefanprofileresponse.InquireFanProfileResponseInfo;
import com.cingular.csi.csi.namespaces.container._public.inquiresubscriberparentalcontrolsresponse.InquireSubscriberParentalControlsResponseInfo;


/**
 * @author SC9833
 *
 */
class DataAugXMLParser {
	
	public DataAugXMLParser() {
	// TODO Auto-generated constructor stub
		
	}
	
	/**
	 * Provide CSIDipKeys model based on TPP_ProvisioningRequest XML.
	 *
	 * @param provReqXML TPP_ProvisioningRequest XML to be parsed
	 * @return CSIDipKeys
	 */
	def CSIDipKeys getCSIKeyInfo(String provReqXML){
		def tppProvReq = new XmlSlurper().parseText(provReqXML)
		def header = tppProvReq.Header
		def order = tppProvReq.Order
		def account = order.Account
		def fan = order.BillingAccount.FAN
		
		def transactionId = new Header(header.@TransactionId.toString())  //TransactionId is a guaranteed field.  No need for null or blank check.
		def parsedAccount = new Account(account.@MSISDN.toString(), account.@SubscriberNumber.toString())  //MSISDN is a guaranteed field.  No need for null or blank check.
		
		def parsedFAN = null
		
		//FAN check
		println("FAN size---> " + fan.size().toString())
		if(fan.size() > 0){
			if(fan.@currentFAN.size() > 0){
				parsedFAN = new FAN(fan.@currentFAN.toString())
			}
		}		
		
		return new CSIDipKeys(transactionId,parsedAccount, parsedFAN)
	}
	
	/**
	 * Provide Account model based on TPP_ProvisioningRequest XML.
	 *
	 * @param provReqXML TPP_ProvisioningRequest XML to be parsed
	 * @return Account
	 */
	def Account getProvReqAccount(String provReqXML){
		def tppProvReq = new XmlSlurper().parseText(provReqXML)
		
		//Order
		def order = tppProvReq.Order
		
		//Account
		def account = order.Account
				
		
		/*String msisdn, String prevMSISDN, String wirelessServiceId,
		String subscriberNumber, String ban, String banName,
		String prevBAN, String accountTypeIndicator,
		String socEffectiveDate, String invoiceId, String eodgroupid*/
		return new Account(account.@MSISDN.toString(), account.@PrevMSISDN.toString(), account.@WirelessServiceId.toString(),
			               account.@SubscriberNumber.toString(), account.@BAN.toString(), account.@BANName.toString(),
						   account.@prevBAN.toString(), account.@accountTypeIndicator.toString(), account.@socEffectiveDate.toString(), account.@InvoiceId.toString(),
						   account.@EOD_GROUP_ID.toString(),)
	}
	
	/**
	 * Provide Account model based on TPP_ProvisioningRequest XML node child account (tppProvReq.Order.Account).
	 *
	 * @param account NodeChildren to be parsed
	 * @return Account
	 */
	def Account getProvReqAccount(NodeChildren account){				
		
		def parsedAccount = null
		
		parsedAccount = new Account(account.@MSISDN.toString(),
			(account.@PrevMSISDN.size()>0) ? account.@PrevMSISDN.toString() : null,
			(account.@WirelessServiceId.size()>0) ? account.@WirelessServiceId.toString() : null,
			account.@SubscriberNumber.toString(),
			account.@BAN.toString(),
			(account.@BANName.size()>0) ? account.@BANName.toString() : null,
			(account.@prevBAN.size()>0) ? account.@prevBAN.toString() : null,
			(account.@prevBAN.size()>0) ? account.@accountTypeIndicator.toString() : null,
			(account.@socEffectiveDate.size()>0) ? account.@socEffectiveDate.toString() : null,
			(account.@InvoiceId.size()>0) ? account.@InvoiceId.toString() : null,
			(account.@EOD_GROUP_ID.size()>0) ? account.@EOD_GROUP_ID.toString() : null)
		
		
		return parsedAccount
	}
	
	/**
	 * Provide FAN model based on TPP_ProvisioningRequest XML.
	 *
	 * @param provReqXML TPP_ProvisioningRequest XML to be parsed
	 * @return FAN
	 */
	def FAN getProvReqFAN(String provReqXML){
		def tppProvReq = new XmlSlurper().parseText(provReqXML)
		
		//Order
		def order = tppProvReq.Order
		
		//BillingAccount		
		def fan = order.BillingAccount.FAN
		
		def parsedFAN = null
		
		//FAN check
		println("FAN size---> " + fan.size().toString())
		if(fan.size() > 0){
			if(fan.@currentFAN.size() > 0){
				parsedFAN = new FAN(fan.@currentFAN.toString())
			}
		}
				
		return parsedFAN 
	}
	 	
	
	/**
	 * Provide parsed TPP_ProvisioningRequest XML into TPPProvisioningRequest model.
	 * 
	 * @param provReqXML TPP_ProvisioningRequest XML to be parsed
	 * @return TPPPRovisioningRequest 
	 */
	def TPPProvisioningRequest getTPPProvReq(String provReqXML, InquireAccountProfileResponseInfo inquireAccountProfileResponse,
		                                     InquireFanProfileResponseInfo inquireFanProfileResponse,InquireFANProfileContactsResponse inquireFanProfileContactsResponse,
											  InquireSubscriberParentalControlsResponseInfo  inquireSubscriberParentalControlsResponse
											 ){
		def tppProvReq = new XmlSlurper().parseText(provReqXML)
		
		//TPP ProvReq XML
		def header = tppProvReq.Header
		def sender = header.Sender
		def notification = header.Notification
		def order = tppProvReq.Order		
		def products = tppProvReq.Products
		
		//Account
		def account = order.Account
		
		//Subscriber
		def subscriber = order.Subscriber
		def subscriberContact = subscriber.Contact
		def subscriberAddress = subscriber.Address
		
		//SubscriberStatusDetail
		def subscriberStatusDetail = order.SubscriberStatusDetail
		
		//Equipment
		def equipment = order.Equipment
		def device = equipment.Device
		def sim = equipment.SIM
		
		//Service Info
		def serviceInfo = order.ServiceInfo
		
		//Market Options
		def marketOptions = order.MarketingOptions //This element has 1 or more children
		
		//Billing Account
		def billingAccount = order.BillingAccount
		
		//Financial Notification
		def financialNotification = order.FinancialNotification
		
		//SKU Order
		def orderNotification = order.TPP_SKUOrder.OrderNotification
		
		//FemtocellNotification
		def femtoCellNotification = order.FemtocellTNUpdate
		
		//ServiceStatusNotification
		def serviceStatusNotification = order.ImmutableKeys
		
		//Parental Controls Info
		def parentalControlsSetting = order.ParentalControlsSettingInfo
		
		//Account Type Info
		/*def accountTypeInfo = order.AccountTypeInfo*/
		
		/*//Segment Type Info
		def segmentType = order.segmentType*/
		
		//Sales Reps
		/*def salesReps = order.salesReps*/  //This element has 0 or more children
		
		//Customer Reg Contact Info
		/*def custRegContactInfo_BASE = order.CustRegContactInfo_BASE*/  //This element has 0 or more children
		
		//Combined Billing
		def combinedBilling = order.CombinedBilling
		
		//Event Type
		def eventType = order.EventType
			
		//Header/Sender Object
		def parsedSender = new Sender(sender.@Login.toString(), sender.@Password.toString())
		
		//Header/Notification Object
		def parsedNotification = new Notification(notification.@URL.toString())
		
		//Header Object
		def parsedHeader = new Header(header.@Atlas_Event_Type.toString(), header.@TransactionId.toString(), 
			header.@ProvisioningCarrier.toString(), header.@RoutingCarrier.toString(), 
			header.@TimeStamp.toString(), parsedSender, parsedNotification)
		
		// Order/Account Object		
		def parsedAccount = getProvReqAccount(account)
		
		// Order/Subscriber/Contact
		def parsedSubContact = subscriberContact.collect {
			new Contact((it.@NamePrefix.size()>0) ? it.@NamePrefix.toString() : null, it.@FirstName.toString(), 
				(it.@MiddleName.size()>0) ? it.@MiddleName.toString() : null,
				it.@LastName.toString(), 
				(it.@NameSuffix.size()>0) ? it.@NameSuffix.toString() : null,
				(it.@PhoneNumber.size()>0) ? it.@PhoneNumber.toString() : null,
				(it.@PersonalEmailAddress.size()>0) ? it.@PersonalEmailAddress.toString() : null,
				(it.@BusinessEmailAddress.size()>0) ? it.@BusinessEmailAddress.toString() : null)
			
		}
		
		// Order/Subscriber/Address
		def parsedSubAddress = subscriberAddress.collect {
			new com.att.tpp.xml.model.Address(
				(it.@Type.size()>0) ? it.@Type.toString() : null,
				(it.@Street.size()>0) ? it.@Street.toString() : null,
				(it.@City.size()>0) ? it.@City.toString() : null, 
				(it.@State.size()>0) ? it.@State.toString() : null, 
				(it.@PostalCode.size()>0) ? it.@PostalCode.toString() : null, 
				(it.@PostalPlusCode.size()>0) ? it.@PostalPlusCode.toString() : null, 
				(it.@CountryName.size()>0) ? it.@CountryName.toString() : null, 
				(it.@CountryCode.size()>0) ? it.@CountryCode.toString() : null,  
				(it.@GeoCode.size()>0) ? it.@GeoCode.toString() : null, 
				(it.@LocalCompanyName.size()>0) ? it.@LocalCompanyName.toString() : null
			)
		}
		
		// Order/Subscriber
		def parsedSubscriber = new Subscriber(parsedSubContact, parsedSubAddress)
		
		// Order/SubscriberStatusDetail
		def parsedSubscriberStatusDetail = null
		
		if(subscriberStatusDetail.size() > 0 ){
			parsedSubscriberStatusDetail = new SubscriberStatusDetailInfo(
				subscriberStatusDetail.subscriberStatus.toString(),				
				subscriberStatusDetail.statusReasonCode.toString(),
				subscriberStatusDetail.isSuspensionVoluntary.toBoolean()				
			)			
		}else
	      if(inquireAccountProfileResponse!=null && inquireAccountProfileResponse?.account?.subscriber?.get(0)?.getSubscriber()?.subscriberStatus?.subscriberStatus.value().length()>0)
		  {
			  def subscriberStatusFrmIAP = inquireAccountProfileResponse.account.subscriber.get(0).getSubscriber().subscriberStatus
			  parsedSubscriberStatusDetail = new SubscriberStatusDetailInfo(
				  subscriberStatusFrmIAP.subscriberStatus.toString(),
				  subscriberStatusFrmIAP.statusReasonCode.toString(),
				  subscriberStatusFrmIAP?.isSuspensionVoluntary?.toBoolean()
			  )
		  }	
		
		// Order/Equipment
		def parsedEquipment = null
		def parsedDevice = null
		def parsedSIM = null
		
		if(equipment.size() >  0){
			if(device.size() > 0 ){
				parsedDevice = new Device(
					device.@Make.toString(),
					device.@Model.toString(),
					device.@ESN.toString(),
					device.@IMEI.toString(),
					device.@MMSCapable.toBoolean()
				)
				if(sim.size() > 0){
					parsedSIM = new SIM(
						sim.@IMSI.toString(),
						sim.@ICCID.toString()						
					)
					parsedEquipment = new Equipment(parsedDevice, parsedSIM)					
				}
				else{
					parsedEquipment = new Equipment(parsedDevice)					
				}
			}
		}
		
		// Order/ServiceInfo
		def parsedServiceInfo = null
		
		if (serviceInfo.size() > 0){
			if(serviceInfo.@PrevNetworkGroup.size() > 0){
				if(serviceInfo.@PrepaidPlatformType.size() > 0){
					
					parsedServiceInfo = new ServiceInfo(
						serviceInfo.@Language.toString(),
						serviceInfo.@Currency.toString(),
						serviceInfo.@Generation.toString(),
						serviceInfo.@NetworkGroup.toString(),
						serviceInfo.@PrevNetworkGroup.toString(),
						serviceInfo.@PaymentType.toString(),
						serviceInfo.@PrepaidPlatformType.toString()						
					)					
				}				
			}
			else{
				parsedServiceInfo = new ServiceInfo(
					serviceInfo.@Language.toString(),
					serviceInfo.@Currency.toString(),
					serviceInfo.@Generation.toString(),
					serviceInfo.@NetworkGroup.toString(),
					serviceInfo.@PaymentType.toString()																
					)
			}			
		}
		
		// Order/MarketingOptions
		def parsedMarketingOptions = null
		
		if(marketOptions.size() > 0){
			parsedMarketingOptions = marketOptions.MarketingOption.collect {
				new MarketingOption(
					it.@Name.toString(),
					it.@Value.toBoolean().booleanValue()
				)
			}
		}
		
		// Order/BillingAccount
		def parsedBillingAccont = null
		
		if(billingAccount.size() > 0){
			parsedBillingAccont = getParsedBillingAccount(billingAccount, inquireAccountProfileResponse, inquireFanProfileResponse)
		}
		
		// Order/FinancialNotification
		def parsedFinancialNotification = null
		
		if(financialNotification.size() > 0){
			parsedFinancialNotification = getParsedFinancialNotification(financialNotification)
		}
		
		// Order/TPP_SKUOrder
		// TODO Need to push this through without parsing if possible
		//Can be skipped since SKU orders do not make it to DIPArchive
		
		// Order/FemtocellTNUpdate
		// TODO Need to push this through without parsing if possible
		def parsedFemtocellTNUpdate = null
		
		if(femtoCellNotification.size() > 0){
			parsedFemtocellTNUpdate = getParsedFemtoCellTNUpdate(femtoCellNotification)
		}
		
		// Order/ImmutableKeys
		// TODO Need to push this through without parsing if possible
		
		// Order/ParentalControlsSettingInfo
		def parsedParentalControls = null
		def reasonCode = inquireSubscriberParentalControlsResponse?.parentalControls?.purchaseBlocking?.reasonCode
		
		if(inquireSubscriberParentalControlsResponse!=null && reasonCode!=null &&  reasonCode.length()>0){
			
			def parentalControl = inquireSubscriberParentalControlsResponse.parentalControls.purchaseBlocking
			
			parsedParentalControls = new ParentalControlsSettingInfo(parentalControl.indicator.toString(), parentalControl.reasonCode.toString())
		}
		
		// Order/AccountTypeInfo
		def parsedAccountTypeInfo = null
		def accountTypeTemp = inquireAccountProfileResponse?.account?.accountType?.accountType
		
		if(inquireAccountProfileResponse != null && accountTypeTemp!=null && accountTypeTemp.length() > 0){
			
			parsedAccountTypeInfo = new AccountTypeInfo(inquireAccountProfileResponse.account.accountType.accountType.toString(), inquireAccountProfileResponse.account.accountType.accountSubType.toString())
		}
		
		// Order/segmentType		
		def parsedSegmentType = null		
		
		def segmentType = inquireFanProfileResponse?.profile?.segmentType
		
		if(inquireFanProfileResponse != null && segmentType!=null)
		{
			parsedSegmentType = new SegmentType(segmentType.segmentCode.toString(), segmentType.segmentDescription.toString(), segmentType.subsegmentCode.toString(), segmentType.subsegmentDescription.toString())
		}
		
		// Order/MarketInfo
		def parsedMarketInfo = null
		def marketInfo = inquireAccountProfileResponse?.account?.billingMarket
		
		if(inquireAccountProfileResponse !=null && inquireAccountProfileResponse?.account?.billingMarket.billingMarket.length() > 0){
			
			parsedMarketInfo = new MarketInfo(marketInfo.billingMarket.toString(), marketInfo.billingSubMarket.toString(), marketInfo.localMarket.toString())
		}
		
		// Order/salesReps		
		def parsedSalesReps = null
		def salesReps = inquireFanProfileResponse?.profile?.salesReps
		
		if(inquireFanProfileResponse != null &&  salesReps!=null ){			
			
			
			parsedSalesReps = salesReps.collect {
				new SalesReps( new NameInfoCSIDP(it.name.namePrefix.toString(), it.name.firstName.toString(),
					                             it.name.middleName.toString(), it.name.lastName.toString(),
												  it.name.nameSuffix.toString(), it.name.additionalTitle.toString() ),
								new DealerInfo(it.dealerCode.code.toString(), it.dealerCode.secondaryCode.toString()),
								it.position.toString(), 
								it.territory.toString(),
								it.jobTitle.toString()
							  )
			}
		}
		
		
		// Order/CustRegContactInfo_BASE
		
		/**
		 * @param namePrefix
		 * @param firstName
		 * @param middleName
		 * @param lastName
		 * @param jobTitle
		 * @param workPhoneNumber
		 * @param email
		 * @param type
		 */
		def parseCustRegContactInfo_BASE = null
		
		if(inquireFanProfileContactsResponse != null && inquireFanProfileContactsResponse?.contact?.get(0)?.firstName?.toString().length()>0)
		{
			def custRegContactInfo_BASE = inquireFanProfileContactsResponse.contact
			parseCustRegContactInfo_BASE = custRegContactInfo_BASE.collect
			{
				new CustRegContactInfoBASE (it.namePrefix.toString(), it.firstName.toString(), it.middleName.toString(),
					                        it.lastName.toString(), it.jobTitle.toString(), it.workPhoneNumber.toString(),
											it.email.toString(), it.type.toString())
			}
		}
		
		
		
		// Order/CombinedBilling
		// TODO Need to push this through without parsing if possible
		
		// Order/EventType
		def parsedEventType = null
		
		if(eventType.size() > 0){
			parsedEventType = new EventTypeInfo(eventType.EventName.toString())
		}

		
		/**
		 * @param account *
		 * @param subscriber *
		 * @param subscriberStatusDetail *
		 * @param equipment *
		 * @param serviceInfo *
		 * @param marketingOptions *
		 * @param billingAccount *
		 * @param financialNotification * 
		 * @param tppskuOrder //need to just pass through
		 * @param * femtocellTNUpdate //need to just pass through
		 * @param immutableKeys //need to just pass through
		 * @param * parentalControlsSettingInfo //populated by dip
		 * @param * accountTypeInfo //populated by dip
		 * @param segmentType //populated by dip
		 * @param marketInfo //populated by dip
		 * @param salesReps //populated by dip
		 * @param custRegContactInfoBASE //populated by dip
		 * @param combinedBilling //need to just pass through
		 * @param eventType *
		 */

		
		//Order Object
		def parsedOrder = new Order(parsedAccount, parsedSubscriber, 
			parsedSubscriberStatusDetail, parsedEquipment, parsedServiceInfo, null,
			parsedBillingAccont, parsedFinancialNotification, null, parsedFemtocellTNUpdate, 
			null, parsedParentalControls, parsedAccountTypeInfo, parsedSegmentType, parsedMarketInfo,
			null, parseCustRegContactInfo_BASE, null, parsedEventType
		)
		
		
		/*def parsedOrder = new Order(parsedAccount, parsedSubscriber,
			parsedSubscriberStatusDetail, parsedEquipment, parsedServiceInfo, parsedMarketingOptions,
			parsedBillingAccont, parsedFinancialNotification, null, parsedFemtocellTNUpdate,
			null, parsedParentalControls, parsedAccountTypeInfo, parsedSegmentType, parsedMarketInfo,
			parsedSalesReps, parseCustRegContactInfo_BASE, null, parsedEventType
		)*/
		
		
		//public TPPProvisioningRequest(Header header, Order order, Products products)
		/**
		 * Use this constructor with Provisioning Request!
		 * @param category
		 * @param id
		 * @param action
		 * @param attribute
		 */

		
		return new TPPProvisioningRequest(parsedHeader, 
			                              parsedOrder,			
								          new Products( products.Product.collect{
								                 new Product("3PP" ,it.@Id.toString(), it.@Action.toString(), 
										         it.Attribute.collect{ new Attribute(it.@Name.toString(), it.@Value.toString()) }
										         )}))
		
		
		
		
	}
	
	/**
	 * Provide BillingAccount model based on TPP_ProvisioningRequest XML node child account (tppProvReq.Order.BillingAccount).
	 *
	 * @param billingAccount (tppProvReq.Order.BillingAccount) NodeChildren to be parsed
	 * @return BillingAccount
	 */
	def BillingAccount getParsedBillingAccount(NodeChildren billingAccount, InquireAccountProfileResponseInfo inquireAccountProfileResponse,
		                                       InquireFanProfileResponseInfo inquireFanProfileResponse ){
		def fan = billingAccount.FAN
		def fanName = billingAccount.FANName
		def contractId = billingAccount.ContractId
		def contractType = billingAccount.ContractType
		def billingCycle = billingAccount.BillingCycle
		def name = billingAccount.Name
		def address = billingAccount.Address
		def phone = billingAccount.Phone
		def email = billingAccount.Email
		def banEmail = billingAccount.BANEmail
		def billingMarket = billingAccount.BillingMarket
		
		def pFan = null
		def pFanName = null
		def pContractId = null
		def pContractType = null
		def pBillingCycle = null
		def pName = null
		def pCurrentName = null
		def pPreviousName = null
		def pAddress = null
		def pCurrentAddress = null
		def pPreviousAddress = null
		def pPhone = null
		def pCurrentPhone = null
		def pPreviousPhone = null
		def pEmail = null
		def pCurrentEmail = null
		def pPreviousEmail = null
		def pBanEmail = null
		def pBillingMarket = null
		
		//FAN check
		println("FAN size---> " + fan.size().toString())
		if(fan.size() > 0){
			if(fan.@currentFAN.size() > 0){
				if(fan.@previousFAN.size() > 0){
					pFan = new FAN(fan.@currentFAN.toString(), fan.@previousFAN.toString())
				}
				else{
					pFan = new FAN(fan.@currentFAN.toString())
				}
			}
		}
		else if((inquireAccountProfileResponse != null && inquireAccountProfileResponse?.account?.fan?.length()>0) || (inquireFanProfileResponse != null && inquireFanProfileResponse?.profile?.fan.length()>0))
		{
			if(inquireFanProfileResponse?.profile?.fan.length()>0)
			pFan = new FAN(inquireFanProfileResponse?.profile?.fan.toString())
			if(inquireAccountProfileResponse?.account?.fan?.length()>0)
			pFan = new FAN(inquireAccountProfileResponse.account.fan.toString())
		}
		
		//FANName check
		println("FANName size---> " + fanName.size().toString())
		if(fanName.size() > 0){
			pFanName = fanName.toString()
		}else
	     if(inquireFanProfileResponse!=null && inquireFanProfileResponse?.profile?.billingInfo?.companyName.length()>0)
		 {
			 pFanName = inquireFanProfileResponse.profile.billingInfo.companyName.toString()
		 }
		
		//ContractID check
		if(contractId.size() > 0){
			pContractId = contractId.toString()
			println("contractId ---> " + contractId.toString())
		}else
	     if(inquireFanProfileResponse != null && inquireFanProfileResponse?.profile?.contractId.length()>0)
		 {
			pContractId =inquireFanProfileResponse.profile.contractId.toString()
			println("contractId From IFP---> " + pContractId)
		 }
		
		//ContractType check
		if(contractType.size() > 0){
			pContractType = contractType.toString()
		}else
	     if(inquireFanProfileResponse != null && inquireFanProfileResponse?.profile?.contractType.length()>0)
		 {
			pContractType =inquireFanProfileResponse.profile.contractType.toString()
			println("contractType From IFP---> " + pContractType)
		 }
		
		//BillingCycle check
		if(billingCycle.size() > 0){
			if(billingCycle.@current.size() > 0){
				if(billingCycle.@previous.size() > 0){
					pBillingCycle = new BillingCycle(billingCycle.@current.toString(), billingCycle.@previous.toString())
				}
				else{
					pBillingCycle = new BillingCycle(billingCycle.@current.toString())
				}
			}
		}else
	     if(inquireAccountProfileResponse != null && inquireAccountProfileResponse?.account?.accountBilling?.billingCycle.toString().length()>0)
		 {
			 pBillingCycle = new BillingCycle(inquireAccountProfileResponse?.account?.accountBilling?.billingCycle.toString())
		 }
		
		//Name check
		if(name.size() > 0){
			if(name.current.size() > 0 && name.current.toString()!="N/A" && name.current.toString()!="NA"){				
				pCurrentName = new BillingAccountName(name.current.@Type.toString(), name.current.@BusinessName.toString(), name.current.@DoingBusinessNameAs.toString(), name.current.@FirstName.toString(), name.current.@LastName.toString())
				pName = new Name(pCurrentName)
				if(name.previous.size() > 0){
					pPreviousName = new BillingAccountName(name.previous.@Type.toString(), name.previous.@BusinessName.toString(), name.previous.@DoingBusinessNameAs.toString(), name.previous.@FirstName.toString(), name.previous.@LastName.toString())
					pName = new Name(pCurrentName, pPreviousName)										
				}				
			}
			else 
			  if ((inquireAccountProfileResponse!=null && inquireAccountProfileResponse.account?.subscriber?.get(0)?.getSubscriber()?.contactInformation?.name?.firstName.length()>0) ||
				  (inquireAccountProfileResponse!=null && inquireAccountProfileResponse.account?.customer?.name?.firstName.length()>0))
			  {
				  def contactInfoIAPSubscriber = inquireAccountProfileResponse.account?.subscriber?.get(0)?.getSubscriber()?.contactInformation				  
				  def contactInfoIAPAccount = inquireAccountProfileResponse.account?.customer
				  
				  if(contactInfoIAPSubscriber?.name?.firstName.length()>0)
				  {					  
					  pCurrentName = new BillingAccountName(name?.current?.@Type.toString(), contactInfoIAPAccount.businessName.businessName.toString(),
						                                    contactInfoIAPAccount.doingBusinessAs.toString(), contactInfoIAPSubscriber.name.firstName.toString(),
															contactInfoIAPAccount.name.lastName.toString())
					  pName = new Name(pCurrentName)
				  }
				  else
				  {
					  pCurrentName = new BillingAccountName(name?.current?.@Type.toString(), contactInfoIAPAccount.businessName.businessName.toString(),
						                                    contactInfoIAPAccount.doingBusinessAs.toString(), contactInfoIAPAccount.name.firstName.toString(),
															contactInfoIAPAccount.name.lastName.toString())
					  pName = new Name(pCurrentName)
				  }
			  }
		}
		
		//Address Check
		println("Address size---> " + address.size().toString())
		println("Address number of children ---> " + address.children().size().toString())
		println("Address depth of element with children (this includes the Address element also) ---> " + address.depthFirst().collect {it}.size().toString())
		if(address.size() > 0){
			if(address.current.size() > 0){
				pCurrentAddress = new BillingAccountAddress(address.current.@Type.toString(), address.current.@AddressLine1.toString(),
					                                        address.current.@AddressLine2.toString(), address.current.@City.toString(),
															 address.current.@State.toString(), address.current.@PostalCode.toString(),
															  address.current.@InternationalPostalCode.toString(),
															   address.current.@InternationalAddressLine.toString(),
															    address.current.@PostalPlusCode.toString(), address.current.@CountryName.toString(),
																 address.current.@CountryCode.toString(), address.current.@LocalCompanyName.toString(),
																  address.current.@GeoCode.toString())
				pAddress = new BillingAccount.Address(pCurrentAddress)
				if(address.previous.size() > 0){
					pPreviousAddress = new BillingAccountAddress(address.previous.@Type.toString(), address.previous.@AddressLine1.toString(), 
						                                         address.previous.@AddressLine2.toString(), address.previous.@City.toString(),
																  address.previous.@State.toString(), address.previous.@PostalCode.toString(),
																   address.previous.@InternationalPostalCode.toString(), 
																   address.previous.@InternationalAddressLine.toString(), address.previous.@PostalPlusCode.toString(),
																    address.previous.@CountryName.toString(), address.previous.@CountryCode.toString(),
																	 address.previous.@LocalCompanyName.toString(), address.previous.@GeoCode.toString())
					pAddress = new BillingAccount.Address(pCurrentAddress, pPreviousAddress)
				}
			}else{
		     if(inquireAccountProfileResponse != null && inquireAccountProfileResponse.account?.customer?.address.addressLine1.length()>0)
			 {
				 def addressFrmIAPAccount = inquireAccountProfileResponse.account?.customer?.address
				 def zipcode =""
				 def zipCodeInternational= ""
				 def internationalAddressLine= ""
				 
				 if(addressFrmIAPAccount?.zip?.zipCode.length()<=6)
				 zipcode =addressFrmIAPAccount.zip.zipCode.toString()
				 if(addressFrmIAPAccount?.zip?.zipCode.length()>=6)
				 zipCodeInternational = addressFrmIAPAccount.zip.zipCode.toString()
				 
				 
				 if(addressFrmIAPAccount!=null && addressFrmIAPAccount.addressType.value().toString().equalsIgnoreCase("F"))
				 internationalAddressLine = addressFrmIAPAccount.internationalAddressLine.toString()
				 
				 pCurrentAddress = new BillingAccountAddress(addressFrmIAPAccount.addressType.value().toString(), addressFrmIAPAccount.addressLine1.toString(),
					                                         addressFrmIAPAccount.addressLine2.toString(), addressFrmIAPAccount.city.toString(),
															 addressFrmIAPAccount.state.toString(), zipcode.toString(),
															 zipCodeInternational.toString(), internationalAddressLine.toString(),
															  addressFrmIAPAccount.zip.zipCodeExtension.toString(), addressFrmIAPAccount.country.toString(),
															   "", "", addressFrmIAPAccount.zip.zipGeoCode.toString())
				 
				 pAddress = new BillingAccount.Address(pCurrentAddress)
			 }else
		      if(inquireAccountProfileResponse!=null && inquireAccountProfileResponse?.account?.subscriber?.get(0)?.getSubscriber()?.contactInformation?.ppuAddress?.addressLine1.length()>0)
			  {
				  def addressFrmIAPSubscriber = inquireAccountProfileResponse.account.subscriber.get(0).getSubscriber().contactInformation.ppuAddress
				  def zipcode =""
				  def zipCodeInternational= ""
				  def internationalAddressLine= ""
				  
				  if(addressFrmIAPSubscriber.zip.zipCode.length()<=6)
				  zipcode =addressFrmIAPSubscriber.zip.zipCode.toString()
				  if(addressFrmIAPSubscriber.zip.zipCode.length()>=6)
				  zipCodeInternational = addressFrmIAPSubscriber.zip.zipCode.toString()
				  
				  
				  if(addressFrmIAPSubscriber.addressType.value().toString().equalsIgnoreCase("F"))
				  internationalAddressLine = addressFrmIAPSubscriber.internationalAddressLine.toString()
				  
				  pCurrentAddress = new BillingAccountAddress(addressFrmIAPSubscriber.addressType.value().toString(), addressFrmIAPSubscriber.addressLine1.toString(),
															  addressFrmIAPSubscriber.addressLine2.toString(), addressFrmIAPSubscriber.city.toString(),
															  addressFrmIAPSubscriber.state.toString(), zipcode.toString(),
															  zipCodeInternational.toString(), internationalAddressLine.toString(),
															   addressFrmIAPSubscriber.zip.zipCodeExtension.toString(), addressFrmIAPSubscriber.country.toString(),
																"", "", addressFrmIAPSubscriber.zip.zipGeoCode.toString())
				  
				  pAddress = new BillingAccount.Address(pCurrentAddress)
			  }
			}
		}
		
		//Phone check
		if(phone.size() > 0){
			if(phone.current.size() > 0){
				pCurrentPhone = new BillingAccountPhone(name.current.@homePhone.toString(), name.current.@workPhone.toString(), name.current.@workPhoneExtension.toString(), name.current.@canBeReachedPhone.toString())				
				pPhone = new Phone(pCurrentPhone)
				if(phone.previous.size() > 0){
					pPreviousPhone = new BillingAccountPhone(name.previous.@homePhone.toString(), name.previous.@workPhone.toString(), name.previous.@workPhoneExtension.toString(), name.previous.@canBeReachedPhone.toString())					
					pPhone = new Phone(pCurrentPhone, pPreviousPhone)
				}
			}
			else
			{
				def phoneFrmAccount = inquireAccountProfileResponse?.account?.customer?.phone
				def phoneFrmSubscriber = inquireAccountProfileResponse?.account?.subscriber?.get(0)?.getSubscriber()?.contactInformation?.phone
				if(inquireAccountProfileResponse!=null && phoneFrmAccount!=null && phoneFrmAccount.canBeReachedPhone.length()>0)
				{					
					pCurrentPhone = new BillingAccountPhone(phoneFrmAccount.homePhone.toString(), phoneFrmAccount.workPhone.toString(),
						                                    phoneFrmAccount.workPhoneExtension.toString(), phoneFrmAccount.workPhoneExtension.toString())
					pPhone = new Phone(pCurrentPhone)
				}else
				if(inquireAccountProfileResponse!=null && phoneFrmSubscriber!=null && phoneFrmSubscriber.canBeReachedPhone.length()>0)
				{
					pCurrentPhone = new BillingAccountPhone(phoneFrmSubscriber.homePhone.toString(), phoneFrmSubscriber.workPhone.toString(),
															phoneFrmSubscriber.workPhoneExtension.toString(), phoneFrmSubscriber.workPhoneExtension.toString())
					pPhone = new Phone(pCurrentPhone)
				}
				
			}
		}
		
		//Email check
		if(email.size() > 0){			
			if(email.current.size() > 0){				
				pCurrentEmail = email.children().collect{					
					if (!it.findAll{it.name() == "current"}.collect{curr -> curr.@emailAddress.toString()}.equals([])){						
						new BillingAccountEmail(it.findAll{it.name() == "current"}.@emailType.toString(), it.findAll{it.name() == "current"}.@emailAddress.toString())
					}										
				}
				pEmail = new BillingAccount.Email(pCurrentEmail)
				
				if(email.previous.size() > 0){				
					pPreviousEmail = email.children().collect{
						if (!it.findAll{it.name() == "previous"}.collect{prev -> prev.@emailAddress.toString()}.equals([])){
							new BillingAccountEmail(it.findAll{it.name() == "previous"}.@emailType.toString(), it.findAll{it.name() == "previous"}.@emailAddress.toString())
						}											
					}
					pEmail = new BillingAccount.Email(pCurrentEmail, pPreviousEmail)
				}
			}
			else
			{
				def emailFrmAccount = inquireAccountProfileResponse?.account?.customer?.email
				def emailFrmSubscriber = inquireAccountProfileResponse?.account?.subscriber?.get(0)?.getSubscriber()?.contactInformation?.email
				
				if(inquireAccountProfileResponse!=null && emailFrmAccount!=null && emailFrmAccount.emailAddress.length()>0)
				{
					pCurrentEmail = emailFrmAccount.collect{						
							new BillingAccountEmail(it.emailType.toString(), it.emailAddress)					
					}
					pEmail = new BillingAccount.Email(pCurrentEmail)
				}
				else
				if(inquireAccountProfileResponse!=null && emailFrmSubscriber!=null && emailFrmSubscriber.emailAddress.length()>0)
				{
					pCurrentEmail = emailFrmSubscriber.collect{
							new BillingAccountEmail(it.emailType.toString(), it.emailAddress)
					}
					pEmail = new BillingAccount.Email(pCurrentEmail)
				}
				
			}
		}
		
		//Debug output
//		pEmail*.each{
//			curr -> curr.current*.each{
//				it -> println(" Current Email <>----> " + it.emailType)
//			}
//			
//			curr.previous*.each{
//				prevIT -> println(" Previous Email <>----> " + prevIT.emailType)
//			}
//			
//		}
		
		//BANEmail check
		println("BANEmail size---> " + banEmail.size().toString())
		def emailFrmAccount = inquireAccountProfileResponse?.account?.customer?.email
		if(inquireAccountProfileResponse!=null && emailFrmAccount!=null && emailFrmAccount?.emailAddress.length() > 0){			
			pBanEmail = new BANEmail(emailFrmAccount.emailType.toString(), emailFrmAccount.emailAddress.toString())			
		}
		
		//BillingMarket check
		println("BillingMarket size---> " + billingMarket.size().toString())
		if(billingMarket.size() > 0){
			if(billingMarket.@current.size() > 0){
				if(billingMarket.@previous.size() > 0){
					pBillingMarket = new BillingMarket(billingMarket.@current.toString(), billingMarket.@previous.toString())
				}
				else{
					pBillingMarket = new BillingMarket(billingMarket.@current.toString())
				}
			}
		}
		
		return new BillingAccount(pFan, pFanName, pContractId, pContractType, pBillingCycle, pName, pAddress, pPhone, pEmail, pBanEmail, pBillingMarket)
	}
	
	/**
	 * Provide FinancialNotificationType model based on TPP_ProvisioningRequest XML node child account (tppProvReq.Order.FinancialNotification).
	 *
	 * @param financialNotification (tppProvReq.Order.FinancialNotification) NodeChildren to be parsed
	 * @return FinancialNotificationType
	 */
	def FinancialNotificationType getParsedFinancialNotification(NodeChildren financialNotification){
		def parsedAdjustmentAmount = null
		def parsedAdjustmentCode = null		
		
		if(financialNotification.@AdjustmentAmount.size() > 0){
			parsedAdjustmentAmount = financialNotification.@AdjustmentAmount.toString()			
			
			if(financialNotification.@AdjustmentCode.size() > 0){
				parsedAdjustmentCode = financialNotification.@AdjustmentCode.toString()			 
			}			
		}	
		
		return new FinancialNotificationType(parsedAdjustmentAmount, parsedAdjustmentCode) 
		
	}
	
	/**
	 * Provide TNUpdateInfo model based on TPP_ProvisioningRequest XML node child account (tppProvReq.Order.FemtocellTNUpdate).
	 *
	 * @param femtoCellNotification (tppProvReq.Order.FemtocellTNUpdate) NodeChildren to be parsed
	 * @return TNUpdateInfo
	 */
	def TNUpdateInfo getParsedFemtoCellTNUpdate(NodeChildren femtoCellNotification){
		def femtoAddress = femtoCellNotification.FemtocellAddress
		def femtoInfo =  femtoCellNotification.FemtocellAdditionalInfo
		
		def parsedTNAddress = null
		def parsedTNInfo = null
		
		if(femtoAddress.size() > 0){
			parsedTNAddress = new TNAddress(femtoAddress.@HNO.toString(), femtoAddress.@HNS.toString(), femtoAddress.@PRD.toString(), femtoAddress.@STN.toString(), 
				femtoAddress.@MCN.toString(), femtoAddress.@STA.toString(), femtoAddress.@LOC.toString(), femtoAddress.@STS.toString(), femtoAddress.@POD.toString(), femtoAddress.@ZIP.toString())
						
			if(femtoInfo.size() > 0){
				parsedTNInfo = new TNInfo(femtoInfo.@ExternalKey.toString(), femtoInfo.@NENAID.toString(), femtoInfo.@CLS.toString(), femtoInfo.@TYS.toString(), femtoInfo.@Latitude.toString(), femtoInfo.@Longitude.toString())
			}		
		}
		
		return new TNUpdateInfo(parsedTNAddress, parsedTNInfo)		
	}
	
	/**
	 * Provide ParentalControlsSettingInfo model based on TPP_ProvisioningRequest XML node child account (tppProvReq.Order.ParentalControlsSettingInfo).
	 *
	 * @param parentalControlsSetting (tppProvReq.Order.ParentalControlsSettingInfo) NodeChildren to be parsed
	 * @return ParentalControlsSettingInfo
	 */
	/*def ParentalControlsSettingInfo getParsedParentalControls(NodeChildren parentalControlsSetting){
		def indicator = parentalControlsSetting.indicator
		def reason = parentalControlsSetting.reasonCode
		
		def parsedIndicator = null
		def parsedReason = null
		
		if(indicator.size() > 0){
			parsedIndicator = indicator.toBoolean()
			
			if(reason.size() > 0){
				parsedReason = indicator.toString()				
			}
		}
		
		return new ParentalControlsSettingInfo(parsedIndicator, parsedReason)
	}*/
	
	/**
	 * Provide AccountTypeInfo model based on TPP_ProvisioningRequest XML node child account (tppProvReq.Order.AccountTypeInfo).
	 *
	 * @param accountTypeInfo (tppProvReq.Order.AccountTypeInfo) NodeChildren to be parsed
	 * @return AccountTypeInfo
	 */
	/*def AccountTypeInfo getParsedAccountTypeInfo(NodeChildren accountTypeInfo, InquireAccountProfileResponseInfo inquireAccountProfileResponse){
		def accType = accountTypeInfo.accountType_CSIIAPDip
		def accSubType = accountTypeInfo.accountSubType_CSIIAPDip
		
		def parsedAccType = null
		def parsedAccSubType = null
		
		if(accType.size() > 0){
			parsedAccType = accType.toString()
			if(accSubType.size() > 0){
				parsedAccSubType = accSubType.toString()
			}
		}
		
		return new AccountTypeInfo(parsedAccType, parsedAccSubType)
	}*/
	
	static main(args) {
		DataAugXMLParser dx = new DataAugXMLParser()
		def temp = dx.getTPPProvReq(new File("C:\\JavaDevSpace\\testMrc1.xml").text)
		
		def account = dx.getProvReqAccount(new File("C:\\JavaDevSpace\\testMrc1.xml").text)
		def fan = dx.getProvReqFAN(new File("C:\\JavaDevSpace\\testMrc1.xml").text)
		
		println("RoutingCarrier ---> " + temp.header.routingCarrier)
		
		println("MSISDN ---> " + account.msisdn)
		println("SUBID ---> " + account.subscriberNumber)
		println("BAN ---> " + account.ban)
		
		//Check if FAN model is null.  Don't traverse model if null.
		if(fan != null){
			println("FAN ---> " + fan.currentFAN)
		}
		else{
			println("FAN ---> value is null (no FAN populated)")
		}	
	}
}
