/**
 * 
 */
package com.att.tpp.service;

import java.io.IOException;
import java.net.URL;
import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Date;
import java.util.HashSet;
import java.util.List;

import javax.jms.JMSException;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.att.tpp.config.InitGlobalInstance;
import com.att.tpp.dao.CSIDao;
import com.att.tpp.enumuration.CSIEventType;
import com.att.tpp.jms.listener.OtherProperties;
import com.att.tpp.jms.sender.ErrorRequestQueueSender;
import com.att.tpp.model.CSIResponseKeys;
import com.att.tpp.model.CSI_MESSAGE_ARCHIVE;
import com.att.tpp.model.CSIRetryErrors;
import com.att.tpp.model.CsiTimer;
import com.att.tpp.model.FeatureCodeRef;
import com.att.tpp.model.RetryConfiguration;
import com.att.tpp.model.SystemConfiguration;
import com.att.tpp.model.TempTransCode;
import com.att.tpp.model.TransCode;
import com.att.tpp.model.UriConfiguration;
import com.att.tpp.model.WebServiceResponseData;
import com.att.tpp.model.ProvisioningRequest;
import com.att.tpp.model.ProvisioningTask;
import com.att.tpp.utils.CSIServiceMessageParser;
import com.att.tpp.utils.ValidateXMLUtil;
import com.att.tpp.utils.XMLGenerator;
import com.att.tpp.ws.AddNote;
import com.att.tpp.ws.AddOrderNotesNotification;
import com.att.tpp.ws.AddOrderShipmentNotification;
import com.att.tpp.ws.CancelOrderNotification;
import com.att.tpp.ws.EchoRequest;
import com.att.tpp.ws.ManageMobileProductsProvisioning;
import com.att.tpp.ws.NotifyFemtocell;
import com.att.tpp.ws.NotifyMetrocell;
import com.att.tpp.ws.NotifySmallcell;
import com.att.tpp.ws.SendEmailNotification;
import com.att.tpp.ws.SendSMSNotification;
import com.att.tpp.xml.model.Product;
import com.att.tpp.xml.model.ProductMax;
import com.att.tpp.xml.model.Products;
import com.att.tpp.xml.model.TransactionCode;
import com.att.tpp.xml.model.TransactionCodeList;
import com.cingular.csi.csi.namespaces.v118.wsdl.cingularwirelesscsi.CSIApplicationException;

/**
 * @author SC9833
 *
 */
@Service("csiService")
public class CSIServiceImpl implements CSIService {
	
	@Autowired	
	private AddOrderNotesNotification addOrderNotesNotification;
	
	@Autowired
	private AddOrderShipmentNotification addOrderShipmentNotification;
	
	@Autowired
	private CancelOrderNotification cancelOrderNotification;
	
	@Autowired
	private EchoRequest echoRequest;
	
	@Autowired
	private AddNote addNote;
	
	@Autowired
	private SendSMSNotification sendSMSNotification;

	@Autowired
	private SendEmailNotification sendEmailNotification;
	
	@Autowired
	private  NotifyFemtocell notifyFemtocell;
	
	@Autowired
	private  NotifyMetrocell notifyMetrocell;
	
	@Autowired
	private  NotifySmallcell notifySmallcell;
	
	@Autowired
	private  ManageMobileProductsProvisioning manageMobileProductsProvisioning;
	
	@Autowired
	private CSIDao csiDao;
	
	@Autowired
	private ErrorRequestQueueSender errorRequestQueueSender;
	
	
	
	private static Logger csiServiceLog = Logger.getLogger(CSIServiceImpl.class);
	
	private final static String skuSchemaDir = "//com//att//tpp//common//schemas//skuschemas//";
	private final static String csiSchemaDir = "//com//att//tpp//common//schemas//";
	
	private final static String TPP_AddNotesXSD = "TPP_CSIAddNoteRequest.xsd";
	private final static String TPP_CSIEchoRequestXSD = "TPP_CSIEchoRequest.xsd";
	private final static String TPP_EmailResponseXSD = "TPP_EmailResponse.xsd";
	private final static String VUI_ResponseXSD = "VUI2.xsd";
	
	
	private final static String TPP_AddOrderNotesNotificationXSD = "TPP_AddOrderNotesNotification.xsd";
	private final static String TPP_AddOrderShipmentNotificationXSD = "TPP_AddOrderShipmentNotification.xsd";
	private final static String TPP_CancelOrderNotificationXSD = "TPP_CancelOrderNotification.xsd";
	private final static String ABS_ProvisioningResponseXSD = "ABS_ProvisioningResponse.xsd";
	private final static String TPP_ErrorRequestXSD = "TPP_ErrorRequest.xsd";
	//private final static String TPP_AddOrderEmailNotificationXSD = "TPP_AddOrderEmailNotification.xsd";
	//private final static String TPP_FulfillmentResultXSD = "TPP_FulfillmentResult.xsd";
	
	
	@Override
	public boolean validateXML(String requestXML,
			String xsdName, boolean isSKU) throws IOException, Exception {
		// TODO Auto-generated method stub
		
		boolean validationResult = false;
		StringBuilder schemaLocation = null;
		
		if(isSKU == true) {
			schemaLocation = new StringBuilder(skuSchemaDir);			
		}
		else{
			schemaLocation = new StringBuilder(csiSchemaDir);
		}
		
		schemaLocation.append(xsdName);
		URL xsdPath = CSIServiceImpl.class
				.getResource(schemaLocation.toString());
		csiServiceLog.debug("xsdPath :" + xsdPath.toString());
		validationResult = ValidateXMLUtil.validateWithXSD(requestXML, xsdPath.toString());
		csiServiceLog.debug("validationResult :" + validationResult);
		return validationResult;
		
	}

	@Override
	public boolean validateEvent(String requestXML, String eventType)
			throws IOException, Exception {
		
		boolean isValidRequest = false;
		boolean isSKU = false;
		
		
		if(eventType.equals(CSIEventType.Echo.toString())){
			//Echo validation
			isSKU = false;
			isValidRequest = validateXML(requestXML, TPP_CSIEchoRequestXSD, isSKU);
			csiServiceLog.info("TPP_CSIEchoRequest XML Validation After Receiving from CSI Inbound Queue: " + isValidRequest);
			
		}
		else if (eventType.equals(CSIEventType.AddNote.toString())) {
			//AddNote validation
			isSKU = false;
			isValidRequest = validateXML(requestXML, TPP_AddNotesXSD, isSKU);
			csiServiceLog.info("TPP_AddOrderNotesNotification XML Validation After Receiving from CSI Inbound Queue: " + isValidRequest);
		}
		else if (eventType.equals(CSIEventType.AddOrderNotes.toString())){
			//AddOrderNotes validation
			isSKU = true;
			isValidRequest = validateXML(requestXML, TPP_AddOrderNotesNotificationXSD, isSKU);
			csiServiceLog.info("TPP_AddOrderNotesNotification XML Validation After Receiving from CSI Inbound Queue: " + isValidRequest);
		}
		else if (eventType.equals(CSIEventType.AddOrderShipment.toString())){
			//AddOrderShipment validation
			isSKU = true;
			isValidRequest = validateXML(requestXML, TPP_AddOrderShipmentNotificationXSD, isSKU);
			csiServiceLog.info("TPP_AddOrderShipmentNotification XML Validation After Receiving from CSI Inbound Queue: " + isValidRequest);
		}
		else if (eventType.equals(CSIEventType.CancelOrder.toString())){
			//CancelOrder validation
			isSKU = true;
			isValidRequest = validateXML(requestXML, TPP_CancelOrderNotificationXSD, isSKU);
			csiServiceLog.info("TPP_CancelOrderNotification XML Validation After Receiving from CSI Inbound Queue: " + isValidRequest);
		}
		else if (eventType.equals(CSIEventType.NotifyFemtocellAction.toString())){
			//NotifyFemtocell validation
			//Not sure if we need to validate this.  Old codebase would take the response and make a call back upstream.
			isSKU = false;
			//isValidRequest = validateXML(requestXML, VUI_ResponseXSD, isSKU);
			isValidRequest=true;
		}
		else if (eventType.equals(CSIEventType.NotifyMetrocellAction.toString())){
			//NotifyMetrocell validation
			//Not sure if we need to validate this.  Old codebase would take the response and make a call back upstream.
			isSKU = false;
			//isValidRequest = validateXML(requestXML, VUI_ResponseXSD, isSKU);
			isValidRequest=true;
		}
		else if (eventType.equals(CSIEventType.NotifySmallcellAction.toString())){
			//NotifySmallcellAction validation
			//Not sure if we need to validate this.  Old codebase would take the response and make a call back upstream.
			isSKU = false;
			//isValidRequest = validateXML(requestXML, VUI_ResponseXSD, isSKU);
			isValidRequest=true;
		}
		else if (eventType.equals(CSIEventType.DCMNotification.toString())){
			//DCMNotification validation
			isSKU = false;
			isValidRequest = validateXML(requestXML, ABS_ProvisioningResponseXSD, isSKU);
		}
		else if (eventType.equals(CSIEventType.SendSMS.toString())){
			//SendSMS validation
			isSKU = false;
			isValidRequest = validateXML(requestXML, ABS_ProvisioningResponseXSD, isSKU);
		}
		else if (eventType.equals(CSIEventType.SendEmail.toString())){
			//SendEmail validation
			isSKU = false;
			isValidRequest = validateXML(requestXML, TPP_EmailResponseXSD, isSKU);
			csiServiceLog.info("TPP_EmailResponse XML Validation After Receiving from CSI Inbound Queue: " + isValidRequest);
		}
		else{
			//unsupported eventType
			isValidRequest = false;			
			csiServiceLog.info("[UNSUPPORTED] EventType: " + eventType);			
			csiServiceLog.info("[UNSUPPORTED] XML NOT Validated After Receiving from CSI Inbound Queue.");			
		}
		 
		return isValidRequest;
	}

	@Override
	@Transactional("configTransactionManager")
	public WebServiceResponseData invokeCSIWebService(OtherProperties otherProperties) throws CSIApplicationException, Exception {		
		
		String methodName = "[invokeCSIWebService] ";
		
		String requestXML = otherProperties.getRequestXML();
		String eventType=otherProperties.getEventType();
		
		
		csiServiceLog.info(methodName + "EventType : "+eventType);
		csiServiceLog.info("Transaction ID from other preoperties:"+otherProperties.getMasterTransId());
	
		
		
		WebServiceResponseData webServiceResponseData =  new WebServiceResponseData();
		webServiceResponseData.setTppcsiTransactionid(otherProperties.getMasterTransId());
		
		//String result = null;
		
		CSIServiceMessageParser csiMessageParser = new CSIServiceMessageParser();
		
		
	   if(eventType.equals(CSIEventType.Echo.toString())){
			
			csiServiceLog.info(methodName + "Inside Echo Web Service");
			webServiceResponseData = echoRequest.invokeEcho(requestXML, eventType,methodName, webServiceResponseData, csiMessageParser);			
			csiServiceLog.info(methodName + "Completed invoking Echo Web Service");			
			
		}
	    else if(eventType.equals(CSIEventType.AddNote.toString())){
			
			csiServiceLog.info(methodName + "Inside AddNote Web Service");
			webServiceResponseData = addNote.invokeAddNote(requestXML, eventType,
					methodName, webServiceResponseData, csiMessageParser);			
			csiServiceLog.info(methodName + "Completed invoking AddNote Web Service");
			
		}
	    else if(eventType.equals(CSIEventType.AddOrderNotes.toString())){
			
			csiServiceLog.info(methodName + "Inside add3PPOrderNotes Web Service");	
			webServiceResponseData = addOrderNotesNotification.invokeAddOrderNotes(requestXML, eventType,	methodName, webServiceResponseData, csiMessageParser);			
			csiServiceLog.info(methodName + "Completed invoking add3PPOrderNotes Web Service");
			
		}
	    else if(eventType.equals(CSIEventType.AddOrderShipment.toString())){
			
			csiServiceLog.info(methodName + "Inside add3PPOrderShipment Web Service");	
			webServiceResponseData = addOrderShipmentNotification.invokeAddOrderShipment(requestXML, eventType,	methodName, webServiceResponseData, csiMessageParser);			
			csiServiceLog.info(methodName + "Completed invoking add3PPOrderShipment Web Service");
			
		}
		else if(eventType.equals(CSIEventType.CancelOrder.toString())){
			
			csiServiceLog.info(methodName + "Inside cancel3PPOrder Web Service");	
			webServiceResponseData = cancelOrderNotification.invokeCancelOrder(requestXML, eventType,methodName, webServiceResponseData, csiMessageParser);			
			csiServiceLog.info(methodName + "Completed invoking cancel3PPOrder Web Service");
			
		}
		else if(eventType.equals(CSIEventType.SendSMS.toString())){
			
			csiServiceLog.info(methodName + "Inside SendSMS Web Service");			
			webServiceResponseData = sendSMSNotification.invokeSendSMS(requestXML, eventType,
					methodName, webServiceResponseData, csiMessageParser);			
			csiServiceLog.info(methodName + "Completed invoking add3PPOrderNotes Web Service");			
			
		}
		else if(eventType.equals(CSIEventType.SendEmail.toString())){
			
			//Todo: add the Keys for the csi message archive
			csiServiceLog.info(methodName + "Inside SendEmail Web Service");			
			webServiceResponseData = sendEmailNotification.invokeSendEmail(requestXML, eventType,
					methodName, webServiceResponseData, csiMessageParser);			
			csiServiceLog.info(methodName + "Completed invoking SendEmail Web Service");
			
		}
		else if(eventType.equals(CSIEventType.NotifyFemtocellAction.toString())){
			
			csiServiceLog.info(methodName + "Inside NotifyFemtocell Web Service");	
			String actionFemto = otherProperties.getActionFemto();
			String masterTransId = otherProperties.getMasterTransId();			
			String provSystemTransId = getProvSystemTransId(masterTransId);
			String externalKey = null;
			
			//This is used to determine the type of Notification is being sent to CSI.
			//If FCNotification respond to CSI with NotifyFemtocell
			//If MetroNotification respond to CSI with NotifyMetrocell
			ProvisioningRequest provRequest = null;
			provRequest = csiDao.queryProvisioningRequest(masterTransId);
			
			if(provRequest.getEventType().equals("FCNotification")){
				//Todo: add the Keys for the csi message archive
				csiServiceLog.info(methodName + "Inside NotifyFemtocell Web Service");			
				webServiceResponseData = notifyFemtocell.invokeNotifyFemtocellAction(requestXML, eventType,
						methodName, webServiceResponseData, csiMessageParser, actionFemto, provSystemTransId, masterTransId);			
				csiServiceLog.info(methodName + "Completed invoking NotifyFemtocell Web Service");
			}
			else if(provRequest.getEventType().equals("MetroNotification")){
				//Todo: add the Keys for the csi message archive
				csiServiceLog.info(methodName + "Inside NotifyMetrocell Web Service from NotifyFemtocellAction");			
				webServiceResponseData = notifyMetrocell.invokeNotifyMetrocellAction(requestXML, eventType,
						methodName, webServiceResponseData, csiMessageParser, actionFemto, provSystemTransId, masterTransId);			
				csiServiceLog.info(methodName + "Completed invoking NotifyMetrocell Web Service from NotifyFemtocellAction");				
			}
			else if(provRequest.getEventType().equals("SmallCellNotification")){
				//Todo: add the Keys for the csi message archive
				externalKey = csiMessageParser.parseIntradoExternalKey(provRequest.getPayload());
				csiServiceLog.info(methodName + "Inside NotifySmallcell Web Service from NotifyFemtocellAction");			
				webServiceResponseData = notifySmallcell.invokeNotifySmallcellAction(requestXML, eventType,
						methodName, webServiceResponseData, csiMessageParser, actionFemto, provSystemTransId, masterTransId, externalKey);			
				csiServiceLog.info(methodName + "Completed invoking NotifySmallcell Web Service from NotifyFemtocellAction");				
			}
		}
		else if(eventType.equals(CSIEventType.NotifyMetrocellAction.toString())){
			//This will be used once the Communication Service is implemented.
			csiServiceLog.info(methodName + "Inside NotifyMetrocell Web Service");	
			
			String actionMetro=otherProperties.getActionFemto();
			String masterTransId = otherProperties.getMasterTransId();			
			String provSystemTransId = getProvSystemTransId(masterTransId);
			
			//Todo: add the Keys for the csi message archive
			csiServiceLog.info(methodName + "Inside NotifyMetrocell Web Service");			
			webServiceResponseData = notifyMetrocell.invokeNotifyMetrocellAction(requestXML, eventType,
					methodName, webServiceResponseData, csiMessageParser, actionMetro, provSystemTransId, masterTransId);			
			csiServiceLog.info(methodName + "Completed invoking NotifyMetrocell Web Service");			
		}
		else if(eventType.equals(CSIEventType.NotifySmallcellAction.toString())){
			//This will be used once the Communication Service is implemented.
			csiServiceLog.info(methodName + "Inside NotifySmallcell Web Service");	
			
			String actionSmallcell=otherProperties.getActionFemto();
			String masterTransId = otherProperties.getMasterTransId();			
			String provSystemTransId = getProvSystemTransId(masterTransId);
			String externalKey = null;   //need to parse from request XML in the prov data table in the data schema.  This is if Communication Service does not provide the externalKey.
			
			ProvisioningRequest provRequest = null;
			provRequest = csiDao.queryProvisioningRequest(masterTransId);
			externalKey = csiMessageParser.parseIntradoExternalKey(provRequest.getPayload());
			
			//Todo: add the Keys for the csi message archive
			csiServiceLog.info(methodName + "Inside NotifySmallcell Web Service");			
			webServiceResponseData = notifySmallcell.invokeNotifySmallcellAction(requestXML, eventType,
					methodName, webServiceResponseData, csiMessageParser, actionSmallcell, provSystemTransId, masterTransId, externalKey);			
			csiServiceLog.info(methodName + "Completed invoking NotifySmallcell Web Service");			
		}
	   
		else if(eventType.equals(CSIEventType.DCMNotification.toString())){
			
			//Todo: add the Keys for the csi message archive
			csiServiceLog.info(methodName + "Inside ManageMobileProductsProvisioning Web Service");
			/* provSystemTransId is the original Transaction Id sent by CSI Service 
			 * We need to pass the same original Transaction Id to CSI for web service call for DCM flow.
			 */
			
			String provSystemTransId = otherProperties.getTransactionId();	
			
			webServiceResponseData = manageMobileProductsProvisioning.invokeDCMNotification(requestXML, eventType,
					methodName, webServiceResponseData, csiMessageParser, provSystemTransId);
			
			csiServiceLog.info(methodName + "Completed invoking ManageMobileProductsProvisioning Web Service");
			
		}
		
		
		return webServiceResponseData;
	}


	@Deprecated
	public CSIResponseKeys generateCSIResponseKeys(String requestXML, String eventType) {
		CSIServiceMessageParser csiMessageParser = new CSIServiceMessageParser();
		CSIResponseKeys csiResponseKeys = csiMessageParser.getCSIResponseKeyInfo(requestXML, eventType);
		//After development change to debug
		csiServiceLog.info("CSI Response Keys");
		csiServiceLog.info("CSI Response Keys OrderID: " + csiResponseKeys.getConcatOrderID());
		csiServiceLog.info("CSI Response Keys ReasonCode: " + csiResponseKeys.getReasonCode());
		csiServiceLog.info("CSI Response Keys Comment: " + csiResponseKeys.getComment());
		return csiResponseKeys;
	}

	@Override
	@Transactional("archiveTransactionManager")
	public boolean insertCSIMessageArchive(CSI_MESSAGE_ARCHIVE csiMessageArchive)	throws Exception {		
		return csiDao.insertCSIMessageArchive(csiMessageArchive);
	}

	@Override
	@Transactional("configTransactionManager")
	public List<CSIRetryErrors> getCSIRetryError() throws Exception {
		return csiDao.getCSIRetryError();
	}
	
	@Transactional("configTransactionManager")
	public String getProvSystemTransId(String masterTransId) throws Exception {
		return csiDao.getProvSystemTransId(masterTransId);
	}

	@Override
	@Transactional("configTransactionManager")
	public List<RetryConfiguration> getRetryConfiguration(String systemName)
			throws Exception {
		return csiDao.getRetryConfiguration(systemName);
	}

	@Override
	@Transactional("dataTransactionManager")
	public List<CsiTimer> getCSITimerRecord(String tppcsiTransactionid)
			throws Exception {
		return csiDao.getCSITimerRecord(tppcsiTransactionid);
	}

	@Override
	@Transactional("dataTransactionManager")
	public boolean insertCSITimerData(CsiTimer csiTimer) throws Exception {
		return csiDao.insertCSITimerData(csiTimer);
	}
	
	/* FIX for WR# 2738943- Multiple Retry of  SKU provisioning request after 200-OK and AddOrderNotes response received */
	@Override
	@Transactional("dataTransactionManager")
	public boolean deleteFromTimer(String taskTransId) throws Exception {
		return csiDao.deleteFromTimer(taskTransId);
	}

	@Override
	@Transactional("dataTransactionManager")
	public boolean deleteFromCSITimer(String masterTransId) throws Exception {
		return csiDao.deleteFromCSITimer(masterTransId);
	}

	@Override
	@Transactional("dataTransactionManager")
	public String getSystemName(String masterTransId) throws Exception {
		return csiDao.getSystemName(masterTransId);
	}

	//Assign the prodict id based on the attribute name and value
	@Override
	@Transactional("configTransactionManager")
	public String getProductId(String productId) throws Exception {
	         	
		   String iPid = null;
		   /* Modified to dcmFeatureCodeRefList from featureCodeRefList as we need DCM SOC code from the feature code table */
		   List<FeatureCodeRef> featureCodeRefList = csiDao.dcmFeatureCodeRefList();
           if (featureCodeRefList != null && featureCodeRefList.size() > 0) {
                  for (FeatureCodeRef featureCode : featureCodeRefList) {
                        if (featureCode.getId().getProductId().equals(productId)) {
                        	iPid = featureCode.getId().getFeatureCode();
                        }
                  }
           }

           
           return iPid;
    }
	
	@Override
	@Transactional("configTransactionManager")
	public boolean findFulfillmentIndicator(String vendorName) throws Exception {
		return csiDao.findFulfillmentIndicator(vendorName);
	}

	@Override
	@Transactional("configTransactionManager")
	public void loadInitialData() {
		List<SystemConfiguration> systemConfigList = csiDao.getSytemConfiguartionList();		
		for (SystemConfiguration systemConfiguration : systemConfigList) {
			InitGlobalInstance.storeCurrentSystemConfig(systemConfiguration.getId().getSystemName(), 
					systemConfiguration.getLoginName(), systemConfiguration.getPasswordText(), systemConfiguration.getBulkInd(), 
					systemConfiguration.getEvalFinalRspInd(), systemConfiguration.getNonCriticalInd(), systemConfiguration.getXsltFile(), systemConfiguration.getNotificationUrl());				
		}
		
		List<UriConfiguration> uriConfigList = csiDao.getURIonfiguartionList();		
		for (UriConfiguration uriConfiguration : uriConfigList) {
			InitGlobalInstance.storeCurrentURIConfig(uriConfiguration.getSystemName(), uriConfiguration.getUriText(), uriConfiguration.getSynchTransactionInd(), uriConfiguration.getProxyEnabled());
		}
		
	}

	@Override
	@Transactional("dataTransactionManager")
	public boolean insertTranscode(TransCode transCode) {
		return csiDao.insertTranscode(transCode);		
	}

	@Override
	@Transactional("dataTransactionManager")
	public boolean generateAndSendErrorRequest(String messageId,
			String masterTransId) throws IOException, Exception {
		Products products;
		ProvisioningRequest provRequest;
		List<ProvisioningTask> provisioningTasks;
		boolean isValidErrorRequest = false;
		String createErrorRequestXML="";
		//create model				
		if(masterTransId!=null && masterTransId.length()>0){
			provRequest = csiDao.queryProvisioningRequest(masterTransId);
			//If more than one then get only $ provisioningTasks.
			provisioningTasks = csiDao.queryProvisioningTask(masterTransId);
			List<TransCode> transCode = csiDao.queryTransCode(masterTransId);			
			//Generate Distinct products
			List<String> distinctProductIdList = removeDuplicates(transCode);
			//Created Products
			products = addProductList(transCode,distinctProductIdList);				
		//Create Error Request XML.
		XMLGenerator xmlGenerator = new XMLGenerator();
		createErrorRequestXML = xmlGenerator.createErrorRequestXML(products,provRequest,provisioningTasks);
		csiServiceLog.info("createErrorRequestXML :"+createErrorRequestXML);
		isValidErrorRequest = validateXML(createErrorRequestXML, TPP_ErrorRequestXSD, false);
		csiServiceLog.info("isValid Generated Error Request XML :"+isValidErrorRequest);
			//Send to the Error queue.
			if(isValidErrorRequest){
				csiServiceLog.info("Sending to the Archive queue messageId:"+messageId +" masterTransId :"+masterTransId);
				sendErrorMessage(createErrorRequestXML,messageId);
				return true;
			}else{
				csiServiceLog.info("Since the generated Error Request is not valid, not sending it to the Error Queue. messageId :"+messageId +" masterTransId :"+masterTransId);
				return false;
			}
		}else{
			csiServiceLog.info("masterTransId should not be null to generate and send to Error Request to Error queue. messageId :"+messageId +" masterTransId :"+masterTransId);
			return false;
		}		
	}
	
	
	private void sendErrorMessage(String createErrorRequestXML, String messageId) {
		try {
			errorRequestQueueSender.sendMessage(createErrorRequestXML,messageId);
		} catch (JMSException e) {
			e.printStackTrace();
		}
		
	}
	
	private Products addProductList(List<TransCode> transCode, List<String> distinctProductIdList) {
		Products products = new Products();
		
		String action = "";
		Collection<Product> productCollection = new ArrayList<Product>();
		
		for (String productId : distinctProductIdList) {						
			
			ArrayList<TempTransCode> tempTransCodeList = new ArrayList<TempTransCode>();
			
			for (TransCode transCode2 : transCode) {
				if(transCode2.getProductId().equals(productId)){
					TempTransCode tempTransCode = new  TempTransCode();
					tempTransCode.setAction(transCode2.getAction());									
					tempTransCode.setMajorCode(transCode2.getMajorcode());
					tempTransCode.setMajorDesc(transCode2.getMajordesc());
					tempTransCode.setMinorCode(transCode2.getMinorcode());
					tempTransCode.setMinorDesc(transCode2.getMinordesc());
					tempTransCodeList.add(tempTransCode);
				}				
			}
			
			//Create Product
			Product product = new Product();
			product.setId(productId);
			product.setAction(tempTransCodeList.get(0).getAction());
			product.setMajorCode(Long.valueOf((String)tempTransCodeList.get(0).getMajorCode()));
			product.setDescription(tempTransCodeList.get(0).getMajorDesc());
			
			
			TransactionCode transactionCode = new TransactionCode();
			ProductMax prodMax = new ProductMax();
			for (TempTransCode tempTransCode : tempTransCodeList){
			
				TransactionCodeList transactionCodelist = new TransactionCodeList();
				Collection<TransactionCodeList> transactionCodeList = new ArrayList<TransactionCodeList>();
				transactionCodelist.setErrorCode(Long.valueOf((String)tempTransCode.getMinorCode()));
				transactionCodelist.setErrorMessageText(tempTransCode.getMinorDesc());
				transactionCodeList.add(transactionCodelist);					
				transactionCode.setTransactionCodeList(transactionCodeList);
				
				
				
				if(prodMax!=null && prodMax.getMajorCode()== null){
					prodMax.setMajorCode(tempTransCode.getMajorCode());
					prodMax.setMajorDesc(tempTransCode.getMajorDesc());
					prodMax.setMinorCode(tempTransCode.getMinorCode());
					prodMax.setMinorDesc(tempTransCode.getMinorDesc());
				}
				else
					if(Long.valueOf((String)(prodMax.getMajorCode())) < Long.valueOf((String)tempTransCode.getMajorCode()))
					{
						prodMax.setMajorCode(tempTransCode.getMajorCode());
						prodMax.setMajorDesc(tempTransCode.getMajorDesc());
						
					}
				    if(Long.valueOf((String)(prodMax.getMinorCode())) < Long.valueOf((String)tempTransCode.getMinorCode()))
				    {
				    	prodMax.setMinorCode(tempTransCode.getMinorCode());
						prodMax.setMinorDesc(tempTransCode.getMinorDesc());
				    }
			
			}
			product.setTransactionCode(transactionCode);
			product.setProductMax(prodMax);
			//Adding product to collection
			productCollection.add(product);
		}
		//Adding product collection to Products.
		products.setProduct(productCollection);
		
		return products;
	}
	
	private List<String> removeDuplicates(List<TransCode> transCode) {
		List<String> productIdList = new ArrayList<String>();
		
		for (TransCode transCode2 : transCode) {
			productIdList.add(transCode2.getProductId());						
		}
		
		HashSet<String> listToSet = new HashSet<String>(productIdList);
		csiServiceLog.info("productIdList: "+productIdList.size());
		
		List<String> productIdListWithoutDuplicates = new ArrayList<String>(listToSet);
		return productIdListWithoutDuplicates;
	}

	@Override
	@Transactional("dataTransactionManager")
	public TransCode generateTransCode(String masterTransId,
			CSIResponseKeys csiResponseKeys, String actionFemto) {
		TransCode transCode = new TransCode();
		
		
		//Query task table to get the task transid
		String taskTransId=null;
		List<ProvisioningTask> provisioningTasks = csiDao.queryProvisioningTask(masterTransId);
		
		if(provisioningTasks!=null && provisioningTasks.size()>0){
			taskTransId=getTaskTransId(provisioningTasks);
		}
		
		transCode.setMasterTransid(masterTransId);
		transCode.setTaskTransid(taskTransId);
		transCode.setProductId("7000");
		Date errorTime = new Date();		
		transCode.setErrorTime(new Timestamp(errorTime.getTime()));
		transCode.setMajordesc(csiResponseKeys.getFemtocellDescription());
		transCode.setMinorcode(csiResponseKeys.getFemtocellCode());
		transCode.setMinordesc(csiResponseKeys.getFemtocellDescription());
		transCode.setAction(actionFemto.trim());
		
		
		//Todo:Set the TransCodes
		String reasonCode = csiResponseKeys.getFemtocellCode();
		System.out.println("reasonCode-->"+ reasonCode);
		String majorCode="";
		
		if(reasonCode.equalsIgnoreCase("000") || reasonCode.equalsIgnoreCase("0")){
			majorCode="0";
		}else if(reasonCode.equalsIgnoreCase("70010")){
			majorCode="71000";
		}else if(reasonCode.equalsIgnoreCase("701")){
			majorCode="51000";
		}else{
			majorCode=reasonCode;
		}
		
		transCode.setMajorcode(majorCode);
		
		return transCode;
	}
	
	
	private String getTaskTransId(List<ProvisioningTask> provisioningTasks) {
		// Get the TraskTransId from the ProvisioningTasks
		String taskTransId = "";
		for (ProvisioningTask provisioningTasks2 : provisioningTasks) {
			if (provisioningTasks2.getId().getTaskTransid().contains("$")) {
				taskTransId = provisioningTasks2.getId().getTaskTransid();
			}
		}
		return taskTransId;
	}

}
