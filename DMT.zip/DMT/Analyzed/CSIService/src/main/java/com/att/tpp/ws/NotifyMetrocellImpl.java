package com.att.tpp.ws;

import java.sql.Timestamp;
import java.util.Date;

import javax.xml.ws.Holder;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.att.tpp.enumuration.CSIEventType;
import com.att.tpp.model.CSIResponseKeys;
import com.att.tpp.model.TransCode;
import com.att.tpp.model.WebServiceResponseData;
import com.att.tpp.service.CSIService;
import com.att.tpp.utils.CSIServiceMessageParser;
import com.att.tpp.utils.CSITransactionIDGenerator;
import com.cingular.csi.csi.namespaces.container._public.notifymetrocellactionrequest.NotifyMetrocellActionRequestInfo;
import com.cingular.csi.csi.namespaces.container._public.notifymetrocellactionresponse.NotifyMetrocellActionResponseInfo;
import com.cingular.csi.csi.namespaces.types._public.cingulardatamodel.ResponseInfo;
import com.cingular.csi.csi.namespaces.types._public.messageheader.MessageHeaderInfo;
import com.cingular.csi.csi.namespaces.v118.wsdl.cingularwirelesscsi.CSIApplicationException;
import com.cingular.csi.csi.namespaces.v118.wsdl.cingularwirelesscsi.NotifyMetrocellActionPortType;

@Service("notifyMetrocell")
public class NotifyMetrocellImpl implements NotifyMetrocell {
	
	private static final String methodName = "[doNotifyMetrocellAction] ";

	private static Logger notifyMetrocellActionLog = Logger.getLogger(NotifyMetrocellImpl.class);
	
	@Autowired
	private CSIMessageHeaderService csiMessageHeaderService;
	
	@Autowired
	private NotifyMetrocellActionPortType notifyMetrocellActionPortType;	
	
	@Autowired
	private CSIService csiService;

	@Override
	public WebServiceResponseData doNotifyMetrocellAction(
			CSIResponseKeys csiResponseKeys, String requestXML,
			String actionMetro, String provSystemTransId)
			throws CSIApplicationException, Exception {
		
		notifyMetrocellActionLog.info(methodName + "Executing NotifyMetrocellAction");
		
		//Generating Message Header
		Holder<MessageHeaderInfo> messageHeader = null;
		String csiTransactionId = null;
		CSITransactionIDGenerator csiIDGen = new CSITransactionIDGenerator();
		
		csiTransactionId = csiIDGen.generateCSITransactionId(provSystemTransId);  //passing blank to get generated transactionId for CSI Service call		
		
		
		//Generate the WebresponseData.
		WebServiceResponseData webServiceResponseData = new WebServiceResponseData();
		webServiceResponseData.setTppcsiTransactionid(csiTransactionId);			
		webServiceResponseData.setTppTransactionid(csiResponseKeys.getMessageTransactionID());
		webServiceResponseData.setInputXml(requestXML);
		webServiceResponseData.setCarrierName(csiResponseKeys.getProvisioningCarrier());
		webServiceResponseData.setRoutingCarrier(csiResponseKeys.getRoutingCarrier());
		webServiceResponseData.setInterfaceName(CSIEventType.NotifyMetrocellAction.toString());
		Date date = new Date();			
		webServiceResponseData.setTimeStamp(new Timestamp(date.getTime()));
		
		try {
			
			messageHeader = csiMessageHeaderService.generateCSIMessageHeader(csiTransactionId);  //The TransactionId should be the one that is used in the initiating call from upstream (CSI).
			
		} catch (Exception e) {
			
			notifyMetrocellActionLog.info(methodName + "Exception occured while generating CSIMessageHeader, MessageId: " + csiTransactionId);			
			e.printStackTrace();
			throw e;
		}
		String action = null;
		if(actionMetro!=null && actionMetro.equals("Cancel")){
			action="005";
		}else{
			action="004";
		}
		//Create Web Service request
		ResponseInfo responseInfo = new ResponseInfo();
		responseInfo.setCode(csiResponseKeys.getFemtocellCode());  //*** need to review with team if we want to add specific field in csiResponseKey Model for Metrocell.  Maybe refactor to e911ResponseCode
		responseInfo.setDescription(csiResponseKeys.getFemtocellDescription());  //*** need to review with team if we want to add specific field in csiResponseKey Model for Metrocell.  Maybe refactor to e911ResponseDescription
		
		NotifyMetrocellActionRequestInfo notifyMetrocellActionRequestInfo = new NotifyMetrocellActionRequestInfo();
		notifyMetrocellActionRequestInfo.setAction(action);  //need to pull the action for the table for the particular transaction ID or sent in the payload from response Service
		notifyMetrocellActionRequestInfo.setResponse(responseInfo);

		NotifyMetrocellActionResponseInfo notifyMetrocellActionResponseInfo = null;
		
		try{
			
			notifyMetrocellActionResponseInfo = notifyMetrocellActionPortType.notifyMetrocellAction(messageHeader, notifyMetrocellActionRequestInfo);
			
			webServiceResponseData.setCsiResponsecode(notifyMetrocellActionResponseInfo.getResponse().getCode());
			webServiceResponseData.setCsiResponsedesc(notifyMetrocellActionResponseInfo.getResponse().getDescription());	
			webServiceResponseData.setSkuStatus("S");
			
			
			
			//TODO Need to persist response
			
		} catch (CSIApplicationException csiApplicationException){
			
			notifyMetrocellActionLog.info(methodName + "NotifyMetrocellAction Web Service call Failed!");
			notifyMetrocellActionLog.info(methodName + "Error Code: " + csiApplicationException.getFaultInfo().getResponse().getCode());
			notifyMetrocellActionLog.info(methodName + "Error Description: " + csiApplicationException.getFaultInfo().getResponse().getDescription());
			notifyMetrocellActionLog.info(methodName + "Error Message: " + csiApplicationException.getMessage());
			
			webServiceResponseData.setSkuStatus("F");
			webServiceResponseData.setCsiResponsecode(csiApplicationException.getFaultInfo().getResponse().getCode());
			webServiceResponseData.setCsiResponsedesc(csiApplicationException.getFaultInfo().getResponse().getDescription());
			webServiceResponseData.setErrorMessage(csiApplicationException.getMessage());
			
			//TODO Need to persist error response
			//throw csiApplicationException;
		} catch (Exception e){
			notifyMetrocellActionLog.info(methodName + "Exception :: Error Message: " + e.getMessage());
			webServiceResponseData.setSkuStatus("F");
			webServiceResponseData.setCsiResponsecode("900");
			webServiceResponseData.setCsiResponsedesc("Exception thrown in NotifyMetrocellAction Response");
			webServiceResponseData.setErrorMessage(e.getMessage());
		}
		
		notifyMetrocellActionLog.info(methodName + "NotifyMetrocellAction Web Service call completed with Success!");
		notifyMetrocellActionLog.info(methodName + "NotifyMetrocellAction Web Service call made with CTN: " + csiResponseKeys.getCtn());
		notifyMetrocellActionLog.info(methodName + "NotifyMetrocellAction Web Service call made with MessageID: " + csiTransactionId);
		
		
		
		return webServiceResponseData;
		
	}

	@Override
	public WebServiceResponseData invokeNotifyMetrocellAction(
			String requestXML, String eventType, String methodName,
			WebServiceResponseData webServiceResponseData,
			CSIServiceMessageParser csiMessageParser, String actionMetro,
			String provSystemTransId, String masterTransId)
			throws CSIApplicationException, Exception {
		
		try{
			
			notifyMetrocellActionLog.info(methodName + "Invoking NotifyMetrocellAction Web Service");
			CSIResponseKeys csiResponseKeys = csiMessageParser.parseNotifyFemtocell(requestXML, eventType);
			
			csiResponseKeys.setMessageTransactionID(masterTransId);			
			webServiceResponseData = doNotifyMetrocellAction(csiResponseKeys, requestXML, actionMetro, provSystemTransId);		
			notifyMetrocellActionLog.info(methodName + "Completed invoking NotifyMetrocellAction Web Service");
			
			//Generate TransCode and Insert into DB.
			TransCode transCode = csiService.generateTransCode(masterTransId, csiResponseKeys, actionMetro);
			boolean insertTransCode = csiService.insertTranscode(transCode);
			notifyMetrocellActionLog.info(methodName + "insertTransCode result: "+insertTransCode);
		
			//Note: For now we are sending only 71000 errors to the Error Service.
			//Please check with prod support
			if(transCode.getMajorcode().equalsIgnoreCase("71000")){
				String messageId="";
				boolean sendToErrorQueue = csiService.generateAndSendErrorRequest(messageId, masterTransId);
				notifyMetrocellActionLog.info(methodName + "sendToErrorQueue result: "+sendToErrorQueue);
			}
			
			
		} catch (CSIApplicationException csiApplicationException){				
			
			notifyMetrocellActionLog.info(methodName + "Exception occured when invoking NotifyMetrocellAction Web Service");
			notifyMetrocellActionLog.info(methodName + "Error Code: " + csiApplicationException.getFaultInfo().getResponse().getCode());
			notifyMetrocellActionLog.info(methodName + "Error Description: "  + csiApplicationException.getFaultInfo().getResponse().getDescription());
			notifyMetrocellActionLog.info(methodName + "Error Message: " + csiApplicationException.getMessage());
			//throw csiApplicationException;
				
		} 
		
		return webServiceResponseData;		
	}

}
