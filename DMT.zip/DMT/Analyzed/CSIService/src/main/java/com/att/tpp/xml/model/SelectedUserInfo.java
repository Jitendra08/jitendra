package com.att.tpp.xml.model;

public class SelectedUserInfo {

    private String accessID;
    private String memberID;
    
	/**
	 * Pass the memberID or accessID value
	 * With the selector value set to either 
	 * MemberID or AccessID to set the respective property.
	 *
	 * 
	 * @param id
	 * @param selector
	 */
	public SelectedUserInfo(String id, String selector) {
		if (selector.equalsIgnoreCase("MemberID")){
			this.memberID = id;			
		}
		if (selector.equalsIgnoreCase("AccessID")){
			this.accessID = id;
		}
	}

	/**
     * Gets the value of the accessID property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getAccessID() {
        return accessID;
    }

    /**
     * Sets the value of the accessID property.
     * 
     * @param accessID
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setAccessID(String accessID) {
        this.accessID = accessID;
    }

    /**
     * Gets the value of the memberID property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getMemberID() {
        return memberID;
    }

    /**
     * Sets the value of the memberID property.
     * 
     * @param memberID
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setMemberID(String memberID) {
        this.memberID = memberID;
    }

}
