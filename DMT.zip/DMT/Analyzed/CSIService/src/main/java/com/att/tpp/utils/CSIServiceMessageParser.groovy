/**
 * 
 */
package com.att.tpp.utils

import groovy.util.logging.Log4j;
import groovy.util.slurpersupport.NodeChild;

import com.att.aft.dme2.internal.google.common.cache.CacheBuilderSpec.MaximumSizeParser
import com.att.tpp.model.CSIResponseKeys;
import com.att.tpp.model.CampaignParameters
import com.att.tpp.model.SendEmailKeys;
import com.att.tpp.xml.model.Notification;
import com.att.tpp.xml.model.OrderDocumentInfo
import com.cingular.csi.csi.namespaces.container._public.managemobileproductsprovisioningrequest.ManageMobileProductsProvisioningRequestInfo.Product;
import com.cingular.csi.csi.namespaces.container._public.managemobileproductsprovisioningrequest.ManageMobileProductsProvisioningRequestInfo.Product.ProvisioningResponse;
import com.cingular.csi.csi.namespaces.types._public.cingulardatamodel.AttributeInfo
import com.cingular.csi.csi.namespaces.types._public.cingulardatamodel.ShipmentLineInfo
import com.cingular.csi.csi.namespaces.types._public.cingulardatamodel.ShipmentSubLineInfo
import com.sun.xml.internal.ws.api.streaming.XMLStreamReaderFactory.Default;
import com.sun.xml.internal.ws.org.objectweb.asm.Item;

/**
 * @author SC9833
 *
 */
@Log4j
class CSIServiceMessageParser {
	
	def CSIResponseKeys parseEcho(String responseXML, String eventType){
		
		def notification = new XmlSlurper().parseText(responseXML)
		def noteText = notification.@message.toString()
		def csiResponseKeys = new CSIResponseKeys()
		
		csiResponseKeys.inputText = noteText
		csiResponseKeys.messageTransactionID ="TPP_ECHO_ID_N/A"
		csiResponseKeys.eventType = eventType
				
		return csiResponseKeys;
		
	
	}
	
	/**
	 * This method will provide the ConversationId from the CSI API Response
	 * @param csiResXML is the response from the CSI
	 * @return parsedConId - ConversationId
	 */
	def String getHeaderInfo(String csiResXML){
		def strCSIResponseXML = new XmlSlurper().parseText(csiResXML)
		def messageHeader = strCSIResponseXML.Header.MessageHeader.TrackingMessageHeader
		def parsedConId = null
		parsedConId=messageHeader.conversationId.toString();
		return parsedConId;
	}
	
	def CSIResponseKeys parseAddNote(String responseXML, String eventType){
		
		def notification = new XmlSlurper().parseText(responseXML)		
		def ban = notification.@BAN.toString()
		def ctn = notification.@subscriberNumber.toString()
		/*
		 * WR #2999975 - 3PP limitation: AddNote CSI call not supported for Multiple APP Ids
		 * Modified below code to add multiple Notes to the Notes tag for AddNote service.
		 */
		//def noteText = notification.Notes.noteText.toString()
		def noteTextList = new ArrayList<String>()
		def noteText = ""
		notification.Notes.noteText.collect{
			if(it.size()>0){
				noteText=it.toString()
				noteTextList.add(noteText)
			}
		}
		
		
		def csiResponseKeys = new CSIResponseKeys();
		
		csiResponseKeys.messageTransactionID = notification.@MasterTransID.toString()
		csiResponseKeys.routingCarrier = notification.@RoutingCarrier.toString()
		csiResponseKeys.ban = ban
		csiResponseKeys.ctn = ctn
		csiResponseKeys.inputText = noteText
		csiResponseKeys.eventType = eventType
		csiResponseKeys.noteTextList = noteTextList
				
		return csiResponseKeys; 		
				
	}
	
	def CSIResponseKeys parseSendSMS(String responseXML, String eventType){
		
		def notification = new XmlSlurper().parseText(responseXML)		
		def header = notification.Header
		def account = notification.Order.Account		
		def transactionId = header.@TransactionId.toString()
		def msisdn = account.@MSISDN.toString()
		def ctn = msisdn.substring(1, msisdn.length()).toString()
		def sms = account.@SMS.toString()		
		def csiResponseKeys = new CSIResponseKeys();
		
		csiResponseKeys.messageTransactionID = transactionId
		csiResponseKeys.provisioningCarrier = header.@ProvisioningCarrier.toString()
		csiResponseKeys.routingCarrier = header.@RoutingCarrier.toString()
		csiResponseKeys.msisdn = msisdn
		csiResponseKeys.ctn = ctn
		csiResponseKeys.inputText = sms		
		csiResponseKeys.eventType = eventType
				
		return csiResponseKeys
	
	}
	
	def CSIResponseKeys parseAddOrderNotes(String responseXML, String eventType){
		
		def msgTransactionID=null;
		def provisioningCarrier=null;
		def routingCarrier=null;
		
		def notification = new XmlSlurper().parseText(responseXML)
		def header = notification.Header
		def orderId = notification.OrderId		
		def parsedOrderId = new OrderDocumentInfo(orderId.location.toString(), orderId.activity.toString(), orderId.orderId.toString())		 
		def csiResponseKeys = new CSIResponseKeys()
		
		msgTransactionID=header.@TransactionId?.toString();
		def n1MsgTransactionID =header.@'n1:TransactionId'?.toString();
		def n2MsgTransactionID =header.@'n2:TransactionId'?.toString();
		/* Added ns1 check as the ns1 prefix is coming from VPP */
		def ns1MsgTransactionID =header.@'ns1:TransactionId'?.toString();
		
		if(msgTransactionID.size()>0){
			msgTransactionID=msgTransactionID;
			provisioningCarrier=header.@ProvisioningCarrier?.toString();
			routingCarrier = header.@RoutingCarrier?.toString();
		}else if(n1MsgTransactionID.size()>0){
			msgTransactionID=n1MsgTransactionID;
			provisioningCarrier=header.@'n1:ProvisioningCarrier'?.toString();
			routingCarrier = header.@'n1:RoutingCarrier'?.toString();
		}else if(n2MsgTransactionID.size()>0){
			msgTransactionID=n2MsgTransactionID;
			provisioningCarrier=header.@'n2:ProvisioningCarrier'?.toString();
			routingCarrier = header.@'n2:RoutingCarrier'?.toString();
		}else if(ns1MsgTransactionID.size()>0){
			msgTransactionID=ns1MsgTransactionID;
			provisioningCarrier=header.@'ns1:ProvisioningCarrier'?.toString();
			routingCarrier = header.@'ns1:RoutingCarrier'?.toString();
		}
				
		//csiResponseKeys.messageTransactionID = header.@TransactionId.toString()
		//csiResponseKeys.provisioningCarrier = header.@ProvisioningCarrier.toString()
		//csiResponseKeys.routingCarrier = header.@RoutingCarrier.toString()
		
		csiResponseKeys.messageTransactionID = msgTransactionID
		csiResponseKeys.provisioningCarrier = provisioningCarrier
		csiResponseKeys.routingCarrier = routingCarrier
		println("CSI Parse >>>provisioningCarrier>>>"+provisioningCarrier)
		println("CSI Parse >>>routingCarrier>>>"+routingCarrier)
		csiResponseKeys.orderId = parsedOrderId
		csiResponseKeys.reasonCode = notification.reasonCode.toString()
		csiResponseKeys.comment = notification.comment.toString()
		csiResponseKeys.eventType = eventType		
		
		return csiResponseKeys
		
	}
	
	
	def CSIResponseKeys parseAddOrderShipment(String responseXML, String eventType){
		
		def msgTransactionID=null;
		def provisioningCarrier=null;
		def routingCarrier=null;
		
		def notification = new XmlSlurper().parseText(responseXML)
		def header = notification.Header
		def orderId = notification.OrderId
		def parsedOrderId = new OrderDocumentInfo(orderId.location.toString(), orderId.activity.toString(), orderId.orderId.toString())
		def fulfillmentId = notification.fulfillmentId.toString()
		def fulfillmentType = notification.type.toString()
		def carrierId = notification.carrierId.toString()
		def csiResponseKeys = new CSIResponseKeys()
		
		println("CSI Parse >>>msgTransactionID>>>"+msgTransactionID)
		msgTransactionID=header.@TransactionId?.toString();
		println("CSI Parse1 >>>msgTransactionID>>>"+msgTransactionID)
		def n1MsgTransactionID =header.@'n1:TransactionId'?.toString();
		println("CSI Parse >>>n1MsgTransactionID>>>"+n1MsgTransactionID)
		def n2MsgTransactionID =header.@'n2:TransactionId'?.toString();
		println("CSI Parse >>>n2MsgTransactionID>>>"+n2MsgTransactionID)
		/* Added ns1 check as the ns1 prefix is coming from VPP */
		def ns1MsgTransactionID =header.@'ns1:TransactionId'?.toString();
		println("CSI Parse >>>ns1MsgTransactionID>>>"+ns1MsgTransactionID)
		
		if(msgTransactionID.size()>0){
			msgTransactionID=msgTransactionID;
			provisioningCarrier=header.@ProvisioningCarrier?.toString();
			routingCarrier = header.@RoutingCarrier?.toString();
		}else if(n1MsgTransactionID.size()>0){
			msgTransactionID=n1MsgTransactionID;
			provisioningCarrier=header.@'n1:ProvisioningCarrier'?.toString();
			routingCarrier = header.@'n1:RoutingCarrier'?.toString();
		}else if(n2MsgTransactionID.size()>0){
			msgTransactionID=n2MsgTransactionID;
			provisioningCarrier=header.@'n2:ProvisioningCarrier'?.toString();
			routingCarrier = header.@'n2:RoutingCarrier'?.toString();
		}else if(ns1MsgTransactionID.size()>0){
			msgTransactionID=ns1MsgTransactionID;
			provisioningCarrier=header.@'ns1:ProvisioningCarrier'?.toString();
			routingCarrier = header.@'ns1:RoutingCarrier'?.toString();
		}
		
		csiResponseKeys.messageTransactionID = msgTransactionID
		csiResponseKeys.provisioningCarrier = provisioningCarrier
		csiResponseKeys.routingCarrier = routingCarrier
		
		println("CSI Parse >>>provisioningCarrier>>>"+provisioningCarrier)
		println("CSI Parse >>>routingCarrier>>>"+routingCarrier)
		
		/*csiResponseKeys.messageTransactionID = header.@TransactionId.toString()
		csiResponseKeys.provisioningCarrier = header.@ProvisioningCarrier.toString()
		csiResponseKeys.routingCarrier = header.@RoutingCarrier.toString()*/
		
		csiResponseKeys.orderId = parsedOrderId
		csiResponseKeys.fulfillmentId = fulfillmentId
		csiResponseKeys.fulfillmentType = fulfillmentType		
		csiResponseKeys.carrierId = (carrierId.size()>0) ? carrierId : ""
		
		def shipmentLineInfoList = new ArrayList<ShipmentLineInfo>()
		def deviceAssociationList = new ArrayList<ShipmentSubLineInfo>()
		
		notification.ShipmentLine.collect{
			def shipmentLineInfo = new ShipmentLineInfo()
			
			shipmentLineInfo.orderLineNumber = it.orderLineNumber.toInteger().value
			shipmentLineInfo.trackingNumber = it.trackingNumber.toString()
			shipmentLineInfo.itemId = it.itemId.toString()
			shipmentLineInfo.quantity = it.quantity.toInteger().value
			
			if(it.DeviceAssociation.size()>0){
				it.DeviceAssociation.collect{
					da ->
					def deviceAssociation = new ShipmentSubLineInfo()
					
					deviceAssociation.subscriberNumber = da.subscriberNumber.toString()
					deviceAssociation.serialNumber = da.serialNumber.toString()
					
					deviceAssociationList.add(deviceAssociation)
				}
				
				shipmentLineInfo.deviceAssociation = deviceAssociationList
			}	
						
			shipmentLineInfoList.add(shipmentLineInfo)
		}
		
		csiResponseKeys.setShipmentLineInfo(shipmentLineInfoList)
		
		return csiResponseKeys
		
	}
	
	def CSIResponseKeys parseCancelOrder(String responseXML, String eventType){
		def msgTransactionID=null;
		def provisioningCarrier=null;
		def routingCarrier=null;
		
		def notification = new XmlSlurper().parseText(responseXML)		
		def header = notification.Header
		def orderId = notification.OrderId
		def parsedOrderId = new OrderDocumentInfo(orderId.location.toString(), orderId.activity.toString(), orderId.orderId.toString())
		def csiResponseKeys = new CSIResponseKeys()
		
		msgTransactionID=header.@TransactionId?.toString();
		def n1MsgTransactionID =header.@'n1:TransactionId'?.toString();
		def n2MsgTransactionID =header.@'n2:TransactionId'?.toString();
		/* Added ns1 check as the ns1 prefix is coming from VPP */
		def ns1MsgTransactionID =header.@'ns1:TransactionId'?.toString();
		
		if(msgTransactionID.size()>0){
			msgTransactionID=msgTransactionID;
			provisioningCarrier=header.@ProvisioningCarrier?.toString();
			routingCarrier = header.@RoutingCarrier?.toString();
		}else if(n1MsgTransactionID.size()>0){
			msgTransactionID=n1MsgTransactionID;
			provisioningCarrier=header.@'n1:ProvisioningCarrier'?.toString();
			routingCarrier = header.@'n1:RoutingCarrier'?.toString();
		}else if(n2MsgTransactionID.size()>0){
			msgTransactionID=n2MsgTransactionID;
			provisioningCarrier=header.@'n2:ProvisioningCarrier'?.toString();
			routingCarrier = header.@'n2:RoutingCarrier'?.toString();
		}else if(ns1MsgTransactionID.size()>0){
			msgTransactionID=ns1MsgTransactionID;
			provisioningCarrier=header.@'ns1:ProvisioningCarrier'?.toString();
			routingCarrier = header.@'ns1:RoutingCarrier'?.toString();
		}
		
		csiResponseKeys.messageTransactionID = msgTransactionID
		csiResponseKeys.provisioningCarrier = provisioningCarrier
		csiResponseKeys.routingCarrier = routingCarrier
		println("CSI Parse >>>provisioningCarrier>>>"+provisioningCarrier)
		println("CSI Parse >>>routingCarrier>>>"+routingCarrier)
		/*csiResponseKeys.messageTransactionID = header.@TransactionId.toString()
		csiResponseKeys.provisioningCarrier = header.@ProvisioningCarrier.toString()
		csiResponseKeys.routingCarrier = header.@RoutingCarrier.toString()*/
		csiResponseKeys.orderId = parsedOrderId		
		csiResponseKeys.reasonCode = notification.reasonCode.toString()
		csiResponseKeys.comment = notification.comment.toString()		
		csiResponseKeys.eventType = eventType
		
		return csiResponseKeys
		
	}	
	

	public SendEmailKeys parseSendEmail(String requestXML, String eventType) {
				
		def notification = new XmlSlurper().parseText(requestXML)
		def header = notification.Header
		def accountNumber = notification.Account.@BAN.toString()
		def accountNamePrefix = notification.EmailMsg.NamePrefix.toString()
		def accountFirstName = notification.EmailMsg.FirstName.toString()
		def accountMiddleName = notification.EmailMsg.MiddleName.toString()
		def accountLastName  = notification.EmailMsg.LastName.toString()
		def accountNameSuffix = notification.EmailMsg.NameSuffix.toString()
		def billingMarket = notification.MarketInfo.billingMarket.toString()
		def billingSubMarket = notification.MarketInfo.billingSubMarket.toString()
		def localMarket  = notification.MarketInfo.localMarket.toString()
		def destinationEmailAddress  = notification.EmailMsg.EmailAddress.toString()
		def subject  = notification.EmailMsg.Subject.toString()
		def campaignName = notification.campaignName.toString()
		def attributeInfo = new AttributeInfo();
		def campaignParameters = notification.CampaignParameters.collect{			
			attributeInfo.setAttributeName(it.attributeName.toString())
			attributeInfo.setAttributeValue(it.attributeValue.toString())
		}
		def sendEmailKeys = new SendEmailKeys()
		
		sendEmailKeys.messageTransactionID = header.@TransactionId.toString()
		sendEmailKeys.provisioningCarrier = header.@ProvisioningCarrier.toString()
		sendEmailKeys.routingCarrier = header.@RoutingCarrier.toString()
		sendEmailKeys.accountNumber=accountNumber;
		sendEmailKeys.accountNamePrefix=accountNamePrefix;
		sendEmailKeys.accountFirstName=accountFirstName;
		sendEmailKeys.accountMiddleName=accountMiddleName;
		sendEmailKeys.accountLastName=accountLastName;
		sendEmailKeys.accountNameSuffix=accountNameSuffix;
		sendEmailKeys.billingMarket=billingMarket;
		sendEmailKeys.billingSubMarket=billingSubMarket;
		sendEmailKeys.localMarket=localMarket;
		sendEmailKeys.destinationEmailAddress=destinationEmailAddress;
		sendEmailKeys.subject=subject;
		sendEmailKeys.campaignName=campaignName;
		sendEmailKeys.campaignParameters=campaignParameters;
		
		return sendEmailKeys;
		
	}
	
	def CSIResponseKeys parseNotifyFemtocell(String responseXML, String eventType){
		
		def notification = new XmlSlurper().parseText(responseXML)				
		//def payload = notification.VUI.Payload.ALIUpdateResponse		
		def csiResponseKeys = new CSIResponseKeys()
		
		csiResponseKeys.provisioningCarrier = "CSI"
		csiResponseKeys.routingCarrier = "CSI"
		//csiResponseKeys.externalKey = notification.externalKey.toString()
		csiResponseKeys.aliUpdateResponseVersion = notification.@ver.size() > 0 ? notification.@ver.toString() : "1.0"		
       	csiResponseKeys.femtocellCode = notification.rc1.toString()
		csiResponseKeys.femtocellDescription = notification.rc1.@message.toString()
		csiResponseKeys.eventType = eventType
		//csiResponseKeys.messageTransactionID = "TestNotifyFemtocell"  
		//Todo:This is not available in the incoming message pull from OtherProps
		
		return csiResponseKeys
		
	}
	
	def String parseIntradoExternalKey (String intradoRequestXML){
		def request = new XmlSlurper().parseText(intradoRequestXML)
		def externalKey = null
				
		externalKey = request.FemtocellTNUpdate.FemtocellAdditionalInfo.@ExternalKey.toString()
		
		return externalKey
	}
	
	def CSIResponseKeys parseManageMobileProductsProvisioning(String responseXML, String eventType){
		
		log.info("parseManageMobileProductsProvisioning responseXML >>"+responseXML);
		
		def notification = new XmlSlurper().parseText(responseXML)
		def header = notification.Header
		def order = notification.Order
		//def product = new Product();
		def csiResponseKeys = new CSIResponseKeys()
		def provisioningResponse = new ProvisioningResponse()
		
		csiResponseKeys.messageTransactionID = header.@TransactionId.toString()
		csiResponseKeys.provisioningCarrier = header.@ProvisioningCarrier.toString()
		csiResponseKeys.routingCarrier = header.@RoutingCarrier.toString()
		csiResponseKeys.msisdn = order.Account.@MSISDN.toString()
		
		
		provisioningResponse.code = order.Products.Product[0].TransactionCode.@MajorCode.toString()
		provisioningResponse.message = order.Products.Product[0].TransactionCode.@Description.toString()
		provisioningResponse.detail = order.Products.Product[0].TransactionCode.TransactionCodeList[0].@ErrorMessageText.toString()
		csiResponseKeys.action = order.Products.Product[0].@Action.toString().toUpperCase()
		
		/* Below code commented as this support only for single product. */
		
		
		/*
		 log.info("parseManageMobileProductsProvisioning action >>"+order.Products.Product[0].@Action.toString().toUpperCase());
		 product.category = order.Products.Product[0].@Category.toString()
		 log.info("parseManageMobileProductsProvisioning category >>"+order.Products.Product[0].@Category.toString());
		 product.id = order.Products.Product[0].@Id.toString()
		 log.info("parseManageMobileProductsProvisioning id >>"+order.Products.Product[0].@Id.toString());
		 
		 log.info("Product size>>"+order.Products.size());
		 
		 order.Products.Product[0].Attribute.collect{
			 if(!it.findAll{it.name() == "Attribute"}.collect{qty -> qty.@Name.toString()}.equals([])){
				 if(it.findAll{it.name() == "Attribute"}.@Name.equals("QTY")){
					 log.info("Product quantity>>"+it.findAll{it.name() == "Attribute"}.@Value.toInteger().value);
					 product.quantity = it.findAll{it.name() == "Attribute"}.@Value.toInteger().value
				 }
			 }
		 }
		 
		 order.Products.Product[0].Attribute.collect{
			 if(!it.findAll{it.name() == "Attribute"}.collect{qty -> qty.@Name.toString()}.equals([])){
				 if(it.findAll{it.name() == "Attribute"}.@Name.equals("PREV_QTY")){
					 log.info("Product quantity>>"+it.findAll{it.name() == "Attribute"}.@Value.toInteger().value);
					 product.previousQuantity = it.findAll{it.name() == "Attribute"}.@Value.toInteger().value
				 }
			 }
		 }
		 
		 //product.provisioningResponse = provisioningResponse
		 
		 //csiResponseKeys.product = product
	 */	
		
		/* Added the below code to support multiple product for DCM Notification */
		
		def productList = new ArrayList<Product>()
		notification.Order.Products.Product.collect{
			def product = new Product();
			product.category = it.@Category.toString()
			product.id = it.@Id.toString()
			log.info("it.Attribute.size() >>"+it.Attribute.size());
			if(it.Attribute.size()>0){
				it.Attribute.collect{
					att ->
					if(att.@Name.toString().equals("QTY")){
						product.quantity=att.@Value.toInteger().value
					}
					if(att.@Name.toString().equals("PREV_QTY")){
						product.previousQuantity=att.@Value.toInteger().value
					}
				}
			}
			if(it.TransactionCode.size()>0){
				it.TransactionCode.collect{
					transCode ->
					provisioningResponse.code=transCode.@MajorCode.toString()
					provisioningResponse.message=transCode.@Description.toString()
					if(it.TransactionCodeList.size()>0){
						it.TransactionCodeList.collect{
							transCodeList ->
							provisioningResponse.detail=transCodeList.@ErrorMessageText.toString()
						}
					}
				}
			}
			product.provisioningResponse = provisioningResponse
			productList.add(product)
		}

		csiResponseKeys.product = productList
		
		return csiResponseKeys
		
	}
	
	@Deprecated
	def CSIResponseKeys getCSIResponseKeyInfo(String responseXML, String eventType){
		
		def notification = new XmlSlurper().parseText(responseXML)
		def header = notification.Header
		def orderId = notification.OrderId
		def parsedOrderId = new OrderDocumentInfo(orderId.location.toString(), orderId.activity.toString(), orderId.orderId.toString())
		def csiResponseKeys = new CSIResponseKeys()
		 
		
				
		csiResponseKeys.messageTransactionID = header.@TransactionId.toString()
		csiResponseKeys.orderId = parsedOrderId
		csiResponseKeys.reasonCode = notification.reasonCode.toString()
		csiResponseKeys.comment = notification.comment.toString()
		csiResponseKeys.eventType = eventType
		
		return csiResponseKeys
		
	}
	
	
	static main(args) {
		def cmp = new CSIServiceMessageParser()
		
		
		def crp = new CSIResponseKeys()
		
		crp = cmp.parseIntradoExternalKey((new File("C:\\Users\\SC9833\\Desktop\\2014 Projects\\NGP-3PPv20\\getIntradoExternalKey.xml").text))
		
		println ("ExternalKey: " + crp);
		
		
		
//		crp = cmp.parseNotifyFemtocell((new File("C:\\Users\\SC9833\\Desktop\\2014 Projects\\SmallCell\\VUI.xml").text), "NotifySmallcellAction")
//		println(crp.aliUpdateResponseVersion)
//		println(crp.externalKey)
//		println(crp.femtocellCode)
//		println(crp.femtocellDescription)
		
		
//		def shipment = new ShipmentLineInfo()
//		crp = cmp.parseAddOrderShipment((new File("C:\\Users\\SC9833\\Desktop\\2014 Projects\\ProntoFormsSKU\\SKU_XMLS\\testShip3.xml").text),"")
//						
//		println("TransactionID: ${crp.messageTransactionID}")
//				
//		println(crp.provisioningCarrier)
//		println(crp.routingCarrier)
//		println(crp.fulfillmentId)
//		println(crp.fulfillmentType)
//		println(crp.orderId.location)
//		println(crp.orderId.activity)
//		println(crp.orderId.orderId)
//		
//		println(crp.shipmentLineInfo.toString())
//				
//		crp.shipmentLineInfo*.each{
//			println("orderLineNume -> " + it.orderLineNumber)
//		}
//	
//		crp.shipmentLineInfo*.each{
//			
//			ship -> ship.deviceAssociation
//			
//			println("lineNum: " + ship.orderLineNumber)
//			println("quantity: " + ship.quantity)
//			println("itemId: " + ship.itemId)
//			println("trackingNumber: " + ship.trackingNumber)
//			ship.deviceAssociation.each{
//				dev ->
//				println(dev.subscriberNumber)
//				println(dev.serialNumber)
//			}
//		}		
		
	}
	
	

}
