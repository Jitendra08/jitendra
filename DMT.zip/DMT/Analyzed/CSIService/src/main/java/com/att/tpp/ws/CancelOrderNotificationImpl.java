package com.att.tpp.ws;

import java.math.BigInteger;
import java.sql.Timestamp;
import java.util.Date;

import javax.xml.ws.Holder;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.att.tpp.enumuration.CSIEventType;
import com.att.tpp.model.CSIResponseKeys;
import com.att.tpp.model.WebServiceResponseData;
import com.att.tpp.utils.CSIServiceMessageParser;
import com.att.tpp.utils.CSITransactionIDGenerator;
import com.cingular.csi.csi.namespaces.container._public.cancel3pporderrequest.Cancel3PPOrderRequestInfo;
import com.cingular.csi.csi.namespaces.container._public.cancel3pporderresponse.Cancel3PPOrderResponseInfo;
import com.cingular.csi.csi.namespaces.types._public.cingulardatamodel.OrderDocumentInfo;
import com.cingular.csi.csi.namespaces.types._public.messageheader.MessageHeaderInfo;
import com.cingular.csi.csi.namespaces.v118.wsdl.cingularwirelesscsi.CSIApplicationException;
import com.cingular.csi.csi.namespaces.v118.wsdl.cingularwirelesscsi.Cancel3PPOrderPortType;

@Transactional
@Service("cancelOrderNotification")
public class CancelOrderNotificationImpl implements CancelOrderNotification {
	
	private static final String methodName = "[doCancel3PPOrderRequest] ";
	
	private static Logger cancelOrderNotificationLog = Logger.getLogger(CancelOrderNotificationImpl.class);
	
	@Autowired
	private CSIMessageHeaderService csiMessageHeaderService;
		
	@Autowired 
	private Cancel3PPOrderPortType cancel3PPOrderPortType;	

	@Override
	public WebServiceResponseData doCancel3PPOrderRequest(
			CSIResponseKeys csiResponseKeys, String requestXML) throws CSIApplicationException,
			Exception {
		
		cancelOrderNotificationLog.info(methodName + "Executing Add3PPOrderNotesRequest with OrderId: " + csiResponseKeys.getConcatOrderID());
		
		
		//Generating Message Header
		Holder<MessageHeaderInfo> messageHeader = null;
		String csiTransactionId = null;
		CSITransactionIDGenerator csiIDGen = new CSITransactionIDGenerator();
		csiTransactionId = csiIDGen.generateCSITransactionId("");  //passing blank to get generated transactionId for CSI Service call
		
		
		//Generate the WebresponseData.
		WebServiceResponseData webServiceResponseData = new WebServiceResponseData();
		webServiceResponseData.setTppcsiTransactionid(csiTransactionId);			
		webServiceResponseData.setTppTransactionid(csiResponseKeys.getMessageTransactionID());
		webServiceResponseData.setOrderid(csiResponseKeys.getConcatOrderID());
		webServiceResponseData.setInputXml(requestXML);
		webServiceResponseData.setCarrierName(csiResponseKeys.getProvisioningCarrier());
		webServiceResponseData.setRoutingCarrier(csiResponseKeys.getRoutingCarrier());
		webServiceResponseData.setInterfaceName(CSIEventType.CancelOrder.toString());
		Date date = new Date();			
		webServiceResponseData.setTimeStamp(new Timestamp(date.getTime()));
		
		try {
			
			messageHeader = csiMessageHeaderService.generateCSIMessageHeader(csiTransactionId);
			
		} catch (Exception e) {
			
			cancelOrderNotificationLog.info(methodName + "Exception occured while generating CSIMessageHeader, MessageId: " + csiTransactionId);
			cancelOrderNotificationLog.info(methodName + "Exception occured while generating CSIMessageHeader, OrderId: " + csiResponseKeys.getConcatOrderID());
			e.printStackTrace();
			throw e;
		}
		
		//Create Web Service request
		OrderDocumentInfo orderId = new OrderDocumentInfo();
		orderId.setLocation(csiResponseKeys.getOrderId().getLocation());
		orderId.setActivity(csiResponseKeys.getOrderId().getActivity());
		orderId.setOrderId(new BigInteger(csiResponseKeys.getOrderId().getOrderId()));
		
		Cancel3PPOrderRequestInfo cancel3PPOrderRequestInfo = new Cancel3PPOrderRequestInfo();
		cancel3PPOrderRequestInfo.setOrderId(orderId);
		cancel3PPOrderRequestInfo.setReasonCode(csiResponseKeys.getReasonCode());
		cancel3PPOrderRequestInfo.setComment(csiResponseKeys.getComment());
		
		Cancel3PPOrderResponseInfo cancel3PPOrderResponseInfo = null;
		
		try{
			
			cancel3PPOrderResponseInfo = cancel3PPOrderPortType.cancel3PPOrder(messageHeader, cancel3PPOrderRequestInfo);			
			//TODO Need to persist response
			
			//Pass the Response code information
			webServiceResponseData.setCsiResponsecode(cancel3PPOrderResponseInfo.getResponse().getCode());
			webServiceResponseData.setCsiResponsedesc(cancel3PPOrderResponseInfo.getResponse().getDescription());	
			webServiceResponseData.setSkuStatus("S");
			
		} catch (CSIApplicationException csiae){
			
			cancelOrderNotificationLog.info(methodName + "Add3PPOrderNotes Web Service call Failed!");
			cancelOrderNotificationLog.info(methodName + "Error Code: " + csiae.getFaultInfo().getResponse().getCode());
			cancelOrderNotificationLog.info(methodName + "Error Description: " + csiae.getFaultInfo().getResponse().getDescription());
			cancelOrderNotificationLog.info(methodName + "Error Message: " + csiae.getMessage());
			
			webServiceResponseData.setSkuStatus("F");
			webServiceResponseData.setCsiResponsecode(csiae.getFaultInfo().getResponse().getCode());
			webServiceResponseData.setCsiResponsedesc(csiae.getFaultInfo().getResponse().getDescription());
			webServiceResponseData.setErrorMessage(csiae.getMessage());
			
			//throw csiae;
		} catch (Exception e){
			cancelOrderNotificationLog.info(methodName + "Exception :: Error Message: " + e.getMessage());
			webServiceResponseData.setSkuStatus("F");
			webServiceResponseData.setCsiResponsecode("900");
			webServiceResponseData.setCsiResponsedesc("Exception thrown in Add3PPOrderNotes Response");
			webServiceResponseData.setErrorMessage(e.getMessage());
		}
		
		cancelOrderNotificationLog.info(methodName + "Add3PPOrderNotes Web Service call completed with Success!");
		cancelOrderNotificationLog.info(methodName + "Add3PPOrderNotes Web Service call made with OrderId: " + csiResponseKeys.getConcatOrderID());
		
		return webServiceResponseData;
		
	}

	@Override
	public WebServiceResponseData invokeCancelOrder(String requestXML,
			String eventType, String methodName,
			WebServiceResponseData webServiceResponseData,
			CSIServiceMessageParser csiMessageParser)
			throws CSIApplicationException, Exception {
		try {
			
			cancelOrderNotificationLog.info(methodName + "Invoking cancel3PPOrder Web Service");
			CSIResponseKeys csiResponseKeys = csiMessageParser.parseCancelOrder(requestXML, eventType);
			webServiceResponseData = doCancel3PPOrderRequest(csiResponseKeys, requestXML);				
			cancelOrderNotificationLog.info(methodName + "Completed invoking cancel3PPOrder Web Service");
			
		} catch (CSIApplicationException csiApplicationException){
			
			cancelOrderNotificationLog.info(methodName + "Exception occured when invoking cancel3PPOrder Web Service");
			cancelOrderNotificationLog.info(methodName + "Error Code: " + csiApplicationException.getFaultInfo().getResponse().getCode());
			cancelOrderNotificationLog.info(methodName + "Error Description: "  + csiApplicationException.getFaultInfo().getResponse().getDescription());
			cancelOrderNotificationLog.info(methodName + "Error Message: " + csiApplicationException.getMessage());
			//result = csiApplicationException.getFaultInfo().getResponse().getCode() + " - " + csiApplicationException.getFaultInfo().getResponse().getDescription() + "-" + csiApplicationException.getMessage();
			//throw csiApplicationException;				
		} 
		return webServiceResponseData;
	}

}