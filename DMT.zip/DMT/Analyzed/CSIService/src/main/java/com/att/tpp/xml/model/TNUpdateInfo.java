package com.att.tpp.xml.model;

public class TNUpdateInfo {

    private TNAddress femtocellAddress;
    private TNInfo femtocellAdditionalInfo;
    
    /**
	 * @param femtocellAddress
	 * @param femtocellAdditionalInfo
	 */
	public TNUpdateInfo(TNAddress femtocellAddress,
			TNInfo femtocellAdditionalInfo) {
		this.femtocellAddress = femtocellAddress;
		this.femtocellAdditionalInfo = femtocellAdditionalInfo;
	}

	/**
     * Gets the value of the femtocellAddress property.
     * 
     * @return
     *     possible object is
     *     {@link TNAddress }
     *     
     */
    public TNAddress getFemtocellAddress() {
        return femtocellAddress;
    }

    /**
     * Sets the value of the femtocellAddress property.
     * 
     * @param femtocellAddress
     *     allowed object is
     *     {@link TNAddress }
     *     
     */
    public void setFemtocellAddress(TNAddress femtocellAddress) {
        this.femtocellAddress = femtocellAddress;
    }

    /**
     * Gets the value of the femtocellAdditionalInfo property.
     * 
     * @return
     *     possible object is
     *     {@link TNInfo }
     *     
     */
    public TNInfo getFemtocellAdditionalInfo() {
        return femtocellAdditionalInfo;
    }

    /**
     * Sets the value of the femtocellAdditionalInfo property.
     * 
     * @param femtocellAdditionalInfo
     *     allowed object is
     *     {@link TNInfo }
     *     
     */
    public void setFemtocellAdditionalInfo(TNInfo femtocellAdditionalInfo) {
        this.femtocellAdditionalInfo = femtocellAdditionalInfo;
    }

}
