package com.att.tpp.xml.model;

public class Equipment {

	private Device device;
	private SIM sim;
	
	/**
	 * @param device
	 */
	public Equipment(Device device) {
		this.device = device;
	}

	/**
	 * @param device
	 * @param sim
	 */
	public Equipment(Device device, SIM sim) {
		this.device = device;
		this.sim = sim;
	}

	/**
	 * @return the device
	 */
	public Device getDevice() {
		return device;
	}
	
	/**
	 * @param device the device to set
	 */
	public void setDevice(Device device) {
		this.device = device;
	}
	
	/**
	 * @return the sim
	 */
	public SIM getSim() {
		return sim;
	}
	
	/**
	 * @param sim the sim to set
	 */
	public void setSim(SIM sim) {
		this.sim = sim;
	}
	
	


}
