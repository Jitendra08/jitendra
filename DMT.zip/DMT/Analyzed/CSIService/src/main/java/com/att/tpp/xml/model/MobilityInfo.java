package com.att.tpp.xml.model;

public class MobilityInfo {

    private String msisdn;
    private String subscriberID;

    /**
	 * @param msisdn
	 * @param subscriberID
	 */
	public MobilityInfo(String msisdn, String subscriberID) {
		this.msisdn = msisdn;
		this.subscriberID = subscriberID;
	}

	/**
     * Gets the value of the msisdn property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getMSISDN() {
        return msisdn;
    }

    /**
     * Sets the value of the msisdn property.
     * 
     * @param msisdn
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setMSISDN(String msisdn) {
        this.msisdn = msisdn;
    }

    /**
     * Gets the value of the subscriberID property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getSubscriberID() {
        return subscriberID;
    }

    /**
     * Sets the value of the subscriberID property.
     * 
     * @param subscriberID
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setSubscriberID(String subscriberID) {
        this.subscriberID = subscriberID;
    }

}
