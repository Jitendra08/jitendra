package com.att.tpp.ws;

import java.sql.Timestamp;
import java.util.Date;
import java.util.Iterator;
import java.util.List;

import javax.xml.ws.Holder;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.att.tpp.enumuration.CSIEventType;
import com.att.tpp.model.CSIResponseKeys;
import com.att.tpp.model.WebServiceResponseData;
import com.att.tpp.service.CSIService;
import com.att.tpp.utils.CSIServiceMessageParser;
import com.att.tpp.utils.CSITransactionIDGenerator;
import com.cingular.csi.csi.namespaces.container._public.managemobileproductsprovisioningrequest.ManageMobileProductsProvisioningRequestInfo;
import com.cingular.csi.csi.namespaces.container._public.managemobileproductsprovisioningrequest.ManageMobileProductsProvisioningRequestInfo.Product;
import com.cingular.csi.csi.namespaces.container._public.managemobileproductsprovisioningresponse.ManageMobileProductsProvisioningResponseInfo;
import com.cingular.csi.csi.namespaces.types._public.cingulardatamodel.CustomerCredentialInfo;
import com.cingular.csi.csi.namespaces.types._public.messageheader.MessageHeaderInfo;
import com.cingular.csi.csi.namespaces.v118.wsdl.cingularwirelesscsi.CSIApplicationException;
import com.cingular.csi.csi.namespaces.v118.wsdl.cingularwirelesscsi.ManageMobileProductsProvisioningPortType;

@Service("manageMobileProductsProvisioning")
public class ManageMobileProductsProvisioningImpl implements
		ManageMobileProductsProvisioning {
	
	private static final String methodName = "[doManageMobileProductsProvisioning] ";
	
	private static final String MODE = "PROVISIONING_RESPONSE";
	private static final String CREDENTIAL_TYPE = "MSISDN";

	private static Logger manageMobileProductsProvisioningLog = Logger.getLogger(ManageMobileProductsProvisioningImpl.class);
	
	@Autowired
	private CSIMessageHeaderService csiMessageHeaderService;
	
	@Autowired
	private CSIService csiService;
	
		
	@Autowired
	private ManageMobileProductsProvisioningPortType manageMobileProductsProvisioningPortType;	

	@Override
	public WebServiceResponseData doManageMobileProductsProvisioning(
			CSIResponseKeys csiResponseKeys, String requestXML, String provSystemTransId) throws CSIApplicationException,
			Exception {
		
		manageMobileProductsProvisioningLog.info(methodName + "Executing ManageMobileProductsProvisioning");
		
		//Generating Message Header
		Holder<MessageHeaderInfo> messageHeader = null;
		String csiTransactionId = null;
		CSITransactionIDGenerator csiIDGen = new CSITransactionIDGenerator();
		/* Below line commented and added code below for DCM flow the csiTransactionId should be original Transaction Id sent by CSI in DCM Notification xml  */
		//csiTransactionId = csiIDGen.generateCSITransactionId("");  //passing blank to get generated transactionId for CSI Service call	

		manageMobileProductsProvisioningLog.info("doManageMobileProductsProvisioning outside check :: csiTransactionId: " + csiResponseKeys.getTppCSITransactionID());
		if(provSystemTransId==null || provSystemTransId.equals(""))
		{
			manageMobileProductsProvisioningLog.info("doManageMobileProductsProvisioning inside null :: provSystemTransId: " + provSystemTransId);
			csiTransactionId = csiIDGen.generateCSITransactionId(""); //passing blank to get generated transactionId for CSI Service call
		}else{
			csiTransactionId=provSystemTransId;
			manageMobileProductsProvisioningLog.info("doManageMobileProductsProvisioning inside else :: provSystemTransId: " + provSystemTransId);
		}
		manageMobileProductsProvisioningLog.info("doManageMobileProductsProvisioning csiTransactionId: " + csiTransactionId);
		//Generate the WebresponseData.
		WebServiceResponseData webServiceResponseData = new WebServiceResponseData();
		webServiceResponseData.setTppcsiTransactionid(csiTransactionId);			
		webServiceResponseData.setTppTransactionid(csiResponseKeys.getMessageTransactionID());
		webServiceResponseData.setInputXml(requestXML);
		webServiceResponseData.setCarrierName(csiResponseKeys.getProvisioningCarrier());
		webServiceResponseData.setRoutingCarrier(csiResponseKeys.getRoutingCarrier());
		webServiceResponseData.setInterfaceName(CSIEventType.DCMNotification.toString());
		Date date = new Date();			
		webServiceResponseData.setTimeStamp(new Timestamp(date.getTime()));
		
		try {
			
			messageHeader = csiMessageHeaderService.generateCSIMessageHeader(csiTransactionId);
			
		} catch (Exception e) {
			
			manageMobileProductsProvisioningLog.info(methodName + "Exception occured while generating CSIMessageHeader, MessageId: " + csiTransactionId);			
			e.printStackTrace();
			throw e;
		}
		
		//Create Web Service request
		CustomerCredentialInfo customerCredentialInfo = new CustomerCredentialInfo();
		customerCredentialInfo.setCredentialType(CREDENTIAL_TYPE);  
		customerCredentialInfo.setCredentialId(csiResponseKeys.getMsisdn());
		
		ManageMobileProductsProvisioningRequestInfo manageMobileProductsProvisioningRequestInfo = new ManageMobileProductsProvisioningRequestInfo();
		manageMobileProductsProvisioningRequestInfo.setMode(MODE);
		
		
		manageMobileProductsProvisioningRequestInfo.setAction(csiResponseKeys.getAction());		
		manageMobileProductsProvisioningRequestInfo.setCustomerCredentials(customerCredentialInfo);	
		
		/* Modified below codes to support multiple product id */
		//List<Product> product = csiResponseKeys.getProduct();
		//manageMobileProductsProvisioningRequestInfo.getProduct().add(product);
		
	//	manageMobileProductsProvisioningLog.info("ProductId from response :"+product.getId());
		
		//get product id from the featurecode ref
	//	String iPid = csiService.getProductId(product.getId());
	//	manageMobileProductsProvisioningLog.info("Ipid for the response :"+iPid);
		
		//Overriding with iPid
		/* Added below iPid not null check to handle invalid IPID transaction from CSICollectorService */ 		
	//	if(iPid!=null){
			/* iPid from featureCodeRef table aka valid IPID */
	//		product.setId(iPid);
	//	}else{
			/* iPid from ABSResponse xml aka invalid IPID */
	//		product.setId(product.getId());
	//	}
		//List<Product> productList = csiResponseKeys.getProduct();
		
		List<Product> productList = manageMobileProductsProvisioningRequestInfo.getProduct();
		
		manageMobileProductsProvisioningLog.info("Inital productList >>>"+productList.size());
		
		List<Product> listProduct = csiResponseKeys.getProduct();
		
		manageMobileProductsProvisioningLog.info("parser productList >>>"+listProduct.size());
		
		Iterator<Product> prodIterator = listProduct.iterator();
		while(prodIterator.hasNext())
		{
				Product product = prodIterator.next();
				String iPid = csiService.getProductId(product.getId());
				if(iPid!=null){
					product.setId(iPid);
				}else{
					product.setId(product.getId());
				}
				productList.add(product);
		}
		manageMobileProductsProvisioningLog.info("final productList >>>"+productList.size());
		//manageMobileProductsProvisioningRequestInfo.getProduct().addAll(productList);
		
		ManageMobileProductsProvisioningResponseInfo manageMobileProductsProvisioningResponseInfo = null;
		
		//TODO populate WebServiceResponseData with the response info and other needed items from CSIResponseKeys.
		
		try{
			
			manageMobileProductsProvisioningResponseInfo = manageMobileProductsProvisioningPortType.manageMobileProductsProvisioning(messageHeader, manageMobileProductsProvisioningRequestInfo);
			
			//Pass the Response code information
			webServiceResponseData.setCsiResponsecode(manageMobileProductsProvisioningResponseInfo.getResponse().getCode());
			webServiceResponseData.setCsiResponsedesc(manageMobileProductsProvisioningResponseInfo.getResponse().getDescription());	
			webServiceResponseData.setSkuStatus("S");
			
			//TODO Need to persist response
			
		} catch (CSIApplicationException csiApplicationException){
			
			manageMobileProductsProvisioningLog.info(methodName + "ManageMobileProductsProvisioning Web Service call Failed!");
			manageMobileProductsProvisioningLog.info(methodName + "Error Code: " + csiApplicationException.getFaultInfo().getResponse().getCode());
			manageMobileProductsProvisioningLog.info(methodName + "Error Description: " + csiApplicationException.getFaultInfo().getResponse().getDescription());
			manageMobileProductsProvisioningLog.info(methodName + "Error Message: " + csiApplicationException.getMessage());
			
			webServiceResponseData.setSkuStatus("F");
			webServiceResponseData.setCsiResponsecode(csiApplicationException.getFaultInfo().getResponse().getCode());
			webServiceResponseData.setCsiResponsedesc(csiApplicationException.getFaultInfo().getResponse().getDescription());
			webServiceResponseData.setErrorMessage(csiApplicationException.getMessage());
		} catch (Exception e){
			manageMobileProductsProvisioningLog.info(methodName + "Exception :: Error Message: " + e.getMessage());
			webServiceResponseData.setSkuStatus("F");
			webServiceResponseData.setCsiResponsecode("900");
			webServiceResponseData.setCsiResponsedesc("Exception thrown in ManageMobileProductsProvisioning Response");
			webServiceResponseData.setErrorMessage(e.getMessage());
		}
		
		//manageMobileProductsProvisioningLog.info(methodName + "ManageMobileProductsProvisioning Web Service call completed with Success!");
		manageMobileProductsProvisioningLog.info(methodName + "ManageMobileProductsProvisioning Web Service call made with MSISDN: " + csiResponseKeys.getMsisdn());
		manageMobileProductsProvisioningLog.info(methodName + "ManageMobileProductsProvisioning Web Service call made with MessageID: " + csiTransactionId);
		
		return webServiceResponseData;
	}

	@Override
	public WebServiceResponseData invokeDCMNotification(String requestXML,
			String eventType, String methodName,
			WebServiceResponseData webServiceResponseData,
			CSIServiceMessageParser csiMessageParser, String provSystemTransId) throws Exception,
			CSIApplicationException {
		try{
			
			manageMobileProductsProvisioningLog.info(methodName + "Invoking ManageMobileProductsProvisioning Web Service");				
			CSIResponseKeys csiResponseKeys = csiMessageParser.parseManageMobileProductsProvisioning(requestXML, eventType);						
			webServiceResponseData = doManageMobileProductsProvisioning(csiResponseKeys, requestXML,provSystemTransId);
			manageMobileProductsProvisioningLog.info(methodName + "Completed invoking ManageMobileProductsProvisioning Web Service");
			
		} catch (CSIApplicationException csiApplicationException){
									
			manageMobileProductsProvisioningLog.info(methodName + "Exception occured when invoking ManageMobileProductsProvisioning Web Service");
			manageMobileProductsProvisioningLog.info(methodName + "Error Code: " + csiApplicationException.getFaultInfo().getResponse().getCode());
			manageMobileProductsProvisioningLog.info(methodName + "Error Description: "  + csiApplicationException.getFaultInfo().getResponse().getDescription());
			manageMobileProductsProvisioningLog.info(methodName + "Error Message: " + csiApplicationException.getMessage());
			//throw csiApplicationException;					
		}
		return webServiceResponseData;
	}
	

}
