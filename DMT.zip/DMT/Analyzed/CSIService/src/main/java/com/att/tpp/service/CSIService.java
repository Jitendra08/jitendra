/**
 * 
 */
package com.att.tpp.service;

import java.io.IOException;
import java.util.List;

import com.att.tpp.jms.listener.OtherProperties;
import com.att.tpp.model.CSIResponseKeys;
import com.att.tpp.model.CSIRetryErrors;
import com.att.tpp.model.CsiTimer;
import com.att.tpp.model.RetryConfiguration;
import com.att.tpp.model.TransCode;
import com.att.tpp.model.WebServiceResponseData;
import com.cingular.csi.csi.namespaces.v118.wsdl.cingularwirelesscsi.CSIApplicationException;

/**
 * @author SC9833
 *
 */
public interface CSIService {
//	
//	all responses that require CSI soap calls go to %%ProvisionJMS/CSIRequestQueue%%
//	All Response XML that go to CSI is the same as what partner responds with.
//
//	Leverage the JMS Other Properties eventName attribute with the following values:
//	eventName IN ('Echo', 'AddOrderNotes', 'AddOrderShipment', 'CancelOrder', 'AddNote', 'NotifyFemtocellAction', 'SendSMS', 'SendEmail', 'DCMNotification')
//
//	Log the XML
//
//	Start the process
//
//	For response flow you need to leverage generate CSI Transaction activity
//	{if (transId == "" || transId.length() <= 0 )
//	csiTransactionId = "3PP_" + Long.toHexString(System.currentTimeMillis()) + Long.toString(new Random().nextLong());
//	else
//	csiTransactionId = transId;}
//
//	assign generated transactionID to the model that will be sent to be processed by the appropriate csi web service call
//	(The model consists XML, generatedTransactionID, eventName, (TBD)Prov_Req_TrxID (= otherProperties/swcTransactionId))
//	Depending on the eventName the specific csi web service is called.
	
	boolean validateXML(String requestXML, String xsdName, boolean isSKU) throws IOException, Exception;
	
	boolean validateEvent(String requestXML, String eventType) throws IOException, Exception;
	
	WebServiceResponseData invokeCSIWebService(OtherProperties otherProperties) throws CSIApplicationException, Exception;

	CSIResponseKeys generateCSIResponseKeys(String requestXML, String eventType);

	boolean insertCSIMessageArchive(com.att.tpp.model.CSI_MESSAGE_ARCHIVE csiMessageArchive) throws Exception;

	List<CSIRetryErrors> getCSIRetryError() throws Exception;

	List<CsiTimer> getCSITimerRecord(String tppcsiTransactionid) throws Exception;

	boolean insertCSITimerData(CsiTimer csiTimer) throws Exception;
	
	boolean deleteFromTimer(String taskTransId) throws Exception; /* FIX for WR# 2738943- Multiple Retry of  SKU provisioning request after 200-OK and AddOrderNotes response received */
	
	boolean deleteFromCSITimer(String masterTransId) throws Exception;

	List<RetryConfiguration> getRetryConfiguration(String systemName) throws Exception;

	String getSystemName(String tppTransactionid) throws Exception;

	String getProductId(String id) throws Exception;

	boolean findFulfillmentIndicator(String vendorName) throws Exception;

	void loadInitialData();

	boolean insertTranscode(TransCode transCode);

	boolean generateAndSendErrorRequest(String messageId, String masterTransId) throws IOException, Exception;

	TransCode generateTransCode(String masterTransId,
			CSIResponseKeys csiResponseKeys, String actionFemto);
	
		
	
	//TPPProvisioningRequest invokeCSIWebService(String csiDips, String requestXML,  CSIDipKeys csiDipKeys) throws Exception;

	//boolean persistDipResults(CSIDipKeys csiDipKeys, String eventName, String errorCode,	String errorDesc) throws ParseException;

	//String getCTNFromMsidn(String msisdn);

	//String createTPPProvReqXML(TPPProvisioningRequest tppProvisioningRequest)throws Exception ;

}
