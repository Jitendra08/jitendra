package com.att.tpp.xml.model;

public class NameInfo {

    private String namePrefix;
    private String firstName;
    private String middleName;
    private String lastName;
    private String nameSuffix;
    private String additionalTitle;

    /**
	 * @param namePrefix
	 * @param firstName
	 * @param middleName
	 * @param lastName
	 * @param nameSuffix
	 * @param additionalTitle
	 */
	public NameInfo(String namePrefix, String firstName, String middleName,
			String lastName, String nameSuffix, String additionalTitle) {
		this.namePrefix = namePrefix;
		this.firstName = firstName;
		this.middleName = middleName;
		this.lastName = lastName;
		this.nameSuffix = nameSuffix;
		this.additionalTitle = additionalTitle;
	}

	/**
     * Gets the value of the namePrefix property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getNamePrefix() {
        return namePrefix;
    }

    /**
     * Sets the value of the namePrefix property.
     * 
     * @param namePrefix
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setNamePrefix(String namePrefix) {
        this.namePrefix = namePrefix;
    }

    /**
     * Gets the value of the firstName property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getFirstName() {
        return firstName;
    }

    /**
     * Sets the value of the firstName property.
     * 
     * @param firstName
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setFirstName(String firstName) {
        this.firstName = firstName;
    }

    /**
     * Gets the value of the middleName property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getMiddleName() {
        return middleName;
    }

    /**
     * Sets the value of the middleName property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setMiddleName(String middleName) {
        this.middleName = middleName;
    }

    /**
     * Gets the value of the lastName property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getLastName() {
        return lastName;
    }

    /**
     * Sets the value of the lastName property.
     * 
     * @param lastName
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setLastName(String lastName) {
        this.lastName = lastName;
    }

    /**
     * Gets the value of the nameSuffix property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getNameSuffix() {
        return nameSuffix;
    }

    /**
     * Sets the value of the nameSuffix property.
     * 
     * @param nameSuffix
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setNameSuffix(String nameSuffix) {
        this.nameSuffix = nameSuffix;
    }

    /**
     * Gets the value of the additionalTitle property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getAdditionalTitle() {
        return additionalTitle;
    }

    /**
     * Sets the value of the additionalTitle property.
     * 
     * @param additionalTitle
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setAdditionalTitle(String additionalTitle) {
        this.additionalTitle = additionalTitle;
    }

}
