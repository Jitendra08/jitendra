
package com.att.tpp.jms.listener;

import javax.annotation.PostConstruct;
import javax.jms.JMSException;
import javax.jms.Message;
import javax.jms.MessageListener;
import javax.jms.TextMessage;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;



import com.att.tpp.controller.CSIController;
import com.att.tpp.enumuration.CSIEventType;
import com.att.tpp.jms.sender.ArchiveRequestSender;
import com.att.tpp.jms.sender.CommunicationRequestSender;
import com.att.tpp.model.ProcessingResult;

/**
 * Class handles  SWC incoming messages
 */
@Service
public class CSIRequestListener implements MessageListener
{
	private static final Logger csiRequestListenerLog = Logger.getLogger(CSIRequestListener.class);
	
	@Autowired
	private ArchiveRequestSender archiveRequestSender;  
	
	@Autowired
	private CommunicationRequestSender communicationRequestSender;  
	
	@Autowired
	private CSIController csiController;
	
	@PostConstruct
	public void initIt() throws Exception {
		csiRequestListenerLog.info("Setting Initial Configurations: Started. It will take few minutes.");
		csiController.loadInitialData();
		csiRequestListenerLog.info("Setting Initial Configurations: Completed");
	}


	/**
	 * Method implements JMS onMessage and acts as the entry
	 * point for messages consumed by Springs DefaultMessageListenerContainer.
	 * When DefaultMessageListenerContainer picks a message from the queue it
	 * invokes this method with the message payload.
	 */
	public void onMessage(Message csiReqMsg)
	{
		csiRequestListenerLog.debug("Received message from DataAugmentation Request Queue [" + csiReqMsg +"]");

		/* The message must be of type TextMessage */
		if (csiReqMsg instanceof TextMessage)			
		{
			ProcessingResult processingResult =  new ProcessingResult();
			try
			{
				OtherProperties otherProperties  = new  OtherProperties();
				String csiRequestXML = ((TextMessage) csiReqMsg).getText();
				csiRequestListenerLog.info("CSI request XML received: " + csiRequestXML);
				
				//Send request to Augment the XML payload of this message
				String eventType = csiReqMsg.getStringProperty("eventName");  //Get the CSI DIPS requested for this message				
				//String eventType = CSIEventType.NotifySmallcellAction.toString();
				//String csiDips = dataAugReqMsg.getStringProperty("eventName");  //Get the CSI DIPS requested for this message	
				
				if(eventType!=null && eventType.length() > 0){
				
					csiRequestListenerLog.info("CSI Event Type : " + eventType);
					csiRequestListenerLog.info("CSI Transaction ID:"+csiReqMsg.getStringProperty("csiTransactionId"));
					otherProperties.setTransactionId(csiReqMsg.getStringProperty("csiTransactionId"));
					otherProperties.setEventType(eventType.trim());
					otherProperties.setRequestXML(csiRequestXML.trim());
					
					if(eventType.equals(CSIEventType.NotifyFemtocellAction.toString())){
				     String actionFemtocell = csiReqMsg.getStringProperty("ActionCode");
					otherProperties.setActionFemto(actionFemtocell.trim());
				      String masterTransId = csiReqMsg.getStringProperty("csiTransactionId");  //Get the csiTransactionId from the transaction service as masterTransId						
						otherProperties.setMasterTransId(masterTransId.trim());						
					}
					//Need to capture transactionID sent from CSI for FemtoCell Response Call back to CSI!!!!!!!
					else if(eventType.equals(CSIEventType.NotifyMetrocellAction.toString())){
						String actionMetrocell = csiReqMsg.getStringProperty("ActionCode");
						otherProperties.setActionFemto(actionMetrocell.trim());
						String masterTransId = csiReqMsg.getStringProperty("csiTransactionId");  //Get the csiTransactionId from the transaction service as masterTransId
						otherProperties.setMasterTransId(masterTransId.trim());						
					}
					//Need to capture transactionID sent from CSI for MetroCell Response Call back to CSI!!!!!!!
					else if(eventType.equals(CSIEventType.NotifySmallcellAction.toString())){
						String actionSmallcell = csiReqMsg.getStringProperty("ActionCode");						
						otherProperties.setActionFemto(actionSmallcell.trim());
						String masterTransId = csiReqMsg.getStringProperty("csiTransactionId");  //Get the csiTransactionId from the transaction service as masterTransId						
						otherProperties.setMasterTransId(masterTransId.trim());						
					}
					//Need to capture transactionID sent from CSI for SmallCell Response Call back to CSI!!!!!!!
										
					processingResult = csiController.processRequest(otherProperties);
					csiRequestListenerLog.info("TransacationId: " + processingResult.getTransactionId());
					
					if (processingResult.isValidArchive() && processingResult.getArchiveRequestXML().length()>0){
						archiveRequestSender.sendMessage(processingResult);
						csiRequestListenerLog.info("Sent request to Archive queue, ProvSystemTransId "+processingResult.getTransactionId());
					}else if(processingResult.isFulfillmentValidXML() && processingResult.getFulfillmentValidationXML().length() > 0){
						communicationRequestSender.sendMessage(processingResult);
						csiRequestListenerLog.info("Sent request to Communication queue, ProvSystemTransId "+processingResult.getTransactionId());
					}
				}else{
					csiRequestListenerLog.info("eventType is empty, no action to be taken in the CSI service");
				}

			}
			catch (JMSException jmsExc)
			{
				String errMsg = "An error occurred extracting Response message";
				csiRequestListenerLog.error(errMsg, jmsExc);
			} catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		else
		{
			String errMsg = "Response Message is not of expected type TextMessage";
			csiRequestListenerLog.error(errMsg);
			throw new RuntimeException(errMsg);
		}
	}


	public void setArchiveRequestSender(ArchiveRequestSender archiveRequestSender) {
		this.archiveRequestSender = archiveRequestSender;
	}


	public void setCommunicationRequestSender(
			CommunicationRequestSender communicationRequestSender) {
		this.communicationRequestSender = communicationRequestSender;
	}


	
}