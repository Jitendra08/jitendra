package com.att.tpp.model;

import java.io.Serializable;
import javax.persistence.*;
import java.math.BigDecimal;


/**
 * The persistent class for the PROVISIONING_TASKS database table.
 * 
 */
@Entity
@Table(name="PROVISIONING_TASKS")
@NamedQuery(name="ProvisioningTask.findAll", query="SELECT p FROM ProvisioningTask p")
public class ProvisioningTask implements Serializable {
	private static final long serialVersionUID = 1L;

	@EmbeddedId
	private ProvisioningTaskPK id;

	@Column(name="CURR_NO_RESP_RETRY_COUNT")
	private BigDecimal currNoRespRetryCount;

	@Column(name="CURR_TECH_RETRY_COUNT")
	private BigDecimal currTechRetryCount;

	@Column(name="MAX_NO_RESP_RETRY_COUNT")
	private BigDecimal maxNoRespRetryCount;

	@Column(name="MAX_TECH_RETRY_COUNT")
	private BigDecimal maxTechRetryCount;

	@Column(name="NOTIFICATION_URL")
	private String notificationUrl;

	@Column(name="POST_COUNT")
	private BigDecimal postCount;

	@Column(name="RETRY_CYCLE_COUNT")
	private BigDecimal retryCycleCount;

	@Column(name="SOLN_INDEX")
	private BigDecimal solnIndex;

	@Column(name="SYSTEM_NAME")
	private String systemName;

	@Column(name="SYSTEM_URI")
	private String systemUri;

	@Column(name="TASK_STATUS")
	private String taskStatus;

	public ProvisioningTask() {
	}

	public ProvisioningTaskPK getId() {
		return this.id;
	}

	public void setId(ProvisioningTaskPK id) {
		this.id = id;
	}

	public BigDecimal getCurrNoRespRetryCount() {
		return this.currNoRespRetryCount;
	}

	public void setCurrNoRespRetryCount(BigDecimal currNoRespRetryCount) {
		this.currNoRespRetryCount = currNoRespRetryCount;
	}

	public BigDecimal getCurrTechRetryCount() {
		return this.currTechRetryCount;
	}

	public void setCurrTechRetryCount(BigDecimal currTechRetryCount) {
		this.currTechRetryCount = currTechRetryCount;
	}

	public BigDecimal getMaxNoRespRetryCount() {
		return this.maxNoRespRetryCount;
	}

	public void setMaxNoRespRetryCount(BigDecimal maxNoRespRetryCount) {
		this.maxNoRespRetryCount = maxNoRespRetryCount;
	}

	public BigDecimal getMaxTechRetryCount() {
		return this.maxTechRetryCount;
	}

	public void setMaxTechRetryCount(BigDecimal maxTechRetryCount) {
		this.maxTechRetryCount = maxTechRetryCount;
	}

	public String getNotificationUrl() {
		return this.notificationUrl;
	}

	public void setNotificationUrl(String notificationUrl) {
		this.notificationUrl = notificationUrl;
	}

	public BigDecimal getPostCount() {
		return this.postCount;
	}

	public void setPostCount(BigDecimal postCount) {
		this.postCount = postCount;
	}

	public BigDecimal getRetryCycleCount() {
		return this.retryCycleCount;
	}

	public void setRetryCycleCount(BigDecimal retryCycleCount) {
		this.retryCycleCount = retryCycleCount;
	}

	public BigDecimal getSolnIndex() {
		return this.solnIndex;
	}

	public void setSolnIndex(BigDecimal solnIndex) {
		this.solnIndex = solnIndex;
	}

	public String getSystemName() {
		return this.systemName;
	}

	public void setSystemName(String systemName) {
		this.systemName = systemName;
	}

	public String getSystemUri() {
		return this.systemUri;
	}

	public void setSystemUri(String systemUri) {
		this.systemUri = systemUri;
	}

	public String getTaskStatus() {
		return this.taskStatus;
	}

	public void setTaskStatus(String taskStatus) {
		this.taskStatus = taskStatus;
	}

}