package com.att.tpp.xml.model;

public class DealerInfo {

    private String code;
    private String secondaryCode;

    /**
	 * @param code
	 */
	public DealerInfo(String code) {
		this.code = code;
	}

	/**
	 * @param code
	 * @param secondaryCode
	 */
	public DealerInfo(String code, String secondaryCode) {
		this.code = code;
		this.secondaryCode = secondaryCode;
	}

	/**
     * Gets the value of the code property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCode() {
        return code;
    }

    /**
     * Sets the value of the code property.
     * 
     * @param code
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCode(String code) {
        this.code = code;
    }

    /**
     * Gets the value of the secondaryCode property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getSecondaryCode() {
        return secondaryCode;
    }

    /**
     * Sets the value of the secondaryCode property.
     * 
     * @param secondaryCode
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setSecondaryCode(String secondaryCode) {
        this.secondaryCode = secondaryCode;
    }

}
