package com.att.tpp.xml.model;

public class AddressTwoLineSimpleInfo {

    private String attention;
    private String addressLine1;
    private String addressLine2;
    private String city;
    private String state;
    private AddressZipInfo zip;
    private String country;

    /**
	 * @param attention
	 * @param addressLine1
	 * @param addressLine2
	 * @param city
	 * @param state
	 * @param zip
	 * @param country
	 */
	public AddressTwoLineSimpleInfo(String attention, String addressLine1,
			String addressLine2, String city, String state,
			AddressZipInfo zip, String country) {
		this.attention = attention;
		this.addressLine1 = addressLine1;
		this.addressLine2 = addressLine2;
		this.city = city;
		this.state = state;
		this.zip = zip;
		this.country = country;
	}

	/**
     * Gets the value of the attention property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getAttention() {
        return attention;
    }

    /**
     * Sets the value of the attention property.
     * 
     * @param attention
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setAttention(String attention) {
        this.attention = attention;
    }

    /**
     * Gets the value of the addressLine1 property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getAddressLine1() {
        return addressLine1;
    }

    /**
     * Sets the value of the addressLine1 property.
     * 
     * @param addressLine1
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setAddressLine1(String addressLine1) {
        this.addressLine1 = addressLine1;
    }

    /**
     * Gets the value of the addressLine2 property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getAddressLine2() {
        return addressLine2;
    }

    /**
     * Sets the value of the addressLine2 property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setAddressLine2(String addressLine2) {
        this.addressLine2 = addressLine2;
    }

    /**
     * Gets the value of the city property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCity() {
        return city;
    }

    /**
     * Sets the value of the city property.
     * 
     * @param city
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCity(String city) {
        this.city = city;
    }

    /**
     * Gets the value of the state property.
     * 
     * @return
     *     possible object is
     *     {@link AddressStateInfo }
     *     
     */
    public String getState() {
        return state;
    }

    /**
     * Sets the value of the state property.
     * 
     * @param state
     *     allowed object is
     *     {@link AddressStateInfo }
     *     
     */
    public void setState(String state) {
        this.state = state;
    }

    /**
     * Gets the value of the zip property.
     * 
     * @return
     *     possible object is
     *     {@link AddressZipInfo }
     *     
     */
    public AddressZipInfo getZip() {
        return zip;
    }

    /**
     * Sets the value of the zip property.
     * 
     * @param zip
     *     allowed object is
     *     {@link AddressZipInfo }
     *     
     */
    public void setZip(AddressZipInfo zip) {
        this.zip = zip;
    }

    /**
     * Gets the value of the country property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCountry() {
        return country;
    }

    /**
     * Sets the value of the country property.
     * 
     * @param country
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCountry(String country) {
        this.country = country;
    }

}
