package com.att.tpp.enumuration;

public enum CSIEventType {
	Echo,
	AddOrderNotes,
	AddOrderShipment,
	CancelOrder,
	AddNote,
	NotifyFemtocellAction,
	NotifyMetrocellAction,
	NotifySmallcellAction,
	SendSMS,
	SendEmail,
	DCMNotification,
	FulfillmentResult
}
