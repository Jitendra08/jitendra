package com.att.tpp.config;

import java.io.Serializable;

public class SystemConfigElement implements Serializable {
	private static final long serialVersionUID = 1L;
	
public String system;
   public String login;
   public String passwd;
   public String bulkInd;
   public String evalFinalRespInd;
   public String nonCriticalInd;
   public String xsltFile;
   public String notifURL;
 
   SystemConfigElement ( String systemX ,
                         String loginX,
                         String passwdX,
                         String bulkIndX,
                         String evalFinalRespIndX,
                         String nonCriticalIndX,
                         String xsltFileX , 
                         String notifURLX ) {
       system  = systemX;
       login = loginX;
       passwd = passwdX;
       bulkInd = bulkIndX;
       evalFinalRespInd = evalFinalRespIndX;
       nonCriticalInd = nonCriticalIndX;
       xsltFile = xsltFileX ;
       notifURL = notifURLX ;
 }
   
   
   
   
   

}
