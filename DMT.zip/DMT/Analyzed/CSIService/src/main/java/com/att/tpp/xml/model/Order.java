package com.att.tpp.xml.model;

import java.util.Collection;

public class Order {

	private Account account;
	private Subscriber subscriber;
	private SubscriberStatusDetailInfo subscriberStatusDetail;
	private Equipment equipment;
	private ServiceInfo serviceInfo;
    private MarketingOptions marketingOptions;
    private BillingAccount billingAccount;
    private FinancialNotificationType financialNotification;
    private TPPSKUOrder tppskuOrder;
    private TNUpdateInfo femtocellTNUpdate;
    private ImmutableKeyInfo immutableKeys;
    private ParentalControlsSettingInfo parentalControlsSettingInfo;
    private AccountTypeInfo accountTypeInfo;
    private SegmentType segmentType;
    private MarketInfo marketInfo;
    private Collection<SalesReps> salesReps;
    private Collection<CustRegContactInfoBASE> custRegContactInfoBASE;
    private CombinedBillingType combinedBilling;
    private EventTypeInfo eventType;
            
	/**
	 * @param account
	 */
	public Order(Account account) {
		this.account = account;
	}
	
	/**
	 * @param account
	 * @param subscriber
	 * @param subscriberStatusDetail
	 * @param equipment
	 * @param serviceInfo
	 * @param marketingOptions
	 * @param billingAccount
	 * @param financialNotification
	 * @param tppskuOrder
	 * @param femtocellTNUpdate
	 * @param immutableKeys
	 * @param parentalControlsSettingInfo
	 * @param accountTypeInfo
	 * @param segmentType
	 * @param marketInfo
	 * @param salesReps
	 * @param custRegContactInfoBASE
	 * @param combinedBilling
	 * @param eventType
	 */
	public Order(Account account, Subscriber subscriber,
			SubscriberStatusDetailInfo subscriberStatusDetail,
			Equipment equipment, 
			ServiceInfo serviceInfo,
			MarketingOptions marketingOptions,
			BillingAccount billingAccount,
			FinancialNotificationType financialNotification,
			TPPSKUOrder tppskuOrder, 
			TNUpdateInfo femtocellTNUpdate,
			ImmutableKeyInfo immutableKeys,
			ParentalControlsSettingInfo parentalControlsSettingInfo,
			AccountTypeInfo accountTypeInfo, 
			SegmentType segmentType,
			MarketInfo marketInfo, 
			Collection<SalesReps> salesReps,
			Collection<CustRegContactInfoBASE> custRegContactInfoBASE,
			CombinedBillingType combinedBilling, 
			EventTypeInfo eventType) {
		this.account = account;
		this.subscriber = subscriber;
		this.subscriberStatusDetail = subscriberStatusDetail;
		this.equipment = equipment;
		this.serviceInfo = serviceInfo;
		this.marketingOptions = marketingOptions;
		this.billingAccount = billingAccount;
		this.financialNotification = financialNotification;
		this.tppskuOrder = tppskuOrder;
		this.femtocellTNUpdate = femtocellTNUpdate;
		this.immutableKeys = immutableKeys;
		this.parentalControlsSettingInfo = parentalControlsSettingInfo;
		this.accountTypeInfo = accountTypeInfo;
		this.segmentType = segmentType;
		this.marketInfo = marketInfo;
		this.salesReps = salesReps;
		this.custRegContactInfoBASE = custRegContactInfoBASE;
		this.combinedBilling = combinedBilling;
		this.eventType = eventType;
	}

	/**
	 * @return the account
	 */
	public Account getAccount() {
		return account;
	}
	
	/**
	 * @param account the account to set
	 */
	public void setAccount(Account account) {
		this.account = account;
	}
	
	/**
	 * @return the subscriber
	 */
	public Subscriber getSubscriber() {
		return subscriber;
	}
	
	/**
	 * @param subscriber the subscriber to set
	 */
	public void setSubscriber(Subscriber subscriber) {
		this.subscriber = subscriber;
	}
	
	/**
	 * @return the subscriberStatusDetail
	 */
	public SubscriberStatusDetailInfo getSubscriberStatusDetail() {
		return subscriberStatusDetail;
	}
	
	/**
	 * @param subscriberStatusDetail the subscriberStatusDetail to set
	 */
	public void setSubscriberStatusDetail(
			SubscriberStatusDetailInfo subscriberStatusDetail) {
		this.subscriberStatusDetail = subscriberStatusDetail;
	}
	
	/**
	 * @return the equipment
	 */
	public Equipment getEquipment() {
		return equipment;
	}
	
	/**
	 * @param equipment the equipment to set
	 */
	public void setEquipment(Equipment equipment) {
		this.equipment = equipment;
	}
	
	/**
	 * @return the serviceInfo
	 */
	public ServiceInfo getServiceInfo() {
		return serviceInfo;
	}
	
	/**
	 * @param serviceInfo the serviceInfo to set
	 */
	public void setServiceInfo(ServiceInfo serviceInfo) {
		this.serviceInfo = serviceInfo;
	}
	
	/**
	 * @return the marketingOptions
	 */
	public MarketingOptions getMarketingOptions() {
		return marketingOptions;
	}
	
	/**
	 * @param marketingOptions the marketingOptions to set
	 */
	public void setMarketingOptions(MarketingOptions marketingOptions) {
		this.marketingOptions = marketingOptions;
	}
	
	/**
	 * @return the billingAccount
	 */
	public BillingAccount getBillingAccount() {
		return billingAccount;
	}
	
	/**
	 * @param billingAccount the billingAccount to set
	 */
	public void setBillingAccount(BillingAccount billingAccount) {
		this.billingAccount = billingAccount;
	}
	
	/**
	 * @return the financialNotification
	 */
	public FinancialNotificationType getFinancialNotification() {
		return financialNotification;
	}
	
	/**
	 * @param financialNotification the financialNotification to set
	 */
	public void setFinancialNotification(
			FinancialNotificationType financialNotification) {
		this.financialNotification = financialNotification;
	}
	
	/**
	 * @return the tppskuOrder
	 */
	public TPPSKUOrder getTppskuOrder() {
		return tppskuOrder;
	}
	
	/**
	 * @param tppskuOrder the tppskuOrder to set
	 */
	public void setTppskuOrder(TPPSKUOrder tppskuOrder) {
		this.tppskuOrder = tppskuOrder;
	}
	
	/**
	 * @return the femtocellTNUpdate
	 */
	public TNUpdateInfo getFemtocellTNUpdate() {
		return femtocellTNUpdate;
	}
	
	/**
	 * @param femtocellTNUpdate the femtocellTNUpdate to set
	 */
	public void setFemtocellTNUpdate(TNUpdateInfo femtocellTNUpdate) {
		this.femtocellTNUpdate = femtocellTNUpdate;
	}
	
	/**
	 * @return the immutableKeys
	 */
	public ImmutableKeyInfo getImmutableKeys() {
		return immutableKeys;
	}
	
	/**
	 * @param immutableKeys the immutableKeys to set
	 */
	public void setImmutableKeys(ImmutableKeyInfo immutableKeys) {
		this.immutableKeys = immutableKeys;
	}
	
	/**
	 * @return the parentalControlsSettingInfo
	 */
	public ParentalControlsSettingInfo getParentalControlsSettingInfo() {
		return parentalControlsSettingInfo;
	}
	
	/**
	 * @param parentalControlsSettingInfo the parentalControlsSettingInfo to set
	 */
	public void setParentalControlsSettingInfo(
			ParentalControlsSettingInfo parentalControlsSettingInfo) {
		this.parentalControlsSettingInfo = parentalControlsSettingInfo;
	}
	
	/**
	 * @return the accountTypeInfo
	 */
	public AccountTypeInfo getAccountTypeInfo() {
		return accountTypeInfo;
	}
	
	/**
	 * @param accountTypeInfo the accountTypeInfo to set
	 */
	public void setAccountTypeInfo(AccountTypeInfo accountTypeInfo) {
		this.accountTypeInfo = accountTypeInfo;
	}
	
	/**
	 * @return the segmentType
	 */
	public SegmentType getSegmentType() {
		return segmentType;
	}
	
	/**
	 * @param segmentType the segmentType to set
	 */
	public void setSegmentType(SegmentType segmentType) {
		this.segmentType = segmentType;
	}
	
	/**
	 * @return the marketInfo
	 */
	public MarketInfo getMarketInfo() {
		return marketInfo;
	}
	
	/**
	 * @param marketInfo the marketInfo to set
	 */
	public void setMarketInfo(MarketInfo marketInfo) {
		this.marketInfo = marketInfo;
	}
	
	/**
	 * @return the salesReps
	 */
	public Collection<SalesReps> getSalesReps() {
		return salesReps;
	}
	
	/**
	 * @param salesReps the salesReps to set
	 */
	public void setSalesReps(Collection<SalesReps> salesReps) {
		this.salesReps = salesReps;
	}
	
	/**
	 * @return the custRegContactInfoBASE
	 */
	public Collection<CustRegContactInfoBASE> getCustRegContactInfoBASE() {
		return custRegContactInfoBASE;
	}
	
	/**
	 * @param custRegContactInfoBASE the custRegContactInfoBASE to set
	 */
	public void setCustRegContactInfoBASE(
			Collection<CustRegContactInfoBASE> custRegContactInfoBASE) {
		this.custRegContactInfoBASE = custRegContactInfoBASE;
	}
	
	/**
	 * @return the combinedBilling
	 */
	public CombinedBillingType getCombinedBilling() {
		return combinedBilling;
	}
	
	/**
	 * @param combinedBilling the combinedBilling to set
	 */
	public void setCombinedBilling(CombinedBillingType combinedBilling) {
		this.combinedBilling = combinedBilling;
	}
	
	/**
	 * @return the eventType
	 */
	public EventTypeInfo getEventType() {
		return eventType;
	}
	
	/**
	 * @param eventType the eventType to set
	 */
	public void setEventType(EventTypeInfo eventType) {
		this.eventType = eventType;
	}
    
}
