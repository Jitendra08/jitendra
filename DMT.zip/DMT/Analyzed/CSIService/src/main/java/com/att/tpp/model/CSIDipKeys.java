/**
 *  This class is to be used to hold the parsed CSI DIP Key information needed to execute dips.
 *  Current CSI DIPs require only the MSISDN or the FAN.
 */
package com.att.tpp.model;

import java.io.Serializable;

import com.att.tpp.xml.model.Account;
import com.att.tpp.xml.model.BillingAccount.FAN;
import com.att.tpp.xml.model.Header;

/**
 * @author SC9833
 *
 */
public class CSIDipKeys implements Serializable {
	

	private static final long serialVersionUID = 1L;
	


	private Account accountData;
	private FAN fanData;
	private Header header;
	

	
	public CSIDipKeys(Header header,Account accountData, FAN fanData) {
		super();
		this.header = header;
		this.accountData = accountData;
		this.fanData = fanData;
	}
	
	/**
	 * 
	 */
	public CSIDipKeys() {
		// TODO Auto-generated constructor stub
	}
	
	/**
	 * @param accountData
	 */
	public CSIDipKeys(Account accountData) {
		this.accountData = accountData;
	}

	/**
	 * @param fanData
	 */
	public CSIDipKeys(FAN fanData) {
		this.fanData = fanData;
	}

	/**
	 * @param accountData
	 * @param fanData
	 */
	public CSIDipKeys(Account accountData, FAN fanData) {
		this.accountData = accountData;
		this.fanData = fanData;
	}

	/**
	 * @return the accountData
	 */
	public Account getAccountData() {
		return accountData;
	}

	/**
	 * @param accountData the accountData to set
	 */
	public void setAccountData(Account accountData) {
		this.accountData = accountData;
	}

	/**
	 * @return the fanData
	 */
	public FAN getFanData() {
		return fanData;
	}

	/**
	 * @param fanData the fanData to set
	 */
	public void setFanData(FAN fanData) {
		this.fanData = fanData;
	}

	public Header getHeader() {
		return header;
	}

	public void setHeader(Header header) {
		this.header = header;
	}

	


}
