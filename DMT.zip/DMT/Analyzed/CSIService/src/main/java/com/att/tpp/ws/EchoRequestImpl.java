package com.att.tpp.ws;

import java.sql.Timestamp;
import java.util.Date;

import javax.xml.ws.Holder;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.att.tpp.enumuration.CSIEventType;
import com.att.tpp.model.CSIResponseKeys;
import com.att.tpp.model.WebServiceResponseData;
import com.att.tpp.utils.CSIServiceMessageParser;
import com.att.tpp.utils.CSITransactionIDGenerator;
import com.cingular.csi.csi.namespaces.container._public.echorequest.EchoRequestInfo;
import com.cingular.csi.csi.namespaces.container._public.echoresponse.EchoResponseInfo;
import com.cingular.csi.csi.namespaces.types._public.messageheader.MessageHeaderInfo;
import com.cingular.csi.csi.namespaces.v118.wsdl.cingularwirelesscsi.CSIApplicationException;
import com.cingular.csi.csi.namespaces.v118.wsdl.cingularwirelesscsi.EchoPortType;

@Transactional
@Service("echoRequest")
public class EchoRequestImpl implements EchoRequest {
	
	private static Logger echoRequestLog = Logger.getLogger(EchoRequestImpl.class);
	
	@Autowired
	private CSIMessageHeaderService csiMessageHeaderService;
		
	@Autowired 
	private EchoPortType echoPortType;
	

	@Override
	public WebServiceResponseData doEchoRequest(CSIResponseKeys csiResponseKeys, String requestXML)
			throws CSIApplicationException, Exception {
		  echoRequestLog.info("[doEchoRequest] Executing EchoRequest with message: " + csiResponseKeys);
		  
		  
			//Generating Message Header
			Holder<MessageHeaderInfo> messageHeader = null;
			String csiTransactionId = null;
			CSITransactionIDGenerator csiIDGen = new CSITransactionIDGenerator();
			csiTransactionId = csiIDGen.generateCSITransactionId("");  //passing blank to get generated transactionId for CSI Service call
			
			
			//Generate the WebresponseData.
		WebServiceResponseData webServiceResponseData = new WebServiceResponseData();
		webServiceResponseData.setTppcsiTransactionid(csiTransactionId);			
		webServiceResponseData.setTppTransactionid(csiTransactionId);
		webServiceResponseData.setOrderid("N/A");
		webServiceResponseData.setInputXml(requestXML);
		webServiceResponseData.setCarrierName(csiResponseKeys.getProvisioningCarrier());
		webServiceResponseData.setRoutingCarrier(csiResponseKeys.getRoutingCarrier());
		webServiceResponseData.setInterfaceName(CSIEventType.Echo.toString());
		Date date = new Date();			
		webServiceResponseData.setTimeStamp(new Timestamp(date.getTime()));
			
			try {
				
				messageHeader = csiMessageHeaderService.generateCSIMessageHeader(csiTransactionId);
				
			} catch (Exception e) {				
				echoRequestLog.info("Exception occured while generating CSIMessageHeader, MessageId: " + csiTransactionId);
				e.printStackTrace();
				throw e;
			}
			
			//Create Web Service request
			EchoResponseInfo echoResponseInfo = null;
			try{
			EchoRequestInfo echoRequestInfo = new EchoRequestInfo();
			echoRequestInfo.setData(csiResponseKeys.getInputText());

			echoResponseInfo = echoPortType.echo(messageHeader, echoRequestInfo);
			String echoResponseCode = echoResponseInfo.getResponse().getCode();
			String echoResponseDescription = echoResponseInfo.getResponse().getDescription();
			echoRequestLog.info("[doEchoRequest] Response Code: " + echoResponseCode);
			echoRequestLog.info("[doEchoRequest] Response Description: " + echoResponseDescription);
			
			
			webServiceResponseData.setCsiResponsecode(echoResponseInfo.getResponse().getCode());
			webServiceResponseData.setCsiResponsedesc(echoResponseInfo.getResponse().getDescription());		
			webServiceResponseData.setSkuStatus("S");
			
			
			}catch (CSIApplicationException csiApplicationException){
				
				echoRequestLog.info("[doEchoRequest] EchoRequest Web Service call Failed!");
				echoRequestLog.info("[doEchoRequest] Error Code: " + csiApplicationException.getFaultInfo().getResponse().getCode());
				echoRequestLog.info("[doEchoRequest] Error Description: " + csiApplicationException.getFaultInfo().getResponse().getDescription());
				echoRequestLog.info("[doEchoRequest] Error Message: " + csiApplicationException.getMessage());
				
				webServiceResponseData.setSkuStatus("F");
				webServiceResponseData.setCsiResponsecode(csiApplicationException.getFaultInfo().getResponse().getCode());
				webServiceResponseData.setCsiResponsedesc(csiApplicationException.getFaultInfo().getResponse().getDescription());
				webServiceResponseData.setErrorMessage(csiApplicationException.getMessage());
				
				//TODO Need to persist error response
				
				//throw csiApplicationException;
			} catch (Exception e){
				echoRequestLog.info("[doEchoRequest] Exception :: Error Message: " + e.getMessage());
				webServiceResponseData.setSkuStatus("F");
				webServiceResponseData.setCsiResponsecode("900");
				webServiceResponseData.setCsiResponsedesc("Exception thrown in EchoRequest Response");
				webServiceResponseData.setErrorMessage(e.getMessage());
			}
			
			echoRequestLog.info("[doEchoRequest] Error Web Service call completed with Success!");
			
			
		return webServiceResponseData;
	}


	
	@Override	
	public WebServiceResponseData invokeEcho(String requestXML,
			String eventType, String methodName,
			WebServiceResponseData webServiceResponseData,
			CSIServiceMessageParser csiMessageParser)
			throws CSIApplicationException, Exception {
		try{				
			echoRequestLog.info(methodName + "Invoking Echo Web Service");	
			CSIResponseKeys csiResponseKeys = csiMessageParser.parseEcho(requestXML, eventType);
			webServiceResponseData= doEchoRequest(csiResponseKeys, requestXML);				
			echoRequestLog.info(methodName + "Completed invoking Echo Web Service");
		
		} catch (CSIApplicationException csiApplicationException){				
			echoRequestLog.info(methodName + "Exception occured when invoking add3PPOrderNotes Web Service");
			echoRequestLog.info(methodName + "Error Code: " + csiApplicationException.getFaultInfo().getResponse().getCode());
			echoRequestLog.info(methodName + "Error Description: "  + csiApplicationException.getFaultInfo().getResponse().getDescription());
			echoRequestLog.info(methodName + "Error Message: " + csiApplicationException.getMessage());				
			//result = csiApplicationException.getFaultInfo().getResponse().getCode() + " - " + csiApplicationException.getFaultInfo().getResponse().getDescription() + "-" + csiApplicationException.getMessage();								
			//throw csiApplicationException;
			
		} 
		return webServiceResponseData;
	}
	

}
