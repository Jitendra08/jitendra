/**
 * 
 */
package com.att.tpp.utils

import groovy.xml.MarkupBuilder
import javax.xml.soap.SOAPMessage;

import com.att.tpp.model.WebServiceResponseData;
import com.att.tpp.xml.model.OrderDocumentInfo;

/**
 * @author SC9833
 *
 */
class FulfillmentValidationXMLGenerator {	
	
	def String getXML(WebServiceResponseData webServiceResponseData, boolean isSuccess){
		
		if(isSuccess){
			return buildSuccessXML(webServiceResponseData);
		}
		else{
			return buildFailureXML(webServiceResponseData);
		}
		
	}
		
	def String buildSuccessXML(WebServiceResponseData webServiceResponseData){
		def successXML = new StringWriter()
		def xmlMessage = new MarkupBuilder(successXML)
		def successMsg = "Fulfillment successful, please proceed with the shipment"
		def timeStamp = new Date()
		
		xmlMessage.setDoubleQuotes(true)
		xmlMessage.setExpandEmptyElements(false)
		xmlMessage.mkp.xmlDeclaration(version: "1.0", encoding: "UTF-8")
		
		xmlMessage.'ns0:TPP_FulfillmentResult'("xmlns:ns0" : "http://tpp.cingular.com/TPP_FulfillmentResult.xsd"){
			'ns0:Header'('ns0:TransactionId': webServiceResponseData.tppTransactionid, 'ns0:ProvisioningCarrier': webServiceResponseData.carrierName, 'ns0:TimeStamp':timeStamp.getDateTimeString())
			'ns0:OrderId'(){
				'ns0:location'(webServiceResponseData.structuredOrderId.location)
				'ns0:activity'(webServiceResponseData.structuredOrderId.activity)
				'ns0:orderId'(webServiceResponseData.structuredOrderId.orderId)
			}
			'ns0:FulfillmentId'(webServiceResponseData.fulfillmentId)
			'ns0:FulfillmentResult'("Success")
			'ns0:FulfillmentResultDescription'(successMsg)
		}
				
		return successXML.toString()
	}	
	
	def String buildFailureXML(WebServiceResponseData webServiceResponseData){
		def failureXML = new StringWriter()
		def xmlMessage = new MarkupBuilder(failureXML)
		def errorCode = webServiceResponseData.csiResponsecode
		def errorDesc = webServiceResponseData.csiResponsedesc
		def errorMsg = webServiceResponseData.errorMessage
		def failureMsg = "Fulfillment failed, hold on the shipment, Error Code: " + errorCode + " | Error Desc: " + errorDesc + " | Error Msg: " + errorMsg
		def timeStamp = new Date()
		
		xmlMessage.setDoubleQuotes(true)
		xmlMessage.setExpandEmptyElements(false)
		xmlMessage.mkp.xmlDeclaration(version: "1.0", encoding: "UTF-8")
		
		xmlMessage.'ns0:TPP_FulfillmentResult'("xmlns:ns0" : "http://tpp.cingular.com/TPP_FulfillmentResult.xsd"){
			'ns0:Header'('ns0:TransactionId': webServiceResponseData.tppTransactionid, 'ns0:ProvisioningCarrier': webServiceResponseData.carrierName, 'ns0:TimeStamp':timeStamp.getDateTimeString())
			'ns0:OrderId'(){
				'ns0:location'(webServiceResponseData.structuredOrderId.location)
				'ns0:activity'(webServiceResponseData.structuredOrderId.activity)
				'ns0:orderId'(webServiceResponseData.structuredOrderId.orderId)
			}
			'ns0:FulfillmentId'(webServiceResponseData.fulfillmentId)
			'ns0:FulfillmentResult'("Failure")
			'ns0:FulfillmentResultDescription'(failureMsg)
		}
				
		return failureXML.toString()
		
	}		

	static main(args) {
		
		def fvxg = new FulfillmentValidationXMLGenerator()
		def webSvcRespData = new WebServiceResponseData()
		webSvcRespData.carrierName="ATT"
		webSvcRespData.csiResponsecode="0"
		webSvcRespData.csiResponsedesc="Success"
		webSvcRespData.errorMessage="Success Request"
		webSvcRespData.tppTransactionid="123456789"
		
		def odi = new OrderDocumentInfo("N014", "OY", "123") 
		
		webSvcRespData.structuredOrderId=odi		
		webSvcRespData.fulfillmentId="Fulfill1234"
		
		println(fvxg.getXML(webSvcRespData, false))
		
	}

}
