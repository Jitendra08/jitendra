package com.att.tpp.xml.model;

public class BillingAccountEmail {

    private String emailType;
    private String emailAddress;

    /**
	 * @param emailType
	 * @param emailAddress
	 */
	public BillingAccountEmail(String emailType, String emailAddress) {
		this.emailType = emailType;
		this.emailAddress = emailAddress;
	}

	/**
     * Gets the value of the emailType property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getEmailType() {
        return emailType;
    }

    /**
     * Sets the value of the emailType property.
     * 
     * @param emailType
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setEmailType(String emailType) {
        this.emailType = emailType;
    }

    /**
     * Gets the value of the emailAddress property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getEmailAddress() {
        return emailAddress;
    }

    /**
     * Sets the value of the emailAddress property.
     * 
     * @param emailAddress
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setEmailAddress(String emailAddress) {
        this.emailAddress = emailAddress;
    }

}
