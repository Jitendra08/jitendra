package com.att.tpp.ws;

import java.sql.Timestamp;
import java.util.Date;

import javax.xml.ws.Holder;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.att.tpp.enumuration.CSIEventType;
import com.att.tpp.model.CSIResponseKeys;
import com.att.tpp.model.TransCode;
import com.att.tpp.model.WebServiceResponseData;
import com.att.tpp.service.CSIService;
import com.att.tpp.utils.CSIServiceMessageParser;
import com.att.tpp.utils.CSITransactionIDGenerator;
import com.cingular.csi.csi.namespaces.container._public.notifyfemtocellactionrequest.NotifyFemtocellActionRequestInfo;
import com.cingular.csi.csi.namespaces.container._public.notifyfemtocellactionresponse.NotifyFemtocellActionResponseInfo;
import com.cingular.csi.csi.namespaces.types._public.cingulardatamodel.ResponseInfo;
import com.cingular.csi.csi.namespaces.types._public.messageheader.MessageHeaderInfo;
import com.cingular.csi.csi.namespaces.v118.wsdl.cingularwirelesscsi.CSIApplicationException;
import com.cingular.csi.csi.namespaces.v118.wsdl.cingularwirelesscsi.NotifyFemtocellActionPortType;

@Service("notifyFemtocell")
public class NotifyFemtocellImpl implements NotifyFemtocell {
	
	private static final String methodName = "[doNotifyFemtocellAction] ";

	private static Logger notifyFemtocellActionLog = Logger.getLogger(NotifyFemtocellImpl.class);
	
	@Autowired
	private CSIMessageHeaderService csiMessageHeaderService;
		
	@Autowired
	private NotifyFemtocellActionPortType notifyFemtocellActionPortType;	
	
	@Autowired
	private CSIService csiService;
	
	@Override
	public WebServiceResponseData doNotifyFemtocellAction(
			CSIResponseKeys csiResponseKeys, String requestXML, String actionFemto, String provSystemTransId) throws CSIApplicationException,
			Exception {
		
		notifyFemtocellActionLog.info(methodName + "Executing NotifyFemtocellAction");
		
		//Generating Message Header
		Holder<MessageHeaderInfo> messageHeader = null;
		String csiTransactionId = null;
		CSITransactionIDGenerator csiIDGen = new CSITransactionIDGenerator();
		
		csiTransactionId = csiIDGen.generateCSITransactionId(provSystemTransId);  //passing blank to get generated transactionId for CSI Service call		
		
		
		//Generate the WebresponseData.
		WebServiceResponseData webServiceResponseData = new WebServiceResponseData();
		webServiceResponseData.setTppcsiTransactionid(csiTransactionId);			
		webServiceResponseData.setTppTransactionid(csiResponseKeys.getMessageTransactionID());
		webServiceResponseData.setInputXml(requestXML);
		webServiceResponseData.setCarrierName(csiResponseKeys.getProvisioningCarrier());
		webServiceResponseData.setRoutingCarrier(csiResponseKeys.getRoutingCarrier());
		webServiceResponseData.setInterfaceName(CSIEventType.NotifyFemtocellAction.toString());
		Date date = new Date();			
		webServiceResponseData.setTimeStamp(new Timestamp(date.getTime()));
		
		try {
			
			messageHeader = csiMessageHeaderService.generateCSIMessageHeader(csiTransactionId);  //The TransactionId should be the one that is used in the initiating call from upstream (CSI).
			
		} catch (Exception e) {
			
			notifyFemtocellActionLog.info(methodName + "Exception occured while generating CSIMessageHeader, MessageId: " + csiTransactionId);			
			e.printStackTrace();
			throw e;
		}
		String action = null;
		if(actionFemto!=null && actionFemto.equals("Cancel")){
			action="005";
		}else{
			action="004";
		}
		//Create Web Service request
		ResponseInfo responseInfo = new ResponseInfo();
		responseInfo.setCode(csiResponseKeys.getFemtocellCode());
		responseInfo.setDescription(csiResponseKeys.getFemtocellDescription());
		
		NotifyFemtocellActionRequestInfo notifyFemtocellActionRequestInfo = new NotifyFemtocellActionRequestInfo();
		notifyFemtocellActionRequestInfo.setAction(action);  //need to pull the action for the table for the particular transaction ID or sent in the payload from response Service
		notifyFemtocellActionRequestInfo.setResponse(responseInfo);

		NotifyFemtocellActionResponseInfo notifyFemtocellActionResponseInfo = null;
		
		try{
			
			notifyFemtocellActionResponseInfo = notifyFemtocellActionPortType.notifyFemtocellAction(messageHeader, notifyFemtocellActionRequestInfo);
			
			webServiceResponseData.setCsiResponsecode(notifyFemtocellActionResponseInfo.getResponse().getCode());
			webServiceResponseData.setCsiResponsedesc(notifyFemtocellActionResponseInfo.getResponse().getDescription());	
			webServiceResponseData.setSkuStatus("S");
			
			
			
			//TODO Need to persist response
			
		} catch (CSIApplicationException csiApplicationException){
			
			notifyFemtocellActionLog.info(methodName + "NotifyFemtocellAction Web Service call Failed!");
			notifyFemtocellActionLog.info(methodName + "Error Code: " + csiApplicationException.getFaultInfo().getResponse().getCode());
			notifyFemtocellActionLog.info(methodName + "Error Description: " + csiApplicationException.getFaultInfo().getResponse().getDescription());
			notifyFemtocellActionLog.info(methodName + "Error Message: " + csiApplicationException.getMessage());
			
			webServiceResponseData.setSkuStatus("F");
			webServiceResponseData.setCsiResponsecode(csiApplicationException.getFaultInfo().getResponse().getCode());
			webServiceResponseData.setCsiResponsedesc(csiApplicationException.getFaultInfo().getResponse().getDescription());
			webServiceResponseData.setErrorMessage(csiApplicationException.getMessage());
			
			//TODO Need to persist error response
			//throw csiApplicationException;
		}catch(Exception e){
			notifyFemtocellActionLog.info(methodName + "Exception in NotifyFemtocellAction Web Service call >>>>"+e.getMessage());
			webServiceResponseData.setSkuStatus("F");
			webServiceResponseData.setCsiResponsecode("900");
			webServiceResponseData.setCsiResponsedesc("Exception thrown in NotifyFemtocellAction Response");
			webServiceResponseData.setErrorMessage(e.getMessage());
		}
		
		notifyFemtocellActionLog.info(methodName + "NotifyFemtocellAction Web Service call completed with Success!");
		notifyFemtocellActionLog.info(methodName + "NotifyFemtocellAction Web Service call made with CTN: " + csiResponseKeys.getCtn());
		notifyFemtocellActionLog.info(methodName + "NotifyFemtocellAction Web Service call made with MessageID: " + csiTransactionId);
		
		
		
		return webServiceResponseData;
	}

	@Override
	public WebServiceResponseData invokeNotifyFemtocellAction(String requestXML,
			String eventType, String methodName,
			WebServiceResponseData webServiceResponseData,
			CSIServiceMessageParser csiMessageParser, String actionFemto, String provSystemTransId, String masterTransId)
			throws CSIApplicationException, Exception {
		try{
			
			notifyFemtocellActionLog.info(methodName + "Invoking NotifyFemtocell Web Service");
			CSIResponseKeys csiResponseKeys = csiMessageParser.parseNotifyFemtocell(requestXML, eventType);
			
			csiResponseKeys.setMessageTransactionID(masterTransId);			
			webServiceResponseData = doNotifyFemtocellAction(csiResponseKeys, requestXML, actionFemto, provSystemTransId);		
			notifyFemtocellActionLog.info(methodName + "Completed invoking NotifyFemtocell Web Service");
			
			//Generate TransCode and Insert into DB.
			TransCode transCode = csiService.generateTransCode(masterTransId, csiResponseKeys, actionFemto);
			boolean insertTransCode = csiService.insertTranscode(transCode);
			notifyFemtocellActionLog.info(methodName + "insertTransCode result: "+insertTransCode);
		
			//Note: For now we are sending only 71000 errors to the Error Service.
			//Please check with prod support
			if(transCode.getMajorcode().equalsIgnoreCase("71000")){
				String messageId="";
				boolean sendToErrorQueue = csiService.generateAndSendErrorRequest(messageId, masterTransId);
				notifyFemtocellActionLog.info(methodName + "sendToErrorQueue result: "+sendToErrorQueue);
			}
			
			
		} catch (CSIApplicationException csiApplicationException){				
			
			notifyFemtocellActionLog.info(methodName + "Exception occured when invoking NotifyFemtocell Web Service");
			notifyFemtocellActionLog.info(methodName + "Error Code: " + csiApplicationException.getFaultInfo().getResponse().getCode());
			notifyFemtocellActionLog.info(methodName + "Error Description: "  + csiApplicationException.getFaultInfo().getResponse().getDescription());
			notifyFemtocellActionLog.info(methodName + "Error Message: " + csiApplicationException.getMessage());
			//throw csiApplicationException;
				
		} 
		
		return webServiceResponseData;
	}

}
