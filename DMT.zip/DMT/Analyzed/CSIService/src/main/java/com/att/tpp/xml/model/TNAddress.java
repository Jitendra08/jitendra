package com.att.tpp.xml.model;

public class TNAddress {

    private String hno;
    private String hns;
    private String prd;
    private String stn;
    private String mcn;
    private String sta;
    private String loc;
    private String sts;
    private String pod;
    private String zip;

    /**
	 * @param hno
	 * @param hns
	 * @param prd
	 * @param stn
	 * @param mcn
	 * @param sta
	 * @param loc
	 * @param sts
	 * @param pod
	 * @param zip
	 */
	public TNAddress(String hno, String hns, String prd, String stn,
			String mcn, String sta, String loc, String sts, String pod,
			String zip) {
		this.hno = hno;
		this.hns = hns;
		this.prd = prd;
		this.stn = stn;
		this.mcn = mcn;
		this.sta = sta;
		this.loc = loc;
		this.sts = sts;
		this.pod = pod;
		this.zip = zip;
	}

	/**
     * Gets the value of the hno property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getHNO() {
        return hno;
    }

    /**
     * Sets the value of the hno property.
     * 
     * @param hno
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setHNO(String hno) {
        this.hno = hno;
    }

    /**
     * Gets the value of the hns property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getHNS() {
        return hns;
    }

    /**
     * Sets the value of the hns property.
     * 
     * @param hns
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setHNS(String hns) {
        this.hns = hns;
    }

    /**
     * Gets the value of the prd property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getPRD() {
        return prd;
    }

    /**
     * Sets the value of the prd property.
     * 
     * @param prd
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setPRD(String prd) {
        this.prd = prd;
    }

    /**
     * Gets the value of the stn property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getSTN() {
        return stn;
    }

    /**
     * Sets the value of the stn property.
     * 
     * @param stn
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setSTN(String stn) {
        this.stn = stn;
    }

    /**
     * Gets the value of the mcn property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getMCN() {
        return mcn;
    }

    /**
     * Sets the value of the mcn property.
     * 
     * @param mcn
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setMCN(String mcn) {
        this.mcn = mcn;
    }

    /**
     * Gets the value of the sta property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getSTA() {
        return sta;
    }

    /**
     * Sets the value of the sta property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setSTA(String sta) {
        this.sta = sta;
    }

    /**
     * Gets the value of the loc property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getLOC() {
        return loc;
    }

    /**
     * Sets the value of the loc property.
     * 
     * @param loc
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setLOC(String loc) {
        this.loc = loc;
    }

    /**
     * Gets the value of the sts property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getSTS() {
        return sts;
    }

    /**
     * Sets the value of the sts property.
     * 
     * @param sts
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setSTS(String sts) {
        this.sts = sts;
    }

    /**
     * Gets the value of the pod property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getPOD() {
        return pod;
    }

    /**
     * Sets the value of the pod property.
     * 
     * @param pod
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setPOD(String pod) {
        this.pod = pod;
    }

    /**
     * Gets the value of the zip property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getZIP() {
        return zip;
    }

    /**
     * Sets the value of the zip property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setZIP(String zip) {
        this.zip = zip;
    }

}
