/**
 * 
 */
package com.att.tpp.utils;

import java.util.Random;

/**
 * @author SC9833
 *
 */
public class CSITransactionIDGenerator {
	
	private String transId = "";
	private String csiTransactionId = "";
	
	/**
	 * 
	 */
	public CSITransactionIDGenerator() {}

	/**
	 * @return the transId
	 */
	public String getTransId() {
		return transId;
	}
	
	/**
	 * @param transId the transId to set
	 */
	public void setTransId(String transId) {
		this.transId = transId;
	}
	
	/**
	 * @return the csiTransactionId
	 */
	public String getCsiTransactionId() {
		return csiTransactionId;
	}
	
	/**
	 * @param csiTransactionId the csiTransactionId to set
	 */
	public void setCsiTransactionId(String csiTransactionId) {
		this.csiTransactionId = csiTransactionId;
	}
	
	public String generateCSITransactionId(String inputTransId){
		transId = inputTransId;
		
		if (transId == null || transId.equals("") || transId.length() <= 0  ){
			csiTransactionId = "3PP_" + Long.toHexString(System.currentTimeMillis()) + Long.toString(new Random().nextLong());			
		}
		else{
			csiTransactionId = transId;			
		}
		
		return csiTransactionId;		
	}
	

}
