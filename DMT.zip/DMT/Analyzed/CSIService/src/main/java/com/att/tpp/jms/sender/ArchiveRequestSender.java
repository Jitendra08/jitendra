package com.att.tpp.jms.sender;

import javax.jms.JMSException;
import javax.jms.Message;
import javax.jms.Queue;
import javax.jms.Session;
import javax.jms.TextMessage;

import org.apache.log4j.Logger;
import org.springframework.jms.core.JmsTemplate;
import org.springframework.jms.core.MessageCreator;

import com.att.tpp.model.ProcessingResult;

/**
 * The TestMessageSender class uses the injected JMSTemplate to send a message
 * to a specified Queue. In our case we're sending messages to 'TestQueueTwo'
 */
public class ArchiveRequestSender
{
	private JmsTemplate jmsTemplate;
	private Queue archiveRequestQueue;
	private static final Logger archiveRequestSender = Logger.getLogger(ArchiveRequestSender.class);
	private final static String SWCTransasctionId = "swcTransactionId";
	
	/**
	 * Sends message to gatewayProvisioningRequestQueue using JMS Template.
	 * @param provReqXML the message_p
	 * @throws JMSException the jms exception
	 */
	public void sendMessage(final ProcessingResult processingResult) throws JMSException
	{
		
		archiveRequestSender.debug("Sending TPP_Archive Request Message From CSI Service to Archive Service");

		jmsTemplate.send(this.archiveRequestQueue, new MessageCreator(){

			@Override
			public Message createMessage(Session session) throws JMSException {
				TextMessage message = session.createTextMessage(processingResult.getArchiveRequestXML().toString());
				message.setStringProperty(SWCTransasctionId,processingResult.getTransactionId());				
				return message;
			}
			
		});		
		
	}

	/**
	 * Sets the jms template.
	 *
	 * @param template the jms template
	 */
	public void setJmsTemplate(JmsTemplate tmpl)
	{
		this.jmsTemplate = tmpl;
	}


	/**
	 * Sets the test queue.
	 *
	 * @param ArchiveQueue sender the new test queue
	 */
	public void setArchiveRequestQueue(Queue archiveRequestQueue) {
		this.archiveRequestQueue = archiveRequestQueue;
	}

}