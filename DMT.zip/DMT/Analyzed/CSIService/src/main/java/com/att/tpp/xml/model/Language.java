package com.att.tpp.xml.model;

public enum Language {

    CHS,
    DAN,
    DEU,
    ENU,
    ESN,
    FRA,
    HEB,
    ITA,
    JPN,
    KOR,
    NLD,
    PTB,
    SVE,
    ESP;

    public String value() {
        return name();
    }

    public static Language fromValue(String v) {
        return valueOf(v);
    }

}
