package com.att.tpp.xml.model;

public class AttachedIDInfo {

	private String attachAction;
    private boolean mainUserID;
	private MobilityInfo mobilityID;
    private UserIDInfo attachedID;
    
    /**
	 * @param attachAction
	 * @param mainUserID
	 * @param mobilityID
	 * @param attachedID
	 */
	public AttachedIDInfo(String attachAction, boolean mainUserID,
			MobilityInfo mobilityID, UserIDInfo attachedID) {
		this.attachAction = attachAction;
		this.mainUserID = mainUserID;
		this.mobilityID = mobilityID;
		this.attachedID = attachedID;
	}

	/**
     * Gets the value of the attachAction property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getAttachAction() {
        return attachAction;
    }

    /**
     * Sets the value of the attachAction property.
     * 
     * @param attachAction
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setAttachAction(String attachAction) {
        this.attachAction = attachAction;
    }

    /**
     * Gets the value of the mainUserID property.
     * 
     */
    public boolean isMainUserID() {
        return mainUserID;
    }

    /**
     * Sets the value of the mainUserID property.
     * 
     */
    public void setMainUserID(boolean mainUserID) {
        this.mainUserID = mainUserID;
    }
    
    /**
     * Gets the value of the mobilityID property.
     * 
     * @return
     *     possible object is
     *     {@link MobilityInfo }
     *     
     */
    public MobilityInfo getMobilityID() {
        return mobilityID;
    }

    /**
     * Sets the value of the mobilityID property.
     * 
     * @param mobilityID
     *     allowed object is
     *     {@link MobilityInfo }
     *     
     */
    public void setMobilityID(MobilityInfo mobilityID) {
        this.mobilityID = mobilityID;
    }

    /**
     * Gets the value of the attachedID property.
     * 
     * @return
     *     possible object is
     *     {@link UserIDInfo }
     *     
     */
    public UserIDInfo getAttachedID() {
        return attachedID;
    }

    /**
     * Sets the value of the attachedID property.
     * 
     * @param attachedID
     *     allowed object is
     *     {@link UserIDInfo }
     *     
     */
    public void setAttachedID(UserIDInfo attachedID) {
        this.attachedID = attachedID;
    }

}
