package com.att.tpp.xml.model;

public class Device {

	private String make;
	private String model;
	private String esn;
	private String imei;
	private Boolean mmsCapable;
		
	/**
	 * @param make
	 * @param model
	 * @param esn
	 * @param imei
	 * @param mmsCapable
	 */
	public Device(String make, String model, String esn, String imei,
			Boolean mmsCapable) {
		this.make = make;
		this.model = model;
		this.esn = esn;
		this.imei = imei;
		this.mmsCapable = mmsCapable;
	}

	/**
	 * @return the make
	 */
	public String getMake() {
		return make;
	}
	
	/**
	 * @param make the make to set
	 */
	public void setMake(String make) {
		this.make = make;
	}
	
	/**
	 * @return the model
	 */
	public String getModel() {
		return model;
	}
	
	/**
	 * @param model the model to set
	 */
	public void setModel(String model) {
		this.model = model;
	}
	
	/**
	 * @return the esn
	 */
	public String getEsn() {
		return esn;
	}
	
	/**
	 * @param esn the esn to set
	 */
	public void setEsn(String esn) {
		this.esn = esn;
	}
	
	/**
	 * @return the imei
	 */
	public String getImei() {
		return imei;
	}
	
	/**
	 * @param imei the imei to set
	 */
	public void setImei(String imei) {
		this.imei = imei;
	}
	
	/**
	 * @return the mmsCapable
	 */
	public Boolean getMmsCapable() {
		return mmsCapable;
	}
	
	/**
	 * @param mmsCapable the mmsCapable to set
	 */
	public void setMmsCapable(Boolean mmsCapable) {
		this.mmsCapable = mmsCapable;
	}

}
