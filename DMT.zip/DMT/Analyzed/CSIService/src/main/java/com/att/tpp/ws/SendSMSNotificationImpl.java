package com.att.tpp.ws;

import java.sql.Timestamp;
import java.util.Date;

import javax.xml.ws.Holder;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.att.tpp.enumuration.CSIEventType;
import com.att.tpp.model.CSIResponseKeys;
import com.att.tpp.model.WebServiceResponseData;
import com.att.tpp.utils.CSIServiceMessageParser;
import com.att.tpp.utils.CSITransactionIDGenerator;
import com.cingular.csi.csi.namespaces.container._public.sendsmsrequest.SendSmsRequestInfo;
import com.cingular.csi.csi.namespaces.container._public.sendsmsresponse.SendSmsResponseInfo;
import com.cingular.csi.csi.namespaces.types._public.messageheader.MessageHeaderInfo;
import com.cingular.csi.csi.namespaces.v118.wsdl.cingularwirelesscsi.CSIApplicationException;
import com.cingular.csi.csi.namespaces.v118.wsdl.cingularwirelesscsi.SendSmsPortType;

@Transactional
@Service("sendSMSNotification")
public class SendSMSNotificationImpl implements SendSMSNotification {
	
	private static Logger sendSMSNotificationLog = Logger.getLogger(SendSMSNotificationImpl.class);
	
	@Autowired
	private CSIMessageHeaderService csiMessageHeaderService;
		
	@Autowired 
	private SendSmsPortType sendSmsPortType;

	@Override
	public WebServiceResponseData dosendSMSRequest(CSIResponseKeys csiResponseKeys, String requestXML) throws CSIApplicationException, Exception {
						
		//Generating Message Header
		Holder<MessageHeaderInfo> messageHeader = null;
		String csiTransactionId = null;
		CSITransactionIDGenerator csiIDGen = new CSITransactionIDGenerator();
		csiTransactionId = csiIDGen.generateCSITransactionId("");  //passing blank to get generated transactionId for CSI Service call
		
		//Generate the WebresponseData.
		WebServiceResponseData webServiceResponseData = new WebServiceResponseData();
		webServiceResponseData.setTppcsiTransactionid(csiTransactionId);			
		webServiceResponseData.setTppTransactionid(csiResponseKeys.getMessageTransactionID());
    	webServiceResponseData.setOrderid("NA");
		webServiceResponseData.setInputXml(requestXML);
		webServiceResponseData.setCarrierName(csiResponseKeys.getProvisioningCarrier());
		webServiceResponseData.setRoutingCarrier(csiResponseKeys.getRoutingCarrier());
		webServiceResponseData.setInterfaceName(CSIEventType.SendSMS.toString());
		Date date = new Date();			
		webServiceResponseData.setTimeStamp(new Timestamp(date.getTime()));
		
		try {
			
			messageHeader = csiMessageHeaderService.generateCSIMessageHeader(csiTransactionId);
			
		} catch (Exception e) {
			
			sendSMSNotificationLog.info("Exception occured while generating CSIMessageHeader, MessageId: " + csiTransactionId);
			e.printStackTrace();
			throw e;
		}
		
		//Create Web Service request
		SendSmsResponseInfo sendSmsResponseInfo = null;
		
		try{

			SendSmsRequestInfo sendSmsRequestInfo = new SendSmsRequestInfo();	
			sendSmsRequestInfo.setDestinationAddress(csiResponseKeys.getCtn());
			sendSmsRequestInfo.setShortMessage(csiResponseKeys.getInputText());
			
			sendSmsResponseInfo = sendSmsPortType.sendSms(messageHeader, sendSmsRequestInfo);
			//TODO Need to persist response
			
			sendSMSNotificationLog.info("[dosendSMSRequest] Response Code: " + sendSmsResponseInfo.getResponse().getCode());
			sendSMSNotificationLog.info("[dosendSMSRequest] Response Msg: " + sendSmsResponseInfo.getResponse().getDescription());
			
			
			//Pass the Response code information
			webServiceResponseData.setCsiResponsecode(sendSmsResponseInfo.getResponse().getCode());
			webServiceResponseData.setCsiResponsedesc(sendSmsResponseInfo.getResponse().getDescription());		
			webServiceResponseData.setSkuStatus("S");
			
		} catch (CSIApplicationException csiae){
			
			sendSMSNotificationLog.info("[dosendSMSRequest] SendSMS Web Service call Failed!");
			sendSMSNotificationLog.info("[dosendSMSRequest] Error Code: " + csiae.getFaultInfo().getResponse().getCode());
			sendSMSNotificationLog.info("[dosendSMSRequest] Error Description: " + csiae.getFaultInfo().getResponse().getDescription());
			sendSMSNotificationLog.info("[dosendSMSRequest] Error Message: " + csiae.getMessage());
			
			
			webServiceResponseData.setSkuStatus("F");
			webServiceResponseData.setCsiResponsecode(csiae.getFaultInfo().getResponse().getCode());
			webServiceResponseData.setCsiResponsedesc(csiae.getFaultInfo().getResponse().getDescription());
			webServiceResponseData.setErrorMessage(csiae.getMessage());
			
			//TODO Need to persist error response
			
			//throw csiae;
		} catch (Exception e){
			sendSMSNotificationLog.info("[dosendSMSRequest] Exception :: Error Message: " + e.getMessage());
			webServiceResponseData.setSkuStatus("F");
			webServiceResponseData.setCsiResponsecode("900");
			webServiceResponseData.setCsiResponsedesc("Exception thrown in SendSMS Response");
			webServiceResponseData.setErrorMessage(e.getMessage());
		}
		
		sendSMSNotificationLog.info("[dosendSMSRequest] SendSMS Web Service call completed with Success!");
		//sendSMSNotificationLog.info("[dosendSMSRequest] SendSMS Web Service call made with OrderId: " + csiResponseKeys.getConcatOrderID());
		
		return webServiceResponseData;
	}

	@Override
	public WebServiceResponseData invokeSendSMS(String requestXML,	String eventType, String methodName,
			WebServiceResponseData webServiceResponseData,CSIServiceMessageParser csiMessageParser)
			throws CSIApplicationException, Exception {
		try{
							
			sendSMSNotificationLog.info(methodName + "Invoking SendSMS Web Service");				
			CSIResponseKeys csiResponseKeys = csiMessageParser.parseSendSMS(requestXML, eventType);
			webServiceResponseData= dosendSMSRequest(csiResponseKeys, requestXML);
			sendSMSNotificationLog.info(methodName + "Completed invoking SendSMS Web Service");
			
		} catch (CSIApplicationException csiApplicationException){

			sendSMSNotificationLog.info(methodName + "Exception occured when invoking SendSMS Web Service");
			sendSMSNotificationLog.info(methodName + "Error Code: " + csiApplicationException.getFaultInfo().getResponse().getCode());
			sendSMSNotificationLog.info(methodName + "Error Description: "  + csiApplicationException.getFaultInfo().getResponse().getDescription());
			sendSMSNotificationLog.info(methodName + "Error Message: " + csiApplicationException.getMessage());

			//result = csiApplicationException.getFaultInfo().getResponse().getCode() + " - " + csiApplicationException.getFaultInfo().getResponse().getDescription() + "-" + csiApplicationException.getMessage();

			throw csiApplicationException;

		} 
		return webServiceResponseData;
	}

}
