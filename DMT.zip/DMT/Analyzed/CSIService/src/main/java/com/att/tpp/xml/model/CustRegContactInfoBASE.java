package com.att.tpp.xml.model;

public class CustRegContactInfoBASE {

    private String namePrefix;
    private String firstName;
    private String middleName;
    private String lastName;
    private String jobTitle;
    private String workPhoneNumber;
    private String email;
    private String type;

    /**
	 * @param firstName
	 * @param lastName
	 * @param type
	 */
	public CustRegContactInfoBASE(String firstName, String lastName, String type) {
		this.firstName = firstName;
		this.lastName = lastName;
		this.type = type;
	}

	/**
	 * @param namePrefix
	 * @param firstName
	 * @param middleName
	 * @param lastName
	 * @param jobTitle
	 * @param workPhoneNumber
	 * @param email
	 * @param type
	 */
	public CustRegContactInfoBASE(String namePrefix, String firstName,
			String middleName, String lastName, String jobTitle,
			String workPhoneNumber, String email, String type) {
		this.namePrefix = namePrefix;
		this.firstName = firstName;
		this.middleName = middleName;
		this.lastName = lastName;
		this.jobTitle = jobTitle;
		this.workPhoneNumber = workPhoneNumber;
		this.email = email;
		this.type = type;
	}

	/**
     * Gets the value of the namePrefix property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getNamePrefix() {
        return namePrefix;
    }

    /**
     * Sets the value of the namePrefix property.
     * 
     * @param namePrefix
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setNamePrefix(String namePrefix) {
        this.namePrefix = namePrefix;
    }

    /**
     * Gets the value of the firstName property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getFirstName() {
        return firstName;
    }

    /**
     * Sets the value of the firstName property.
     * 
     * @param firstName
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setFirstName(String firstName) {
        this.firstName = firstName;
    }

    /**
     * Gets the value of the middleName property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getMiddleName() {
        return middleName;
    }

    /**
     * Sets the value of the middleName property.
     * 
     * @param middleName
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setMiddleName(String middleName) {
        this.middleName = middleName;
    }

    /**
     * Gets the value of the lastName property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getLastName() {
        return lastName;
    }

    /**
     * Sets the value of the lastName property.
     * 
     * @param lastName
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setLastName(String lastName) {
        this.lastName = lastName;
    }

    /**
     * Gets the value of the jobTitle property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getJobTitle() {
        return jobTitle;
    }

    /**
     * Sets the value of the jobTitle property.
     * 
     * @param jobTitle
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setJobTitle(String jobTitle) {
        this.jobTitle = jobTitle;
    }

    /**
     * Gets the value of the workPhoneNumber property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getWorkPhoneNumber() {
        return workPhoneNumber;
    }

    /**
     * Sets the value of the workPhoneNumber property.
     * 
     * @param workPhoneNumber
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setWorkPhoneNumber(String workPhoneNumber) {
        this.workPhoneNumber = workPhoneNumber;
    }

    /**
     * Gets the value of the email property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getEmail() {
        return email;
    }

    /**
     * Sets the value of the email property.
     * 
     * @param email
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setEmail(String email) {
        this.email = email;
    }

    /**
     * Gets the value of the type property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getType() {
        return type;
    }

    /**
     * Sets the value of the type property.
     * 
     * @param type
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setType(String type) {
        this.type = type;
    }

}
