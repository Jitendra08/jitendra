package com.att.tpp.xml.model;

public enum Action {

    ADD("Add"),
    CANCEL("Cancel"),
    MODIFY("Modify"),
    RESUME("Resume"),
    SUSPEND("Suspend"),
    PURGE("Purge"),
    REINSTATE("Reinstate"),
    ADD_OCC("AddOCC");
    
    private final String value;

    Action(String v) {
        value = v;
    }

    public String value() {
        return value;
    }

    public static Action fromValue(String v) {
        for (Action c: Action.values()) {
            if (c.value.equals(v)) {
                return c;
            }
        }
        throw new IllegalArgumentException(v);
    }

}
