package com.att.tpp.jms.sender;

import javax.jms.JMSException;
import javax.jms.Message;
import javax.jms.Queue;
import javax.jms.Session;
import javax.jms.TextMessage;

import org.apache.log4j.Logger;
import org.springframework.jms.core.JmsTemplate;
import org.springframework.jms.core.MessageCreator;

import com.att.tpp.model.ProcessingResult;

/**
 * The TestMessageSender class uses the injected JMSTemplate to send a message
 * to a specified Queue. In our case we're sending messages to 'TestQueueTwo'
 */
public class CommunicationRequestSender
{
	private JmsTemplate jmsTemplate;
	private Queue communicationRequestQueue;
	private static final Logger communicationRequestSenderLog = Logger.getLogger(CommunicationRequestSender.class);
	private final static String swcTransactionId = "swcTransactionId";
	private final static String fulfillmentIndicator = "fulfillmentIndicator";
	private final static String systemName = "systemName";
	
	/**
	 * Sends message to gatewayProvisioningRequestQueue using JMS Template.
	 * @param provReqXML the message_p
	 * @throws JMSException the jms exception
	 */
	public void sendMessage(final ProcessingResult processingResult) throws JMSException
	{
		
		communicationRequestSenderLog.debug("Sending Fulfillment Validation Message From CSI Service to Communication Service");

		jmsTemplate.send(this.communicationRequestQueue, new MessageCreator(){

			//Take a look at what is needed to be sent to Communication Service to post the Fulfillment Validation to the partner after
			//An AddOrderShipment of type="Fulfillment" web service call.
			@Override
			public Message createMessage(Session session) throws JMSException {
				TextMessage message = session.createTextMessage(processingResult.getFulfillmentValidationXML().toString());
				message.setStringProperty(swcTransactionId,processingResult.getTransactionId());
				message.setStringProperty(fulfillmentIndicator,"YES");
				message.setStringProperty(systemName,"Todo:SystemName");
				return message;
			}
			
		});		
		
	}

	/**
	 * Sets the jms template.
	 *
	 * @param template the jms template
	 */
	public void setJmsTemplate(JmsTemplate tmpl)
	{
		this.jmsTemplate = tmpl;
	}

	/**
	 * Sets the test queue.
	 *
	 * @param communicationRequestQueue the new test queue
	 */
	public void setCommunicationRequestQueue(Queue communicationRequestQueue)
	{
		this.communicationRequestQueue = communicationRequestQueue;
	}
}