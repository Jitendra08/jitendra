package com.att.tpp.xml.model;

public class ParentalControlsSettingInfo {

    private Boolean indicator;
    private String reasonCode;

    /**
	 * @param indicator
	 * @param reasonCode
	 */
	public ParentalControlsSettingInfo(Boolean indicator, String reasonCode) {
		this.indicator = indicator;
		this.reasonCode = reasonCode;
	}

	/**
     * Gets the value of the indicator property.
     * 
     * @return
     *     possible object is
     *     {@link Boolean }
     *     
     */
    public Boolean isIndicator() {
        return indicator;
    }

    /**
     * Sets the value of the indicator property.
     * 
     * @param indicator
     *     allowed object is
     *     {@link Boolean }
     *     
     */
    public void setIndicator(Boolean indicator) {
        this.indicator = indicator;
    }

    /**
     * Gets the value of the reasonCode property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getReasonCode() {
        return reasonCode;
    }

    /**
     * Sets the value of the reasonCode property.
     * 
     * @param reasonCode
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setReasonCode(String reasonCode) {
        this.reasonCode = reasonCode;
    }

}
