package com.att.tpp.ws;

import java.beans.ConstructorProperties;
import java.math.BigInteger;

import javax.xml.datatype.XMLGregorianCalendar;
import javax.xml.ws.Holder;

import org.apache.log4j.Logger;
import com.att.tpp.utils.XMLDateUtil;
import com.cingular.csi.csi.namespaces.types._public.cingulardatamodel.MessageHeaderSecurity;
import com.cingular.csi.csi.namespaces.types._public.cingulardatamodel.MessageHeaderSequence;
import com.cingular.csi.csi.namespaces.types._public.cingulardatamodel.MessageHeaderTracking;
import com.cingular.csi.csi.namespaces.types._public.messageheader.MessageHeaderInfo;

public class CSIMessageHeaderService {
	
	private static Logger csiMessageHeaderServiceLog = Logger.getLogger(CSIMessageHeaderService.class);
	
	private String user;
	private String pass;
	private String version;
	private String csittl;
	
	@ConstructorProperties({"user", "pass", "version", "csittl"})
	public CSIMessageHeaderService(String user, String pass, String version, String csittl){
		this.user = user;
		this.pass = pass;
		this.version = version;
		this.csittl = csittl;
	}

	public Holder<MessageHeaderInfo> generateCSIMessageHeader(String messageId)	throws Exception {
		csiMessageHeaderServiceLog.debug("CSI Version: " + version);
		csiMessageHeaderServiceLog.info("Inside CSIMessageHeaderService, messageId: " + messageId);
		csiMessageHeaderServiceLog.info("Inside CSIMessageHeaderService, csittl: " + csittl);
		
		XMLGregorianCalendar date = null;
		date = XMLDateUtil.getNow();
		
		MessageHeaderInfo newHeader = new MessageHeaderInfo();
			
    	//BigInteger ttl = new BigInteger("30000");
		BigInteger ttl = new BigInteger(csittl);
		MessageHeaderSecurity userPass = new MessageHeaderSecurity();
		userPass.setUserName(user);
		userPass.setUserPassword(pass);		

		MessageHeaderSequence sequence = new MessageHeaderSequence();
		sequence.setSequenceNumber("1");
		sequence.setTotalInSequence("1");

		MessageHeaderTracking tracking = new MessageHeaderTracking();
		tracking.setMessageId(messageId);
		tracking.setVersion(version);
		tracking.setOriginalVersion(version);
		tracking.setOriginatorId("3PP");
		tracking.setTimeToLive(ttl);
		tracking.setDateTimeStamp(date);

		newHeader.setSecurityMessageHeader(userPass);
		newHeader.setSequenceMessageHeader(sequence);
		newHeader.setTrackingMessageHeader(tracking);

		Holder<MessageHeaderInfo> messageHeader = new Holder<MessageHeaderInfo>(newHeader);
		
		return messageHeader;
	}

}