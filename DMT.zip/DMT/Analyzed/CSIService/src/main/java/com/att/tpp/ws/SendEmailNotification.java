package com.att.tpp.ws;

import com.att.tpp.model.SendEmailKeys;
import com.att.tpp.model.WebServiceResponseData;
import com.att.tpp.utils.CSIServiceMessageParser;
import com.cingular.csi.csi.namespaces.v118.wsdl.cingularwirelesscsi.CSIApplicationException;

public interface SendEmailNotification {
	
	
	WebServiceResponseData dosendEmailRequest(SendEmailKeys sendEmailKeys, String requestXML) throws CSIApplicationException, Exception;

	WebServiceResponseData invokeSendEmail(String requestXML, String eventType,
			String methodName, WebServiceResponseData webServiceResponseData,
			CSIServiceMessageParser csiMessageParser) throws CSIApplicationException, Exception;

}
