package com.att.tpp.dao;

import java.util.List;

import com.att.tpp.model.CSI_MESSAGE_ARCHIVE;
import com.att.tpp.model.CSIRetryErrors;
import com.att.tpp.model.CsiTimer;
import com.att.tpp.model.FeatureCodeRef;
import com.att.tpp.model.ProvisioningRequest;
import com.att.tpp.model.ProvisioningTask;
import com.att.tpp.model.RetryConfiguration;
import com.att.tpp.model.SystemConfiguration;
import com.att.tpp.model.TransCode;
import com.att.tpp.model.UriConfiguration;


public interface CSIDao {
	
	public boolean insertCSIMessageArchive(CSI_MESSAGE_ARCHIVE csiMessageArchive) throws Exception;

	public List<CSIRetryErrors> getCSIRetryError() throws Exception;

	public List<CsiTimer> getCSITimerRecord(String tppcsiTransactionid) throws Exception;

	public boolean insertCSITimerData(CsiTimer csiTimer)  throws Exception;
	
	public boolean deleteFromTimer(String taskTransId)  throws Exception;  /* FIX for WR# 2738943- Multiple Retry of SKU provisioning request after 200-OK and AddOrderNotes response received */
	
	public boolean deleteFromCSITimer(String masterTransId)  throws Exception;

	public List<RetryConfiguration> getRetryConfiguration(String systemName)  throws Exception;

	public String getSystemName(String tppTransactionid)  throws Exception;

	public List<FeatureCodeRef> featureCodeRefList()   throws Exception;

	public boolean findFulfillmentIndicator(String vendorName) throws Exception;

	public List<SystemConfiguration> getSytemConfiguartionList();

	public List<UriConfiguration> getURIonfiguartionList();

	public String getProvSystemTransId(String masterTransId);

	public boolean insertTranscode(TransCode transCode);

	public ProvisioningRequest queryProvisioningRequest(String masterTransId);

	public List<TransCode> queryTransCode(String masterTransId);

	public List<ProvisioningTask> queryProvisioningTask(
			String masterTransId);
	
	public List<FeatureCodeRef> dcmFeatureCodeRefList()   throws Exception;
	
}