package com.att.tpp.xml.model;

public class TPPSKUOrder {

    private TPPSKUOrder.OrderNotification orderNotification;

    /**
     * Gets the value of the orderNotification property.
     * 
     * @return
     *     possible object is
     *     {@link TPPSKUOrder.OrderNotification }
     *     
     */
    public TPPSKUOrder.OrderNotification getOrderNotification() {
        return orderNotification;
    }

    /**
     * Sets the value of the orderNotification property.
     * 
     * @param orderNotification
     *     allowed object is
     *     {@link TPPSKUOrder.OrderNotification }
     *     
     */
    public void setOrderNotification(TPPSKUOrder.OrderNotification orderNotification) {
        this.orderNotification = orderNotification;
    }


    //TO DO: need to updated this class make sure the model works for OrderNotification!
    public static class OrderNotification
        //extends OrderNotificationInfo
    {
    	private String eventName;
    	private OrderNotificationInfo order;

        /**
		 * @param eventName
		 * @param order
		 */
		public OrderNotification(String eventName, OrderNotificationInfo order) {
			this.eventName = eventName;
			this.order = order;
		}

		/**
         * Gets the value of the eventName property.
         * 
         * @return
         *     possible object is
         *     {@link String }
         *     
         */
        public String getEventName() {
            return eventName;
        }

        /**
         * Sets the value of the eventName property.
         * 
         * @param eventName
         *     allowed object is
         *     {@link String }
         *     
         */
        public void setEventName(String eventName) {
            this.eventName = eventName;
        }

		/**
		 * @return the order
		 */
		public OrderNotificationInfo getOrder() {
			return order;
		}

		/**
		 * @param order the order to set
		 */
		public void setOrder(OrderNotificationInfo order) {
			this.order = order;
		}

    }

}
