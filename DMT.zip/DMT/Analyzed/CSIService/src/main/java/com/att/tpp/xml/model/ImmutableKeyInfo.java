package com.att.tpp.xml.model;

import java.util.Collection;

public class ImmutableKeyInfo {

    private Collection<User> user;

	/**
	 * @param user
	 */
	public ImmutableKeyInfo(Collection<User> user) {
		this.user = user;
	}

	/**
	 * @return the user
	 */
	public Collection<User> getUser() {
		return user;
	}

	/**
	 * @param user the user to set
	 */
	public void setUser(Collection<User> user) {
		this.user = user;
	}

}
