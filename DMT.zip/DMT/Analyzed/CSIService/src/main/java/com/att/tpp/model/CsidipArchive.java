package com.att.tpp.model;

import java.io.Serializable;

import javax.persistence.*;

import org.hibernate.annotations.GenericGenerator;

import java.math.BigDecimal;
import java.util.Date;


/**
 * The persistent class for the CSIDIP_ARCHIVE database table.
 * 
 */
@Entity
@Table(name="CSIDIP_ARCHIVE")
@NamedQuery(name="CsidipArchive.findAll", query="SELECT c FROM CsidipArchive c")
public class CsidipArchive implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	private BigDecimal csidipcount;

	private String errorcode;

	private String errordesc;

	@Column(name="EVENT_NAME")
	private String eventName;

	@Lob
	@Column(name="LOAD_XML")
	private String loadXml;

	private BigDecimal maxcsicount;

	private String msisdn;

	private String provsystrxid;

	private String subid;

	@Temporal(TemporalType.TIMESTAMP)
	@Column(name="\"TIMESTAMP\"")
	private Date timestamp;

	public CsidipArchive() {
	}

	//Modify the DB column lenght.
	@GenericGenerator(name="generator", strategy="increment")
	@GeneratedValue(generator="generator")
	public BigDecimal getCsidipcount() {
		return this.csidipcount;
	}

	public void setCsidipcount(BigDecimal csidipcount) {
		this.csidipcount = csidipcount;
	}

	public String getErrorcode() {
		return this.errorcode;
	}

	public void setErrorcode(String errorcode) {
		this.errorcode = errorcode;
	}

	public String getErrordesc() {
		return this.errordesc;
	}

	public void setErrordesc(String errordesc) {
		this.errordesc = errordesc;
	}

	public String getEventName() {
		return this.eventName;
	}

	public void setEventName(String eventName) {
		this.eventName = eventName;
	}

	public String getLoadXml() {
		return this.loadXml;
	}

	public void setLoadXml(String loadXml) {
		this.loadXml = loadXml;
	}

	public BigDecimal getMaxcsicount() {
		return this.maxcsicount;
	}

	public void setMaxcsicount(BigDecimal maxcsicount) {
		this.maxcsicount = maxcsicount;
	}

	public String getMsisdn() {
		return this.msisdn;
	}

	public void setMsisdn(String msisdn) {
		this.msisdn = msisdn;
	}

	public String getProvsystrxid() {
		return this.provsystrxid;
	}

	public void setProvsystrxid(String provsystrxid) {
		this.provsystrxid = provsystrxid;
	}

	public String getSubid() {
		return this.subid;
	}

	public void setSubid(String subid) {
		this.subid = subid;
	}

	public Date getTimestamp() {
		return this.timestamp;
	}

	public void setTimestamp(Date timestamp) {
		this.timestamp = timestamp;
	}

	


}