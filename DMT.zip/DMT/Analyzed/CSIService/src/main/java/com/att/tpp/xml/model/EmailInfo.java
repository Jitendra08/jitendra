package com.att.tpp.xml.model;

public class EmailInfo {

    private String emailAddress;
    private String emailType;
    private Boolean primaryAddressIndicator;
    private LanguagePreferenceInfo language;
 
	/**
	 * @param emailAddress
	 * @param emailType
	 */
	public EmailInfo(String emailAddress, String emailType) {
		this.emailAddress = emailAddress;
		this.emailType = emailType;
	}

	/**
	 * @param emailAddress
	 * @param emailType
	 * @param primaryAddressIndicator
	 * @param language
	 */
	public EmailInfo(String emailAddress, String emailType,
			Boolean primaryAddressIndicator, LanguagePreferenceInfo language) {
		this.emailAddress = emailAddress;
		this.emailType = emailType;
		this.primaryAddressIndicator = primaryAddressIndicator;
		this.language = language;
	}

	/**
     * Gets the value of the emailAddress property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getEmailAddress() {
        return emailAddress;
    }

    /**
     * Sets the value of the emailAddress property.
     * 
     * @param emailAddress
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setEmailAddress(String emailAddress) {
        this.emailAddress = emailAddress;
    }

    /**
     * Gets the value of the emailType property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getEmailType() {
        return emailType;
    }

    /**
     * Sets the value of the emailType property.
     * 
     * @param emailType
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setEmailType(String emailType) {
        this.emailType = emailType;
    }

    /**
     * Gets the value of the primaryAddressIndicator property.
     * 
     * @return
     *     possible object is
     *     {@link Boolean }
     *     
     */
    public Boolean isPrimaryAddressIndicator() {
        return primaryAddressIndicator;
    }

    /**
     * Sets the value of the primaryAddressIndicator property.
     * 
     * @param primaryAddressIndicator
     *     allowed object is
     *     {@link Boolean }
     *     
     */
    public void setPrimaryAddressIndicator(Boolean primaryAddressIndicator) {
        this.primaryAddressIndicator = primaryAddressIndicator;
    }

    /**
     * Gets the value of the language property.
     * 
     * @return
     *     possible object is
     *     {@link LanguagePreferenceInfo }
     *     
     */
    public LanguagePreferenceInfo getLanguage() {
        return language;
    }

    /**
     * Sets the value of the language property.
     * 
     * @param language
     *     allowed object is
     *     {@link LanguagePreferenceInfo }
     *     
     */
    public void setLanguage(LanguagePreferenceInfo language) {
        this.language = language;
    }

}
