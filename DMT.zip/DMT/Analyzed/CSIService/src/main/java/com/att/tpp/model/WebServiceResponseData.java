package com.att.tpp.model;

import java.io.Serializable;
import java.math.BigDecimal;
import java.util.Date;

import com.att.tpp.xml.model.OrderDocumentInfo;




public class WebServiceResponseData implements Serializable{


	private static final long serialVersionUID = 1L;
	
	private String carrierName;
	private String csiResponsecode;
	private String csiResponsedesc;
	private String inputXml;
	private String interfaceName;
	private String location;
	private String orderid;
	private OrderDocumentInfo structuredOrderId;
	private String fulfillmentId;
	private BigDecimal retryCount;
	private String retryStatus;
	private String routingCarrier;
	private String skuStatus;
	private Date timeStamp;
	private String tppTransactionid;
	private String tppcsiTransactionid;
	private String vendorName;
	private String errorMessage;
	private boolean isFulfillmentValidation=false;
	private String fulfillmentValidationXML;
	private String masterTransId;
	
	public String getCarrierName() {
		return carrierName;
	}
	public void setCarrierName(String carrierName) {
		this.carrierName = carrierName;
	}
	public String getCsiResponsecode() {
		return csiResponsecode;
	}
	public void setCsiResponsecode(String csiResponsecode) {
		this.csiResponsecode = csiResponsecode;
	}
	public String getCsiResponsedesc() {
		return csiResponsedesc;
	}
	public void setCsiResponsedesc(String csiResponsedesc) {
		this.csiResponsedesc = csiResponsedesc;
	}
	public String getInputXml() {
		return inputXml;
	}
	public void setInputXml(String inputXml) {
		this.inputXml = inputXml;
	}
	public String getInterfaceName() {
		return interfaceName;
	}
	public void setInterfaceName(String interfaceName) {
		this.interfaceName = interfaceName;
	}
	public String getLocation() {
		return location;
	}
	public void setLocation(String location) {
		this.location = location;
	}
	public String getOrderid() {
		return orderid;
	}
	public void setOrderid(String orderid) {
		this.orderid = orderid;
	}
	public OrderDocumentInfo getStructuredOrderId() {
		return structuredOrderId;
	}
	public void setStructuredOrderId(OrderDocumentInfo structuredOrderId) {
		this.structuredOrderId = structuredOrderId;
	}
	public String getFulfillmentId() {
		return fulfillmentId;
	}
	public void setFulfillmentId(String fulfillmentId) {
		this.fulfillmentId = fulfillmentId;
	}
	public BigDecimal getRetryCount() {
		return retryCount;
	}
	public void setRetryCount(BigDecimal retryCount) {
		this.retryCount = retryCount;
	}
	public String getRetryStatus() {
		return retryStatus;
	}
	public void setRetryStatus(String retryStatus) {
		this.retryStatus = retryStatus;
	}
	public String getRoutingCarrier() {
		return routingCarrier;
	}
	public void setRoutingCarrier(String routingCarrier) {
		this.routingCarrier = routingCarrier;
	}
	public String getSkuStatus() {
		return skuStatus;
	}
	public void setSkuStatus(String skuStatus) {
		this.skuStatus = skuStatus;
	}
	public Date getTimeStamp() {
		return timeStamp;
	}
	public void setTimeStamp(Date timeStamp) {
		this.timeStamp = timeStamp;
	}
	public String getTppTransactionid() {
		return tppTransactionid;
	}
	public void setTppTransactionid(String tppTransactionid) {
		this.tppTransactionid = tppTransactionid;
	}
	public String getTppcsiTransactionid() {
		return tppcsiTransactionid;
	}
	public void setTppcsiTransactionid(String tppcsiTransactionid) {
		this.tppcsiTransactionid = tppcsiTransactionid;
	}
	public String getVendorName() {
		return vendorName;
	}
	public void setVendorName(String vendorName) {
		this.vendorName = vendorName;
	}
	public String getErrorMessage() {
		return errorMessage;
	}
	public void setErrorMessage(String errorMessage) {
		this.errorMessage = errorMessage;
	}
	public boolean isFulfillmentValidation() {
		return isFulfillmentValidation;
	}
	public void setFulfillmentValidation(boolean isFulfillmentValidation) {
		this.isFulfillmentValidation = isFulfillmentValidation;
	}
	public String getFulfillmentValidationXML() {
		return fulfillmentValidationXML;
	}
	public void setFulfillmentValidationXML(String fulfillmentValidationXML) {
		this.fulfillmentValidationXML = fulfillmentValidationXML;
	}
	public String getMasterTransId() {
		return masterTransId;
	}
	public void setMasterTransId(String masterTransId) {
		this.masterTransId = masterTransId;
	}


	
}
