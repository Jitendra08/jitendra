package com.att.tpp.xml.model;

public enum SubscriberStatusInfo {

    R,
    A,
    C,
    S,
    L;

    public String value() {
        return name();
    }

    public static SubscriberStatusInfo fromValue(String v) {
        return valueOf(v);
    }

}
