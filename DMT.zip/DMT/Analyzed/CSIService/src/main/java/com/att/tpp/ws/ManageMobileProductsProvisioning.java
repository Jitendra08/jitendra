package com.att.tpp.ws;

import com.att.tpp.model.CSIResponseKeys;
import com.att.tpp.model.WebServiceResponseData;
import com.att.tpp.utils.CSIServiceMessageParser;
import com.cingular.csi.csi.namespaces.v118.wsdl.cingularwirelesscsi.CSIApplicationException;

public interface ManageMobileProductsProvisioning {
	
	WebServiceResponseData doManageMobileProductsProvisioning(CSIResponseKeys csiResponseKeys, String requestXML, String provSystemTransId) throws CSIApplicationException, Exception;

	WebServiceResponseData invokeDCMNotification(String requestXML,
			String eventType, String methodName,
			WebServiceResponseData webServiceResponseData,
			CSIServiceMessageParser csiMessageParser, String provSystemTransId)  throws CSIApplicationException, Exception;

}
