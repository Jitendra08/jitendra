package com.att.tpp.xml.model;

public enum ProvisioningCarrier {

    AWSCV_2("AWSCV2"),
    CARIBB("CARIBB"),
    SMS_SE("SMS_SE"),
    SMS_SW("SMS_SW"),
    SMS_NE("SMS_NE"),
    SMS_WE("SMS_WE"),
    CNGULR("CNGULR"),
    ATT("ATT"),
    CSI("CSI");

    private final String value;

    ProvisioningCarrier(String v) {
        value = v;
    }

    public String value() {
        return value;
    }

    public static ProvisioningCarrier fromValue(String v) {
        for (ProvisioningCarrier c: ProvisioningCarrier.values()) {
            if (c.value.equals(v)) {
                return c;
            }
        }
        throw new IllegalArgumentException(v);
    }

}
