package com.att.tpp.xml.model;

public class TNInfo {

	private String externalKey;
	private String nenaid;
	private String cls;
	private String tys;
	private String latitude;
    private String longitude;

    /**
	 * @param externalKey
	 * @param nenaid
	 * @param cls
	 * @param tys
	 * @param latitude
	 * @param longitude
	 */
	public TNInfo(String externalKey, String nenaid, String cls, String tys,
			String latitude, String longitude) {
		this.externalKey = externalKey;
		this.nenaid = nenaid;
		this.cls = cls;
		this.tys = tys;
		this.latitude = latitude;
		this.longitude = longitude;
	}

	/**
     * Gets the value of the externalKey property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getExternalKey() {
        return externalKey;
    }

    /**
     * Sets the value of the externalKey property.
     * 
     * @param externalKey
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setExternalKey(String externalKey) {
        this.externalKey = externalKey;
    }

    /**
     * Gets the value of the nenaid property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getNENAID() {
        return nenaid;
    }

    /**
     * Sets the value of the nenaid property.
     * 
     * @param nenaid
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setNENAID(String nenaid) {
        this.nenaid = nenaid;
    }

    /**
     * Gets the value of the cls property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCLS() {
        return cls;
    }

    /**
     * Sets the value of the cls property.
     * 
     * @param cls
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCLS(String cls) {
        this.cls = cls;
    }

    /**
     * Gets the value of the tys property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getTYS() {
        return tys;
    }

    /**
     * Sets the value of the tys property.
     * 
     * @param tys
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setTYS(String tys) {
        this.tys = tys;
    }

    /**
     * Gets the value of the latitude property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getLatitude() {
        return latitude;
    }

    /**
     * Sets the value of the latitude property.
     * 
     * @param latitude
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setLatitude(String latitude) {
        this.latitude = latitude;
    }

    /**
     * Gets the value of the longitude property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getLongitude() {
        return longitude;
    }

    /**
     * Sets the value of the longitude property.
     * 
     * @param longitude
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setLongitude(String longitude) {
        this.longitude = longitude;
    }

}
