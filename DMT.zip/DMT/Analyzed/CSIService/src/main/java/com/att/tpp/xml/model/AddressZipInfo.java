package com.att.tpp.xml.model;

public class AddressZipInfo {

    private String zipCode;
    private String zipCodeExtension;
    private String zipGeoCode;

    /**
	 * @param zipCode
	 */
	public AddressZipInfo(String zipCode) {
		this.zipCode = zipCode;
	}

	/**
	 * @param zipCode
	 * @param zipCodeExtension
	 * @param zipGeoCode
	 */
	public AddressZipInfo(String zipCode, String zipCodeExtension,
			String zipGeoCode) {
		this.zipCode = zipCode;
		this.zipCodeExtension = zipCodeExtension;
		this.zipGeoCode = zipGeoCode;
	}

	/**
     * Gets the value of the zipCode property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getZipCode() {
        return zipCode;
    }

    /**
     * Sets the value of the zipCode property.
     * 
     * @param zipCode
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setZipCode(String zipCode) {
        this.zipCode = zipCode;
    }

    /**
     * Gets the value of the zipCodeExtension property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getZipCodeExtension() {
        return zipCodeExtension;
    }

    /**
     * Sets the value of the zipCodeExtension property.
     * 
     * @param zipCodeExtension
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setZipCodeExtension(String zipCodeExtension) {
        this.zipCodeExtension = zipCodeExtension;
    }

    /**
     * Gets the value of the zipGeoCode property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getZipGeoCode() {
        return zipGeoCode;
    }

    /**
     * Sets the value of the zipGeoCode property.
     * 
     * @param zipGeoCode
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setZipGeoCode(String zipGeoCode) {
        this.zipGeoCode = zipGeoCode;
    }

}
