package com.att.tpp.xml.model;

public enum AccountType {

    B,
    G,
    S,
    I,
    E,
    A,
    T,
    C,
    J,
    K,
    L,
    M,
    N,
    O,
    P,
    R,
    W,
    Z,
    U,
    H;

    public String value() {
        return name();
    }

    public static AccountType fromValue(String v) {
        return valueOf(v);
    }

}
