package com.att.tpp.xml.model;

import java.util.Collection;

public class MarketingOptions {

	private Collection<MarketingOption> marketingOption;

	/**
	 * @param marketingOption
	 */
	public MarketingOptions(Collection<MarketingOption> marketingOption) {
		this.marketingOption = marketingOption;
	}

	/**
	 * @return the marketingOption
	 */
	public Collection<MarketingOption> getMarketingOption() {
		return marketingOption;
	}

	/**
	 * @param marketingOption the marketingOption to set
	 */
	public void setMarketingOption(Collection<MarketingOption> marketingOption) {
		this.marketingOption = marketingOption;
	}

}
