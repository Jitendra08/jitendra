/**
 * 
 */
package com.att.tpp.utils;

import java.sql.Timestamp;
import java.util.Date;
import java.util.GregorianCalendar;

import javax.xml.datatype.DatatypeConfigurationException;
import javax.xml.datatype.DatatypeFactory;
import javax.xml.datatype.XMLGregorianCalendar;

/**
 * @author SC9833
 *
 */
public class XMLDateUtil {

	/**
	 * 
	 */
	public static XMLGregorianCalendar getNow() throws DatatypeConfigurationException{
		
		GregorianCalendar gregory = new GregorianCalendar();
		gregory.setTimeInMillis(new Date().getTime());
		
		XMLGregorianCalendar dateTS = null;
		
		try {
			
			dateTS = DatatypeFactory.newInstance()
			        .newXMLGregorianCalendar(
			            gregory);			
//			
//			System.out.println("Day: " + dateTS.getDay());
//			System.out.println("Date: " + dateTS.normalize().toString());
			
			return dateTS.normalize();
			
		} catch (DatatypeConfigurationException dce) {
			throw dce;			
		}		
		
	}
	
	public Timestamp getTimeStamp(){
		GregorianCalendar gregory = new GregorianCalendar();		
		gregory.setTimeInMillis(new Date().getTime());		
		Timestamp ts = new Timestamp(gregory.getTimeInMillis());		
		//System.out.println(ts.toString());
		return ts;
	}
	

}
