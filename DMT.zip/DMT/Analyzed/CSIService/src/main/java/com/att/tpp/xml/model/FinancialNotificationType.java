package com.att.tpp.xml.model;

public class FinancialNotificationType {

    private String adjustmentAmount;
    private String adjustmentCode;

    /**
	 * @param adjustmentAmount
	 * @param adjustmentCode
	 */
	public FinancialNotificationType(String adjustmentAmount,
			String adjustmentCode) {
		this.adjustmentAmount = adjustmentAmount;
		this.adjustmentCode = adjustmentCode;
	}

	/**
     * Gets the value of the adjustmentAmount property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getAdjustmentAmount() {
        return adjustmentAmount;
    }

    /**
     * Sets the value of the adjustmentAmount property.
     * 
     * @param adjustmentAmount
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setAdjustmentAmount(String adjustmentAmount) {
        this.adjustmentAmount = adjustmentAmount;
    }

    /**
     * Gets the value of the adjustmentCode property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getAdjustmentCode() {
        return adjustmentCode;
    }

    /**
     * Sets the value of the adjustmentCode property.
     * 
     * @param adjustmentCode
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setAdjustmentCode(String adjustmentCode) {
        this.adjustmentCode = adjustmentCode;
    }

}
