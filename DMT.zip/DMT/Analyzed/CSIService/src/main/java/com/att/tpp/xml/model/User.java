package com.att.tpp.xml.model;

import java.util.Collection;

public class User {

	private String action;
	private UserIDInfo userID;
    private Collection<AttachedIDInfo> attachedIDs;
    
    /**
	 * @param action
	 * @param userID
	 */
	public User(String action, UserIDInfo userID) {
		this.action = action;
		this.userID = userID;
	}

	/**
	 * @param action
	 * @param userID
	 * @param attachedIDs
	 */
	public User(String action, UserIDInfo userID,
			Collection<AttachedIDInfo> attachedIDs) {
		this.action = action;
		this.userID = userID;
		this.attachedIDs = attachedIDs;
	}

	/**
     * Gets the value of the action property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getAction() {
        return action;
    }

    /**
     * Sets the value of the action property.
     * 
     * @param action
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setAction(String action) {
        this.action = action;
    }
    
    /**
     * Gets the value of the userID property.
     * 
     * @return
     *     possible object is
     *     {@link UserIDInfo }
     *     
     */
    public UserIDInfo getUserID() {
        return userID;
    }

    /**
     * Sets the value of the userID property.
     * 
     * @param userID
     *     allowed object is
     *     {@link UserIDInfo }
     *     
     */
    public void setUserID(UserIDInfo userID) {
        this.userID = userID;
    }

    /**
	 * @return the attachedIDs
	 */
	public Collection<AttachedIDInfo> getAttachedIDs() {
		return attachedIDs;
	}

	/**
	 * @param attachedIDs the attachedIDs to set
	 */
	public void setAttachedIDs(Collection<AttachedIDInfo> attachedIDs) {
		this.attachedIDs = attachedIDs;
	}	

}
