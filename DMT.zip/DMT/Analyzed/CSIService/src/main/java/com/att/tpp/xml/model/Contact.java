package com.att.tpp.xml.model;

public class Contact {

	private String namePrefix;
	private String firstName;
	private String middleName;
	private String lastName;
	private String nameSuffix;
	private String phoneNumber;
	private String personalEmailAddress;
	private String businessEmailAddress;
	
	/**
	 * @param namePrefix
	 * @param firstName
	 * @param middleName
	 * @param lastName
	 * @param nameSuffix
	 * @param phoneNumber
	 * @param personalEmailAddress
	 * @param businessEmailAddress
	 */
	public Contact(String namePrefix, String firstName, String middleName,
			String lastName, String nameSuffix, String phoneNumber,
			String personalEmailAddress, String businessEmailAddress) {
		this.namePrefix = namePrefix;
		this.firstName = firstName;
		this.middleName = middleName;
		this.lastName = lastName;
		this.nameSuffix = nameSuffix;
		this.phoneNumber = phoneNumber;
		this.personalEmailAddress = personalEmailAddress;
		this.businessEmailAddress = businessEmailAddress;
	}

	/**
	 * @return the namePrefix
	 */
	public String getNamePrefix() {
		return namePrefix;
	}
	
	/**
	 * @param namePrefix the namePrefix to set
	 */
	public void setNamePrefix(String namePrefix) {
		this.namePrefix = namePrefix;
	}
	
	/**
	 * @return the firstName
	 */
	public String getFirstName() {
		return firstName;
	}
	
	/**
	 * @param firstName the firstName to set
	 */
	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}
	
	/**
	 * @return the middleName
	 */
	public String getMiddleName() {
		return middleName;
	}
	
	/**
	 * @param middleName the middleName to set
	 */
	public void setMiddleName(String middleName) {
		this.middleName = middleName;
	}
	
	/**
	 * @return the lastName
	 */
	public String getLastName() {
		return lastName;
	}
	
	/**
	 * @param lastName the lastName to set
	 */
	public void setLastName(String lastName) {
		this.lastName = lastName;
	}
	
	/**
	 * @return the nameSuffix
	 */
	public String getNameSuffix() {
		return nameSuffix;
	}
	
	/**
	 * @param nameSuffix the nameSuffix to set
	 */
	public void setNameSuffix(String nameSuffix) {
		this.nameSuffix = nameSuffix;
	}
	
	/**
	 * @return the phoneNumber
	 */
	public String getPhoneNumber() {
		return phoneNumber;
	}
	
	/**
	 * @param phoneNumber the phoneNumber to set
	 */
	public void setPhoneNumber(String phoneNumber) {
		this.phoneNumber = phoneNumber;
	}
	
	/**
	 * @return the personalEmailAddress
	 */
	public String getPersonalEmailAddress() {
		return personalEmailAddress;
	}
	
	/**
	 * @param personalEmailAddress the personalEmailAddress to set
	 */
	public void setPersonalEmailAddress(String personalEmailAddress) {
		this.personalEmailAddress = personalEmailAddress;
	}
	
	/**
	 * @return the businessEmailAddress
	 */
	public String getBusinessEmailAddress() {
		return businessEmailAddress;
	}
	
	/**
	 * @param businessEmailAddress the businessEmailAddress to set
	 */
	public void setBusinessEmailAddress(String businessEmailAddress) {
		this.businessEmailAddress = businessEmailAddress;
	}
    
}
