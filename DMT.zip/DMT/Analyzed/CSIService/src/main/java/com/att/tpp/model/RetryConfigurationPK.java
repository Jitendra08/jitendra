package com.att.tpp.model;

import java.io.Serializable;
import javax.persistence.*;

/**
 * The primary key class for the RETRY_CONFIGURATION database table.
 * 
 */
@Embeddable
public class RetryConfigurationPK implements Serializable {
	//default serial version id, required for serializable classes.
	private static final long serialVersionUID = 1L;

	@Column(name="SYSTEM_NAME", insertable=false, updatable=false)
	private String systemName;

	@Column(name="RETRY_ATTEMPT_NUM")
	private long retryAttemptNum;

	@Column(name="RETRY_TYPE")
	private String retryType;

	public RetryConfigurationPK() {
	}
	public String getSystemName() {
		return this.systemName;
	}
	public void setSystemName(String systemName) {
		this.systemName = systemName;
	}
	public long getRetryAttemptNum() {
		return this.retryAttemptNum;
	}
	public void setRetryAttemptNum(long retryAttemptNum) {
		this.retryAttemptNum = retryAttemptNum;
	}
	public String getRetryType() {
		return this.retryType;
	}
	public void setRetryType(String retryType) {
		this.retryType = retryType;
	}
}