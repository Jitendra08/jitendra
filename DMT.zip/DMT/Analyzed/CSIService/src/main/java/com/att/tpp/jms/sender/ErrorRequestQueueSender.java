package com.att.tpp.jms.sender;

import javax.jms.JMSException;
import javax.jms.Message;
import javax.jms.Queue;
import javax.jms.Session;
import javax.jms.TextMessage;

import org.apache.log4j.Logger;
import org.springframework.jms.core.JmsTemplate;
import org.springframework.jms.core.MessageCreator;

/**
 * 
 * The ErrorRequestQueueSender class uses the injected JMSTemplate to send a message
 * to Error queue. 
 */
public class ErrorRequestQueueSender
{
	private JmsTemplate jmsTemplate;
	private Queue errorRequestQueue;
	private static final Logger errorRequestSenderLog = Logger.getLogger(ErrorRequestQueueSender.class);
	private final static String swcTransactionId = "swcTransactionId";
	
	/**
	 * Sends message to finalTransRequestQueue using JMS Template.
	 * @param messageId 
	 * @param provReqXML the message_p
	 * @throws JMSException the jms exception
	 */
	public void sendMessage(final String errorRequestXML, final String messageId) throws JMSException
	{
		
		errorRequestSenderLog.info("Sending ErrorRequest Message From CSI Service to Error Service");

		jmsTemplate.send(this.errorRequestQueue, new MessageCreator(){

			@Override
			public Message createMessage(Session session) throws JMSException {
				TextMessage message = session.createTextMessage(errorRequestXML.toString());
				message.setStringProperty(swcTransactionId,messageId);	
				errorRequestSenderLog.info("Message sent: " + message);
				return message;
			}
			
		});		
		
	}
	/**
	 * Sets the jms template.
	 *
	 * @param template the jms template
	 */
	public void setJmsTemplate(JmsTemplate tmpl)
	{
		this.jmsTemplate = tmpl;
	}


	
	public void setErrorRequestQueue(Queue errorRequestQueue) {
		this.errorRequestQueue = errorRequestQueue;
	}

	
}