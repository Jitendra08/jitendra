/**
 * 
 */
package com.att.tpp.model;

import java.io.Serializable;
import java.util.List;

import com.att.tpp.xml.model.OrderDocumentInfo;
import com.cingular.csi.csi.namespaces.container._public.managemobileproductsprovisioningrequest.ManageMobileProductsProvisioningRequestInfo.Product;
import com.cingular.csi.csi.namespaces.types._public.cingulardatamodel.ShipmentLineInfo;

/**
 * @author SC9833
 *
 */
public class CSIResponseKeys implements Serializable {

	private static final long serialVersionUID = 1L;
	
	
	private String ban;
	private String msisdn;
	
	
	/**
	 * This is the MSISDN without the leading "1".  
	 * The field length is 10 digits.
	 * Used for calls to CSI Web Services since they leverage CTN over MSISDN
	 */
	private String ctn;  
	
	/**
	 * To be used with AddNote, SendSMS, and SendEmail	
	 */
	private String inputText;	
		 
	private String eventType;
	private String messageTransactionID;
	
	private List<String> noteTextList;
	

	/**
	 * @return the noteTextList
	 */
	public List<String> getNoteTextList() {
		return noteTextList;
	}

	/**
	 * @param noteTextList the noteTextList to set
	 */
	public void setNoteTextList(List<String> noteTextList) {
		this.noteTextList = noteTextList;
	}

	/**
	 * tppcsiTransactionId = Generated Transaction ID 
	 * Mainly used for CSI Service Response Web Service calls for SKU Responses.
	 */
	private String tppCSITransactionID; 
	
	/**
	 * For use with SKU Responses
	 */
	private OrderDocumentInfo orderId;
	private String reasonCode;
	private String comment;
	private String fulfillmentId;
	private String fulfillmentType;
	private String carrierId;
	private List<ShipmentLineInfo> shipmentLineInfo;
	
	
	/**
	 * For use with Femtocell Notifications to CSI
	 */
	private String femtocellAction;
	private String femtocellCode;
	private String femtocellDescription;
	
	
	/**
	 * For use with Smallcell Notifications to eSCORE
	 */
	private String externalKey;
	private String aliUpdateResponseVersion;
	
	
	/**
	 * For use with DCM Notification Response to CSI
	 * 
	 */
	/* Changed the single Product to List<Product> to support multiple product in DCM request*/
	//private Product product;
	private List<Product> product;
	private String action;
	
	
	private String provisioningCarrier;
	private String routingCarrier;
	private String systemName;
	
	
	/**
	 * 
	 */
	public CSIResponseKeys() {}

	/**
	 * @return the ban
	 */
	public String getBan() {
		return ban;
	}

	/**
	 * @param ban the ban to set
	 */
	public void setBan(String ban) {
		this.ban = ban;
	}	
	
	/**
	 * @return the msisdn
	 */
	public String getMsisdn() {
		return msisdn;
	}

	/**
	 * @param msisdn the msisdn to set
	 */
	public void setMsisdn(String msisdn) {
		this.msisdn = msisdn;
	}

	/**
	 * @return the ctn
	 */
	public String getCtn() {
		return ctn;
	}

	/**
	 * @param ctn the ctn to set
	 */
	public void setCtn(String ctn) {
		this.ctn = ctn;
	}

	/**
	 * @return the inputText
	 */
	public String getInputText() {
		return inputText;
	}

	/**
	 * @param inputText the inputText to set
	 */
	public void setInputText(String inputText) {
		this.inputText = inputText;
	}

	/**
	 * @return the tppCSITransactionID
	 */
	public String getTppCSITransactionID() {
		return tppCSITransactionID;
	}
	
	/**
	 * @param tppCSITransactionID the tppCSITransactionID to set
	 */
	public void setTppCSITransactionID(String tppCSITransactionID) {
		this.tppCSITransactionID = tppCSITransactionID;
	}
	
	/**
	 * @return the orderId
	 */
	public OrderDocumentInfo getOrderId() {
		return orderId;
	}
	
	/**
	 * @param orderId the orderId to set
	 */
	public void setOrderId(OrderDocumentInfo orderId) {
		this.orderId = orderId;
	}
	
	/**
	 * @return the reasonCode
	 */
	public String getReasonCode() {
		return reasonCode;
	}
	
	/**
	 * @param reasonCode the reasonCode to set
	 */
	public void setReasonCode(String reasonCode) {
		this.reasonCode = reasonCode;
	}
	
	/**
	 * @return the comment
	 */
	public String getComment() {
		return comment;
	}
	
	/**
	 * @param comment the comment to set
	 */
	public void setComment(String comment) {
		this.comment = comment;
	}
	
	/**
	 * @return the fulfillmentId
	 */
	public String getFulfillmentId() {
		return fulfillmentId;
	}

	/**
	 * @param fulfillmentId the fulfillmentId to set
	 */
	public void setFulfillmentId(String fulfillmentId) {
		this.fulfillmentId = fulfillmentId;
	}

	/**
	 * @return the fulfillmentType
	 */
	public String getFulfillmentType() {
		return fulfillmentType;
	}

	/**
	 * @param fulfillmentType the fulfillmentType to set
	 */
	public void setFulfillmentType(String fulfillmentType) {
		this.fulfillmentType = fulfillmentType;
	}

	/**
	 * @return the carrierId
	 */
	public String getCarrierId() {
		return carrierId;
	}

	/**
	 * @param carrierId the carrierId to set
	 */
	public void setCarrierId(String carrierId) {
		this.carrierId = carrierId;
	}

	/**
	 * @return the shipmentLineInfo
	 */
	public List<ShipmentLineInfo> getShipmentLineInfo() {
		return shipmentLineInfo;
	}

	/**
	 * @param shipmentLineInfo the shipmentLineInfo to set
	 */
	public void setShipmentLineInfo(List<ShipmentLineInfo> shipmentLineInfo) {
		this.shipmentLineInfo = shipmentLineInfo;
	}

	/**
	 * @return the eventType
	 */
	public String getEventType() {
		return eventType;
	}
	
	/**
	 * @param eventType the eventType to set
	 */
	public void setEventType(String eventType) {
		this.eventType = eventType;
	}

	/**
	 * @return the messageTransactionID
	 */
	public String getMessageTransactionID() {
		return messageTransactionID;
	}

	/**
	 * @param messageTransactionID the messageTransactionID to set
	 */
	public void setMessageTransactionID(String messageTransactionID) {
		this.messageTransactionID = messageTransactionID;
	}
	
	/**
	 * @return the femtocellAction
	 */
	public String getFemtocellAction() {
		return femtocellAction;
	}

	/**
	 * @param femtocellAction the femtocellAction to set
	 */
	public void setFemtocellAction(String femtocellAction) {
		this.femtocellAction = femtocellAction;
	}

	/**
	 * @return the femtocellCode
	 */
	public String getFemtocellCode() {
		return femtocellCode;
	}

	/**
	 * @param femtocellCode the femtocellCode to set
	 */
	public void setFemtocellCode(String femtocellCode) {
		this.femtocellCode = femtocellCode;
	}

	/**
	 * @return the femtocellDescription
	 */
	public String getFemtocellDescription() {
		return femtocellDescription;
	}

	/**
	 * @param femtocellDescription the femtocellDescription to set
	 */
	public void setFemtocellDescription(String femtocellDescription) {
		this.femtocellDescription = femtocellDescription;
	}

	/**
	 * @return the externalKey
	 */
	public String getExternalKey() {
		return externalKey;
	}

	/**
	 * @param externalKey the externalKey to set
	 */
	public void setExternalKey(String externalKey) {
		this.externalKey = externalKey;
	}

	/**
	 * @return the aliUpdateResponseVersion
	 */
	public String getAliUpdateResponseVersion() {
		return aliUpdateResponseVersion;
	}

	/**
	 * @param aliUpdateResponseVersion the aliUpdateResponseVersion to set
	 */
	public void setAliUpdateResponseVersion(String aliUpdateResponseVersion) {
		this.aliUpdateResponseVersion = aliUpdateResponseVersion;
	}

	/**
	 * @return the product
	 */
	/*public Product getProduct() {
		return product;
	}
*/
	/**
	 * @param product the product to set
	 */
/*	public void setProduct(Product product) {
		this.product = product;
	}
*/
	public String getAction() {
		return action;
	}

	public void setAction(String action) {
		this.action = action;
	}

	public String getConcatOrderID(){
		return orderId.getLocation() + "-" + orderId.getActivity() + "-" + orderId.getOrderId();
	}

	public String getSystemName() {
		return systemName;
	}

	public void setSystemName(String systemName) {
		this.systemName = systemName;
	}

	public String getProvisioningCarrier() {
		return provisioningCarrier;
	}

	public void setProvisioningCarrier(String provisioningCarrier) {
		this.provisioningCarrier = provisioningCarrier;
	}

	public String getRoutingCarrier() {
		return routingCarrier;
	}

	public void setRoutingCarrier(String routingCarrier) {
		this.routingCarrier = routingCarrier;
	}

	/**
	 * @return the product
	 */
	public List<Product> getProduct() {
		return product;
	}

	/**
	 * @param product the product to set
	 */
	public void setProduct(List<Product> product) {
		this.product = product;
	}
	

}
