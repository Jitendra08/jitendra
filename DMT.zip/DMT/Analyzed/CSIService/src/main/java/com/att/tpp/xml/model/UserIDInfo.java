package com.att.tpp.xml.model;

public class UserIDInfo {

    private SelectedUserInfo id;
    private String guid;

    /**
	 * @param id
	 * @param guid
	 */
	public UserIDInfo(SelectedUserInfo id, String guid) {
		this.id = id;
		this.guid = guid;
	}

	/**
     * Gets the value of the id property.
     * 
     * @return
     *     possible object is
     *     {@link SelectedUserInfo }
     *     
     */
    public SelectedUserInfo getID() {
        return id;
    }

    /**
     * Sets the value of the id property.
     * 
     * @param id
     *     allowed object is
     *     {@link SelectedUserInfo }
     *     
     */
    public void setID(SelectedUserInfo id) {
        this.id = id;
    }

    /**
     * Gets the value of the guid property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getGUID() {
        return guid;
    }

    /**
     * Sets the value of the guid property.
     * 
     * @param guid
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setGUID(String guid) {
        this.guid = guid;
    }

}
