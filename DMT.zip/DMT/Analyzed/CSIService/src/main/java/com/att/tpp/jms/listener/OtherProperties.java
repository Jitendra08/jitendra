package com.att.tpp.jms.listener;

import java.io.Serializable;

public class OtherProperties implements Serializable {
	 
	private static final long serialVersionUID = 1L;

	private String requestXML;
	private String eventType;
	private String actionFemto;
	private String transactionId;
	private String masterTransId;
	
	
	public String getRequestXML() {
		return requestXML;
	}
	public void setRequestXML(String requestXML) {
		this.requestXML = requestXML;
	}
	public String getEventType() {
		return eventType;
	}
	public void setEventType(String eventType) {
		this.eventType = eventType;
	}
	public String getActionFemto() {
		return actionFemto;
	}
	public void setActionFemto(String actionFemto) {
		this.actionFemto = actionFemto;
	}
	public String getTransactionId() {
		return transactionId;
	}
	public void setTransactionId(String transactionId) {
		this.transactionId = transactionId;
	}
	public String getMasterTransId() {
		return masterTransId;
	}
	public void setMasterTransId(String masterTransId) {
		this.masterTransId = masterTransId;
	}
	
	
}
