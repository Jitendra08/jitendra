/**
 * 
 */
package com.att.tpp.utils;

import java.beans.ConstructorProperties;

import org.apache.log4j.Logger;

/**
 * @author sc9833
 *
 */
public class PropertiesUtil {
	
	private static final Logger propertiesUtilLog = Logger.getLogger(PropertiesUtil.class);
	
	private String vtierName;

	/**
	 * @param location
	 */
	@ConstructorProperties({"vtierName"})
	public PropertiesUtil(String vtierName) {
		this.vtierName = vtierName;
	}
	
	public String getLocation(String tppTransactionid) {
		String location = "No Location";
		if(tppTransactionid.contains("$")){
			location = tppTransactionid.substring(tppTransactionid.indexOf("$")+1, tppTransactionid.length());
				propertiesUtilLog.info("Getting Location from tppTransactionId: " + location);						
		}
		else{			
			location = vtierName;			
		}
		propertiesUtilLog.info("Location: "+ location +" from TaskTransactionId: "+tppTransactionid);
		return location;
	}

}
