package com.att.tpp.ws;

import com.att.tpp.model.CSIResponseKeys;
import com.att.tpp.model.WebServiceResponseData;
import com.att.tpp.utils.CSIServiceMessageParser;
import com.cingular.csi.csi.namespaces.v118.wsdl.cingularwirelesscsi.CSIApplicationException;

public interface AddOrderNotesNotification {
	
	WebServiceResponseData doAdd3PPOrderNotesRequest(CSIResponseKeys csiResponseKeys, String requestXML) throws CSIApplicationException, Exception;

	WebServiceResponseData invokeAddOrderNotes(String requestXML,
			String eventType, String methodName,
			WebServiceResponseData webServiceResponseData,
			CSIServiceMessageParser csiMessageParser) throws CSIApplicationException, Exception;

}
