package com.att.tpp.xml.model;

public class BillingAccountName {

	private String type;
	private String businessName;
	private String doingBusinessNameAs;
	private String firstName;
	private String lastName;

    /**
	 * @param type
	 * @param businessName
	 * @param doingBusinessNameAs
	 * @param firstName
	 * @param lastName
	 */
	public BillingAccountName(String type, String businessName,
			String doingBusinessNameAs, String firstName, String lastName) {
		this.type = type;
		this.businessName = businessName;
		this.doingBusinessNameAs = doingBusinessNameAs;
		this.firstName = firstName;
		this.lastName = lastName;
	}

	/**
     * Gets the value of the type property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getType() {
        return type;
    }

    /**
     * Sets the value of the type property.
     * 
     * @param type
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setType(String type) {
        this.type = type;
    }

    /**
     * Gets the value of the businessName property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getBusinessName() {
        return businessName;
    }

    /**
     * Sets the value of the businessName property.
     * 
     * @param businessName
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setBusinessName(String businessName) {
        this.businessName = businessName;
    }

    /**
     * Gets the value of the doingBusinessNameAs property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getDoingBusinessNameAs() {
        return doingBusinessNameAs;
    }

    /**
     * Sets the value of the doingBusinessNameAs property.
     * 
     * @param doingBusinessNameAs
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setDoingBusinessNameAs(String doingBusinessNameAs) {
        this.doingBusinessNameAs = doingBusinessNameAs;
    }

    /**
     * Gets the value of the firstName property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getFirstName() {
        return firstName;
    }

    /**
     * Sets the value of the firstName property.
     * 
     * @param firstName
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setFirstName(String firstName) {
        this.firstName = firstName;
    }

    /**
     * Gets the value of the lastName property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getLastName() {
        return lastName;
    }

    /**
     * Sets the value of the lastName property.
     * 
     * @param lastName
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setLastName(String lastName) {
        this.lastName = lastName;
    }

}
