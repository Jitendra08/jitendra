package com.att.tpp.xml.model;

public enum NetworkGroup {

    GSM_GROUP("GSM-group"),
    MBMI_GROUP("MBMI-group"),
    TDMA_GROUP("TDMA-group"),
    UMTS_GROUP("UMTS-group"),
    TDMA_GAIT("TDMA-GAIT"),
    GSM_GAIT("GSM-GAIT"),
    GSM_UMTS("GSM-UMTS"),
    GAIT("GAIT"),
    LTE("LTE");
    private final String value;

    NetworkGroup(String v) {
        value = v;
    }

    public String value() {
        return value;
    }

    public static NetworkGroup fromValue(String v) {
        for (NetworkGroup c: NetworkGroup.values()) {
            if (c.value.equals(v)) {
                return c;
            }
        }
        throw new IllegalArgumentException(v);
    }

}
