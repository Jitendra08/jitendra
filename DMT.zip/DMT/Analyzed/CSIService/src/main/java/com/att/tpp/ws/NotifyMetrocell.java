package com.att.tpp.ws;

import com.att.tpp.model.CSIResponseKeys;
import com.att.tpp.model.WebServiceResponseData;
import com.att.tpp.utils.CSIServiceMessageParser;
import com.cingular.csi.csi.namespaces.v118.wsdl.cingularwirelesscsi.CSIApplicationException;

public interface NotifyMetrocell {
	
	WebServiceResponseData doNotifyMetrocellAction (CSIResponseKeys csiResponseKeys, String requestXML, String actionMetro, String provSystemTransId) throws CSIApplicationException, Exception;

	WebServiceResponseData invokeNotifyMetrocellAction(String requestXML,
			String eventType, String methodName,
			WebServiceResponseData webServiceResponseData,
			CSIServiceMessageParser csiMessageParser, String actionMetro, String provSystemTransId, String masterTransId)  throws CSIApplicationException, Exception;

}
