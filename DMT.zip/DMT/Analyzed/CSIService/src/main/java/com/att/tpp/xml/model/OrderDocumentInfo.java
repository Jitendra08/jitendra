package com.att.tpp.xml.model;

public class OrderDocumentInfo {

    private String location;
    private String activity;
    private String orderId;
    
    /**
	 * @param location
	 * @param activity
	 * @param orderId
	 */
	public OrderDocumentInfo(String location, String activity, String orderId) {
		this.location = location;
		this.activity = activity;
		this.orderId = orderId;
	}

	/**
     * Gets the value of the location property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getLocation() {
        return location;
    }

    /**
     * Sets the value of the location property.
     * 
     * @param location
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setLocation(String location) {
        this.location = location;
    }

    /**
     * Gets the value of the activity property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getActivity() {
        return activity;
    }

    /**
     * Sets the value of the activity property.
     * 
     * @param activity
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setActivity(String activity) {
        this.activity = activity;
    }

    /**
     * Gets the value of the orderId property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getOrderId() {
        return orderId;
    }

    /**
     * Sets the value of the orderId property.
     * 
     * @param orderId
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setOrderId(String orderId) {
        this.orderId = orderId;
    }

}
