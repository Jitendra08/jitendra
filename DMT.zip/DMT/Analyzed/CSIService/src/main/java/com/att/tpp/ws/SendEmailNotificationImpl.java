package com.att.tpp.ws;

import java.sql.Timestamp;
import java.util.Date;
import java.util.Iterator;

import javax.xml.ws.Holder;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.att.tpp.enumuration.CSIEventType;
import com.att.tpp.model.SendEmailKeys;
import com.att.tpp.model.WebServiceResponseData;
import com.att.tpp.utils.CSIServiceMessageParser;
import com.att.tpp.utils.CSITransactionIDGenerator;
import com.cingular.csi.csi.namespaces.container._public.sendemailrequest.SendEmailRequestInfo;
import com.cingular.csi.csi.namespaces.container._public.sendemailresponse.SendEmailResponseInfo;
import com.cingular.csi.csi.namespaces.types._public.cingulardatamodel.AttributeInfo;
import com.cingular.csi.csi.namespaces.types._public.cingulardatamodel.MarketInfo;
import com.cingular.csi.csi.namespaces.types._public.cingulardatamodel.NameInfo;
import com.cingular.csi.csi.namespaces.types._public.messageheader.MessageHeaderInfo;
import com.cingular.csi.csi.namespaces.v118.wsdl.cingularwirelesscsi.CSIApplicationException;
import com.cingular.csi.csi.namespaces.v118.wsdl.cingularwirelesscsi.SendEmailPortType;

@Transactional
@Service("sendEmailNotification")
public class SendEmailNotificationImpl implements SendEmailNotification {
	
	private static Logger sendEmailNotificationLog = Logger.getLogger(SendEmailNotificationImpl.class);
	
	@Autowired
	private CSIMessageHeaderService csiMessageHeaderService;
		
	@Autowired 
	private SendEmailPortType sendEmailPortType;

	@Override
	public WebServiceResponseData dosendEmailRequest(SendEmailKeys sendEmailKeys, String requestXML) throws CSIApplicationException, Exception {
						
		
		//Generating Message Header
		Holder<MessageHeaderInfo> messageHeader = null;
		String csiTransactionId = null;
		CSITransactionIDGenerator csiIDGen = new CSITransactionIDGenerator();
		csiTransactionId = csiIDGen.generateCSITransactionId("");  //passing blank to get generated transactionId for CSI Service call
		
		//Generate the WebresponseData.
		WebServiceResponseData webServiceResponseData = new WebServiceResponseData();
		webServiceResponseData.setTppcsiTransactionid(csiTransactionId);			
		webServiceResponseData.setTppTransactionid(sendEmailKeys.getMessageTransactionID());
		webServiceResponseData.setOrderid("N/A");
		webServiceResponseData.setInputXml(requestXML);
		webServiceResponseData.setCarrierName(sendEmailKeys.getProvisioningCarrier());
		webServiceResponseData.setRoutingCarrier(sendEmailKeys.getRoutingCarrier());
		webServiceResponseData.setInterfaceName(CSIEventType.SendEmail.toString());
		Date date = new Date();			
		webServiceResponseData.setTimeStamp(new Timestamp(date.getTime()));
		
		try {
			
			messageHeader = csiMessageHeaderService.generateCSIMessageHeader(csiTransactionId);
			
		} catch (Exception e) {
			
			sendEmailNotificationLog.info("Exception occured while generating CSIMessageHeader, MessageId: " + csiTransactionId);
			e.printStackTrace();
			throw e;
		}
		
		//Create Web Service request
		SendEmailResponseInfo sendEmailResponseInfo = null;
		
		try{

		    SendEmailRequestInfo sendEmailRequestInfo = new SendEmailRequestInfo();
		    sendEmailRequestInfo.setAccountNumber(sendEmailKeys.getAccountNumber());
		    
		    NameInfo nameInfo = new NameInfo();
		    nameInfo.setNamePrefix(sendEmailKeys.getAccountNamePrefix());
		    nameInfo.setFirstName(sendEmailKeys.getAccountFirstName());
		    nameInfo.setMiddleName(sendEmailKeys.getAccountMiddleName());
		    nameInfo.setLastName(sendEmailKeys.getAccountLastName());
		    nameInfo.setNameSuffix(sendEmailKeys.getAccountNameSuffix());
		    sendEmailRequestInfo.setAccountName(nameInfo);
			
			MarketInfo marketInfo =  new MarketInfo();
			marketInfo.setBillingMarket(sendEmailKeys.getBillingMarket());
			marketInfo.setBillingSubMarket(sendEmailKeys.getBillingSubMarket());
			sendEmailRequestInfo.setBillingMarket(marketInfo);
			
			sendEmailRequestInfo.setCampaignName(sendEmailKeys.getCampaignName());
			sendEmailRequestInfo.setSubject(sendEmailKeys.getSubject());
		    sendEmailRequestInfo.getDestinationEmailAddress().add(sendEmailKeys.getDestinationEmailAddress());
		    
		    
		    Iterator<AttributeInfo> campaignParameters = sendEmailKeys.getCampaignParameters().iterator();
		     
		     while(campaignParameters.hasNext()){
		    	 AttributeInfo attributeInfo = campaignParameters.next();		    	 
				 sendEmailRequestInfo.getCampaignParameters().add(attributeInfo);
		     }
		    
		   
			sendEmailResponseInfo = sendEmailPortType.sendEmail(messageHeader, sendEmailRequestInfo);

			sendEmailNotificationLog.info("[dosendEmailRequest] Response Code: " + sendEmailResponseInfo.getResponse().getCode());
			sendEmailNotificationLog.info("[dosendEmailRequest] Response Msg: " + sendEmailResponseInfo.getResponse().getDescription());
			
			//Pass the Response code information
			webServiceResponseData.setCsiResponsecode(sendEmailResponseInfo.getResponse().getCode());
			webServiceResponseData.setCsiResponsedesc(sendEmailResponseInfo.getResponse().getDescription());	
			webServiceResponseData.setSkuStatus("S");
			
		} catch (CSIApplicationException csiae){
			
			sendEmailNotificationLog.info("[dosendEmailRequest] SendEmail Web Service call Failed!");
			sendEmailNotificationLog.info("[dosendEmailRequest] Error Code: " + csiae.getFaultInfo().getResponse().getCode());
			sendEmailNotificationLog.info("[dosendEmailRequest] Error Description: " + csiae.getFaultInfo().getResponse().getDescription());
			sendEmailNotificationLog.info("[dosendEmailRequest] Error Message: " + csiae.getMessage());
			
			webServiceResponseData.setSkuStatus("F");
			webServiceResponseData.setCsiResponsecode(csiae.getFaultInfo().getResponse().getCode());
			webServiceResponseData.setCsiResponsedesc(csiae.getFaultInfo().getResponse().getDescription());
			webServiceResponseData.setErrorMessage(csiae.getMessage());
			
			//throw csiae;
		} catch (Exception e){
			sendEmailNotificationLog.info("[dosendEmailRequest] Exception :: Error Message: " + e.getMessage());
			webServiceResponseData.setSkuStatus("F");
			webServiceResponseData.setCsiResponsecode("900");
			webServiceResponseData.setCsiResponsedesc("Exception thrown in SendEmail Response");
			webServiceResponseData.setErrorMessage(e.getMessage());
		}
		
		sendEmailNotificationLog.info("[dosendEmailRequest] SendSMS Web Service call completed with Success!");
		
		return webServiceResponseData;
	}

	@Override
	public WebServiceResponseData invokeSendEmail(String requestXML,
			String eventType, String methodName,
			WebServiceResponseData webServiceResponseData,
			CSIServiceMessageParser csiMessageParser)
			throws CSIApplicationException, Exception {
		try{
			
			sendEmailNotificationLog.info(methodName + "Invoking SendEmail Web Service");
			
			SendEmailKeys sendEmailKeys = csiMessageParser.parseSendEmail(requestXML, eventType);				
			webServiceResponseData = dosendEmailRequest(sendEmailKeys,requestXML);		
			
			sendEmailNotificationLog.info(methodName + "Completed invoking SendEmail Web Service");
			
		} catch (CSIApplicationException csiApplicationException){
									
			sendEmailNotificationLog.info(methodName + "Exception occured when invoking SendEmail Web Service");
			sendEmailNotificationLog.info(methodName + "Error Code: " + csiApplicationException.getFaultInfo().getResponse().getCode());
			sendEmailNotificationLog.info(methodName + "Error Description: "  + csiApplicationException.getFaultInfo().getResponse().getDescription());
			sendEmailNotificationLog.info(methodName + "Error Message: " + csiApplicationException.getMessage());
			//result = csiApplicationException.getFaultInfo().getResponse().getCode() + " - " + csiApplicationException.getFaultInfo().getResponse().getDescription() + "-" + csiApplicationException.getMessage();
		  //throw csiApplicationException;

		}
		return webServiceResponseData;
	}
	

}
