package com.att.tpp.xml.model;

public class Account {

    private String msisdn;
    private String prevMSISDN;
    private String wirelessServiceId;
    private String subscriberNumber;
    private String ban;
    private String banName;
    private String prevBAN;
    private String accountTypeIndicator;
    private String socEffectiveDate;
    private String invoiceId;
    private String eodgroupid;
        
	/**
	 * @param msisdn
	 */
	public Account(String msisdn) {
		this.msisdn = msisdn;
	}
	
	/**
	 * @param msisdn
	 * @param subscriberNumber
	 */
	public Account(String msisdn, String subscriberNumber) {
		this.msisdn = msisdn;
		this.subscriberNumber = subscriberNumber;
	}

	/**
	 * @param msisdn
	 * @param subscriberNumber
	 * @param ban
	 */
	public Account(String msisdn, String subscriberNumber, String ban) {
		this.msisdn = msisdn;
		this.subscriberNumber = subscriberNumber;
		this.ban = ban;
	}

	/**
	 * @param msisdn
	 * @param prevMSISDN
	 * @param wirelessServiceId
	 * @param subscriberNumber
	 * @param ban
	 * @param banName
	 * @param prevBAN
	 * @param accountTypeIndicator
	 * @param socEffectiveDate
	 * @param invoiceId
	 * @param eodgroupid
	 */
	public Account(String msisdn, String prevMSISDN, String wirelessServiceId,
			String subscriberNumber, String ban, String banName,
			String prevBAN, String accountTypeIndicator,
			String socEffectiveDate, String invoiceId, String eodgroupid) {
		this.msisdn = msisdn;
		this.prevMSISDN = prevMSISDN;
		this.wirelessServiceId = wirelessServiceId;
		this.subscriberNumber = subscriberNumber;
		this.ban = ban;
		this.banName = banName;
		this.prevBAN = prevBAN;
		this.accountTypeIndicator = accountTypeIndicator;
		this.socEffectiveDate = socEffectiveDate;
		this.invoiceId = invoiceId;
		this.eodgroupid = eodgroupid;
	}

	/**
	 * @return the msisdn
	 */
	public String getMsisdn() {
		return msisdn;
	}
	
	/**
	 * @param msisdn the msisdn to set
	 */
	public void setMsisdn(String msisdn) {
		this.msisdn = msisdn;
	}
	
	/**
	 * @return the prevMSISDN
	 */
	public String getPrevMSISDN() {
		return prevMSISDN;
	}
	
	/**
	 * @param prevMSISDN the prevMSISDN to set
	 */
	public void setPrevMSISDN(String prevMSISDN) {
		this.prevMSISDN = prevMSISDN;
	}
	
	/**
	 * @return the wirelessServiceId
	 */
	public String getWirelessServiceId() {
		return wirelessServiceId;
	}
	
	/**
	 * @param wirelessServiceId the wirelessServiceId to set
	 */
	public void setWirelessServiceId(String wirelessServiceId) {
		this.wirelessServiceId = wirelessServiceId;
	}
	
	/**
	 * @return the subscriberNumber
	 */
	public String getSubscriberNumber() {
		return subscriberNumber;
	}
	
	/**
	 * @param subscriberNumber the subscriberNumber to set
	 */
	public void setSubscriberNumber(String subscriberNumber) {
		this.subscriberNumber = subscriberNumber;
	}
	
	/**
	 * @return the ban
	 */
	public String getBan() {
		return ban;
	}
	
	/**
	 * @param ban the ban to set
	 */
	public void setBan(String ban) {
		this.ban = ban;
	}
	
	/**
	 * @return the banName
	 */
	public String getBanName() {
		return banName;
	}
	
	/**
	 * @param banName the banName to set
	 */
	public void setBanName(String banName) {
		this.banName = banName;
	}
	
	/**
	 * @return the prevBAN
	 */
	public String getPrevBAN() {
		return prevBAN;
	}
	
	/**
	 * @param prevBAN the prevBAN to set
	 */
	public void setPrevBAN(String prevBAN) {
		this.prevBAN = prevBAN;
	}
	
	/**
	 * @return the accountTypeIndicator
	 */
	public String getAccountTypeIndicator() {
		return accountTypeIndicator;
	}
	
	/**
	 * @param accountTypeIndicator the accountTypeIndicator to set
	 */
	public void setAccountTypeIndicator(String accountTypeIndicator) {
		this.accountTypeIndicator = accountTypeIndicator;
	}
	
	/**
	 * @return the socEffectiveDate
	 */
	public String getSocEffectiveDate() {
		return socEffectiveDate;
	}
	
	/**
	 * @param socEffectiveDate the socEffectiveDate to set
	 */
	public void setSocEffectiveDate(String socEffectiveDate) {
		this.socEffectiveDate = socEffectiveDate;
	}
	
	/**
	 * @return the invoiceId
	 */
	public String getInvoiceId() {
		return invoiceId;
	}
	
	/**
	 * @param invoiceId the invoiceId to set
	 */
	public void setInvoiceId(String invoiceId) {
		this.invoiceId = invoiceId;
	}
	
	/**
	 * @return the eodgroupid
	 */
	public String getEodgroupid() {
		return eodgroupid;
	}
	
	/**
	 * @param eodgroupid the eodgroupid to set
	 */
	public void setEodgroupid(String eodgroupid) {
		this.eodgroupid = eodgroupid;
	}
	
}
