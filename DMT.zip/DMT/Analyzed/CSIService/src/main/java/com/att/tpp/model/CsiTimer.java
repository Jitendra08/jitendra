package com.att.tpp.model;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Lob;
import javax.persistence.NamedQuery;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;


/**
 * The persistent class for the CSI_TIMER database table.
 * 
 */
@Entity
@Table(name="CSI_TIMER")
@NamedQuery(name="CsiTimer.findAll", query="SELECT c FROM CsiTimer c")
public class CsiTimer implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@Column(name="TPPCSI_TRANSACTIONID")
	private String tppcsiTransactionid;
		
	@Temporal(TemporalType.TIMESTAMP)
	@Column(name="CREATION_TIME")
	private Date creationTime;

	@Temporal(TemporalType.TIMESTAMP)
	@Column(name="EXPIRY_TIME")
	private Date expiryTime;

	@Column(name="MAX_RETRY_COUNT")
	private int maxRetryCount;

	@Lob
	private String payload;

	@Column(name="RETRY_COUNT")
	private int retryCount;

	@Column(name="RETRY_IND")
	private String retryInd;

	@Column(name="RETRY_TYPE")
	private String retryType;

	@Column(name="SYSTEM_NAME")
	private String systemName;

	@Column(name="TIMER_DURATION")
	private int timerDuration;

	@Column(name="TIMER_STATE")
	private String timerState;



	public CsiTimer() {
	}

	public Date getCreationTime() {
		return this.creationTime;
	}

	public void setCreationTime(Date creationTime) {
		this.creationTime = creationTime;
	}

	public Date getExpiryTime() {
		return this.expiryTime;
	}

	public void setExpiryTime(Date expiryTime) {
		this.expiryTime = expiryTime;
	}

	
	

	public String getPayload() {
		return this.payload;
	}

	public void setPayload(String payload) {
		this.payload = payload;
	}

	
	public String getRetryInd() {
		return this.retryInd;
	}

	public void setRetryInd(String retryInd) {
		this.retryInd = retryInd;
	}

	public String getRetryType() {
		return this.retryType;
	}

	public void setRetryType(String retryType) {
		this.retryType = retryType;
	}

	public String getSystemName() {
		return this.systemName;
	}

	public void setSystemName(String systemName) {
		this.systemName = systemName;
	}



	public String getTimerState() {
		return this.timerState;
	}

	public void setTimerState(String timerState) {
		this.timerState = timerState;
	}

	public String getTppcsiTransactionid() {
		return this.tppcsiTransactionid;
	}

	public void setTppcsiTransactionid(String tppcsiTransactionid) {
		this.tppcsiTransactionid = tppcsiTransactionid;
	}

	public int getMaxRetryCount() {
		return maxRetryCount;
	}

	public void setMaxRetryCount(int maxRetryCount) {
		this.maxRetryCount = maxRetryCount;
	}

	public int getRetryCount() {
		return retryCount;
	}

	public void setRetryCount(int retryCount) {
		this.retryCount = retryCount;
	}

	public int getTimerDuration() {
		return timerDuration;
	}

	public void setTimerDuration(int timerDuration) {
		this.timerDuration = timerDuration;
	}

}