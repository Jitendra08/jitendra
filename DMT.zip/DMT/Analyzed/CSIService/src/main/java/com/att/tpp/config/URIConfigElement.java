package com.att.tpp.config;

import java.io.Serializable;

public class URIConfigElement implements Serializable {
	private static final long serialVersionUID = 1L;
	
	public String system;
	public String URI;
	public String synchTransIND;
	public String proxyEnabled;


	URIConfigElement (String systemX, String URIX,
                     String synchTransINDX, String proxyEnabledX) {
      system = systemX;
      URI = URIX;
      synchTransIND = synchTransINDX;
      proxyEnabled = proxyEnabledX;
  }

 public String toString() {
   return system + "," + URI + "," + synchTransIND  + "," + proxyEnabled ;
 }
}
