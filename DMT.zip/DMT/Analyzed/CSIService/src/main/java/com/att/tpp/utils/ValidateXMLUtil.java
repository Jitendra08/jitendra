package com.att.tpp.utils;

import java.io.IOException;
import java.io.StringReader;

import javax.xml.parsers.ParserConfigurationException;
import javax.xml.parsers.SAXParser;
import javax.xml.parsers.SAXParserFactory;
import javax.xml.transform.Source;
import javax.xml.transform.stream.StreamSource;
import javax.xml.validation.SchemaFactory;

import org.apache.log4j.Logger;
import org.xml.sax.ErrorHandler;
import org.xml.sax.InputSource;
import org.xml.sax.SAXException;
import org.xml.sax.SAXParseException;
import org.xml.sax.XMLReader;


public class ValidateXMLUtil {


	private static Logger parserlogger = Logger
			.getLogger(ValidateXMLUtil.class);

	public static boolean validateWithXSD(String inputXML, String xsdPath)
			throws ParserConfigurationException, IOException {
		try {
			SAXParserFactory factory = SAXParserFactory.newInstance();
			factory.setValidating(false);
			factory.setNamespaceAware(true);

			SchemaFactory schemaFactory = SchemaFactory
					.newInstance("http://www.w3.org/2001/XMLSchema");
			SAXParser parser = null;
			try {
				factory.setSchema(schemaFactory
						.newSchema(new Source[] { new StreamSource(xsdPath) }));
				parser = factory.newSAXParser();
			} catch (SAXException se) {
				// problem in the XSD itself
				parserlogger.info("SCHEMA : " + se.getMessage());
				return false;
			}

			XMLReader reader = parser.getXMLReader();
			reader.setErrorHandler(new ErrorHandler() {
				public void warning(SAXParseException e) throws SAXException {
					// do nothing
					parserlogger.info("WARNING: " + e.getMessage());
				}

				public void error(SAXParseException e) throws SAXException {
					parserlogger.error("ERROR Exception in ParseXML METHOD  : "
							+ e.getMessage());
					throw e;
				}

				public void fatalError(SAXParseException e) throws SAXException {
					parserlogger.error("FATAL Exception in ParseXML METHOD : "
							+ e.getMessage());
					throw e;
				}
			});
			reader.parse(new InputSource(new StringReader(inputXML)));

			return true;
		} catch (ParserConfigurationException pce) {
			throw pce;

		} catch (IOException io) {
			throw io;
		} catch (SAXException se) {
			return false;
		}
	}

}
