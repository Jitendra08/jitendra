package com.att.tpp.model;

import java.io.Serializable;
import javax.persistence.*;
import java.util.Date;


/**
 * The persistent class for the FEATURE_CODE_REF database table.
 * 
 */
@Entity
@Table(name="FEATURE_CODE_REF")
@NamedQuery(name="FeatureCodeRef.findAll", query="SELECT f FROM FeatureCodeRef f")
public class FeatureCodeRef implements Serializable {
	private static final long serialVersionUID = 1L;

	@EmbeddedId
	private FeatureCodeRefPK id;

	private String accounttypeindicatorinfo;

	private String accounttypeinfo;

	private String address;

	@Column(name="ATTRIBUTE_NAME")
	private String attributeName;

	//@Column(name="ATTRIBUTE_VALUE")
	//private String attributeValue;

	private String ban;

	private String contractinfo;

	@Column(name="CUSTREGCONTACTINFO_BASE")
	private String custregcontactinfoBase;

	private String email;

	private String fan;

	private String fanname;

	private String iccid;

	private String imei;

	private String imsi;

	@Temporal(TemporalType.DATE)
	@Column(name="INSERT_DATE")
	private Date insertDate;

	private String kintana;

	@Column(name="LBS_IND")
	private String lbsInd;

	private String make;

	private String model;

	private String name;

	private String parentalcontrolssettinginfo;

	private String phonenumber;

	private String rateplan;

	private String salesrepinfo;

	private String segmentinfo;

	private String subscribernumber;

	private String subscriberstatusinfo;

	@Column(name="WAP_ENABLED")
	private String wapEnabled;

	@Column(name="WORK_REQ")
	private String workReq;

	public FeatureCodeRef() {
	}

	/*public FeatureCodeRef(String featureCode, String productId,
			String AttributeName, String AttributeValue, String WapEnabled,
			String Name, String Address, String PhoneNumber, String Email,
			String Ban, String Fan, String SubscriberNumber, String IMEI,
			String IMSI, String ICCID, String Make, String Model,
			String RatePlan) {
		this
	}*/
	
	public FeatureCodeRefPK getId() {
		return this.id;
	}

	public void setId(FeatureCodeRefPK id) {
		this.id = id;
	}

	public String getAccounttypeindicatorinfo() {
		return this.accounttypeindicatorinfo;
	}

	public void setAccounttypeindicatorinfo(String accounttypeindicatorinfo) {
		this.accounttypeindicatorinfo = accounttypeindicatorinfo;
	}

	public String getAccounttypeinfo() {
		return this.accounttypeinfo;
	}

	public void setAccounttypeinfo(String accounttypeinfo) {
		this.accounttypeinfo = accounttypeinfo;
	}

	public String getAddress() {
		return this.address;
	}

	public void setAddress(String address) {
		this.address = address;
	}

	public String getAttributeName() {
		return this.attributeName;
	}

	public void setAttributeName(String attributeName) {
		this.attributeName = attributeName;
	}
/*
	public String getAttributeValue() {
		return this.attributeValue;
	}

	public void setAttributeValue(String attributeValue) {
		this.attributeValue = attributeValue;
	}
*/
	public String getBan() {
		return this.ban;
	}

	public void setBan(String ban) {
		this.ban = ban;
	}

	public String getContractinfo() {
		return this.contractinfo;
	}

	public void setContractinfo(String contractinfo) {
		this.contractinfo = contractinfo;
	}

	public String getCustregcontactinfoBase() {
		return this.custregcontactinfoBase;
	}

	public void setCustregcontactinfoBase(String custregcontactinfoBase) {
		this.custregcontactinfoBase = custregcontactinfoBase;
	}

	public String getEmail() {
		return this.email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getFan() {
		return this.fan;
	}

	public void setFan(String fan) {
		this.fan = fan;
	}

	public String getFanname() {
		return this.fanname;
	}

	public void setFanname(String fanname) {
		this.fanname = fanname;
	}

	public String getIccid() {
		return this.iccid;
	}

	public void setIccid(String iccid) {
		this.iccid = iccid;
	}

	public String getImei() {
		return this.imei;
	}

	public void setImei(String imei) {
		this.imei = imei;
	}

	public String getImsi() {
		return this.imsi;
	}

	public void setImsi(String imsi) {
		this.imsi = imsi;
	}

	public Date getInsertDate() {
		return this.insertDate;
	}

	public void setInsertDate(Date insertDate) {
		this.insertDate = insertDate;
	}

	public String getKintana() {
		return this.kintana;
	}

	public void setKintana(String kintana) {
		this.kintana = kintana;
	}

	public String getLbsInd() {
		return this.lbsInd;
	}

	public void setLbsInd(String lbsInd) {
		this.lbsInd = lbsInd;
	}

	public String getMake() {
		return this.make;
	}

	public void setMake(String make) {
		this.make = make;
	}

	public String getModel() {
		return this.model;
	}

	public void setModel(String model) {
		this.model = model;
	}

	public String getName() {
		return this.name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getParentalcontrolssettinginfo() {
		return this.parentalcontrolssettinginfo;
	}

	public void setParentalcontrolssettinginfo(String parentalcontrolssettinginfo) {
		this.parentalcontrolssettinginfo = parentalcontrolssettinginfo;
	}

	public String getPhonenumber() {
		return this.phonenumber;
	}

	public void setPhonenumber(String phonenumber) {
		this.phonenumber = phonenumber;
	}

	public String getRateplan() {
		return this.rateplan;
	}

	public void setRateplan(String rateplan) {
		this.rateplan = rateplan;
	}

	public String getSalesrepinfo() {
		return this.salesrepinfo;
	}

	public void setSalesrepinfo(String salesrepinfo) {
		this.salesrepinfo = salesrepinfo;
	}

	public String getSegmentinfo() {
		return this.segmentinfo;
	}

	public void setSegmentinfo(String segmentinfo) {
		this.segmentinfo = segmentinfo;
	}

	public String getSubscribernumber() {
		return this.subscribernumber;
	}

	public void setSubscribernumber(String subscribernumber) {
		this.subscribernumber = subscribernumber;
	}

	public String getSubscriberstatusinfo() {
		return this.subscriberstatusinfo;
	}

	public void setSubscriberstatusinfo(String subscriberstatusinfo) {
		this.subscriberstatusinfo = subscriberstatusinfo;
	}

	public String getWapEnabled() {
		return this.wapEnabled;
	}

	public void setWapEnabled(String wapEnabled) {
		this.wapEnabled = wapEnabled;
	}

	public String getWorkReq() {
		return this.workReq;
	}

	public void setWorkReq(String workReq) {
		this.workReq = workReq;
	}

}