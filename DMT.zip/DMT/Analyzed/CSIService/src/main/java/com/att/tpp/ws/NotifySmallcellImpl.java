package com.att.tpp.ws;

import java.sql.Timestamp;
import java.util.Date;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.amdocs.aff.csi.e911registrationcompletion.request.E911RegistrationCompletion;
import com.amdocs.aff.csi.e911registrationcompletion.request.E911RegistrationCompletionRequestInfo;
import com.amdocs.aff.csi.e911registrationcompletion.request.E911RegistrationCompletionResponseInfo;
import com.att.tpp.enumuration.CSIEventType;
import com.att.tpp.model.CSIResponseKeys;
import com.att.tpp.model.TransCode;
import com.att.tpp.model.WebServiceResponseData;
import com.att.tpp.service.CSIService;
import com.att.tpp.utils.CSIServiceMessageParser;
import com.att.tpp.utils.CSITransactionIDGenerator;
import com.cingular.csi.csi.namespaces.v118.wsdl.cingularwirelesscsi.CSIApplicationException;

@Service("notifySmallcell")
public class NotifySmallcellImpl implements NotifySmallcell {
	
	private static final String methodName = "[doNotifySmallcellAction] ";

	private static Logger notifySmallcellActionLog = Logger.getLogger(NotifySmallcellImpl.class);
	
	@Autowired
	private CSIMessageHeaderService csiMessageHeaderService;
		
	@Autowired
	private E911RegistrationCompletion e911RegistrationCompletion;	
	
	@Autowired
	private CSIService csiService;

	@Override
	public WebServiceResponseData doNotifySmallcellAction(
			CSIResponseKeys csiResponseKeys, String requestXML,
			String actionSmallcell, String provSystemTransId)
			throws CSIApplicationException, Exception {
		
		notifySmallcellActionLog.info(methodName + "Executing NotifySmallcellAction");
		
		String csiTransactionId = null;
		CSITransactionIDGenerator csiIDGen = new CSITransactionIDGenerator();
		
		csiTransactionId = csiIDGen.generateCSITransactionId(provSystemTransId);  //passing blank to get generated transactionId for CSI Service call		
		
		
		//Generate the WebresponseData.
		WebServiceResponseData webServiceResponseData = new WebServiceResponseData();
		webServiceResponseData.setTppcsiTransactionid(csiTransactionId);			
		webServiceResponseData.setTppTransactionid(csiResponseKeys.getMessageTransactionID());
		webServiceResponseData.setInputXml(requestXML);
		webServiceResponseData.setCarrierName(csiResponseKeys.getProvisioningCarrier());
		webServiceResponseData.setRoutingCarrier(csiResponseKeys.getRoutingCarrier());
		webServiceResponseData.setInterfaceName(CSIEventType.NotifySmallcellAction.toString());

		Date date = new Date();			
		webServiceResponseData.setTimeStamp(new Timestamp(date.getTime()));

		
		E911RegistrationCompletionRequestInfo e911RegistrationCompletionRequestInfo = new E911RegistrationCompletionRequestInfo();
		e911RegistrationCompletionRequestInfo.setTransactionId(csiTransactionId);
		e911RegistrationCompletionRequestInfo.setVersion(csiResponseKeys.getAliUpdateResponseVersion());
		e911RegistrationCompletionRequestInfo.setExternalKey(csiResponseKeys.getExternalKey().trim());
		e911RegistrationCompletionRequestInfo.setReturnCode1(csiResponseKeys.getFemtocellCode());
		e911RegistrationCompletionRequestInfo.setReturnCode1Message(csiResponseKeys.getFemtocellDescription());
		
		/*
		 * We do not pull the second or third set of codes returned from Intrado.
		 * Defaulted to empty string.
		 */
		e911RegistrationCompletionRequestInfo.setReturnCode2("");
		e911RegistrationCompletionRequestInfo.setReturnCode2Message("");
		e911RegistrationCompletionRequestInfo.setReturnCode3("");
		e911RegistrationCompletionRequestInfo.setReturnCode3Message("");
		
		E911RegistrationCompletionResponseInfo e911RegistrationCompletionResponseInfo = null;

		try{
						
			e911RegistrationCompletionResponseInfo = e911RegistrationCompletion.e911RegistrationCompletionRequest(e911RegistrationCompletionRequestInfo);
			
			webServiceResponseData.setCsiResponsecode(e911RegistrationCompletionResponseInfo.getCode());
			webServiceResponseData.setCsiResponsedesc(e911RegistrationCompletionResponseInfo.getDescription());	
			webServiceResponseData.setSkuStatus("S");
			
		}
		catch(Exception e){
			
			notifySmallcellActionLog.info(methodName + "NotifySmallcellAction Web Service call Failed!");
			notifySmallcellActionLog.info(methodName + "Error Description: " + e.toString());
			notifySmallcellActionLog.info(methodName + "Error Message: " + e.getMessage());
			
			webServiceResponseData.setSkuStatus("F");
			
			/*
			 * Since the web service does not return a fault exception from the web service call,
			 * we are capturing only the exception generated.			 * 
			 */
			webServiceResponseData.setCsiResponsecode("N/A");
			webServiceResponseData.setCsiResponsedesc("N/A");
			webServiceResponseData.setErrorMessage(e.getMessage());
			
		}
		
		notifySmallcellActionLog.info(methodName + "NotifySmallcellAction Web Service call completed with Success!");
		notifySmallcellActionLog.info(methodName + "NotifySmallcellAction Web Service response code: " + e911RegistrationCompletionResponseInfo.getCode());
		notifySmallcellActionLog.info(methodName + "NotifySmallcellAction Web Service response Description: " + e911RegistrationCompletionResponseInfo.getDescription());
		notifySmallcellActionLog.info(methodName + "NotifySmallcellAction Web Service call made with MessageID: " + csiTransactionId);
		notifySmallcellActionLog.info(methodName + "NotifySmallcellAction Web Service call made with ExternalKey: " + csiResponseKeys.getExternalKey());
		
		return webServiceResponseData;
		
	}

	@Override
	public WebServiceResponseData invokeNotifySmallcellAction(
			String requestXML, String eventType, String methodName,
			WebServiceResponseData webServiceResponseData,
			CSIServiceMessageParser csiMessageParser, String actionSmallcell,
			String provSystemTransId, String masterTransId, String externalKey)
			throws CSIApplicationException, Exception {
		
		try{
			
			notifySmallcellActionLog.info(methodName + "Invoking NotifySmallcellAction Web Service");
			CSIResponseKeys csiResponseKeys = csiMessageParser.parseNotifyFemtocell(requestXML, eventType);
			
			csiResponseKeys.setMessageTransactionID(masterTransId);
			csiResponseKeys.setExternalKey(externalKey);
			webServiceResponseData = doNotifySmallcellAction(csiResponseKeys, requestXML, actionSmallcell, provSystemTransId);		
			notifySmallcellActionLog.info(methodName + "Completed invoking NotifySmallcellAction Web Service");
			
			//Generate TransCode and Insert into DB.
			TransCode transCode = csiService.generateTransCode(masterTransId, csiResponseKeys, actionSmallcell);
			boolean insertTransCode = csiService.insertTranscode(transCode);
			notifySmallcellActionLog.info(methodName + "insertTransCode result: "+insertTransCode);
		
			//Note: For now we are sending only 71000 errors to the Error Service.
			//Please check with prod support
			if(transCode.getMajorcode().equalsIgnoreCase("71000")){
				String messageId="";
				boolean sendToErrorQueue = csiService.generateAndSendErrorRequest(messageId, masterTransId);
				notifySmallcellActionLog.info(methodName + "sendToErrorQueue result: "+sendToErrorQueue);
			}
			
			
		} catch (Exception e){				
			
			notifySmallcellActionLog.info(methodName + "Exception occured when invoking NotifySmallcellAction Web Service");
			//notifySmallcellActionLog.info(methodName + "Error Code: " + csiApplicationException.getFaultInfo().getResponse().getCode());
			notifySmallcellActionLog.info(methodName + "Error Description: "  + e.toString());
			notifySmallcellActionLog.info(methodName + "Error Message: " + e.getMessage());
			//throw csiApplicationException;
				
		} 
		
		return webServiceResponseData;		
	}

}
