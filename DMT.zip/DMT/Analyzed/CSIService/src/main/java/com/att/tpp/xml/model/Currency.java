package com.att.tpp.xml.model;

public enum Currency {

    USD,
    CAN;

    public String value() {
        return name();
    }

    public static Currency fromValue(String v) {
        return valueOf(v);
    }

}
