package com.att.tpp.ws;

import java.math.BigInteger;
import java.sql.Timestamp;
import java.util.Date;

import javax.xml.ws.Holder;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.att.tpp.enumuration.CSIEventType;
import com.att.tpp.model.CSIResponseKeys;
import com.att.tpp.model.WebServiceResponseData;
import com.att.tpp.utils.CSIServiceMessageParser;
import com.att.tpp.utils.CSITransactionIDGenerator;
import com.att.tpp.utils.FulfillmentValidationXMLGenerator;
import com.cingular.csi.csi.namespaces.container._public.add3ppordershipmentrequest.Add3PPOrderShipmentRequestInfo;
import com.cingular.csi.csi.namespaces.container._public.add3ppordershipmentresponse.Add3PPOrderShipmentResponseInfo;
import com.cingular.csi.csi.namespaces.types._public.cingulardatamodel.OrderDocumentInfo;
import com.cingular.csi.csi.namespaces.types._public.messageheader.MessageHeaderInfo;
import com.cingular.csi.csi.namespaces.v118.wsdl.cingularwirelesscsi.Add3PPOrderShipmentPortType;
import com.cingular.csi.csi.namespaces.v118.wsdl.cingularwirelesscsi.CSIApplicationException;

@Transactional
@Service("addOrderShipmentNotification")
public class AddOrderShipmentNotificationImpl implements AddOrderShipmentNotification {
	
	private static Logger addOrderShipmentNotificationLog = Logger.getLogger(AddOrderShipmentNotificationImpl.class);
	
	@Autowired
	private CSIMessageHeaderService csiMessageHeaderService;
		
	@Autowired 
	private Add3PPOrderShipmentPortType add3PPOrderShipmentPortType;
	
	@Override
	public WebServiceResponseData doAdd3PPOrderShipmentRequest(
			CSIResponseKeys csiResponseKeys, String requestXML) throws CSIApplicationException, Exception {
						
		addOrderShipmentNotificationLog.info("[doAdd3PPOrderShipmentRequest] Executing Add3PPOrderShipmentRequest with OrderId: " + csiResponseKeys.getConcatOrderID());
		
		
		//Generating Message Header
		Holder<MessageHeaderInfo> messageHeader = null;
		String csiTransactionId = null;
		CSITransactionIDGenerator csiIDGen = new CSITransactionIDGenerator();
		csiTransactionId = csiIDGen.generateCSITransactionId("");  //passing blank to get generated transactionId for CSI Service call
		
		//Generate the WebresponseData.
		WebServiceResponseData webServiceResponseData = new WebServiceResponseData();
		webServiceResponseData.setTppcsiTransactionid(csiTransactionId);			
		webServiceResponseData.setTppTransactionid(csiResponseKeys.getMessageTransactionID());
		webServiceResponseData.setOrderid(csiResponseKeys.getConcatOrderID());
		webServiceResponseData.setStructuredOrderId(csiResponseKeys.getOrderId());
		webServiceResponseData.setFulfillmentId(csiResponseKeys.getFulfillmentId());
		webServiceResponseData.setInputXml(requestXML);
		webServiceResponseData.setCarrierName(csiResponseKeys.getProvisioningCarrier());
		webServiceResponseData.setRoutingCarrier(csiResponseKeys.getRoutingCarrier());
		webServiceResponseData.setInterfaceName(CSIEventType.AddOrderShipment.toString());
		Date date = new Date();			
		webServiceResponseData.setTimeStamp(new Timestamp(date.getTime()));
		
		try {
			
			messageHeader = csiMessageHeaderService.generateCSIMessageHeader(csiTransactionId);
			
		} catch (Exception e) {
			
			addOrderShipmentNotificationLog.info("Exception occured while generating CSIMessageHeader, MessageId: " + csiTransactionId);
			addOrderShipmentNotificationLog.info("Exception occured while generating CSIMessageHeader, OrderId: " + csiResponseKeys.getConcatOrderID());
			e.printStackTrace();
			throw e;
		}
		
		//Create Web Service request
		
		OrderDocumentInfo orderId = new OrderDocumentInfo();		
		orderId.setLocation(csiResponseKeys.getOrderId().getLocation());
		orderId.setActivity(csiResponseKeys.getOrderId().getActivity());
		orderId.setOrderId(new BigInteger(csiResponseKeys.getOrderId().getOrderId()));
		
		Add3PPOrderShipmentRequestInfo add3PPOrderShipmentRequestData = new Add3PPOrderShipmentRequestInfo();
		add3PPOrderShipmentRequestData.setOrderId(orderId);
		add3PPOrderShipmentRequestData.setType(csiResponseKeys.getFulfillmentType());
		add3PPOrderShipmentRequestData.setFulfillmentId(csiResponseKeys.getFulfillmentId());
		
		if(csiResponseKeys.getCarrierId().length() > 0){
			add3PPOrderShipmentRequestData.setCarrierId(csiResponseKeys.getCarrierId());			
		}		
		
		add3PPOrderShipmentRequestData.getShipmentLine().addAll(csiResponseKeys.getShipmentLineInfo());
		
		Add3PPOrderShipmentResponseInfo add3PPOrderShipmentResponseInfo = null;
		
		try{
						
			add3PPOrderShipmentResponseInfo = add3PPOrderShipmentPortType.add3PPOrderShipment(messageHeader, add3PPOrderShipmentRequestData);
			
			//Pass the Response code information
			webServiceResponseData.setCsiResponsecode(add3PPOrderShipmentResponseInfo.getResponse().getCode());
			webServiceResponseData.setCsiResponsedesc(add3PPOrderShipmentResponseInfo.getResponse().getDescription());	
			webServiceResponseData.setSkuStatus("S");
			
			
		} catch (CSIApplicationException csiae){
			
			addOrderShipmentNotificationLog.info("[doAdd3PPOrderShipmentRequest] Add3PPOrderShipmentRequest Web Service call Failed!");
			addOrderShipmentNotificationLog.info("[doAdd3PPOrderShipmentRequest] Error Code: " + csiae.getFaultInfo().getResponse().getCode());
			addOrderShipmentNotificationLog.info("[doAdd3PPOrderShipmentRequest] Error Description: " + csiae.getFaultInfo().getResponse().getDescription());
			addOrderShipmentNotificationLog.info("[doAdd3PPOrderShipmentRequest] Error Message: " + csiae.getMessage());
			
			webServiceResponseData.setSkuStatus("F");
			webServiceResponseData.setCsiResponsecode(csiae.getFaultInfo().getResponse().getCode());
			webServiceResponseData.setCsiResponsedesc(csiae.getFaultInfo().getResponse().getDescription());
			webServiceResponseData.setErrorMessage(csiae.getMessage());
			
			//throw csiae;
		} catch (Exception e){
			addOrderShipmentNotificationLog.info("[doAdd3PPOrderShipmentRequest] Exception :: Error Message: " + e.getMessage());
			webServiceResponseData.setSkuStatus("F");
			webServiceResponseData.setCsiResponsecode("900");
			webServiceResponseData.setCsiResponsedesc("Exception thrown in doAdd3PPOrderNotesRequest Response");
			webServiceResponseData.setErrorMessage(e.getMessage());
		}
		
		addOrderShipmentNotificationLog.info("[doAdd3PPOrderShipmentRequest] Add3PPOrderShipmentRequest Web Service call completed with Success!");
		addOrderShipmentNotificationLog.info("[doAdd3PPOrderShipmentRequest] Add3PPOrderShipmentRequest Web Service call made with OrderId: " + csiResponseKeys.getConcatOrderID());
		
		return webServiceResponseData;
	}

	@Override
	public WebServiceResponseData invokeAddOrderShipment(String requestXML,
			String eventType, String methodName,
			WebServiceResponseData webServiceResponseData,
			CSIServiceMessageParser csiMessageParser)
			throws CSIApplicationException, Exception {
		//String result;
		try {								
			addOrderShipmentNotificationLog.info(methodName + "Invoking add3PPOrderShipment Web Service");				
			CSIResponseKeys csiResponseKeys = csiMessageParser.parseAddOrderShipment(requestXML, eventType);			
			webServiceResponseData = doAdd3PPOrderShipmentRequest(csiResponseKeys, requestXML);
			
			if(csiResponseKeys.getFulfillmentType().equals("Fulfillment")){
				//Todo: Genereate the XML when indicator is Yes
				FulfillmentValidationXMLGenerator fulfillmentValidationXMLGenerator = new FulfillmentValidationXMLGenerator();
				String fulfillmentValidationXML	= fulfillmentValidationXMLGenerator.getXML(webServiceResponseData, webServiceResponseData.getSkuStatus().equals("S"));					
				webServiceResponseData.setFulfillmentValidation(true);
				webServiceResponseData.setFulfillmentValidationXML(fulfillmentValidationXML);				
			}
			addOrderShipmentNotificationLog.info(methodName + "Completed invoking add3PPOrderShipment Web Service");
			
		} catch (CSIApplicationException csiApplicationException){				
			addOrderShipmentNotificationLog.info(methodName + "Exception occured when invoking add3PPOrderShipment Web Service");
			addOrderShipmentNotificationLog.info(methodName + "Error Code: " + csiApplicationException.getFaultInfo().getResponse().getCode());
			addOrderShipmentNotificationLog.info(methodName + "Error Description: "  + csiApplicationException.getFaultInfo().getResponse().getDescription());
			addOrderShipmentNotificationLog.info(methodName + "Error Message: " + csiApplicationException.getMessage());				
			//result = csiApplicationException.getFaultInfo().getResponse().getCode() + " - " + csiApplicationException.getFaultInfo().getResponse().getDescription() + "-" + csiApplicationException.getMessage();				
			//throw csiApplicationException;				
		} 
		return webServiceResponseData;
	}
	

}
