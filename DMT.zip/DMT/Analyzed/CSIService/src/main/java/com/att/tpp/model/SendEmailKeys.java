/**
 * 
 */
package com.att.tpp.model;

import java.io.Serializable;
import java.util.List;

import com.cingular.csi.csi.namespaces.types._public.cingulardatamodel.AttributeInfo;

/**
 * @author SC9833
 *
 */
public class SendEmailKeys implements Serializable {

	private static final long serialVersionUID = 1L;
	
	private String accountNumber;
	private String accountNamePrefix;
	private String accountFirstName;
	private String accountMiddleName;
	private String accountLastName;
	private String accountNameSuffix;
	private String billingMarket;
	private String billingSubMarket;
	private String localMarket;
	private String destinationEmailAddress;
	private String subject;
	private String campaignName;
	private List<AttributeInfo> campaignParameters;
	
	private String messageTransactionID;	
	private String tppCSITransactionID; 
	private String provisioningCarrier;
	private String routingCarrier;
	private String systemName;
	
	public String getAccountNumber() {
		return accountNumber;
	}
	public void setAccountNumber(String accountNumber) {
		this.accountNumber = accountNumber;
	}
	public String getAccountNamePrefix() {
		return accountNamePrefix;
	}
	public void setAccountNamePrefix(String accountNamePrefix) {
		this.accountNamePrefix = accountNamePrefix;
	}
	public String getAccountFirstName() {
		return accountFirstName;
	}
	public void setAccountFirstName(String accountFirstName) {
		this.accountFirstName = accountFirstName;
	}
	public String getAccountMiddleName() {
		return accountMiddleName;
	}
	public void setAccountMiddleName(String accountMiddleName) {
		this.accountMiddleName = accountMiddleName;
	}
	public String getAccountLastName() {
		return accountLastName;
	}
	public void setAccountLastName(String accountLastName) {
		this.accountLastName = accountLastName;
	}
	public String getAccountNameSuffix() {
		return accountNameSuffix;
	}
	public void setAccountNameSuffix(String accountNameSuffix) {
		this.accountNameSuffix = accountNameSuffix;
	}
	public String getBillingMarket() {
		return billingMarket;
	}
	public void setBillingMarket(String billingMarket) {
		this.billingMarket = billingMarket;
	}
	public String getBillingSubMarket() {
		return billingSubMarket;
	}
	public void setBillingSubMarket(String billingSubMarket) {
		this.billingSubMarket = billingSubMarket;
	}
	public String getLocalMarket() {
		return localMarket;
	}
	public void setLocalMarket(String localMarket) {
		this.localMarket = localMarket;
	}
	public String getDestinationEmailAddress() {
		return destinationEmailAddress;
	}
	public void setDestinationEmailAddress(String destinationEmailAddress) {
		this.destinationEmailAddress = destinationEmailAddress;
	}
	public String getSubject() {
		return subject;
	}
	public void setSubject(String subject) {
		this.subject = subject;
	}
	public String getCampaignName() {
		return campaignName;
	}
	public void setCampaignName(String campaignName) {
		this.campaignName = campaignName;
	}
	public List<AttributeInfo> getCampaignParameters() {
		return campaignParameters;
	}
	public void setCampaignParameters(List<AttributeInfo> campaignParameters) {
		this.campaignParameters = campaignParameters;
	}
	public String getMessageTransactionID() {
		return messageTransactionID;
	}
	public void setMessageTransactionID(String messageTransactionID) {
		this.messageTransactionID = messageTransactionID;
	}
	public String getTppCSITransactionID() {
		return tppCSITransactionID;
	}
	public void setTppCSITransactionID(String tppCSITransactionID) {
		this.tppCSITransactionID = tppCSITransactionID;
	}
	public String getProvisioningCarrier() {
		return provisioningCarrier;
	}
	public void setProvisioningCarrier(String provisioningCarrier) {
		this.provisioningCarrier = provisioningCarrier;
	}
	public String getRoutingCarrier() {
		return routingCarrier;
	}
	public void setRoutingCarrier(String routingCarrier) {
		this.routingCarrier = routingCarrier;
	}
	public String getSystemName() {
		return systemName;
	}
	public void setSystemName(String systemName) {
		this.systemName = systemName;
	}

	
}
