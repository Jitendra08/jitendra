package com.att.tpp.xml.model;

import java.util.Collection;

public class Subscriber {

    private Collection<Contact> contact;
    private Collection<Address> address;

	/**
	 * @param contact
	 * @param address
	 */
	public Subscriber(Collection<Contact> contact, Collection<Address> address) {
		this.contact = contact;
		this.address = address;
	}

	/**
	 * @return the contact
	 */
	public Collection<Contact> getContact() {
		return contact;
	}
	
	/**
	 * @param contact the contact to set
	 */
	public void setContact(Collection<Contact> contact) {
		this.contact = contact;
	}
	
	/**
	 * @return the address
	 */
	public Collection<Address> getAddress() {
		return address;
	}
	
	/**
	 * @param address the address to set
	 */
	public void setAddress(Collection<Address> address) {
		this.address = address;
	}

}
