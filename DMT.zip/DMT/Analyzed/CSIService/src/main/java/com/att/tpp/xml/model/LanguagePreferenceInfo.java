package com.att.tpp.xml.model;

public enum LanguagePreferenceInfo {

    E,
    S;

    public String value() {
        return name();
    }

    public static LanguagePreferenceInfo fromValue(String v) {
        return valueOf(v);
    }

}
