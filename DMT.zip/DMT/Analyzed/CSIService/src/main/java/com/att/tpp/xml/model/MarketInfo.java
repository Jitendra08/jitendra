package com.att.tpp.xml.model;

public class MarketInfo {

    private String billingMarket;
    private String billingSubMarket;
    private String localMarket;

    /**
	 * @param billingMarket
	 * @param billingSubMarket
	 */
	public MarketInfo(String billingMarket, String billingSubMarket) {
		this.billingMarket = billingMarket;
		this.billingSubMarket = billingSubMarket;
	}

	/**
	 * @param billingMarket
	 * @param billingSubMarket
	 * @param localMarket
	 */
	public MarketInfo(String billingMarket, String billingSubMarket,
			String localMarket) {
		this.billingMarket = billingMarket;
		this.billingSubMarket = billingSubMarket;
		this.localMarket = localMarket;
	}

	/**
     * Gets the value of the billingMarket property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getBillingMarket() {
        return billingMarket;
    }

    /**
     * Sets the value of the billingMarket property.
     * 
     * @param billingMarket
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setBillingMarket(String billingMarket) {
        this.billingMarket = billingMarket;
    }

    /**
     * Gets the value of the billingSubMarket property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getBillingSubMarket() {
        return billingSubMarket;
    }

    /**
     * Sets the value of the billingSubMarket property.
     * 
     * @param billingSubMarket
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setBillingSubMarket(String billingSubMarket) {
        this.billingSubMarket = billingSubMarket;
    }

    /**
     * Gets the value of the localMarket property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getLocalMarket() {
        return localMarket;
    }

    /**
     * Sets the value of the localMarket property.
     * 
     * @param localMarket
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setLocalMarket(String localMarket) {
        this.localMarket = localMarket;
    }

}
