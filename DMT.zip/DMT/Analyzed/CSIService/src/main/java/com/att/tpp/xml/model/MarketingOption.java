package com.att.tpp.xml.model;

public class MarketingOption {

	private String name;
	private boolean value;
	
	/**
	 * @param name
	 * @param value
	 */
	public MarketingOption(String name, boolean value) {
		this.name = name;
		this.value = value;
	}

	/**
	 * @return the name
	 */
	public String getName() {
		return name;
	}

	/**
	 * @param name the name to set
	 */
	public void setName(String name) {
		this.name = name;
	}

	/**
	 * @return the value
	 */
	public boolean isValue() {
		return value;
	}

	/**
	 * @param value the value to set
	 */
	public void setValue(boolean value) {
		this.value = value;
	}
	
}
