package com.att.tpp.utils

import java.util.List;
import java.util.Formatter.DateTime

import com.att.tpp.config.SystemConfigElement;
import com.att.tpp.config.URIConfigElement;
import com.att.tpp.model.ProvisioningTask;
import com.att.tpp.model.WebServiceResponseData;

import groovy.xml.MarkupBuilder


class TPP_TransactionRequestXMLGenerator {

	public TPP_TransactionRequestXMLGenerator() {
	}

	def String createTransactionRequestXML(String fulfillmentValidationXML, WebServiceResponseData webServiceResponseData, URIConfigElement uriConfigElement, SystemConfigElement systemConfigElement) {
		
		Date date = new Date();
		
		def transactionrequestXML = new StringWriter()
		def xml = new MarkupBuilder(transactionrequestXML)
		
		xml.setDoubleQuotes(true)
		xml.mkp.xmlDeclaration(version: "1.0", encoding: "UTF-8")
		
		xml.TransactionRequest("xmlns:xsi":"http://www.w3.org/2001/XMLSchema-instance")
		{
			
			TaskInfo(CurrentNoResponseRetryCount:"0",
				MaxNoResponseRetryCount:"3",
				Task_TransID: webServiceResponseData.getTppTransactionid(),
				ProvisioningCarrier:"ATT",
				NotificationURL:systemConfigElement.notifURL,				
				RoutingCarrier:webServiceResponseData.getRoutingCarrier().toString(),
				Login:systemConfigElement.login,
				Password:systemConfigElement.passwd,
				CurrentTechRetryCount:"0",
				MaxTechRetryCount:"3",
				EventType:"FulfillmentResults",
				TimeStamp:date,
				System: webServiceResponseData.getVendorName().toString(),
				URL:uriConfigElement.URI,
				ProxyEnabled:uriConfigElement.proxyEnabled
				)
			
			
			if(fulfillmentValidationXML!=null && fulfillmentValidationXML.length()>0)
			{
			  xml.SystemPayload(fulfillmentValidationXML)
			}
			
		}
		return transactionrequestXML.toString()
	}
	
}
