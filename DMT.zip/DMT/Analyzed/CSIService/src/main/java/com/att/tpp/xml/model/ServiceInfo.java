package com.att.tpp.xml.model;

public class ServiceInfo {

	private String language;
	private String currency;
	private String generation;
	private String networkGroup;
    private String prevNetworkGroup;
    private String paymentType;
    private String prepaidPlatformType;
    
	/**
	 * @param language
	 * @param currency
	 * @param generation
	 * @param networkGroup
	 * @param paymentType
	 */
	public ServiceInfo(String language, String currency, String generation,
			String networkGroup, String paymentType) {
		this.language = language;
		this.currency = currency;
		this.generation = generation;
		this.networkGroup = networkGroup;
		this.paymentType = paymentType;
	}

	/**
	 * @param language
	 * @param currency
	 * @param generation
	 * @param networkGroup
	 * @param prevNetworkGroup
	 * @param paymentType
	 * @param prepaidPlatformType
	 */
	public ServiceInfo(String language, String currency, String generation,
			String networkGroup, String prevNetworkGroup, String paymentType,
			String prepaidPlatformType) {
		this.language = language;
		this.currency = currency;
		this.generation = generation;
		this.networkGroup = networkGroup;
		this.prevNetworkGroup = prevNetworkGroup;
		this.paymentType = paymentType;
		this.prepaidPlatformType = prepaidPlatformType;
	}

	/**
	 * @return the language
	 */
	public String getLanguage() {
		return language;
	}

	/**
	 * @param language
	 *            the language to set
	 */
	public void setLanguage(String language) {
		this.language = language;
	}

	/**
	 * @return the currency
	 */
	public String getCurrency() {
		return currency;
	}

	/**
	 * @param currency
	 *            the currency to set
	 */
	public void setCurrency(String currency) {
		this.currency = currency;
	}

	/**
	 * @return the generation
	 */
	public String getGeneration() {
		return generation;
	}

	/**
	 * @param generation
	 *            the generation to set
	 */
	public void setGeneration(String generation) {
		this.generation = generation;
	}

	/**
	 * @return the networkGroup
	 */
	public String getNetworkGroup() {
		return networkGroup;
	}

	/**
	 * @param networkGroup
	 *            the networkGroup to set
	 */
	public void setNetworkGroup(String networkGroup) {
		this.networkGroup = networkGroup;
	}

	/**
	 * @return the prevNetworkGroup
	 */
	public String getPrevNetworkGroup() {
		return prevNetworkGroup;
	}

	/**
	 * @param prevNetworkGroup
	 *            the prevNetworkGroup to set
	 */
	public void setPrevNetworkGroup(String prevNetworkGroup) {
		this.prevNetworkGroup = prevNetworkGroup;
	}

	/**
	 * @return the paymentType
	 */
	public String getPaymentType() {
		return paymentType;
	}

	/**
	 * @param paymentType
	 *            the paymentType to set
	 */
	public void setPaymentType(String paymentType) {
		this.paymentType = paymentType;
	}

	/**
	 * @return the prepaidPlatformType
	 */
	public String getPrepaidPlatformType() {
		return prepaidPlatformType;
	}

	/**
	 * @param prepaidPlatformType
	 *            the prepaidPlatformType to set
	 */
	public void setPrepaidPlatformType(String prepaidPlatformType) {
		this.prepaidPlatformType = prepaidPlatformType;
	}
    
    
        
}
