package com.att.tpp.xml.model;

public enum RoutingCarrier {

    CNGULR("CNGULR"),
    CNGLR_1("CNGLR1"),
    CNGLR_2("CNGLR2"),
    CNGLR_3("CNGLR3"),
    CNGLR_4("CNGLR4"),
    AWSCV_2("AWSCV2"),
    CARIBB("CARIBB"),
    SMS_SE("SMS_SE"),
    SMS_SW("SMS_SW"),
    SMS_NE("SMS_NE"),
    SMS_WE("SMS_WE"),
    MIM("MIM"),
    CARE("CARE"),
    TLG("TLG"),
    COMPAS("COMPAS"),
    CSI("CSI"),
    OLAMCEF("OLAMCEF"),
    EOD("EOD");

    private final String value;

    RoutingCarrier(String v) {
        value = v;
    }

    public String value() {
        return value;
    }

    public static RoutingCarrier fromValue(String v) {
        for (RoutingCarrier c: RoutingCarrier.values()) {
            if (c.value.equals(v)) {
                return c;
            }
        }
        throw new IllegalArgumentException(v);
    }

}
