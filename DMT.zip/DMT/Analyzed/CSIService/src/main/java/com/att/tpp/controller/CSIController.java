/**
 * 
 */
package com.att.tpp.controller;

import java.io.IOException;
import java.util.Calendar;
import java.util.List;
import java.util.StringTokenizer;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.att.aft.dme2.internal.jackson.map.ObjectMapper;
import com.att.tpp.config.InitGlobalInstance;
import com.att.tpp.config.SystemConfigElement;
import com.att.tpp.config.URIConfigElement;
import com.att.tpp.enumuration.CSIEventType;
import com.att.tpp.jms.listener.OtherProperties;
import com.att.tpp.model.CSI_MESSAGE_ARCHIVE;
import com.att.tpp.model.CsiTimer;
import com.att.tpp.model.ProcessingResult;
import com.att.tpp.model.RetryConfiguration;
import com.att.tpp.model.WebServiceResponseData;
import com.att.tpp.service.CSIService;
import com.att.tpp.utils.PropertiesUtil;
import com.att.tpp.utils.TPP_TransactionRequestXMLGenerator;
import com.att.tpp.utils.XMLDateUtil;
import com.att.tpp.utils.XMLGenerator;
import com.att.tpp.model.CSIRetryErrors;
import org.json.JSONObject;

/**
 * @author SC9833
 *
 */
@Service("csiController")
public class CSIController {
	
	@Autowired
	private CSIService csiService;
	
	@Autowired
	private PropertiesUtil propertiesUtilService;
		
	private static final Logger csiControllerLog = Logger.getLogger(CSIController.class);
	
	private final static String TPP_ArchiveRequestXSD = "TPP_ArchiveRequest.xsd";
	private final static String TPP_FulfillmentResultXSD = "TPP_FulfillmentResult.xsd";
	private final static String TPP_TransactionRequestXSD = "TPP_TransactionRequest.xsd";
	
	
	
	
	public ProcessingResult processRequest(OtherProperties otherProperties) throws IOException, Exception{
		
		boolean isValidRequest = false;
		String masterTransId=null;
		String location = null;
		String tppTransactionId = null;
		ProcessingResult processingResult = new ProcessingResult();
		XMLGenerator xmlGenerator = new XMLGenerator();
		WebServiceResponseData webServiceResponseData = null;
		
		
		//Identify if the incoming XML is valid and is of a valid eventType
		isValidRequest = csiService.validateEvent(otherProperties.getRequestXML(), otherProperties.getEventType());
		
		if(isValidRequest){
			csiControllerLog.info("Successful XML Validation After Receiving from CSI Inbound Queue!");
			processingResult.setValidRequest(isValidRequest);
			csiControllerLog.info("ValidRequest = " + isValidRequest);	
			
			//Invoke CSI webservice based on the eventType
			webServiceResponseData = csiService.invokeCSIWebService(otherProperties);
			
			/* FIX for WR# 2738943- Multiple Retry of  SKU provisioning request after 200-OK and AddOrderNotes response received */
			if(otherProperties.getEventType().equals(CSIEventType.AddOrderNotes.toString())){
				csiControllerLog.info("Delete from Timer since AddOrderNotes XML response recieved from vendor");
				csiControllerLog.info("Inside AddOrderNotes Retry Timer check, taskTransId : "+webServiceResponseData.getTppTransactionid());
				boolean deleteFromTimer = csiService.deleteFromTimer(webServiceResponseData.getTppTransactionid());
				csiControllerLog.info("Delete from Timer : "+deleteFromTimer);
			}
			
			if(webServiceResponseData.getTppTransactionid()!=null){
				processingResult.setTransactionId(webServiceResponseData.getTppTransactionid());			
			
				csiControllerLog.info("CSI Service invoked for the following event: " + otherProperties.getEventType());
				csiControllerLog.info("CSI Service call result: " + webServiceResponseData.getCsiResponsecode());			
				csiControllerLog.info("CSITransaction " + webServiceResponseData.getTppTransactionid());
		
				tppTransactionId = webServiceResponseData.getTppTransactionid();
				masterTransId = getMasterTransId(tppTransactionId);	
				csiControllerLog.info("MasterTransId: " + masterTransId);
				webServiceResponseData.setMasterTransId(masterTransId);
				
				location = propertiesUtilService.getLocation(tppTransactionId);						
				csiControllerLog.info("Location: " + location);
				webServiceResponseData.setLocation(location);			
				
				//Get the systemName from the masterTransId 
				String systemName = csiService.getSystemName(masterTransId);
				csiControllerLog.info("SystemName " + systemName);			
				webServiceResponseData.setVendorName(systemName);
			}
			
			insertIntoCsiMessageArchive(webServiceResponseData);
						
			//Based on the CSIResponseCode and fulfillment validation type
			if(webServiceResponseData.isFulfillmentValidation()){		
				processFulfillmentValidationResponse(processingResult, webServiceResponseData);				
				
			}else{
				if(((webServiceResponseData.getCsiResponsecode())!=null) && ((webServiceResponseData.getCsiResponsecode().equals("0")) || !(verifyRetryError(webServiceResponseData))) ){
					if(!(webServiceResponseData.isFulfillmentValidation()) && !(webServiceResponseData.getInterfaceName().equals(CSIEventType.AddOrderNotes.toString()))){
						/* AddNote ws call success response flow */
						
						List<CsiTimer> csiTimerList = csiService.getCSITimerRecord(webServiceResponseData.getMasterTransId());
						if(csiTimerList!=null && csiTimerList.size()>0){ 
							/* If CSITimer already exists please delete it before creating ArchiveRequest */				
							boolean deleteFromCSITimer = csiService.deleteFromCSITimer(webServiceResponseData.getMasterTransId());
						    csiControllerLog.info("Delete from CSITimer : "+deleteFromCSITimer);
						    }
						
						String createArchiveRequestXML = xmlGenerator.createArchiveRequestXML(webServiceResponseData.getMasterTransId());
						csiControllerLog.info("createArchiveRequestXML " + createArchiveRequestXML);		
						boolean isValidArchive = csiService.validateXML(createArchiveRequestXML, TPP_ArchiveRequestXSD, false);
						csiControllerLog.info("Validating the ArchiveRequestXML " + isValidArchive);		
						processingResult.setArchiveRequestXML(createArchiveRequestXML);
						processingResult.setValidArchive(isValidArchive);
					}else{
						//AddOrderNote
						csiControllerLog.info("Not satified the archive and retry conditions, so droping the transaction");
					}
				}else if(verifyRetryError(webServiceResponseData)){
					CsiTimer csiTimer = generateCsiTimerData(webServiceResponseData);
					csiControllerLog.info("Inside processRequest(), csitimer TppcsiTransactionid : "+csiTimer.getTppcsiTransactionid());
					if(csiTimer!=null && csiTimer.getTppcsiTransactionid()!=null && !csiTimer.getTppcsiTransactionid().equals("")){
						boolean csiTimerResult = csiService.insertCSITimerData(csiTimer);
						csiControllerLog.info("Insert into csiTimerResult : " + csiTimerResult);		
					}else{
					 csiControllerLog.info("Since the CSITimer condition is not satisfied, dropping the transaction from the CSI Retry");
					}
				}
			}
			
		}else{
			csiControllerLog.info("Unsuccessful XML Validation After Receiving from CSI Inbound Queue and dropping the message!");
		}
		
		csiControllerLog.info("ValidRequest = " + isValidRequest);
		processingResult.setValidRequest(isValidRequest);
		
		return processingResult;
		
	}


	private void insertIntoCsiMessageArchive(WebServiceResponseData webServiceResponseData)
			throws Exception {
		//Generate the CSI Message Archive Data
		CSI_MESSAGE_ARCHIVE csiMessageArchive = generateCsiMessageArchiveData(webServiceResponseData);			
		boolean csiMessageArchiveResult = csiService.insertCSIMessageArchive(csiMessageArchive);
		csiControllerLog.info("Insert into csiMessageArchiveResult : " + csiMessageArchiveResult);
		ObjectMapper mapper = new ObjectMapper();
		csiControllerLog.info("{"+mapper.writeValueAsString(csiMessageArchive)+"}");
	}


	private void processFulfillmentValidationResponse(ProcessingResult processingResult,
			WebServiceResponseData webServiceResponseData) throws IOException,
			Exception {		
		//if fulfillment indicator is Y then send to comunication queue
		
		boolean fulfillmentIndicator = csiService.findFulfillmentIndicator(webServiceResponseData.getVendorName());
		
		csiControllerLog.info("fulfillmentIndicator : " + fulfillmentIndicator);		
		if(fulfillmentIndicator){
		 	String fulfillmentValidationXML = webServiceResponseData.getFulfillmentValidationXML();
			csiControllerLog.info("fulfillmentValidationXML : " + fulfillmentValidationXML);
			//Getting system configuration element from the hashMap 
			SystemConfigElement systemConfigElement = InitGlobalInstance.getSystemConfig().get(webServiceResponseData.getVendorName());
			//Getting URI configuration element from the hashMap 
			URIConfigElement uriConfigElement = InitGlobalInstance.getURIConfig().get(webServiceResponseData.getVendorName());

			//Generate the tppProvisioningRequest
			TPP_TransactionRequestXMLGenerator tppTransactionRequestXMLGenerator = new TPP_TransactionRequestXMLGenerator();
			String tppProvisioningRequestXML = tppTransactionRequestXMLGenerator.createTransactionRequestXML(fulfillmentValidationXML, webServiceResponseData, uriConfigElement, systemConfigElement);
			
			csiControllerLog.info("tppProvisioningRequestXML : " + tppProvisioningRequestXML);
			
			boolean isValidFulfillmentXML = csiService.validateXML(fulfillmentValidationXML, TPP_FulfillmentResultXSD, true);
			csiControllerLog.info("isValidFulfillmentXML : " + isValidFulfillmentXML);
			
			boolean isValidTppProvisioingRequestXML = csiService.validateXML(tppProvisioningRequestXML, TPP_TransactionRequestXSD, false);
			csiControllerLog.info("isValidTppProvisioingRequestXML : " + isValidTppProvisioingRequestXML);
			processingResult.setFulfillmentValidXML(isValidTppProvisioingRequestXML);
			processingResult.setFulfillmentValidationXML(tppProvisioningRequestXML);
			
			if(isValidTppProvisioingRequestXML){
				webServiceResponseData.setInputXml(fulfillmentValidationXML);
				webServiceResponseData.setInterfaceName(CSIEventType.FulfillmentResult.toString());
				insertIntoCsiMessageArchive(webServiceResponseData);
			}			
			
		}else{
			csiControllerLog.info("fulfillment Indicator is not turn on, so dropping the transaction");
		}
	}


	private String getMasterTransId(String tppTransactionid) {
		String masterTransId=tppTransactionid;
		if(tppTransactionid.contains("_")){
			masterTransId=tppTransactionid.substring(0, tppTransactionid.indexOf("_"));
		/*	StringTokenizer taskTransIdTokenizer = new StringTokenizer(tppTransactionid, "_");
			while (taskTransIdTokenizer.hasMoreElements()) {			
				masterTransId=taskTransIdTokenizer.nextElement().toString();
				break;
				//csiControllerLog.info(taskTransIdTokenizer.nextElement().toString());
				//csiControllerLog.info(taskTransIdTokenizer.nextElement().toString());				
			}	*/		
		}
		csiControllerLog.info("MasterTransId: "+masterTransId +"from TaskTransactionId:"+tppTransactionid);
		return masterTransId;
	}
	
//	private String getLocation(String tppTransactionid) {
//		String location = "No Location";
//		if(tppTransactionid.contains("$")){
//			location = tppTransactionid.substring(tppTransactionid.indexOf("$")+1, tppTransactionid.length());
//				csiControllerLog.info("Getting Location from tppTransactionId: " + location);						
//		}
//		else{
//			//use location passed from properties file
//		}
//		csiControllerLog.info("Location: "+ location +" from TaskTransactionId: "+tppTransactionid);
//		return location;
//	}


	private boolean verifyRetryError(WebServiceResponseData webServiceResponseData) throws Exception {		
		csiControllerLog.info("Inside the verifyRetryError :" + webServiceResponseData.getCsiResponsecode());
		
		/* This code update is to support CSI AddNotes Retry attempts and exclude "invalidProduct" system name getting into retry mode */
		if(webServiceResponseData.getCsiResponsecode()!=null && !(webServiceResponseData.getVendorName() !=null && webServiceResponseData.getVendorName().equalsIgnoreCase("InvalidProduct"))){
			List<CSIRetryErrors> csiRetryError = csiService.getCSIRetryError();
			for (CSIRetryErrors retryInfo : csiRetryError) {
				if(webServiceResponseData.getCsiResponsecode().equals(retryInfo.getErrorCode()) && webServiceResponseData.getInterfaceName().equals(retryInfo.getEventName())){
					csiControllerLog.info("Retry Code Exist: " + webServiceResponseData.getCsiResponsecode() +"EventName :"+ webServiceResponseData.getInterfaceName());		
					return true;
				}
			}
		}
		csiControllerLog.info("Retry Code Doesn't Exist ");
		return false;
	}

	private CSI_MESSAGE_ARCHIVE generateCsiMessageArchiveData(WebServiceResponseData webServiceResponseData) {		
		CSI_MESSAGE_ARCHIVE csiMessageArchive =  new CSI_MESSAGE_ARCHIVE();	
		XMLDateUtil xmlDateUtil = new XMLDateUtil();
		csiMessageArchive.setCarrierName(webServiceResponseData.getRoutingCarrier());
		csiMessageArchive.setCsiResponsecode(webServiceResponseData.getCsiResponsecode());
		csiMessageArchive.setCsiResponsedesc(webServiceResponseData.getCsiResponsedesc());
		csiMessageArchive.setInputXml(webServiceResponseData.getInputXml());
		csiMessageArchive.setInterfaceName(webServiceResponseData.getInterfaceName());
		csiMessageArchive.setLocation(webServiceResponseData.getLocation());
		csiMessageArchive.setOrderid(webServiceResponseData.getOrderid());
		csiMessageArchive.setRoutingCarrier(webServiceResponseData.getRoutingCarrier());
		csiMessageArchive.setSkuStatus(webServiceResponseData.getSkuStatus());
		//Todo:Modify the ws setTimeStamp 
		csiMessageArchive.setTimeStamp(xmlDateUtil.getTimeStamp());		
		csiMessageArchive.setTppcsiTransactionid(webServiceResponseData.getTppcsiTransactionid());
		csiMessageArchive.setTppTransactionid(webServiceResponseData.getTppTransactionid());
		csiMessageArchive.setRoutingCarrier(webServiceResponseData.getRoutingCarrier());
		csiMessageArchive.setVendorName(webServiceResponseData.getVendorName());
		
		
		return csiMessageArchive;
	}
	
	
	private CsiTimer generateCsiTimerData(
			WebServiceResponseData webServiceResponseData) throws Exception {
		
		CsiTimer csiTimer = new CsiTimer();
		
		String tppcsiTransactionid = webServiceResponseData.getMasterTransId();
		csiControllerLog.info("Inside generateCsiTimerData(), tppcsiTransactionid : "+tppcsiTransactionid);
		
		String systemName= webServiceResponseData.getVendorName();
		csiControllerLog.info("Inside generateCsiTimerData(), systemName : "+systemName);
		
		if(tppcsiTransactionid!=null && systemName!=null){
			List<CsiTimer> csiTimerList = csiService.getCSITimerRecord(tppcsiTransactionid);
			csiControllerLog.info("Inside generateCsiTimerData(), csiTimerList size : "+csiTimerList.size());
			
			List<RetryConfiguration> retryConfigurationList = csiService.getRetryConfiguration(systemName);
			csiControllerLog.info("Inside generateCsiTimerData(), retryConfigurationList size : "+retryConfigurationList.size());
			
			RetryConfiguration retryConfiguration = new RetryConfiguration();
			retryConfiguration = retryConfigurationList.get(0);
			Calendar currentTimeStamp = Calendar.getInstance();
			
			csiTimer.setTppcsiTransactionid(tppcsiTransactionid);
			csiTimer.setSystemName(webServiceResponseData.getInterfaceName().trim());
			csiTimer.setTimerState("Waiting To Resubmit");
			csiTimer.setRetryInd("Y");
			csiTimer.setMaxRetryCount(3);
			csiTimer.setRetryType("response_failure");
			csiTimer.setPayload(webServiceResponseData.getInputXml());
			csiTimer.setCreationTime(currentTimeStamp.getTime());
			//csiTimer.setRetryCount(csiTimerList.get(0).getRetryCount());
			
			
		 if(retryConfigurationList!=null && retryConfigurationList.size()>0){	
			 
			if(csiTimerList!=null && csiTimerList.size()>0){
				CsiTimer csiTimerRecord = csiTimerList.get(0);
				retryConfiguration = retryConfigurationList.get(0);
				csiTimer.setTimerDuration(retryConfiguration.getWaitTime());
				currentTimeStamp.add(Calendar.MILLISECOND, retryConfiguration.getWaitTime());
				csiTimer.setExpiryTime(currentTimeStamp.getTime());				
				csiControllerLog.info("Inside generateCsiTimerData(), Current CSI Retry count:"+csiTimerRecord.getRetryCount());		
				csiTimer.setRetryCount(csiTimerRecord.getRetryCount());
			}else{
				retryConfiguration = retryConfigurationList.get(0);				
				csiTimer.setTimerDuration(retryConfiguration.getWaitTime());
				currentTimeStamp.add(Calendar.MILLISECOND, retryConfiguration.getWaitTime());
				csiTimer.setExpiryTime(currentTimeStamp.getTime());
			}			
		 }else{			 
			 csiControllerLog.info("Retry Configuration is empty for the System Name : "+systemName);	 
		 }			
		}else{
			 csiControllerLog.info("tppcsiTransactionid || systemName is null and dropping the transaction ");		 
		}
		return csiTimer;
	}


	public void loadInitialData() {		
		csiService.loadInitialData();		
	}
}
	

