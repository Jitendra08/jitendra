package com.att.tpp.model;

import java.io.Serializable;

/**
 *
 * @author sg625m
 */

public class ProcessingResult implements Serializable  {
	
	private static final long serialVersionUID = 1L;
	
	boolean isValidRequest=false;
	boolean isValidProductExist=false;
	boolean isPersistedInDB=false;
	boolean isDeletedFromDB=false;
	boolean isSystemReroute=false;
	boolean isCSIDipExist=false;
	private String transactionId;
	private String msisdn;
	private String csiEventName;
	private String responseEventType;
	private String archiveRequestXML;
	private boolean isFulfillmentValidXML=false;
	private String fulfillmentValidationXML;
	
	boolean isValidArchive=false;
	
	private String tppProvReq;
	
	public ProcessingResult() {
	}
	
	public String getMsisdn() {
		return msisdn;
	}


	public void setMsisdn(String msisdn) {
		this.msisdn = msisdn;
	}


	public boolean isSystemReroute() {
		return isSystemReroute;
	}


	public void setSystemReroute(boolean isSystemReroute) {
		this.isSystemReroute = isSystemReroute;
	}


	public boolean isDeletedFromDB() {
		return isDeletedFromDB;
	}


	public void setDeletedFromDB(boolean isDeletedFromDB) {
		this.isDeletedFromDB = isDeletedFromDB;
	}


	public String getTransactionId() {
		return transactionId;
	}


	public void setTransactionId(String transactionId) {
		this.transactionId = transactionId;
	}


	public boolean isValidRequest() {
		return isValidRequest;
	}


	public void setValidRequest(boolean isValidRequest) {
		this.isValidRequest = isValidRequest;
	}


	public boolean isValidProductExist() {
		return isValidProductExist;
	}


	public void setValidProductExist(boolean isValidProductExist) {
		this.isValidProductExist = isValidProductExist;
	}


	public boolean isPersistedInDB() {
		return isPersistedInDB;
	}


	public void setPersistedInDB(boolean isPersistedInDB) {
		this.isPersistedInDB = isPersistedInDB;
	}


	public boolean isCSIDipExist() {
		return isCSIDipExist;
	}


	public void setCSIDipExist(boolean isCSIDipExist) {
		this.isCSIDipExist = isCSIDipExist;
	}

	
	public String getCsiEventName() {
		return csiEventName;
	}


	public void setCsiEventName(String csiEventName) {
		this.csiEventName = csiEventName;
	}

	
	public String getResponseEventType() {
		return responseEventType;
	}


	public void setResponseEventType(String responseEventType) {
		this.responseEventType = responseEventType;
	}

	
	public String getTppProvReq() {
		return tppProvReq;
	}


	public void setTppProvReq(String tppProvReq) {
		this.tppProvReq = tppProvReq;
	}

	public String getArchiveRequestXML() {
		return archiveRequestXML;
	}

	public void setArchiveRequestXML(String archiveRequestXML) {
		this.archiveRequestXML = archiveRequestXML;
	}

	public boolean isValidArchive() {
		return isValidArchive;
	}

	public void setValidArchive(boolean isValidArchive) {
		this.isValidArchive = isValidArchive;
	}


	public String getFulfillmentValidationXML() {
		return fulfillmentValidationXML;
	}

	public void setFulfillmentValidationXML(String fulfillmentValidationXML) {
		this.fulfillmentValidationXML = fulfillmentValidationXML;
	}

	public boolean isFulfillmentValidXML() {
		return isFulfillmentValidXML;
	}

	public void setFulfillmentValidXML(boolean isFulfillmentValidXML) {
		this.isFulfillmentValidXML = isFulfillmentValidXML;
	}

	
	

}
