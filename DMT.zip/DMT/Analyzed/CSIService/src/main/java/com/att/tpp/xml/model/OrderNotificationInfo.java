package com.att.tpp.xml.model;

import java.math.BigDecimal;
import java.util.Collection;
import javax.xml.datatype.XMLGregorianCalendar;


public class OrderNotificationInfo {

    private OrderDocumentInfo orderId;
    private String orderWarehouse;
    private XMLGregorianCalendar orderDate;
    private String paymentMethod;
    private OrderNotificationInfo.Customer customer;
    private Collection<AttributeInfo> orderAttributes;
    private Collection<OrderNotificationInfo.OrderLine> orderLine;

    /**
	 * @param orderId
	 * @param orderWarehouse
	 * @param orderDate
	 */
	public OrderNotificationInfo(OrderDocumentInfo orderId,
			String orderWarehouse, XMLGregorianCalendar orderDate) {
		this.orderId = orderId;
		this.orderWarehouse = orderWarehouse;
		this.orderDate = orderDate;
	}

	/**
	 * @param orderId
	 * @param orderWarehouse
	 * @param orderDate
	 * @param paymentMethod
	 * @param customer
	 * @param orderAttributes
	 * @param orderLine
	 */
	public OrderNotificationInfo(OrderDocumentInfo orderId,
			String orderWarehouse, XMLGregorianCalendar orderDate,
			String paymentMethod, Customer customer,
			Collection<AttributeInfo> orderAttributes,
			Collection<OrderLine> orderLine) {
		this.orderId = orderId;
		this.orderWarehouse = orderWarehouse;
		this.orderDate = orderDate;
		this.paymentMethod = paymentMethod;
		this.customer = customer;
		this.orderAttributes = orderAttributes;
		this.orderLine = orderLine;
	}

	/**
     * Gets the value of the orderId property.
     * 
     * @return
     *     possible object is
     *     {@link OrderDocumentInfo }
     *     
     */
    public OrderDocumentInfo getOrderId() {
        return orderId;
    }

    /**
     * Sets the value of the orderId property.
     * 
     * @param orderId
     *     allowed object is
     *     {@link OrderDocumentInfo }
     *     
     */
    public void setOrderId(OrderDocumentInfo orderId) {
        this.orderId = orderId;
    }

    /**
     * Gets the value of the orderWarehouse property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getOrderWarehouse() {
        return orderWarehouse;
    }

    /**
     * Sets the value of the orderWarehouse property.
     * 
     * @param orderWarehouse
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setOrderWarehouse(String orderWarehouse) {
        this.orderWarehouse = orderWarehouse;
    }

    /**
     * Gets the value of the orderDate property.
     * 
     * @return
     *     possible object is
     *     {@link XMLGregorianCalendar }
     *     
     */
    public XMLGregorianCalendar getOrderDate() {
        return orderDate;
    }

    /**
     * Sets the value of the orderDate property.
     * 
     * @param orderDate
     *     allowed object is
     *     {@link XMLGregorianCalendar }
     *     
     */
    public void setOrderDate(XMLGregorianCalendar orderDate) {
        this.orderDate = orderDate;
    }

    /**
     * Gets the value of the paymentMethod property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getPaymentMethod() {
        return paymentMethod;
    }

    /**
     * Sets the value of the paymentMethod property.
     * 
     * @param paymentMethod
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setPaymentMethod(String paymentMethod) {
        this.paymentMethod = paymentMethod;
    }

    /**
     * Gets the value of the customer property.
     * 
     * @return
     *     possible object is
     *     {@link OrderNotificationInfo.Customer }
     *     
     */
    public OrderNotificationInfo.Customer getCustomer() {
        return customer;
    }

    /**
     * Sets the value of the customer property.
     * 
     * @param customer
     *     allowed object is
     *     {@link OrderNotificationInfo.Customer }
     *     
     */
    public void setCustomer(OrderNotificationInfo.Customer customer) {
        this.customer = customer;
    }

    /**
	 * @return the orderAttributes
	 */
	public Collection<AttributeInfo> getOrderAttributes() {
		return orderAttributes;
	}

	/**
	 * @param orderAttributes the orderAttributes to set
	 */
	public void setOrderAttributes(Collection<AttributeInfo> orderAttributes) {
		this.orderAttributes = orderAttributes;
	}

	/**
	 * @return the orderLine
	 */
	public Collection<OrderNotificationInfo.OrderLine> getOrderLine() {
		return orderLine;
	}

	/**
	 * @param orderLine the orderLine to set
	 */
	public void setOrderLine(Collection<OrderNotificationInfo.OrderLine> orderLine) {
		this.orderLine = orderLine;
	}


    public static class Customer {

        private String customerId;
        private NameInfo name;
        private String businessName;
        private NGPNameInfo ngpName;
        private AddressTwoLineSimpleInfo shippingAddress;
        private OrderNotificationInfo.Customer.BillingAccountData billingAccountData;
        private Collection<EmailInfo> email;
        private PhoneInfo phone;

        /**
		 * @param customerId
		 * @param name
		 * @param ngpName
		 * @param shippingAddress
		 */
		public Customer(String customerId, NameInfo name, NGPNameInfo ngpName,
				AddressTwoLineSimpleInfo shippingAddress) {
			this.customerId = customerId;
			this.name = name;
			this.ngpName = ngpName;
			this.shippingAddress = shippingAddress;
		}

		/**
		 * @param customerId
		 * @param businessName
		 * @param ngpName
		 * @param shippingAddress
		 */
		public Customer(String customerId, String businessName,
				NGPNameInfo ngpName, AddressTwoLineSimpleInfo shippingAddress) {
			this.customerId = customerId;
			this.businessName = businessName;
			this.ngpName = ngpName;
			this.shippingAddress = shippingAddress;
		}

		/**
		 * @param customerId
		 * @param name
		 * @param ngpName
		 * @param shippingAddress
		 * @param billingAccountData
		 * @param email
		 * @param phone
		 */
		public Customer(String customerId, NameInfo name, NGPNameInfo ngpName,
				AddressTwoLineSimpleInfo shippingAddress,
				BillingAccountData billingAccountData,
				Collection<EmailInfo> email, PhoneInfo phone) {
			this.customerId = customerId;
			this.name = name;
			this.ngpName = ngpName;
			this.shippingAddress = shippingAddress;
			this.billingAccountData = billingAccountData;
			this.email = email;
			this.phone = phone;
		}

		/**
		 * @param customerId
		 * @param businessName
		 * @param ngpName
		 * @param shippingAddress
		 * @param billingAccountData
		 * @param email
		 * @param phone
		 */
		public Customer(String customerId, String businessName,
				NGPNameInfo ngpName, AddressTwoLineSimpleInfo shippingAddress,
				BillingAccountData billingAccountData,
				Collection<EmailInfo> email, PhoneInfo phone) {
			this.customerId = customerId;
			this.businessName = businessName;
			this.ngpName = ngpName;
			this.shippingAddress = shippingAddress;
			this.billingAccountData = billingAccountData;
			this.email = email;
			this.phone = phone;
		}

		/**
         * Gets the value of the customerId property.
         * 
         * @return
         *     possible object is
         *     {@link String }
         *     
         */
        public String getCustomerId() {
            return customerId;
        }

        /**
         * Sets the value of the customerId property.
         * 
         * @param customerId
         *     allowed object is
         *     {@link String }
         *     
         */
        public void setCustomerId(String customerId) {
            this.customerId = customerId;
        }

        /**
         * Gets the value of the name property.
         * 
         * @return
         *     possible object is
         *     {@link NameInfo }
         *     
         */
        public NameInfo getName() {
            return name;
        }

        /**
         * Sets the value of the name property.
         * 
         * @param name
         *     allowed object is
         *     {@link NameInfo }
         *     
         */
        public void setName(NameInfo name) {
            this.name = name;
        }

        /**
         * Gets the value of the businessName property.
         * 
         * @return
         *     possible object is
         *     {@link String }
         *     
         */
        public String getBusinessName() {
            return businessName;
        }

        /**
         * Sets the value of the businessName property.
         * 
         * @param businessName
         *     allowed object is
         *     {@link String }
         *     
         */
        public void setBusinessName(String businessName) {
            this.businessName = businessName;
        }

        /**
         * Gets the value of the ngpName property.
         * 
         * @return
         *     possible object is
         *     {@link NGPNameInfo }
         *     
         */
        public NGPNameInfo getNGPName() {
            return ngpName;
        }

        /**
         * Sets the value of the ngpName property.
         * 
         * @param ngpName
         *     allowed object is
         *     {@link NGPNameInfo }
         *     
         */
        public void setNGPName(NGPNameInfo ngpName) {
            this.ngpName = ngpName;
        }

        /**
         * Gets the value of the shippingAddress property.
         * 
         * @return
         *     possible object is
         *     {@link AddressTwoLineSimpleInfo }
         *     
         */
        public AddressTwoLineSimpleInfo getShippingAddress() {
            return shippingAddress;
        }

        /**
         * Sets the value of the shippingAddress property.
         * 
         * @param shippingAddress
         *     allowed object is
         *     {@link AddressTwoLineSimpleInfo }
         *     
         */
        public void setShippingAddress(AddressTwoLineSimpleInfo shippingAddress) {
            this.shippingAddress = shippingAddress;
        }

        /**
         * Gets the value of the billingAccountData property.
         * 
         * @return
         *     possible object is
         *     {@link OrderNotificationInfo.Customer.BillingAccountData }
         *     
         */
        public OrderNotificationInfo.Customer.BillingAccountData getBillingAccountData() {
            return billingAccountData;
        }

        /**
         * Sets the value of the billingAccountData property.
         * 
         * @param billingAccountData
         *     allowed object is
         *     {@link OrderNotificationInfo.Customer.BillingAccountData }
         *     
         */
        public void setBillingAccountData(OrderNotificationInfo.Customer.BillingAccountData billingAccountData) {
            this.billingAccountData = billingAccountData;
        }

        /**
		 * @return the email
		 */
		public Collection<EmailInfo> getEmail() {
			return email;
		}

		/**
		 * @param email the email to set
		 */
		public void setEmail(Collection<EmailInfo> email) {
			this.email = email;
		}

		/**
         * Gets the value of the phone property.
         * 
         * @return
         *     possible object is
         *     {@link PhoneInfo }
         *     
         */
        public PhoneInfo getPhone() {
            return phone;
        }

        /**
         * Sets the value of the phone property.
         * 
         * @param phone
         *     allowed object is
         *     {@link PhoneInfo }
         *     
         */
        public void setPhone(PhoneInfo phone) {
            this.phone = phone;
        }

        
        public static class BillingAccountData {

            private String billingMarket;
            private String billingSubMarket;
            private String billingAccountNumber;

            /**
			 * @param billingMarket
			 * @param billingSubMarket
			 * @param billingAccountNumber
			 */
			public BillingAccountData(String billingMarket,
					String billingSubMarket, String billingAccountNumber) {
				this.billingMarket = billingMarket;
				this.billingSubMarket = billingSubMarket;
				this.billingAccountNumber = billingAccountNumber;
			}

			/**
             * Gets the value of the billingMarket property.
             * 
             * @return
             *     possible object is
             *     {@link String }
             *     
             */
            public String getBillingMarket() {
                return billingMarket;
            }

            /**
             * Sets the value of the billingMarket property.
             * 
             * @param billingMarket
             *     allowed object is
             *     {@link String }
             *     
             */
            public void setBillingMarket(String billingMarket) {
                this.billingMarket = billingMarket;
            }

            /**
             * Gets the value of the billingSubMarket property.
             * 
             * @return
             *     possible object is
             *     {@link String }
             *     
             */
            public String getBillingSubMarket() {
                return billingSubMarket;
            }

            /**
             * Sets the value of the billingSubMarket property.
             * 
             * @param billingSubMarket
             *     allowed object is
             *     {@link String }
             *     
             */
            public void setBillingSubMarket(String billingSubMarket) {
                this.billingSubMarket = billingSubMarket;
            }

            /**
             * Gets the value of the billingAccountNumber property.
             * 
             * @return
             *     possible object is
             *     {@link String }
             *     
             */
            public String getBillingAccountNumber() {
                return billingAccountNumber;
            }

            /**
             * Sets the value of the billingAccountNumber property.
             * 
             * @param billingAccountNumber
             *     allowed object is
             *     {@link String }
             *     
             */
            public void setBillingAccountNumber(String billingAccountNumber) {
                this.billingAccountNumber = billingAccountNumber;
            }

        }

    }


    public static class OrderLine {

        private int lineNumber;
        private String actionCode;
        private String vendorItemId;
        private String cingularItemId;
        private String salesRep;
        private long quantity;
        private BigDecimal extendedPrice;
        private String subscriberNumber;

        /**
         * Gets the value of the lineNumber property.
         * 
         */
        public int getLineNumber() {
            return lineNumber;
        }

        /**
         * Sets the value of the lineNumber property.
         * 
         */
        public void setLineNumber(int lineNumber) {
            this.lineNumber = lineNumber;
        }

        /**
         * Gets the value of the actionCode property.
         * 
         * @return
         *     possible object is
         *     {@link ActionInfo }
         *     
         */
        public String getActionCode() {
            return actionCode;
        }

        /**
         * Sets the value of the actionCode property.
         * 
         * @param actionCode
         *     allowed object is
         *     {@link ActionInfo }
         *     
         */
        public void setActionCode(String actionCode) {
            this.actionCode = actionCode;
        }

        /**
         * Gets the value of the vendorItemId property.
         * 
         * @return
         *     possible object is
         *     {@link String }
         *     
         */
        public String getVendorItemId() {
            return vendorItemId;
        }

        /**
         * Sets the value of the vendorItemId property.
         * 
         * @param vendorItemId
         *     allowed object is
         *     {@link String }
         *     
         */
        public void setVendorItemId(String vendorItemId) {
            this.vendorItemId = vendorItemId;
        }

        /**
         * Gets the value of the cingularItemId property.
         * 
         * @return
         *     possible object is
         *     {@link String }
         *     
         */
        public String getCingularItemId() {
            return cingularItemId;
        }

        /**
         * Sets the value of the cingularItemId property.
         * 
         * @param cingularItemId
         *     allowed object is
         *     {@link String }
         *     
         */
        public void setCingularItemId(String cingularItemId) {
            this.cingularItemId = cingularItemId;
        }

        /**
         * Gets the value of the salesRep property.
         * 
         * @return
         *     possible object is
         *     {@link String }
         *     
         */
        public String getSalesRep() {
            return salesRep;
        }

        /**
         * Sets the value of the salesRep property.
         * 
         * @param salesRep
         *     allowed object is
         *     {@link String }
         *     
         */
        public void setSalesRep(String salesRep) {
            this.salesRep = salesRep;
        }

        /**
         * Gets the value of the quantity property.
         * 
         */
        public long getQuantity() {
            return quantity;
        }

        /**
         * Sets the value of the quantity property.
         * 
         */
        public void setQuantity(long quantity) {
            this.quantity = quantity;
        }

        /**
         * Gets the value of the extendedPrice property.
         * 
         * @return
         *     possible object is
         *     {@link BigDecimal }
         *     
         */
        public BigDecimal getExtendedPrice() {
            return extendedPrice;
        }

        /**
         * Sets the value of the extendedPrice property.
         * 
         * @param extendedPrice
         *     allowed object is
         *     {@link BigDecimal }
         *     
         */
        public void setExtendedPrice(BigDecimal extendedPrice) {
            this.extendedPrice = extendedPrice;
        }

        /**
         * Gets the value of the subscriberNumber property.
         * 
         * @return
         *     possible object is
         *     {@link String }
         *     
         */
        public String getSubscriberNumber() {
            return subscriberNumber;
        }

        /**
         * Sets the value of the subscriberNumber property.
         * 
         * @param subscriberNumber
         *     allowed object is
         *     {@link String }
         *     
         */
        public void setSubscriberNumber(String subscriberNumber) {
            this.subscriberNumber = subscriberNumber;
        }

    }

}
