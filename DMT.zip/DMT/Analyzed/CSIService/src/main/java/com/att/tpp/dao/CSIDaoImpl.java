package com.att.tpp.dao;

import java.util.List;

import org.apache.log4j.Logger;
import org.hibernate.HibernateException;
import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cache.annotation.Cacheable;
import org.springframework.stereotype.Repository;

import com.att.tpp.model.CSIRetryErrors;
import com.att.tpp.model.CSI_MESSAGE_ARCHIVE;
import com.att.tpp.model.CsiTimer;
import com.att.tpp.model.Timer;
import com.att.tpp.model.FeatureCodeRef;
import com.att.tpp.model.ProvisioningRequest;
import com.att.tpp.model.ProvisioningTask;
import com.att.tpp.model.RetryConfiguration;
import com.att.tpp.model.SystemConfiguration;
import com.att.tpp.model.TransCode;
import com.att.tpp.model.UriConfiguration;





@Repository("csiDao")
public class CSIDaoImpl implements CSIDao {
	
	private static final Logger csiDaoLog = Logger.getLogger(CSIDaoImpl.class);
	
	@Autowired
	private SessionFactory sessionFactoryArchive;
	
	@Autowired
	private SessionFactory sessionFactoryConfig;
	
	@Autowired
	private SessionFactory sessionFactoryData;



	@Override	
	public boolean insertCSIMessageArchive(CSI_MESSAGE_ARCHIVE csiMessageArchive)
			throws Exception {
		csiDaoLog.debug("Inside CSIDaoImpl insertCSIMessageArchive method");
		try {
			sessionFactoryArchive.getCurrentSession().save(csiMessageArchive);		
			sessionFactoryArchive.getCurrentSession().flush();
			return true;
		}catch (HibernateException e) {
			csiDaoLog.error("Exception occured in the CSIDaoImpl insertCSIMessageArchive method :"+e);
			e.printStackTrace();
			return false;
		}
	}



	@Override
	@SuppressWarnings("unchecked")
	public List<CSIRetryErrors> getCSIRetryError() throws Exception {
		csiDaoLog.debug("Inside CSIDaoImpl getCSIRetryError method");
		List<CSIRetryErrors> csiRetryError = (List<CSIRetryErrors>) sessionFactoryConfig
				.getCurrentSession()
				.createQuery("from CSIRetryErrors")
				.list();
		return csiRetryError;
	}



	@Override
	@SuppressWarnings("unchecked")
	public List<CsiTimer> getCSITimerRecord(String tppcsiTransactionid)
			throws Exception {
		csiDaoLog.debug("Inside CSIDaoImpl getCSIRetryError method");
		List<CsiTimer> csiRetryError = (List<CsiTimer>) sessionFactoryData
				.getCurrentSession()
				.createQuery("from CsiTimer ct where ct.tppcsiTransactionid = :tppcsiTransactionid")
				.setParameter("tppcsiTransactionid", tppcsiTransactionid)
				.list();
		return csiRetryError;
	}



	@Override
	public boolean insertCSITimerData(CsiTimer csiTimer) throws Exception {
		csiDaoLog.debug("Inside CSIDaoImpl insertCSITimerData method");
		try {
			sessionFactoryData.getCurrentSession().saveOrUpdate(csiTimer);		
			sessionFactoryData.getCurrentSession().flush();
			csiDaoLog.debug("Inside CSIDaoImpl insertCSITimerData method, Successfully inserted csitimer data");
			return true;
		}catch (HibernateException e) {
			csiDaoLog.error("Exception occured in the CSIDaoImpl insertCSITimerData method :"+e);
			e.printStackTrace();
			return false;
		}
	}
	
	/* FIX for WR# 2738943- Multiple Retry of SKU provisioning request after 200-OK and AddOrderNotes response received */
	@Override
	public boolean deleteFromTimer(String taskTransID) {
		int success = 0;
		try {
			success = sessionFactoryData
					.getCurrentSession()
					.createQuery("delete from Timer t where t.id.taskTransid = :taskTransid")
					.setParameter("taskTransid", taskTransID)
					.executeUpdate();
			sessionFactoryData.getCurrentSession().flush();
			return isSuccess(success);
		} catch (HibernateException he) {
			csiDaoLog
					.error("Hibernate Exception occured occured deleting from Timer Table: "
							+ he.getMessage());
			return isSuccess(success);
		}
	}

	@Override
	public boolean deleteFromCSITimer(String masterTransID) {
		int success = 0;
		try {
			success = sessionFactoryData
					.getCurrentSession()
					.createQuery("delete from CsiTimer ct where ct.tppcsiTransactionid = :tppcsiTransactionid")
					.setParameter("tppcsiTransactionid", masterTransID)
					.executeUpdate();
			sessionFactoryData.getCurrentSession().flush();
			return isSuccess(success);
		} catch (HibernateException he) {
			csiDaoLog
					.error("Hibernate Exception occured occured deleting from CSITimer Table: "
							+ he.getMessage());
			return isSuccess(success);
		}
	}
	
	
	@Override
	@SuppressWarnings("unchecked")
	public List<RetryConfiguration> getRetryConfiguration(String systemName)
			throws Exception {
		csiDaoLog.debug("Inside CSIDaoImpl getRetryConfiguration method");
		List<RetryConfiguration> retryConfiguration = (List<RetryConfiguration>) sessionFactoryConfig
				.getCurrentSession()
				.createQuery("from RetryConfiguration rc where rc.id.systemName = :systemName and rc.id.retryType= :retryType order by rc.id.retryAttemptNum asc")
				.setParameter("systemName", systemName)
				.setParameter("retryType", "response_failure")
				.list();
		return retryConfiguration;
	}



	@Override
	@SuppressWarnings("unchecked")
	public String getSystemName(String masterTransid) throws Exception {
		csiDaoLog.debug("Inside CSIDaoImpl getSystemName method");
		List<ProvisioningTask> provisioningTaskList = (List<ProvisioningTask>) sessionFactoryData
				.getCurrentSession()
				.createQuery("from ProvisioningTask ts where ts.id.masterTransid = :masterTransid")
				.setParameter("masterTransid", masterTransid)
				.list();
		
		String systemName=null;
		if(provisioningTaskList.size()>0){
			ProvisioningTask provisioningTask = (ProvisioningTask) provisioningTaskList.get(0);
			systemName = provisioningTask.getSystemName();
		}
		return systemName;
	}



	@Override
	@SuppressWarnings("unchecked")
	@Cacheable(value = "featureCodeTLGCache")
	public List<FeatureCodeRef> featureCodeRefList() throws Exception {
		csiDaoLog.debug("Inside the featureCodeList");
		List<FeatureCodeRef> featureCodeRefDBList=null;
		featureCodeRefDBList = (List<FeatureCodeRef>) sessionFactoryConfig
				.getCurrentSession()
				.createQuery("from FeatureCodeRef fr where fr.id.attributeValue=:attValue")
				.setParameter("attValue", "TLG")	
				.list();			
		  
		return featureCodeRefDBList;
		}
	
	@Override
	@SuppressWarnings("unchecked")
	@Cacheable(value = "featureCodeDCMCache")
	public List<FeatureCodeRef> dcmFeatureCodeRefList() throws Exception {
		csiDaoLog.info("Inside the featureCodeList>>>");
		List<FeatureCodeRef> featureCodeRefDBList=null;
		featureCodeRefDBList = (List<FeatureCodeRef>) sessionFactoryConfig
				.getCurrentSession()
				.createQuery("from FeatureCodeRef fr where fr.id.attributeValue=:attValue")
				.setParameter("attValue", "DCM")	
				.list();			
		  
		return featureCodeRefDBList;
		}



	@Override
	public boolean findFulfillmentIndicator(String vendorName) throws Exception {
		csiDaoLog.debug("Inside CSIDaoImpl findFulfillmentIndicator method");
		boolean indicator = false;
		@SuppressWarnings("unchecked")
		List<SystemConfiguration> systemConfigurationList = (List<SystemConfiguration>) sessionFactoryConfig
				.getCurrentSession()
				.createQuery("from SystemConfiguration sc where sc.id.systemName = :vendorName and fulfillmentNoticeInd = :fulfillIndicator")
				.setParameter("vendorName", vendorName)
				.setParameter("fulfillIndicator", "Y")				
				.list();
		
		if(systemConfigurationList.size()>0){
			indicator=true;
		}
		return indicator;
	}



	@Override
	@SuppressWarnings("unchecked")	
	public List<SystemConfiguration> getSytemConfiguartionList() {
		csiDaoLog.debug("Inside the getSytemConfiguartionList");
		List<SystemConfiguration> systemConfigurationList=null;
		systemConfigurationList = (List<SystemConfiguration>) sessionFactoryConfig
				//.openSession()
				.getCurrentSession()
				.createQuery("from SystemConfiguration")
				.list();			
		//sessionFactoryConfig.close();
		return systemConfigurationList;
	}



	@Override
	@SuppressWarnings("unchecked")
	public List<UriConfiguration> getURIonfiguartionList() {
		csiDaoLog.debug("Inside the getURIonfiguartionList");
		List<UriConfiguration> uriConfigurationList=null;
		uriConfigurationList = (List<UriConfiguration>) sessionFactoryConfig
				//.openSession()
				.getCurrentSession()
				.createQuery("from UriConfiguration")
				.list();			
		//sessionFactoryConfig.close(); 
		return uriConfigurationList;
	}



	@SuppressWarnings("unchecked")
	@Override
	public String getProvSystemTransId(String masterTransId) {
		csiDaoLog.debug("Inside CSIDaoImpl getProvSystemTransId method");
		String provSystemTransid=null;
		List<ProvisioningRequest> provisioningRequest=null;
		provisioningRequest = (List<ProvisioningRequest>) sessionFactoryData
				.getCurrentSession()
				.createQuery("from ProvisioningRequest pr where pr.masterTransid = :masterTransid")
				.setParameter("masterTransid", masterTransId)
		        .list();
		if(provisioningRequest!=null && provisioningRequest.size() > 0){
			
			provSystemTransid=provisioningRequest.get(0).getProvSystemTransid();
			
		}
		return provSystemTransid;
	}



	@Override
	public boolean insertTranscode(TransCode transCode) {
		csiDaoLog.debug("Inside CSIDaoImpl insertTranscode method");
		try {
			sessionFactoryData.getCurrentSession().save(transCode);		
			sessionFactoryData.getCurrentSession().flush();
			return true;
		}catch (HibernateException e) {
			csiDaoLog.error("Exception occured in the CSIDaoImpl insertTranscode method :"+e);
			e.printStackTrace();
			return false;
		}
	}



	@SuppressWarnings("unchecked")
	@Override
	public ProvisioningRequest queryProvisioningRequest(String masterTransId) {
		csiDaoLog.debug("Inside the queryProvisioningRequest");
		List<ProvisioningRequest> provisioningRequestList=null;
		provisioningRequestList = (List<ProvisioningRequest>) sessionFactoryData
				.getCurrentSession()
				.createQuery("from ProvisioningRequest pr where pr.masterTransid = :masterTransId")
		        .setParameter("masterTransId", masterTransId)
		        .list();
		return provisioningRequestList.get(0);
	}



	@SuppressWarnings("unchecked")
	@Override
	public List<TransCode> queryTransCode(String masterTransId) {		
		csiDaoLog.debug("Inside the queryTransCode");
		List<TransCode> transCodeList=null;
		transCodeList = (List<TransCode>) sessionFactoryData
				.getCurrentSession()
				.createQuery("from TransCode tc where tc.masterTransid = :masterTransId order by tc.productId desc, tc.errorTime desc")
		        .setParameter("masterTransId", masterTransId)
		        .list();	
		
		return transCodeList;
	}


	@SuppressWarnings("unchecked")
	@Override
	public List<ProvisioningTask> queryProvisioningTask(
			String masterTransId) {
		csiDaoLog.debug("Inside the queryProvisioningTask");
		List<ProvisioningTask> provisioningTaskList=null;
		provisioningTaskList = (List<ProvisioningTask>) sessionFactoryData
				.getCurrentSession()
				.createQuery("from ProvisioningTask pt where pt.id.masterTransid = :masterTransId")
		        .setParameter("masterTransId", masterTransId)
				.list();	
		
		return provisioningTaskList; 
	}
	
	private Boolean isSuccess(int success){
		if (success > 0) {
			return true;
		} 
		else {
			return false;
		}		
	}
	
}
	