package com.att.tpp.xml.model;

import java.util.Collection;

public class Products {

    private Collection<Product> product;

	/**
	 * @param product
	 */
	public Products(Collection<Product> product) {
		this.product = product;
	}

	public Products() {
		// TODO Auto-generated constructor stub
	}

	/**
	 * @return the product
	 */
	public Collection<Product> getProduct() {
		return product;
	}

	/**
	 * @param product the product to set
	 */
	public void setProduct(Collection<Product> product) {
		this.product = product;
	}


}
