package com.att.tpp.xml.model;

import java.util.Collection;
import java.util.Date;

import com.att.tpp.xml.model.Product;

public class ProvisioningRequestData {

	private String transactionId;
	private Date receivedTimeStamp;
	private String msisdn;
	private String provisioningCarrier;
	private String routingCarrier;
	private Collection<Product> productsCollection;
	private String atlasEventType;
	private VendorDetails vendorDetails;

	public ProvisioningRequestData() {
	}
	
	public ProvisioningRequestData(String transactionId,
			Date receivedTimeStamp, String msisdn, String provisioningCarrier,
			String routingCarrier, Collection<Product> productsCollection, String atlasEventType,
			VendorDetails vendorDetails) {
		this.transactionId = transactionId;
		this.receivedTimeStamp = receivedTimeStamp;
		this.msisdn = msisdn;
		this.provisioningCarrier = provisioningCarrier;
		this.routingCarrier = routingCarrier;
		this.productsCollection = productsCollection;
		this.atlasEventType = atlasEventType;
		this.vendorDetails = vendorDetails;
	}

	/**
	 * @param transactionId
	 * @param receivedTimeStamp
	 * @param msisdn
	 * @param provisioningCarrier
	 * @param routingCarrier
	 * @param productsCollection
	 */
	public ProvisioningRequestData(String transactionId,
			Date receivedTimeStamp, String msisdn, String provisioningCarrier,
			String routingCarrier, Collection<Product> productsCollection) {
		this.transactionId = transactionId;
		this.receivedTimeStamp = receivedTimeStamp;
		this.msisdn = msisdn;
		this.provisioningCarrier = provisioningCarrier;
		this.routingCarrier = routingCarrier;
		this.productsCollection = productsCollection;
	}
	
	
	/**
	 * @param transactionId
	 * @param receivedTimeStamp
	 * @param msisdn
	 * @param provisioningCarrier
	 * @param routingCarrier
	 * @param productsCollection
	 * @param atlasEventType
	 */
	public ProvisioningRequestData(String transactionId,
			Date receivedTimeStamp, String msisdn, String provisioningCarrier,
			String routingCarrier, Collection<Product> productsCollection, String atlasEventType ) {
		this.transactionId = transactionId;
		this.receivedTimeStamp = receivedTimeStamp;
		this.msisdn = msisdn;
		this.provisioningCarrier = provisioningCarrier;
		this.routingCarrier = routingCarrier;
		this.productsCollection = productsCollection;
		this.atlasEventType = atlasEventType;
	}

	public String getTransactionId() {
		return this.transactionId;
	}

	public void setTransactionId(String transactionId) {
		this.transactionId = transactionId;
	}

	public String getMsisdn() {
		return this.msisdn;
	}

	public void setMsisdn(String msisdn) {
		this.msisdn = msisdn;
	}

	public Date getReceivedTimeStamp() {
		return receivedTimeStamp;
	}

	public void setReceivedTimeStamp(Date receivedTimeStamp) {
		this.receivedTimeStamp = receivedTimeStamp;
	}

	public String getProvisioningCarrier() {
		return provisioningCarrier;
	}

	public void setProvisioningCarrier(String provisioningCarrier) {
		this.provisioningCarrier = provisioningCarrier;
	}

	public String getRoutingCarrier() {
		return routingCarrier;
	}

	public void setRoutingCarrier(String routingCarrier) {
		this.routingCarrier = routingCarrier;
	}

	public Collection<Product> getProductsCollection() {
		return productsCollection;
	}

	public String getAtlasEventType() {
		return atlasEventType;
	}

	public void setAtlasEventType(String atlasEventType) {
		this.atlasEventType = atlasEventType;
	}

	public void setProductsCollection(Collection<Product> productsCollection) {
		this.productsCollection = productsCollection;
	}

	public VendorDetails getVendorDetails() {
		return vendorDetails;
	}

	public void setVendorDetails(VendorDetails vendorDetails) {
		this.vendorDetails = vendorDetails;
	}

}
