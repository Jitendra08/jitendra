package com.att.tpp.model;

import java.io.Serializable;
import javax.persistence.*;
import java.util.Date;
import java.util.List;


/**
 * The persistent class for the PRODUCT_REF database table.
 * 
 */
@Entity
@Table(name="PRODUCT_REF")
@NamedQuery(name="ProductRef.findAll", query="SELECT p FROM ProductRef p")
public class ProductRef implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	@Column(name="PRODUCT_ID")
	private String productId;

	@Column(name="APPID_FILTRATION_FLAG")
	private String appidFiltrationFlag;

	@Temporal(TemporalType.DATE)
	@Column(name="INSERT_DATE")
	private Date insertDate;

	private String kintana;

	@Column(name="LBS_IND")
	private String lbsInd;

	@Column(name="PRODUCT_DSC")
	private String productDsc;

	@Column(name="ROUTING_FLAG")
	private String routingFlag;

	@Column(name="WORK_REQ")
	private String workReq;

	//bi-directional many-to-one association to ProvisioningSequence
	@OneToMany(mappedBy="productRef")
	private List<ProvisioningSequence> provisioningSequences;

	public ProductRef() {
	}

	public String getProductId() {
		return this.productId;
	}

	public void setProductId(String productId) {
		this.productId = productId;
	}

	public String getAppidFiltrationFlag() {
		return this.appidFiltrationFlag;
	}

	public void setAppidFiltrationFlag(String appidFiltrationFlag) {
		this.appidFiltrationFlag = appidFiltrationFlag;
	}

	public Date getInsertDate() {
		return this.insertDate;
	}

	public void setInsertDate(Date insertDate) {
		this.insertDate = insertDate;
	}

	public String getKintana() {
		return this.kintana;
	}

	public void setKintana(String kintana) {
		this.kintana = kintana;
	}

	public String getLbsInd() {
		return this.lbsInd;
	}

	public void setLbsInd(String lbsInd) {
		this.lbsInd = lbsInd;
	}

	public String getProductDsc() {
		return this.productDsc;
	}

	public void setProductDsc(String productDsc) {
		this.productDsc = productDsc;
	}

	public String getRoutingFlag() {
		return this.routingFlag;
	}

	public void setRoutingFlag(String routingFlag) {
		this.routingFlag = routingFlag;
	}

	public String getWorkReq() {
		return this.workReq;
	}

	public void setWorkReq(String workReq) {
		this.workReq = workReq;
	}

	public List<ProvisioningSequence> getProvisioningSequences() {
		return this.provisioningSequences;
	}

	public void setProvisioningSequences(List<ProvisioningSequence> provisioningSequences) {
		this.provisioningSequences = provisioningSequences;
	}

	public ProvisioningSequence addProvisioningSequence(ProvisioningSequence provisioningSequence) {
		getProvisioningSequences().add(provisioningSequence);
		provisioningSequence.setProductRef(this);

		return provisioningSequence;
	}

	public ProvisioningSequence removeProvisioningSequence(ProvisioningSequence provisioningSequence) {
		getProvisioningSequences().remove(provisioningSequence);
		provisioningSequence.setProductRef(null);

		return provisioningSequence;
	}

}