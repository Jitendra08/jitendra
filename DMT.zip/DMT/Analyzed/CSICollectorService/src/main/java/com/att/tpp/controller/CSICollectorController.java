/**
 * 
 */
package com.att.tpp.controller;

import java.io.IOException;
import java.sql.Timestamp;
import java.util.Collection;
import java.util.Date;
import java.util.Iterator;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.att.tpp.enumuration.NotificationType;
import com.att.tpp.model.DcmMessageArchive;
import com.att.tpp.model.ProcessingResult;
import com.att.tpp.xml.model.ProvisioningRequestData;
import com.att.tpp.service.DCMNotificationService;
import com.att.tpp.service.CSICollectorService;
import com.att.tpp.utils.ParseDCMNotificationRequestData;
import com.att.tpp.xml.model.Product;
import com.att.tpp.xml.model.Products;
import com.att.tpp.xml.model.VendorDetails;



/**
 * @author rg730b
 *
 */

/* ***********************CSICollectorController*************************** */
 /*
 * Get the Notification Type
 * Based on the Notification Type validate request xml against QTY_ProvisioningRequestXSD
 * Parse the request XML and the get the result data
 * Load all the Products with validation status.
 * Validate the IPIDs 
 * Assign productId 
 * Create the TPP_ProvisioningRequest model
 * Generate the TPP_ProvisioingRequest
 * Send the TPP_ProvisioingRequest to Gateway service. 
 * In case of invalid request XML or invalid productId, create ABS_ProvisioingRequest send to CSI Service
 * */
/* *************************************************************************** */
@Service("csiCollectorController")
public class CSICollectorController {
	
	private static final Logger csiCollectorControllerLog = Logger.getLogger(CSICollectorController.class);
	
	private final static String QTY_ProvisioningRequestXSD = "QTY_ProvisioningRequest.xsd";
	private final static String TPP_ProvisioningRequestXSD = "TPP_ProvisioningRequest.xsd";
	private final static String ABS_ProvisioningResponseXSD = "ABS_ProvisioningResponse.xsd";
	
	@Autowired
	private CSICollectorService csiCollectorService;
	
	@Autowired
	private DCMNotificationService dcmNotificationService;
	
	public ProcessingResult processRequest(String dcmRequestXML) throws IOException, Exception {
		
		ProcessingResult processingResult = new ProcessingResult();				
		/* Get the Notification type */
		ParseDCMNotificationRequestData parseDCMRequestData = new ParseDCMNotificationRequestData();
		String notificationType = parseDCMRequestData.getNotificationType(dcmRequestXML);
		csiCollectorControllerLog.info("Notification Type: " + notificationType);		
		ProvisioningRequestData provReqData = null;
		boolean isValidProductExist = true;
		boolean isValidRequest = false;
		boolean isValidTPPProvReq = false;
		boolean isValidTPPABSRes = false;
		Products products=null;
		Products listProducts=null;
		StringBuffer errorMessage = null;
		
		String archiveErrorMessage = "Invalid Notification Type";
		
		boolean isPersisted = false;
		String vendorName = null;
		/* Validate the request XML */
		isValidRequest = csiCollectorService.validateXML(dcmRequestXML,QTY_ProvisioningRequestXSD);
		csiCollectorControllerLog.info("isValidRequest: " + isValidRequest);
		processingResult.setValidRequest(isValidRequest);
		
		if (isValidRequest && (notificationType != null && notificationType.equals(NotificationType.DCMNotification.toString()))) {
			/* Validate the request XML */
			//isValidRequest = csiCollectorService.validateXML(dcmRequestXML,QTY_ProvisioningRequestXSD);
			//csiCollectorControllerLog.info("isValidRequest: " + isValidRequest);
			//processingResult.setValidRequest(isValidRequest);
			provReqData = dcmNotificationService.parseDCMNotificationData(dcmRequestXML);
			csiCollectorControllerLog.info("provReqData.getTransactionId(): " + provReqData.getTransactionId());
			processingResult.setMessageId(provReqData.getTransactionId());
			processingResult.setCsiEventName(notificationType);
			processingResult.setSubscriberNumber(provReqData.getMsisdn());
			if (isValidRequest && (provReqData != null)) {
				VendorDetails vendorDetails = provReqData.getVendorDetails();
				if(vendorDetails != null){
					vendorName=vendorDetails.getVendorName();
				}
				
				if(vendorName != null && vendorName.equalsIgnoreCase("OCE")){
					archiveErrorMessage = "OCE Vendor";
					processingResult.setValidTPPProvReq(isValidTPPProvReq);
					csiCollectorControllerLog.info("Dropped the transaction for OCE vendor.");
				}else{
					/* Load all the product according to IPIDs and validate the Product exist or not */
					listProducts = dcmNotificationService.loadProducts(provReqData.getProductsCollection());
					errorMessage = new StringBuffer("Invalid IPID ");
					Collection<Product> productCollection = listProducts.getProduct();
			 		Iterator<Product> productIterator = productCollection.iterator();
			 		int prodCount = 0;
					while (productIterator.hasNext()) {
						Product lnProduct = productIterator.next();
						boolean validProductId = lnProduct.isValid();
						csiCollectorControllerLog.info("validProductId: "+validProductId);
						if (!validProductId) {
							isValidProductExist = false;
							if(prodCount > 0){
								errorMessage.append(",");
							}
							errorMessage.append(lnProduct.getId()); 
							prodCount++;
						}
					}
					processingResult.setValidProductExist(isValidProductExist);
					csiCollectorControllerLog.info("Valid IPID for TransactionId :: "+provReqData.getTransactionId()+" :: "+ isValidProductExist);
	
					if(isValidProductExist){
						/* ************ Valid IPIDs *************
						 * Assign productIds
						 * Create TPP_ProvisioningResponse
						 * Validate the ProvisioningResponse against TPP_ProvisioningRequestXSD
						 * ****************************************/
						products = dcmNotificationService.assignProductIds(provReqData.getProductsCollection());
						String tppProvReqXML = csiCollectorService.createTPPProvReqXML(provReqData,products);
						processingResult.setTppProvReq(tppProvReqXML);			
						csiCollectorControllerLog.info("tppProvReqXML --->" + tppProvReqXML.toString());
						isValidTPPProvReq = csiCollectorService.validateXML(tppProvReqXML,TPP_ProvisioningRequestXSD);
						csiCollectorControllerLog.info("isValidTPPProvReq:" + isValidTPPProvReq);
						processingResult.setValidTPPProvReq(isValidTPPProvReq);
						archiveErrorMessage = "Valid Transaction";
					}else{
						/* **************** Invalid IPIDs*************
						 * Create ABS_ProvisioningResponse
						 * Validate the ProvisioningResponse against ABS_ProvisioningResponseXSD
						 * *******************************************/
						csiCollectorControllerLog.info("Invalid IPID present in request xml, so sending the transaction to CSI queue :: TransactionId :: "+provReqData.getTransactionId());
						String tppABSResXML = csiCollectorService.createABSProvResXML(provReqData,listProducts, errorMessage);
						processingResult.setTppProvReq(tppABSResXML);			
						csiCollectorControllerLog.info("tppProvReqXML --->" + tppABSResXML.toString());
						isValidTPPABSRes = csiCollectorService.validateXML(tppABSResXML,ABS_ProvisioningResponseXSD);
						processingResult.setValidTPPProvReq(isValidTPPABSRes);
						archiveErrorMessage = "Invalid IPID";
					}
				}
						
			}else{
				/* **************** Invalid request xml*************
				 * Create ABS_ProvisioningResponse
				 * Validate the ProvisioningResponse against ABS_ProvisioningResponseXSD
				 * *******************************************/
				csiCollectorControllerLog.info("Invalid request xml, so sending the transaction to CSI queue :: TransactionId :: "+provReqData.getTransactionId());
				errorMessage = new StringBuffer("Invalid Request XML");
				String tppABSResXML = csiCollectorService.createInvalidXMLABSProvResXML(provReqData, errorMessage);
				processingResult.setTppProvReq(tppABSResXML);			
				csiCollectorControllerLog.info("tppProvReqXML --->" + tppABSResXML.toString());
				isValidTPPABSRes = csiCollectorService.validateXML(tppABSResXML,ABS_ProvisioningResponseXSD);
				processingResult.setValidTPPProvReq(isValidTPPABSRes);
				archiveErrorMessage = "Invalid Request XML";
			}
		}
		
		
		//Persist transaction
		DcmMessageArchive dcmMessageArchive = generateDcmMessageArchiveData(dcmRequestXML, processingResult, notificationType, vendorName, archiveErrorMessage);
		isPersisted = dcmNotificationService.persistDCMRequest(dcmMessageArchive);
		processingResult.setPersisted(isPersisted);	
		
		return processingResult;
	}
	
	//Generated Atlas Message Archive Data
	private DcmMessageArchive generateDcmMessageArchiveData(String dcmRequestXML, ProcessingResult processingResult, String notificationType, String vendorName, String archiveErrorMessage) {
		
		DcmMessageArchive dcmArchive = new DcmMessageArchive();
		Date now = new Date();
		if(processingResult.getMessageId()!=null){
			dcmArchive.setMessageid(processingResult.getMessageId());
		}else{
			dcmArchive.setMessageid("InvalidMessage");
		}
		dcmArchive.setCreatedTimestamp(new Timestamp(now.getTime()));
		if(processingResult.getSubscriberNumber() != null){
			dcmArchive.setMsisdn(processingResult.getSubscriberNumber());
		}else{
			dcmArchive.setMsisdn("");
		}
		dcmArchive.setVendorName(vendorName);
		dcmArchive.setEventText(dcmRequestXML);
		if(processingResult.getTppProvReq()!=null){
			dcmArchive.setTppText(processingResult.getTppProvReq());
		}else{
			dcmArchive.setTppText("NA");
		}
		
		dcmArchive.setEventName(notificationType);
		dcmArchive.setErrorMessage(archiveErrorMessage);
		return dcmArchive;

	}

}
