package com.att.tpp.xml.model;

public class Header {
    

	private String transactionId;
	private String provisioningCarrier;
	private String timeStamp;
	private String atlasEventType;
	private String routingCarrier;

	//private ProvisioningCarrier provisioningCarrier;  //Removed use of enumeration
	//private RoutingCarrier routingCarrier;	//Removed use of enumeration
	private Notification notification;
	private Sender sender;
	private TransactionCode transactionCode;	
	
	public Header(String transactionId, String provisioningCarrier,
			String timeStamp, String routingCarrier) {
		super();
		this.transactionId = transactionId;
		this.provisioningCarrier = provisioningCarrier;
		this.timeStamp = timeStamp;
		this.routingCarrier = routingCarrier;
	}
	

	//For Account Notification
	public Header(String transactionId, String provisioningCarrier,
			String timeStamp, String atlasEventType, String routingCarrier) {
		super();
		this.transactionId = transactionId;
		this.provisioningCarrier = provisioningCarrier;
		this.timeStamp = timeStamp;
		this.atlasEventType = atlasEventType;
		this.routingCarrier = routingCarrier;
	}
	
	/*For SubscriberNoitification*/
	public Header(String transactionId, String provisioningCarrier,
			String timeStamp, String atlasEventType, String routingCarrier,
			Notification notification) {
		super();
		this.transactionId = transactionId;
		this.provisioningCarrier = provisioningCarrier;
		this.timeStamp = timeStamp;
		this.atlasEventType = atlasEventType;
		this.routingCarrier = routingCarrier;
		this.notification = notification;
	}
	
	
	/**
	 * @param atlasEventType
	 * @param transactionId
	 * @param provisioningCarrier
	 * @param timeStamp
	 * @param sender
	 * @param notification
	 */
	public Header(String atlasEventType, String transactionId,
			String provisioningCarrier, String timeStamp,
			Sender sender, Notification notification) {
		this.atlasEventType = atlasEventType;
		this.transactionId = transactionId;
		this.provisioningCarrier = provisioningCarrier;
		this.timeStamp = timeStamp;
		this.sender = sender;
		this.notification = notification;
	}

	/**
	 * @param atlasEventType
	 * @param transactionId
	 * @param provisioningCarrier
	 * @param routingCarrier
	 * @param timeStamp
	 * @param sender
	 * @param notification
	 */
	public Header(String atlasEventType, String transactionId,
			String provisioningCarrier,
			String routingCarrier, String timeStamp, Sender sender,
			Notification notification) {
		this.atlasEventType = atlasEventType;
		this.transactionId = transactionId;
		this.provisioningCarrier = provisioningCarrier;
		this.routingCarrier = routingCarrier;
		this.timeStamp = timeStamp;
		this.sender = sender;
		this.notification = notification;
	}	

	/**
	 * @param atlasEventType
	 * @param transactionId
	 * @param provisioningCarrier
	 * @param routingCarrier
	 * @param timeStamp
	 * @param sender
	 * @param notification
	 * @param transactionCode
	 */
	public Header(String atlasEventType, String transactionId,
			String provisioningCarrier,
			String routingCarrier, String timeStamp, Sender sender,
			Notification notification, TransactionCode transactionCode) {
		this.atlasEventType = atlasEventType;
		this.transactionId = transactionId;
		this.provisioningCarrier = provisioningCarrier;
		this.routingCarrier = routingCarrier;
		this.timeStamp = timeStamp;
		this.sender = sender;
		this.notification = notification;
		this.transactionCode = transactionCode;
	}

	/**
	 * @return the atlasEventType
	 */
	public String getAtlasEventType() {
		return atlasEventType;
	}
	/**
	 * @param atlasEventType the atlasEventType to set
	 */
	public void setAtlasEventType(String atlasEventType) {
		this.atlasEventType = atlasEventType;
	}
	/**
	 * @return the transactionId
	 */
	public String getTransactionId() {
		return transactionId;
	}
	/**
	 * @param transactionId the transactionId to set
	 */
	public void setTransactionId(String transactionId) {
		this.transactionId = transactionId;
	}
	/**
	 * @return the provisioningCarrier
	 */
	public String getProvisioningCarrier() {
		return provisioningCarrier;
	}
	/**
	 * @param provisioningCarrier the provisioningCarrier to set
	 */
	public void setProvisioningCarrier(String provisioningCarrier) {
		this.provisioningCarrier = provisioningCarrier;
	}
	/**
	 * @return the routingCarrier
	 */
	public String getRoutingCarrier() {
		return routingCarrier;
	}
	/**
	 * @param routingCarrier the routingCarrier to set
	 */
	public void setRoutingCarrier(String routingCarrier) {
		this.routingCarrier = routingCarrier;
	}
	/**
	 * @return the timeStamp
	 */
	public String getTimeStamp() {
		return timeStamp;
	}
	/**
	 * @param timeStamp the timeStamp to set
	 */
	public void setTimeStamp(String timeStamp) {
		this.timeStamp = timeStamp;
	}
	/**
	 * @return the sender
	 */
	public Sender getSender() {
		return sender;
	}
	/**
	 * @param sender the sender to set
	 */
	public void setSender(Sender sender) {
		this.sender = sender;
	}
	/**
	 * @return the notification
	 */
	public Notification getNotification() {
		return notification;
	}
	/**
	 * @param notification the notification to set
	 */
	public void setNotification(Notification notification) {
		this.notification = notification;
	}
	/**
	 * @return the transactionCode
	 */
	public TransactionCode getTransactionCode() {
		return transactionCode;
	}
	/**
	 * @param transactionCode the transactionCode to set
	 */
	public void setTransactionCode(TransactionCode transactionCode) {
		this.transactionCode = transactionCode;
	}

}
