package com.att.tpp.xml.model;

public class TransactionCodeList {

    private long errorCode;
    private String errorMessageText;
    private String system;
    private String timeStamp;
        
	/**
	 * @param errorCode
	 * @param errorMessageText
	 */
	public TransactionCodeList(long errorCode, String errorMessageText) {
		this.errorCode = errorCode;
		this.errorMessageText = errorMessageText;
	}
		
	/**
	 * @param errorCode
	 * @param errorMessageText
	 * @param system
	 */
	public TransactionCodeList(long errorCode, String errorMessageText,
			String system) {
		this.errorCode = errorCode;
		this.errorMessageText = errorMessageText;
		this.system = system;
	}

	/**
	 * @param errorCode
	 * @param errorMessageText
	 * @param system
	 * @param timeStamp
	 */
	public TransactionCodeList(long errorCode, String errorMessageText,
			String system, String timeStamp) {
		this.errorCode = errorCode;
		this.errorMessageText = errorMessageText;
		this.system = system;
		this.timeStamp = timeStamp;
	}

	/**
	 * @return the errorCode
	 */
	public long getErrorCode() {
		return errorCode;
	}
	
	/**
	 * @param errorCode the errorCode to set
	 */
	public void setErrorCode(long errorCode) {
		this.errorCode = errorCode;
	}
	
	/**
	 * @return the errorMessageText
	 */
	public String getErrorMessageText() {
		return errorMessageText;
	}
	
	/**
	 * @param errorMessageText the errorMessageText to set
	 */
	public void setErrorMessageText(String errorMessageText) {
		this.errorMessageText = errorMessageText;
	}
	
	/**
	 * @return the system
	 */
	public String getSystem() {
		return system;
	}
	
	/**
	 * @param system the system to set
	 */
	public void setSystem(String system) {
		this.system = system;
	}
	
	/**
	 * @return the timeStamp
	 */
	public String getTimeStamp() {
		return timeStamp;
	}
	
	/**
	 * @param timeStamp the timeStamp to set
	 */
	public void setTimeStamp(String timeStamp) {
		this.timeStamp = timeStamp;
	}
    
}
