/**
 * 
 */
package com.att.tpp.utils;

import com.att.tpp.xml.model.Product;
import com.att.tpp.xml.model.Attribute;
import com.att.tpp.xml.model.ProvisioningRequestData;
import com.att.tpp.xml.model.VendorDetails;


/**
 * @author rg730b
 *
 */
class ParseDCMNotificationRequestData {
	
	/* Get the DCM Notification Data from the request XML */	
	def ProvisioningRequestData getDCMNotificationData(String inXML){
		def dcmNotif = new XmlSlurper().parseText(inXML)
		def now = new Date()
		/*Set ProvisioningCarrier to CSI to support DCM flow */
		def provisioningCarrier = "CSI"
		//println("VendorName>>>"+dcmNotif.Order.VendorDetails?.'xsd1:VendorName'.toString());
		//println("VendorName1>>>"+dcmNotif.Order.VendorDetails?.VendorName.toString());
		//println("TransactionId2>>>"+dcmNotif.Header.@'xsd1:TransactionId'.toString());
		return new  ProvisioningRequestData(
			dcmNotif.Header.@'xsd1:TransactionId'.toString(),
			now,
			dcmNotif.Order.Account.@MSISDN.toString(),
			//dcmNotif.Header.@ProvisioningCarrier.toString(),
			provisioningCarrier,
			dcmNotif.Header.@'xsd1:RoutingCarrier'.toString(),
			dcmNotif.Products.Product.collect{
				new Product(it.@Id.toString(), it.@Id.toString(), it.@Action.toString(),
					it.Attribute.collect{ 
						new Attribute(it.@Name.toString(), it.@Value.toString())
						})
				},
			dcmNotif.Header.@Atlas_Event_Type.toString(),
			new VendorDetails(	dcmNotif.Order.VendorDetails?.VendorName.toString(),
								dcmNotif.Order.VendorDetails?.CompanyName.toString(),
								dcmNotif.Order.VendorDetails?.OrderId.toString()
								)
			)
	}
	
	def String getRootElement(String inXML){
		def dcmNotif = new XmlSlurper().parseText(inXML)
		return dcmNotif.name().toString();
	}
	/* Get the Notification Type from the request XML */
	def String getNotificationType(String inXML){
		def dcmNotif = new XmlSlurper().parseText(inXML)
		return dcmNotif.Header.@Atlas_Event_Type.toString();
	}

}
