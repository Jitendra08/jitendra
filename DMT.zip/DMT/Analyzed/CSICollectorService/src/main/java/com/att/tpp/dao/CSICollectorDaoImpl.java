/**
 * 
 */
package com.att.tpp.dao;

import java.util.List;

import org.apache.log4j.Logger;
import org.hibernate.HibernateException;
import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cache.annotation.Cacheable;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.att.tpp.model.DcmMessageArchive;
import com.att.tpp.model.FeatureCodeRef;

/**
 * @author rg730b
 *
 */

@Repository("csiCollectorDao")
public class CSICollectorDaoImpl implements CSICollectorDao{
	
	private static final Logger csiCollectorDaoLog = Logger.getLogger(CSICollectorDaoImpl.class);
	
	@Autowired
	private SessionFactory sessionFactoryConfig;
	
	@Autowired
	private SessionFactory sessionFactoryArchive;
	
	@Override
	@SuppressWarnings("unchecked")
	@Cacheable(value="productRefCache")
	//Retrieve the product list and keep in the cache productRefCache
	public List<String> productList() throws Exception {
		csiCollectorDaoLog.debug("Inside CSICollectorDaoImpl productList method");
		List<String> productRefList=null;
		productRefList = (List<String>) sessionFactoryConfig
				.getCurrentSession()
				.createQuery("select productId from ProductRef pr where productId not in ('9999')")
				.list();
		return productRefList;
	}
	
	@Override
	@SuppressWarnings("unchecked")
	@Cacheable(value = "featureCodeRefCache")
	public List<FeatureCodeRef> featureCodeRefDCMList() throws Exception {
		csiCollectorDaoLog.info("Inside the featureCodeList");
		List<FeatureCodeRef> featureCodeRefDCMList=null;
		featureCodeRefDCMList = (List<FeatureCodeRef>) sessionFactoryConfig
				.getCurrentSession()
				.createQuery("from FeatureCodeRef fr where fr.id.attributeValue=:attValue")
				.setParameter("attValue", "DCM")
				.list();			
		  
		return featureCodeRefDCMList;
		}
	
	@Transactional
	public boolean persistDcmMessage(DcmMessageArchive dcmMessageArchive) {
		csiCollectorDaoLog.debug("Inside CSICollectorDaoImpl persistDcmMessage method");
		try {
			sessionFactoryArchive.getCurrentSession().save(dcmMessageArchive);		
			sessionFactoryArchive.getCurrentSession().flush();
			return true;
		}catch (HibernateException e) {
			csiCollectorDaoLog.error("Exception occured in the CSICollectorDaoImpl persistDcmMessage method :"+e.getMessage());
			return false;
		}
	}
	
}
