package com.att.tpp.model;

import java.io.Serializable;
import javax.persistence.*;
import java.math.BigDecimal;


/**
 * The persistent class for the PROVISIONING_SEQUENCE database table.
 * 
 */
@Entity
@Table(name="PROVISIONING_SEQUENCE")
@NamedQuery(name="ProvisioningSequence.findAll", query="SELECT p FROM ProvisioningSequence p")
public class ProvisioningSequence implements Serializable {
	private static final long serialVersionUID = 1L;

	@EmbeddedId
	private ProvisioningSequencePK id;

	@Column(name="AUTO_RESP_IND")
	private String autoRespInd;

	@Column(name="BATCH_NUM")
	private BigDecimal batchNum;

	@Column(name="ISEC_STATUS")
	private String isecStatus;

	//bi-directional many-to-one association to ProductRef
	@ManyToOne
	@JoinColumn(name="PRODUCT_ID", insertable = false, updatable = false)
	private ProductRef productRef;

	public ProvisioningSequence() {
	}

	public ProvisioningSequencePK getId() {
		return this.id;
	}

	public void setId(ProvisioningSequencePK id) {
		this.id = id;
	}

	public String getAutoRespInd() {
		return this.autoRespInd;
	}

	public void setAutoRespInd(String autoRespInd) {
		this.autoRespInd = autoRespInd;
	}

	public BigDecimal getBatchNum() {
		return this.batchNum;
	}

	public void setBatchNum(BigDecimal batchNum) {
		this.batchNum = batchNum;
	}

	public String getIsecStatus() {
		return this.isecStatus;
	}

	public void setIsecStatus(String isecStatus) {
		this.isecStatus = isecStatus;
	}

	public ProductRef getProductRef() {
		return this.productRef;
	}

	public void setProductRef(ProductRef productRef) {
		this.productRef = productRef;
	}

}