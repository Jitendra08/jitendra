package com.att.tpp.jms.sender;

import javax.jms.JMSException;
import javax.jms.Message;
import javax.jms.Queue;
import javax.jms.Session;
import javax.jms.TextMessage;

import org.apache.log4j.Logger;
import org.springframework.jms.core.JmsTemplate;
import org.springframework.jms.core.MessageCreator;

import com.att.tpp.model.ProcessingResult;

/**
 * 
 * The CSIQueueSender class uses the injected JMSTemplate to send a message
 * to dualFlowRequestQueue. 
 */
public class CSIQueueSender
{
	private JmsTemplate jmsTemplate;
	private Queue csiServiceRequestQueue; 
	private static final Logger dualFlowRequestSenderLog = Logger.getLogger(CSIQueueSender.class);
	private final static String eventName = "eventName";
	private final static String csiTransactionId = "csiTransactionId";
	private final static String ActionCode = "ActionCode";
	
	/**
	 * Sends message to CSIQueueSender using JMS Template.
	 * @param actionCode 
	 * @param csiTransactionId 
	 * @param provReqXML the message_p
	 * @throws JMSException the jms exception
	 */
	public void sendMessage(final ProcessingResult processingResult) throws JMSException
	{
		
		dualFlowRequestSenderLog.info("Sending ProvisioningResponse Message From CSIColletor Service to CSI Service");

		jmsTemplate.send(this.csiServiceRequestQueue, new MessageCreator(){

			@Override
			public Message createMessage(Session session) throws JMSException {
				TextMessage message = session.createTextMessage(processingResult.getTppProvReq().toString()); 
				/* TppProvReq() is stored as ABSResponseXML internally */
				message.setStringProperty(eventName,processingResult.getCsiEventName().toString());
				message.setStringProperty(csiTransactionId,processingResult.getMessageId().toString());
				return message;
			}
			
		});		
		
	}
	/**
	 * Sets the jms template.
	 *
	 * @param template the jms template
	 */
	public void setJmsTemplate(JmsTemplate tmpl)
	{
		this.jmsTemplate = tmpl;
	}
	
	
	public void setCsiServiceRequestQueue(Queue csiServiceRequestQueue) {
		this.csiServiceRequestQueue = csiServiceRequestQueue;
	}
	
	

	
}