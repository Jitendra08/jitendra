/**
 * 
 */
package com.att.tpp.model;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Lob;
import javax.persistence.NamedQuery;
import javax.persistence.Table;

/**
 * @author rg730b
 *
 */
@Entity
@Table(name="DCM_MESSAGE_ARCHIVE")
@NamedQuery(name="DcmMessageArchive.findAll", query="SELECT c FROM DcmMessageArchive c")
public class DcmMessageArchive implements Serializable{
	private static final long serialVersionUID = 1L;
	
	@Id
    @Column(name="MESSAGEID", nullable=false)
	private String messageid;

	@Column(name="CREATED_TIMESTAMP")
	private java.sql.Timestamp createdTimestamp;
	
	@Column(name="MSISDN")
	private String msisdn;
	
	@Column(name="VENDOR_NAME")
	private String vendorName;
	
	@Lob
	@Column(name="EVENT_TEXT")
	private String eventText;
	
	@Lob
	@Column(name="TPP_TEXT")
	private String tppText;

	@Column(name="EVENT_NAME")
	private String eventName;

	@Column(name="ERROR_MSG")
	private String errorMessage;

	public String getMessageid() {
		return messageid;
	}

	public void setMessageid(String messageid) {
		this.messageid = messageid;
	}

	public java.sql.Timestamp getCreatedTimestamp() {
		return createdTimestamp;
	}

	public void setCreatedTimestamp(java.sql.Timestamp createdTimestamp) {
		this.createdTimestamp = createdTimestamp;
	}

	public String getMsisdn() {
		return msisdn;
	}

	public void setMsisdn(String msisdn) {
		this.msisdn = msisdn;
	}

	public String getVendorName() {
		return vendorName;
	}

	public void setVendorName(String vendorName) {
		this.vendorName = vendorName;
	}

	public String getEventText() {
		return eventText;
	}

	public void setEventText(String eventText) {
		this.eventText = eventText;
	}

	public String getTppText() {
		return tppText;
	}

	public void setTppText(String tppText) {
		this.tppText = tppText;
	}

	public String getEventName() {
		return eventName;
	}

	public void setEventName(String eventName) {
		this.eventName = eventName;
	}

	public String getErrorMessage() {
		return errorMessage;
	}

	public void setErrorMessage(String errorMessage) {
		this.errorMessage = errorMessage;
	}
	
	
}