package com.att.tpp.model;

import java.io.Serializable;
import javax.persistence.*;
import java.util.Date;


// TODO: Auto-generated Javadoc
/**
 * The persistent class for the FEATURE_CODE_REF database table.
 * 
 */
@Entity
@Table(name="FEATURE_CODE_REF")
@NamedQuery(name="FeatureCodeRef.findAll", query="SELECT f FROM FeatureCodeRef f")
public class FeatureCodeRef implements Serializable {
	
	/** The Constant serialVersionUID. */
	private static final long serialVersionUID = 1L;

	/** The id. */
	@EmbeddedId
	private FeatureCodeRefPK id;

	/** The accounttypeindicatorinfo. */
	private String accounttypeindicatorinfo;

	/** The accounttypeinfo. */
	private String accounttypeinfo;

	/** The address. */
	private String address;

	/** The attribute name. */
	@Column(name="ATTRIBUTE_NAME")
	private String attributeName;

	/** The attribute value. */
	//@Column(name="ATTRIBUTE_VALUE")
	//private String attributeValue;

	/** The ban. */
	private String ban;

	/** The contractinfo. */
	private String contractinfo;

	/** The custregcontactinfo base. */
	@Column(name="CUSTREGCONTACTINFO_BASE")
	private String custregcontactinfoBase;

	/** The email. */
	private String email;

	/** The fan. */
	private String fan;

	/** The fanname. */
	private String fanname;

	/** The iccid. */
	private String iccid;

	/** The imei. */
	private String imei;

	/** The imsi. */
	private String imsi;

	/** The insert date. */
	@Temporal(TemporalType.DATE)
	@Column(name="INSERT_DATE")
	private Date insertDate;

	/** The kintana. */
	private String kintana;

	/** The lbs ind. */
	@Column(name="LBS_IND")
	private String lbsInd;

	/** The make. */
	private String make;

	/** The model. */
	private String model;

	/** The name. */
	private String name;

	/** The parentalcontrolssettinginfo. */
	private String parentalcontrolssettinginfo;

	/** The phonenumber. */
	private String phonenumber;

	/** The rateplan. */
	private String rateplan;

	/** The salesrepinfo. */
	private String salesrepinfo;

	/** The segmentinfo. */
	private String segmentinfo;

	/** The subscribernumber. */
	private String subscribernumber;

	/** The subscriberstatusinfo. */
	private String subscriberstatusinfo;

	/** The wap enabled. */
	@Column(name="WAP_ENABLED")
	private String wapEnabled;

	/** The work req. */
	@Column(name="WORK_REQ")
	private String workReq;

	/**
	 * Instantiates a new feature code ref.
	 */
	public FeatureCodeRef() {
	}

	/*public FeatureCodeRef(String featureCode, String productId,
			String AttributeName, String AttributeValue, String WapEnabled,
			String Name, String Address, String PhoneNumber, String Email,
			String Ban, String Fan, String SubscriberNumber, String IMEI,
			String IMSI, String ICCID, String Make, String Model,
			String RatePlan) {
		this
	}*/
	
	/**
	 * Gets the id.
	 *
	 * @return the id
	 */
	public FeatureCodeRefPK getId() {
		return this.id;
	}

	/**
	 * Sets the id.
	 *
	 * @param id the new id
	 */
	public void setId(FeatureCodeRefPK id) {
		this.id = id;
	}

	/**
	 * Gets the accounttypeindicatorinfo.
	 *
	 * @return the accounttypeindicatorinfo
	 */
	public String getAccounttypeindicatorinfo() {
		return this.accounttypeindicatorinfo;
	}

	/**
	 * Sets the accounttypeindicatorinfo.
	 *
	 * @param accounttypeindicatorinfo the new accounttypeindicatorinfo
	 */
	public void setAccounttypeindicatorinfo(String accounttypeindicatorinfo) {
		this.accounttypeindicatorinfo = accounttypeindicatorinfo;
	}

	/**
	 * Gets the accounttypeinfo.
	 *
	 * @return the accounttypeinfo
	 */
	public String getAccounttypeinfo() {
		return this.accounttypeinfo;
	}

	/**
	 * Sets the accounttypeinfo.
	 *
	 * @param accounttypeinfo the new accounttypeinfo
	 */
	public void setAccounttypeinfo(String accounttypeinfo) {
		this.accounttypeinfo = accounttypeinfo;
	}

	/**
	 * Gets the address.
	 *
	 * @return the address
	 */
	public String getAddress() {
		return this.address;
	}

	/**
	 * Sets the address.
	 *
	 * @param address the new address
	 */
	public void setAddress(String address) {
		this.address = address;
	}

	/**
	 * Gets the attribute name.
	 *
	 * @return the attribute name
	 */
	public String getAttributeName() {
		return this.attributeName;
	}

	/**
	 * Sets the attribute name.
	 *
	 * @param attributeName the new attribute name
	 */
	public void setAttributeName(String attributeName) {
		this.attributeName = attributeName;
	}

	/**
	 * Gets the attribute value.
	 *
	 * @return the attribute value
	 */
/*	public String getAttributeValue() {
		return this.attributeValue;
	}
*/
	/**
	 * Sets the attribute value.
	 *
	 * @param attributeValue the new attribute value
	 */
/*	public void setAttributeValue(String attributeValue) {
		this.attributeValue = attributeValue;
	}
*/
	/**
	 * Gets the ban.
	 *
	 * @return the ban
	 */
	public String getBan() {
		return this.ban;
	}

	/**
	 * Sets the ban.
	 *
	 * @param ban the new ban
	 */
	public void setBan(String ban) {
		this.ban = ban;
	}

	/**
	 * Gets the contractinfo.
	 *
	 * @return the contractinfo
	 */
	public String getContractinfo() {
		return this.contractinfo;
	}

	/**
	 * Sets the contractinfo.
	 *
	 * @param contractinfo the new contractinfo
	 */
	public void setContractinfo(String contractinfo) {
		this.contractinfo = contractinfo;
	}

	/**
	 * Gets the custregcontactinfo base.
	 *
	 * @return the custregcontactinfo base
	 */
	public String getCustregcontactinfoBase() {
		return this.custregcontactinfoBase;
	}

	/**
	 * Sets the custregcontactinfo base.
	 *
	 * @param custregcontactinfoBase the new custregcontactinfo base
	 */
	public void setCustregcontactinfoBase(String custregcontactinfoBase) {
		this.custregcontactinfoBase = custregcontactinfoBase;
	}

	/**
	 * Gets the email.
	 *
	 * @return the email
	 */
	public String getEmail() {
		return this.email;
	}

	/**
	 * Sets the email.
	 *
	 * @param email the new email
	 */
	public void setEmail(String email) {
		this.email = email;
	}

	/**
	 * Gets the fan.
	 *
	 * @return the fan
	 */
	public String getFan() {
		return this.fan;
	}

	/**
	 * Sets the fan.
	 *
	 * @param fan the new fan
	 */
	public void setFan(String fan) {
		this.fan = fan;
	}

	/**
	 * Gets the fanname.
	 *
	 * @return the fanname
	 */
	public String getFanname() {
		return this.fanname;
	}

	/**
	 * Sets the fanname.
	 *
	 * @param fanname the new fanname
	 */
	public void setFanname(String fanname) {
		this.fanname = fanname;
	}

	/**
	 * Gets the iccid.
	 *
	 * @return the iccid
	 */
	public String getIccid() {
		return this.iccid;
	}

	/**
	 * Sets the iccid.
	 *
	 * @param iccid the new iccid
	 */
	public void setIccid(String iccid) {
		this.iccid = iccid;
	}

	/**
	 * Gets the imei.
	 *
	 * @return the imei
	 */
	public String getImei() {
		return this.imei;
	}

	/**
	 * Sets the imei.
	 *
	 * @param imei the new imei
	 */
	public void setImei(String imei) {
		this.imei = imei;
	}

	/**
	 * Gets the imsi.
	 *
	 * @return the imsi
	 */
	public String getImsi() {
		return this.imsi;
	}

	/**
	 * Sets the imsi.
	 *
	 * @param imsi the new imsi
	 */
	public void setImsi(String imsi) {
		this.imsi = imsi;
	}

	/**
	 * Gets the insert date.
	 *
	 * @return the insert date
	 */
	public Date getInsertDate() {
		return this.insertDate;
	}

	/**
	 * Sets the insert date.
	 *
	 * @param insertDate the new insert date
	 */
	public void setInsertDate(Date insertDate) {
		this.insertDate = insertDate;
	}

	/**
	 * Gets the kintana.
	 *
	 * @return the kintana
	 */
	public String getKintana() {
		return this.kintana;
	}

	/**
	 * Sets the kintana.
	 *
	 * @param kintana the new kintana
	 */
	public void setKintana(String kintana) {
		this.kintana = kintana;
	}

	/**
	 * Gets the lbs ind.
	 *
	 * @return the lbs ind
	 */
	public String getLbsInd() {
		return this.lbsInd;
	}

	/**
	 * Sets the lbs ind.
	 *
	 * @param lbsInd the new lbs ind
	 */
	public void setLbsInd(String lbsInd) {
		this.lbsInd = lbsInd;
	}

	/**
	 * Gets the make.
	 *
	 * @return the make
	 */
	public String getMake() {
		return this.make;
	}

	/**
	 * Sets the make.
	 *
	 * @param make the new make
	 */
	public void setMake(String make) {
		this.make = make;
	}

	/**
	 * Gets the model.
	 *
	 * @return the model
	 */
	public String getModel() {
		return this.model;
	}

	/**
	 * Sets the model.
	 *
	 * @param model the new model
	 */
	public void setModel(String model) {
		this.model = model;
	}

	/**
	 * Gets the name.
	 *
	 * @return the name
	 */
	public String getName() {
		return this.name;
	}

	/**
	 * Sets the name.
	 *
	 * @param name the new name
	 */
	public void setName(String name) {
		this.name = name;
	}

	/**
	 * Gets the parentalcontrolssettinginfo.
	 *
	 * @return the parentalcontrolssettinginfo
	 */
	public String getParentalcontrolssettinginfo() {
		return this.parentalcontrolssettinginfo;
	}

	/**
	 * Sets the parentalcontrolssettinginfo.
	 *
	 * @param parentalcontrolssettinginfo the new parentalcontrolssettinginfo
	 */
	public void setParentalcontrolssettinginfo(String parentalcontrolssettinginfo) {
		this.parentalcontrolssettinginfo = parentalcontrolssettinginfo;
	}

	/**
	 * Gets the phonenumber.
	 *
	 * @return the phonenumber
	 */
	public String getPhonenumber() {
		return this.phonenumber;
	}

	/**
	 * Sets the phonenumber.
	 *
	 * @param phonenumber the new phonenumber
	 */
	public void setPhonenumber(String phonenumber) {
		this.phonenumber = phonenumber;
	}

	/**
	 * Gets the rateplan.
	 *
	 * @return the rateplan
	 */
	public String getRateplan() {
		return this.rateplan;
	}

	/**
	 * Sets the rateplan.
	 *
	 * @param rateplan the new rateplan
	 */
	public void setRateplan(String rateplan) {
		this.rateplan = rateplan;
	}

	/**
	 * Gets the salesrepinfo.
	 *
	 * @return the salesrepinfo
	 */
	public String getSalesrepinfo() {
		return this.salesrepinfo;
	}

	/**
	 * Sets the salesrepinfo.
	 *
	 * @param salesrepinfo the new salesrepinfo
	 */
	public void setSalesrepinfo(String salesrepinfo) {
		this.salesrepinfo = salesrepinfo;
	}

	/**
	 * Gets the segmentinfo.
	 *
	 * @return the segmentinfo
	 */
	public String getSegmentinfo() {
		return this.segmentinfo;
	}

	/**
	 * Sets the segmentinfo.
	 *
	 * @param segmentinfo the new segmentinfo
	 */
	public void setSegmentinfo(String segmentinfo) {
		this.segmentinfo = segmentinfo;
	}

	/**
	 * Gets the subscribernumber.
	 *
	 * @return the subscribernumber
	 */
	public String getSubscribernumber() {
		return this.subscribernumber;
	}

	/**
	 * Sets the subscribernumber.
	 *
	 * @param subscribernumber the new subscribernumber
	 */
	public void setSubscribernumber(String subscribernumber) {
		this.subscribernumber = subscribernumber;
	}

	/**
	 * Gets the subscriberstatusinfo.
	 *
	 * @return the subscriberstatusinfo
	 */
	public String getSubscriberstatusinfo() {
		return this.subscriberstatusinfo;
	}

	/**
	 * Sets the subscriberstatusinfo.
	 *
	 * @param subscriberstatusinfo the new subscriberstatusinfo
	 */
	public void setSubscriberstatusinfo(String subscriberstatusinfo) {
		this.subscriberstatusinfo = subscriberstatusinfo;
	}

	/**
	 * Gets the wap enabled.
	 *
	 * @return the wap enabled
	 */
	public String getWapEnabled() {
		return this.wapEnabled;
	}

	/**
	 * Sets the wap enabled.
	 *
	 * @param wapEnabled the new wap enabled
	 */
	public void setWapEnabled(String wapEnabled) {
		this.wapEnabled = wapEnabled;
	}

	/**
	 * Gets the work req.
	 *
	 * @return the work req
	 */
	public String getWorkReq() {
		return this.workReq;
	}

	/**
	 * Sets the work req.
	 *
	 * @param workReq the new work req
	 */
	public void setWorkReq(String workReq) {
		this.workReq = workReq;
	}

}