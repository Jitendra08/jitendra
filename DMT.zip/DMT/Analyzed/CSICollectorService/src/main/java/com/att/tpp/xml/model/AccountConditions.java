package com.att.tpp.xml.model;

import java.util.Collection;

public class AccountConditions {
	
 


	private AccountConditions.CombinedBillingRegion combinedBillingRegion;
    private AccountConditions.DealerInfo dealerInfo;
    private AccountConditions.CombinedBillingIndicator combinedBillingIndicator;
    private Collection<AccountAttributes> accountAttributes;
    private AccountConditions.BillingCycle billingCycle;
    private AccountConditions.InvoiceId invoiceId;
    private AccountConditions.AccountStatus accountStatus;
    private String hybridAgent;
    private boolean isNotificationValid=false;
    private boolean hasDelta = false;
     
    
    

	public AccountConditions(CombinedBillingRegion combinedBillingRegion,
			DealerInfo dealerInfo,
			CombinedBillingIndicator combinedBillingIndicator,
			Collection<AccountAttributes> accountAttributes,
			BillingCycle billingCycle, InvoiceId invoiceId,
			AccountStatus accountStatus, String hybridAgent,
			boolean isNotificationValid) {
		super();
		this.combinedBillingRegion = combinedBillingRegion;
		this.dealerInfo = dealerInfo;
		this.combinedBillingIndicator = combinedBillingIndicator;
		this.accountAttributes = accountAttributes;
		this.billingCycle = billingCycle;
		this.invoiceId = invoiceId;
		this.accountStatus = accountStatus;
		this.hybridAgent = hybridAgent;
		this.setNotificationValid(isNotificationValid);
	}
	
	

	/**
	 * @param combinedBillingRegion
	 * @param dealerInfo
	 * @param combinedBillingIndicator
	 * @param accountAttributes
	 * @param billingCycle
	 * @param invoiceId
	 * @param accountStatus
	 * @param hasDelta 
	 * @param hybridAgent
	 */
	public AccountConditions(CombinedBillingRegion combinedBillingRegion,
			DealerInfo dealerInfo,
			CombinedBillingIndicator combinedBillingIndicator,
			Collection<AccountAttributes> accountAttributes,
			BillingCycle billingCycle, InvoiceId invoiceId,
			AccountStatus accountStatus, 
			boolean hasDelta,
			String hybridAgent) {
		this.combinedBillingRegion = combinedBillingRegion;
		this.dealerInfo = dealerInfo;
		this.combinedBillingIndicator = combinedBillingIndicator;
		this.accountAttributes = accountAttributes;
		this.billingCycle = billingCycle;
		this.invoiceId = invoiceId;
		this.accountStatus = accountStatus;
		this.hasDelta = hasDelta;
		this.hybridAgent = hybridAgent;
		
	}



	/**
	 * @param combinedBillingRegion
	 * @param dealerInfo
	 * @param combinedBillingIndicator
	 * @param accountAttributes
	 * @param billingCycle
	 * @param invoiceId
	 */
	public AccountConditions(CombinedBillingRegion combinedBillingRegion,
			DealerInfo dealerInfo,
			CombinedBillingIndicator combinedBillingIndicator,
			Collection<AccountAttributes> accountAttributes,
			BillingCycle billingCycle, InvoiceId invoiceId, AccountStatus accountStatus, String hybridAgent) {
		super();
		this.combinedBillingRegion = combinedBillingRegion;
		this.dealerInfo = dealerInfo;
		this.combinedBillingIndicator = combinedBillingIndicator;
		this.accountAttributes = accountAttributes;
		this.billingCycle = billingCycle;
		this.invoiceId = invoiceId;
		this.accountStatus = accountStatus;
		this.hybridAgent = hybridAgent;
	}
    
    /**
	 * @return the invoiceId
	 */
	public AccountConditions.InvoiceId getInvoiceId() {
		return invoiceId;
	}


	/**
	 * @param invoiceId the invoiceId to set
	 */
	public void setInvoiceId(AccountConditions.InvoiceId invoiceId) {
		this.invoiceId = invoiceId;
	}


	/**
	 * @return the billingCycle
	 */
	public AccountConditions.BillingCycle getBillingCycle() {
		return billingCycle;
	}


	/**
	 * @param billingCycle the billingCycle to set
	 */
	public void setBillingCycle(AccountConditions.BillingCycle billingCycle) {
		this.billingCycle = billingCycle;
	}


	/**
	 * @return the accountAttributes
	 */
	public Collection<AccountAttributes> getAccountAttributes() {
		return accountAttributes;
	}


	/**
	 * @param accountAttributes the accountAttributes to set
	 */
	public void setAccountAttributes(Collection<AccountAttributes> accountAttributes) {
		this.accountAttributes = accountAttributes;
	}


	/**
	 * @return the combinedBillingRegion
	 */
	public AccountConditions.CombinedBillingRegion getCombinedBillingRegion() {
		return combinedBillingRegion;
	}


	/**
	 * @param combinedBillingRegion the combinedBillingRegion to set
	 */
	public void setCombinedBillingRegion(
			AccountConditions.CombinedBillingRegion combinedBillingRegion) {
		this.combinedBillingRegion = combinedBillingRegion;
	}


	/**
	 * @return the dealerInfo
	 */
	public AccountConditions.DealerInfo getDealerInfo() {
		return dealerInfo;
	}


	/**
	 * @return the hybridAgent
	 */
	public String getHybridAgent() {
		return hybridAgent;
	}

	/**
	 * @param hybridAgent the hybridAgent to set
	 */
	public void setHybridAgent(String hybridAgent) {
		this.hybridAgent = hybridAgent;
	}

	/**
	 * @param dealerInfo the dealerInfo to set
	 */
	public void setDealerInfo(AccountConditions.DealerInfo dealerInfo) {
		this.dealerInfo = dealerInfo;
	}


	/**
	 * @return the combinedBillingIndicator
	 */
	public AccountConditions.CombinedBillingIndicator getCombinedBillingIndicator() {
		return combinedBillingIndicator;
	}


	/**
	 * @param combinedBillingIndicator the combinedBillingIndicator to set
	 */
	public void setCombinedBillingIndicator(
			AccountConditions.CombinedBillingIndicator combinedBillingIndicator) {
		this.combinedBillingIndicator = combinedBillingIndicator;
	}

	


	/**
	 * @return the accountStatus
	 */
	public AccountConditions.AccountStatus getAccountStatus() {
		return accountStatus;
	}

	/**
	 * @param accountStatus the accountStatus to set
	 */
	public void setAccountStatus(AccountConditions.AccountStatus accountStatus) {
		this.accountStatus = accountStatus;
	}



	public static class InvoiceId {
		private String currentInvoiceId;
		private String deltaInvoiceId;
		
		
		
		
		
		
		/**
		 * @param currentInvoiceId
		 */
		public InvoiceId(String currentInvoiceId) {
			super();
			this.currentInvoiceId = currentInvoiceId;
		}
		/**
		 * @param currentInvoiceId
		 * @param deltaInvoiceId
		 */
		public InvoiceId(String currentInvoiceId, String deltaInvoiceId) {
			super();
			this.currentInvoiceId = currentInvoiceId;
			this.deltaInvoiceId = deltaInvoiceId;
		}
		/**
		 * @return the currentInvoiceId
		 */
		public String getCurrentInvoiceId() {
			return currentInvoiceId;
		}
		/**
		 * @param currentInvoiceId the currentInvoiceId to set
		 */
		public void setCurrentInvoiceId(String currentInvoiceId) {
			this.currentInvoiceId = currentInvoiceId;
		}
		/**
		 * @return the deltaInvoiceId
		 */
		public String getDeltaInvoiceId() {
			return deltaInvoiceId;
		}
		/**
		 * @param deltaInvoiceId the deltaInvoiceId to set
		 */
		public void setDeltaInvoiceId(String deltaInvoiceId) {
			this.deltaInvoiceId = deltaInvoiceId;
		}
		
		
	}
	
	
	public static class BillingCycle {
		
		
		private String currentBillingCycle;
		private String deltaBillingCycle;
		
		
		public BillingCycle(String currentBillingCycle) {
			super();
			this.currentBillingCycle = currentBillingCycle;
		}
		

		public BillingCycle(String currentBillingCycle, String deltaBillingCycle) {
			super();
			this.currentBillingCycle = currentBillingCycle;
			this.deltaBillingCycle = deltaBillingCycle;
		}
		
		public String getCurrentBillingCycle() {
			return currentBillingCycle;
		}
		public void setCurrentBillingCycle(String currentBillingCycle) {
			this.currentBillingCycle = currentBillingCycle;
		}
		public String getDeltaBillingCycle() {
			return deltaBillingCycle;
		}
		public void setDeltaBillingCycle(String deltaBillingCycle) {
			this.deltaBillingCycle = deltaBillingCycle;
		}
		
		
		
	}

	public static class CombinedBillingRegion {

		private String currentCombinedBillingRegion;
		private String deltaCombinedBillingRegion;

		public CombinedBillingRegion(String currentCombinedBillingRegion,
				String deltaCombinedBillingRegion) {
			super();
			this.currentCombinedBillingRegion = currentCombinedBillingRegion;
			this.deltaCombinedBillingRegion = deltaCombinedBillingRegion;
		}

		public CombinedBillingRegion(String currentCombinedBillingRegion) {
			super();
			this.currentCombinedBillingRegion = currentCombinedBillingRegion;
		}

		public String getCurrentCombinedBillingRegion() {
			return currentCombinedBillingRegion;
		}

		public void setCurrentCombinedBillingRegion(
				String currentCombinedBillingRegion) {
			this.currentCombinedBillingRegion = currentCombinedBillingRegion;
		}

		public String getDeltaCombinedBillingRegion() {
			return deltaCombinedBillingRegion;
		}

		public void setDeltaCombinedBillingRegion(
				String deltaCombinedBillingRegion) {
			this.deltaCombinedBillingRegion = deltaCombinedBillingRegion;
		}

	}
    

	public static class DealerInfo {

		private String currentDealerInfoCode;
		private String deltaDealerInfoCode;

		/**
		 * 
		 * @param currentDealerInfoCode
		 */
		public DealerInfo(String currentDealerInfoCode) {
			super();
			this.currentDealerInfoCode = currentDealerInfoCode;
		}

		/**
		 * @param currentDealerInfoCode
		 * @param deltaDealerInfo
		 */
		public DealerInfo(String currentDealerInfoCode,
				String deltaDealerInfo) {
			super();
			this.currentDealerInfoCode = currentDealerInfoCode;
			this.deltaDealerInfoCode = deltaDealerInfo;
		}

		/**
		 * @return the currentDealerInfoCode
		 */
		public String getCurrentDealerInfoCode() {
			return currentDealerInfoCode;
		}

		/**
		 * @param currentDealerInfoCode
		 *            the currentDealerInfoCode to set
		 */
		public void setCurrentDealerInfoCode(String currentDealerInfoCode) {
			this.currentDealerInfoCode = currentDealerInfoCode;
		}

		/**
		 * @return the deltaDealerInfoCode
		 */
		public String getDeltaDealerInfo() {
			return deltaDealerInfoCode;
		}

		/**
		 * @param deltaDealerInfo
		 *            the deltaDealerInfo to set
		 */
		public void setDeltaDealerInfo(String deltaDealerInfo) {
			this.deltaDealerInfoCode = deltaDealerInfo;
		}

	}
	
	
	public static class CombinedBillingIndicator {

		private String currentCombinedBillingIndicator;
		private String deltaCombinedBillingIndicator;		
		
			
		/**
		 * @param currentCombinedBillingIndicator
		 */
		public CombinedBillingIndicator(String currentCombinedBillingIndicator) {
			super();
			this.currentCombinedBillingIndicator = currentCombinedBillingIndicator;
		}
		/**
		 * @param currentCombinedBillingIndicator
		 * @param deltaCombinedBillingIndicator
		 */
		public CombinedBillingIndicator(String currentCombinedBillingIndicator,
				String deltaCombinedBillingIndicator) {
			super();
			this.currentCombinedBillingIndicator = currentCombinedBillingIndicator;
			this.deltaCombinedBillingIndicator = deltaCombinedBillingIndicator;
		}
		/**
		 * @return the currentCombinedBillingIndicator
		 */
		public String getCurrentCombinedBillingIndicator() {
			return currentCombinedBillingIndicator;
		}
		/**
		 * @param currentCombinedBillingIndicator the currentCombinedBillingIndicator to set
		 */
		public void setCurrentCombinedBillingIndicator(
				String currentCombinedBillingIndicator) {
			this.currentCombinedBillingIndicator = currentCombinedBillingIndicator;
		}
		/**
		 * @return the deltaCombinedBillingIndicator
		 */
		public String getDeltaCombinedBillingIndicator() {
			return deltaCombinedBillingIndicator;
		}
		/**
		 * @param deltaCombinedBillingIndicator the deltaCombinedBillingIndicator to set
		 */
		public void setDeltaCombinedBillingIndicator(
				String deltaCombinedBillingIndicator) {
			this.deltaCombinedBillingIndicator = deltaCombinedBillingIndicator;
		}
		
		
	}

	   

		public static class AccountStatus {

			private String currentStatus;
			private String deltaStatus;
			
			
			
			/**
			 * @return the currentStatus
			 */
			public String getCurrentStatus() {
				return currentStatus;
			}


			/**
			 * @param currentStatus the currentStatus to set
			 */
			public void setCurrentStatus(String currentStatus) {
				this.currentStatus = currentStatus;
			}


			/**
			 * @return the deltaStatus
			 */
			public String getDeltaStatus() {
				return deltaStatus;
			}


			/**
			 * @param deltaStatus the deltaStatus to set
			 */
			public void setDeltaStatus(String deltaStatus) {
				this.deltaStatus = deltaStatus;
			}


			/**
			 * @param currentStatus
			 * @param deltaStatus
			 */
			public AccountStatus(String currentStatus, String deltaStatus) {
				super();
				this.currentStatus = currentStatus;
				this.deltaStatus = deltaStatus;
			}


			/**
			 * @param currentStatus
			 */
			public AccountStatus(String currentStatus) {
				super();
				this.currentStatus = currentStatus;
			}
			
						
			
			
		}



		/**
		 * 
		 */
		public AccountConditions() {
			super();
		}

		public boolean isNotificationValid() {
			return isNotificationValid;
		}

		public void setNotificationValid(boolean isNotificationValid) {
			this.isNotificationValid = isNotificationValid;
		}

		/**
		 * @return the hasDelta
		 */
		public boolean isHasDelta() {
			return hasDelta;
		}

		/**
		 * @param hasDelta the hasDelta to set
		 */
		public void setHasDelta(boolean hasDelta) {
			this.hasDelta = hasDelta;
		}
}
