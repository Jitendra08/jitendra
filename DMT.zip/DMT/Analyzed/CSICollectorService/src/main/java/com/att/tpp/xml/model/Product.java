package com.att.tpp.xml.model;

import java.util.Collection;

public class Product {
    
    private String category;
    private String id;
    private String action;
    private String productDescription;
	private Long majorCode;
    private String description;
    private String status;
    private Collection<Attribute> attribute;
    private TransactionCode transactionCode;
    private Collection<System> system;
    private String effectiveDate;
    private String expirationDate;
    private boolean isValidProduct;
    private String ipid;

	
	public Product() {}
	
	public Product(String id, String ipid, String action, Collection<Attribute> attribute) {
		super();
		this.id = id;
		this.ipid = ipid;
		this.action = action;
		this.attribute = attribute;
	}
    
	public Product(String id, String ipid, String action, Collection<Attribute> attribute, boolean isValidProduct) {
		super();
		this.id = id;
		this.ipid = ipid;
		this.action = action;
		this.attribute = attribute;
		this.isValidProduct=isValidProduct;
	}
	
	public Product(String category, String id, String ipid, String action) {
		this.category = category;
		this.id = id;
		this.ipid = ipid;
		this.action = action;
	}
	/**
	 * @param category
	 * @param id
	 * @param action
	 */
	public Product(String category, String id, String action) {
		this.category = category;
		this.id = id;
		this.action = action;
	}
	
	public Product(String id, String action, Collection<Attribute> attribute) {
		super();
		this.id = id;
		this.action = action;
		this.attribute = attribute;
	}
	
	public Product(String id, String action, Collection<Attribute> attribute, boolean isValidProduct) {
		super();
		this.id = id;
		this.action = action;
		this.attribute = attribute;
		this.isValidProduct=isValidProduct;
	}
	
	/**
	 * @param category
	 * @param id
	 * @param action
	 * @param productDescription
	 */
/*	public Product(String category, String id, String action,
			String productDescription) {
		this.category = category;
		this.id = id;
		this.action = action;
		this.productDescription = productDescription;
	}
*/
	/**
	 * Use this constructor with Provisioning Request!
	 * @param category
	 * @param id
	 * @param action
	 * @param productDescription
	 * @param attribute
	 */
	public Product(String category, String id, String action,
			String productDescription, Collection<Attribute> attribute) {
		this.category = category;
		this.id = id;
		this.action = action;
		this.productDescription = productDescription;
		this.attribute = attribute;
	}

	/**
	 * @param category
	 * @param id
	 * @param action
	 * @param productDescription
	 * @param status
	 * @param attribute
	 */
	public Product(String category, String id, String action,
			String productDescription, String status,
			Collection<Attribute> attribute) {
		this.category = category;
		this.id = id;
		this.action = action;
		this.productDescription = productDescription;
		this.status = status;
		this.attribute = attribute;
	}

	/**
	 * @param category
	 * @param id
	 * @param action
	 * @param productDescription
	 * @param majorCode
	 * @param description
	 * @param status
	 * @param transactionCode
	 */
	public Product(String category, String id, String action,
			String productDescription, Long majorCode, String description,
			String status, TransactionCode transactionCode) {
		this.category = category;
		this.id = id;
		this.action = action;
		this.productDescription = productDescription;
		this.majorCode = majorCode;
		this.description = description;
		this.status = status;
		this.transactionCode = transactionCode;
	}

	/**
	 * Use this constructor with Provisioning Response!
	 * 
	 * @param category
	 * @param id
	 * @param action
	 * @param majorCode
	 * @param description
	 * @param transactionCode
	 */
	public Product(String category, String id, String action, Long majorCode,
			String description, TransactionCode transactionCode) {
		this.category = category;
		this.id = id;
		this.action = action;
		this.majorCode = majorCode;
		this.description = description;
		this.transactionCode = transactionCode;
	}
	
	/**
	 * @param id
	 * @param action
	 * @param attribute
	 * @param effectiveDate
	 * @param expirationDate
	 */
	public Product(String id, String action, Collection<Attribute> attribute,
			String effectiveDate, String expirationDate) {
		this.id = id;
		this.action = action;
		this.attribute = attribute;
		this.effectiveDate = effectiveDate;
		this.expirationDate = expirationDate;
	}

	/**
	 * @return the category
	 */
	public String getCategory() {
		return category;
	}

	/**
	 * @param category
	 *            the category to set
	 */
	public void setCategory(String category) {
		this.category = category;
	}

	/**
	 * @return the id
	 */
	public String getId() {
		return id;
	}

	/**
	 * @param id
	 *            the id to set
	 */
	public void setId(String id) {
		this.id = id;
	}

	/**
	 * @return the action
	 */
	public String getAction() {
		return action;
	}

	/**
	 * @param action
	 *            the action to set
	 */
	public void setAction(String action) {
		this.action = action;
	}

	/**
	 * @return the productDescription
	 */
	public String getProductDescription() {
		return productDescription;
	}

	/**
	 * @param productDescription
	 *            the productDescription to set
	 */
	public void setProductDescription(String productDescription) {
		this.productDescription = productDescription;
	}

	/**
	 * @return the majorCode
	 */
	public Long getMajorCode() {
		return majorCode;
	}

	/**
	 * @param majorCode
	 *            the majorCode to set
	 */
	public void setMajorCode(Long majorCode) {
		this.majorCode = majorCode;
	}

	/**
	 * @return the description
	 */
	public String getDescription() {
		return description;
	}

	/**
	 * @param description
	 *            the description to set
	 */
	public void setDescription(String description) {
		this.description = description;
	}

	/**
	 * @return the status
	 */
	public String getStatus() {
		return status;
	}

	/**
	 * @param status
	 *            the status to set
	 */
	public void setStatus(String status) {
		this.status = status;
	}

	/**
	 * @return the attribute
	 */
	public Collection<Attribute> getAttribute() {
		return attribute;
	}

	/**
	 * @param attribute
	 *            the attribute to set
	 */
	public void setAttribute(Collection<Attribute> attribute) {
		this.attribute = attribute;
	}

	/**
	 * @return the transactionCode
	 */
	public TransactionCode getTransactionCode() {
		return transactionCode;
	}

	/**
	 * @param transactionCode
	 *            the transactionCode to set
	 */
	public void setTransactionCode(TransactionCode transactionCode) {
		this.transactionCode = transactionCode;
	}

	/**
	 * @return the system
	 */
	public Collection<System> getSystem() {
		return system;
	}

	/**
	 * @param system
	 *            the system to set
	 */
	public void setSystem(Collection<System> system) {
		this.system = system;
	}

	/**
	 * @return the effectiveDate
	 */
	public String getEffectiveDate() {
		return effectiveDate;
	}

	/**
	 * @param effectiveDate the effectiveDate to set
	 */
	public void setEffectiveDate(String effectiveDate) {
		this.effectiveDate = effectiveDate;
	}

	/**
	 * @return the expirationDate
	 */
	public String getExpirationDate() {
		return expirationDate;
	}

	/**
	 * @param expirationDate the expirationDate to set
	 */
	public void setExpirationDate(String expirationDate) {
		this.expirationDate = expirationDate;
	}
    
	public boolean isValid() {
		return isValidProduct;
	}

	public void setValid(boolean isValid) {
		this.isValidProduct = isValid;
	}

	public boolean isValidProduct() {
		return isValidProduct;
	}

	public void setValidProduct(boolean isValidProduct) {
		this.isValidProduct = isValidProduct;
	}

	public String getIpid() {
		return ipid;
	}

	public void setIpid(String ipid) {
		this.ipid = ipid;
	}

    
}
