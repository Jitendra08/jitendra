package com.att.tpp.model;

import java.io.Serializable;
import java.util.List;

/**
 *
 * @author sg625m
 */

public class ProcessingResult implements Serializable  {
	
	private static final long serialVersionUID = 1L;
	
	boolean isPersisted=false;
	boolean isValidRequest=false;
	private String messageId;
	private String subscriberNumber;
	private List<String> invalidFeatures;	
	private String tppProvReq;
	boolean isValidTPPProvReq=false;
	private String csiEventName;
	private String atlasEventType;
	boolean isValidProductExist=false;
	
	public boolean isValidRequest() {
		return isValidRequest;
	}
	public void setValidRequest(boolean isValidRequest) {
		this.isValidRequest = isValidRequest;
	}
	public String getSubscriberNumber() {
		return subscriberNumber;
	}
	public void setSubscriberNumber(String subscriberNumber) {
		this.subscriberNumber = subscriberNumber;
	}
	public List<String> getInvalidFeatures() {
		return invalidFeatures;
	}
	public void setInvalidFeatures(List<String> invalidFeatures) {
		this.invalidFeatures = invalidFeatures;
	}
	public String getTppProvReq() {
		return tppProvReq;
	}
	public void setTppProvReq(String tppProvReq) {
		this.tppProvReq = tppProvReq;
	}
	public boolean isValidTPPProvReq() {
		return isValidTPPProvReq;
	}
	public void setValidTPPProvReq(boolean isValidTPPProvReq) {
		this.isValidTPPProvReq = isValidTPPProvReq;
	}
	public String getMessageId() {
		return messageId;
	}
	public void setMessageId(String messageId) {
		this.messageId = messageId;
	}
	public boolean isPersisted() {
		return isPersisted;
	}
	public void setPersisted(boolean isPersisted) {
		this.isPersisted = isPersisted;
	}
	/**
	 * @return the csiEventName
	 */
	public String getCsiEventName() {
		return csiEventName;
	}
	/**
	 * @param csiEventName the csiEventName to set
	 */
	public void setCsiEventName(String csiEventName) {
		this.csiEventName = csiEventName;
	}
	/**
	 * @return the atlasEventType
	 */
	public String getAtlasEventType() {
		return atlasEventType;
	}
	/**
	 * @param atlasEventType the atlasEventType to set
	 */
	public void setAtlasEventType(String atlasEventType) {
		this.atlasEventType = atlasEventType;
	}
	/**
	 * @return the isValidProductExist
	 */
	public boolean isValidProductExist() {
		return isValidProductExist;
	}
	/**
	 * @param isValidProductExist the isValidProductExist to set
	 */
	public void setValidProductExist(boolean isValidProductExist) {
		this.isValidProductExist = isValidProductExist;
	}
	
	


}
