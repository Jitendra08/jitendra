package com.att.tpp.xml.model;

public class Notification {

    private String url;    

	/**
	 * @param url
	 */
	public Notification(String url) {
		this.url = url;
	}

	/**
	 * @return the url
	 */
	public String getUrl() {
		return url;
	}

	/**
	 * @param url the url to set
	 */
	public void setUrl(String url) {
		this.url = url;
	}    
    
}
