/**
 * 
 */
package com.att.tpp.service;

import java.io.IOException;
import java.net.URL;

import org.apache.log4j.Logger;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import com.att.tpp.utils.ABS_ProvisioningResponseXMLGenerator;
import com.att.tpp.utils.TPP_ProvisioningRequestXMLGenerator;
import com.att.tpp.utils.ValidateXMLUtil;
import com.att.tpp.xml.model.Products;
import com.att.tpp.xml.model.ProvisioningRequestData;

/**
 * @author rg730b
 *
 */

@Service("csiCollectorService")
@Transactional(propagation = Propagation.SUPPORTS, readOnly = true)
public class CSICollectorServiceImpl implements CSICollectorService{
	
	private static final Logger csiCollectorServiceLog = Logger
            .getLogger(CSICollectorServiceImpl.class);
	
	private final static String schemaDir = "//com//att//tpp//common//schemas//Atlas//jms//Public//";
    private final static String tppSchemaDir = "//com//att//tpp//common//schemas//";
    
    ValidateXMLUtil validateXMLUtil = new ValidateXMLUtil();
	
	@Override
    public Boolean validateXML(String inputXML, String xsdName)
                  throws IOException, Exception {
           boolean validationResult = false;
           StringBuilder schemaLocation = null;
				if (xsdName.contains("TPP")){
					schemaLocation = new StringBuilder(tppSchemaDir);
				}else if (xsdName.contains("QTY")){
					schemaLocation = new StringBuilder(tppSchemaDir);
				}else if (xsdName.contains("ABS")){
					schemaLocation = new StringBuilder(tppSchemaDir);
				}else{
					schemaLocation = new StringBuilder(schemaDir);
				}
           schemaLocation.append(xsdName);
           URL xsdPath = CSICollectorServiceImpl.class
                        .getResource(schemaLocation.toString());
           csiCollectorServiceLog.debug("xsdPath :" + xsdPath.toString());
           validationResult = validateXMLUtil.validateWithXSD(inputXML,
                        xsdPath.toString());
          return validationResult;
    }
	
    @Override
    public String createTPPProvReqXML(ProvisioningRequestData provisioningRequestData, Products products) {
             String tppProvReqXML="";
             TPP_ProvisioningRequestXMLGenerator tppProvReqXMLGenerator = new TPP_ProvisioningRequestXMLGenerator();
             tppProvReqXML = tppProvReqXMLGenerator.createProvReqXML(provisioningRequestData, products);
             return tppProvReqXML;
      }
    
    @Override
    public String createABSProvResXML(ProvisioningRequestData tppProvisioningRequest, Products products, StringBuffer errorMessage){
    	 String absProvResXML="";
         ABS_ProvisioningResponseXMLGenerator absProvResXMLGenerator = new ABS_ProvisioningResponseXMLGenerator();
         absProvResXML = absProvResXMLGenerator.createABSResXML(tppProvisioningRequest, products, errorMessage);
    	return absProvResXML;
    }
    
    @Override
    public String createInvalidXMLABSProvResXML(ProvisioningRequestData tppProvisioningRequest, StringBuffer errorMessage){
    	 String absProvResXML="";
         ABS_ProvisioningResponseXMLGenerator absProvResXMLGenerator = new ABS_ProvisioningResponseXMLGenerator();
         absProvResXML = absProvResXMLGenerator.createInvalidXMLABSResXML(tppProvisioningRequest, errorMessage);
    	return absProvResXML;
    }


}
