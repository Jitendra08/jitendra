/**
 * 
 */
package com.att.tpp.service;

import java.io.IOException;
import java.util.Collection;

import com.att.tpp.model.DcmMessageArchive;
import com.att.tpp.xml.model.Product;
import com.att.tpp.xml.model.ProvisioningRequestData;
import com.att.tpp.xml.model.Products;

/**
 * @author rg730b
 *
 */
public interface DCMNotificationService {
	
	public ProvisioningRequestData parseDCMNotificationData(String dcmRequestXML) throws IOException, Exception;
	
	public Products loadProducts(Collection<Product> collection) throws Exception;
	
	//public boolean validateIPID(Collection<Product> collection) throws Exception;
	
	public boolean validateIPID(Products listProducts) throws Exception;
	
	public Products assignProductIds(Collection<Product> productCollection) throws IOException, Exception;

	public boolean persistDCMRequest(DcmMessageArchive dcmMessageArchive);
}
