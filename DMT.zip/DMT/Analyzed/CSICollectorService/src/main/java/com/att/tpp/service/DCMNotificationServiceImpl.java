/**
 * 
 */
package com.att.tpp.service;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Iterator;
import java.util.List;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import com.att.tpp.dao.CSICollectorDao;
import com.att.tpp.xml.model.Attribute;
import com.att.tpp.model.DcmMessageArchive;
import com.att.tpp.model.FeatureCodeRef;
import com.att.tpp.xml.model.Product;
import com.att.tpp.xml.model.Products;
import com.att.tpp.xml.model.ProvisioningRequestData;
import com.att.tpp.utils.ParseDCMNotificationRequestData;


/**
 * @author rg730b
 *
 */
@Service("dcmNotificationService")
@Transactional(propagation = Propagation.SUPPORTS, readOnly = true)
public class DCMNotificationServiceImpl implements DCMNotificationService{
	
	private static final Logger dcmNotificationServiceLog = Logger.getLogger(DCMNotificationServiceImpl.class);
	
	@Autowired
	private CSICollectorDao csiCollectorDao;
	
	 @Override
     public ProvisioningRequestData parseDCMNotificationData(
                   String dcmRequestXML) throws IOException, Exception {
		dcmNotificationServiceLog.info("Inside parseDCMNotificationData method of DCMNotificationServiceImpl");
        ParseDCMNotificationRequestData parseDCMNotificationRequestData = new ParseDCMNotificationRequestData();
        ProvisioningRequestData dcmNotificationRequestData = parseDCMNotificationRequestData.getDCMNotificationData(dcmRequestXML);
        return dcmNotificationRequestData;
     }
	 
	// @Override
	// @Transactional("configTransactionManager")
	 public Products loadProducts(Collection<Product> productCollection) throws Exception {
	 	dcmNotificationServiceLog.debug("Inside loadProducts method of DCMNotificationServiceImpl");		
	 	Products products = new Products();
		List<FeatureCodeRef> featureCodeRefList = csiCollectorDao.featureCodeRefDCMList();
		Collection<Product> productList = new ArrayList<Product>();
 		Iterator<Product> productIterator = productCollection.iterator();
	 	if (featureCodeRefList != null && featureCodeRefList.size()>0) {				
			while (productIterator.hasNext()) {
				Product lineProd = productIterator.next();
				String productId = lineProd.getId();
				String strIpid = lineProd.getIpid();
				String strAction = lineProd.getAction();
				boolean isValidProduct = false;
				Collection<Attribute> attributeList = lineProd.getAttribute();
				if (featureCodeRefList != null && featureCodeRefList.size() > 0) {
		    		   for (FeatureCodeRef featureCode : featureCodeRefList) {
		    			   if (featureCode.getId().getFeatureCode().equals(productId)) {
		    					dcmNotificationServiceLog.info("Valid IPID : "+productId);
		    				   isValidProduct = true;
		    			   }        		 
		    		   }
		    	   }
				Product product = new Product(productId, strIpid, strAction, attributeList, isValidProduct);
				productList.add(product);
			}
	 	}else{
	 		dcmNotificationServiceLog
			.info("featureCode list is empty from hibernate query , Inside loadProducts method of DCMNotificationServiceImpl");
	 	}
	 	products.setProduct(productList);
		return products;	
		}
	 
	 
	public boolean validateIPID(Products listProducts) throws Exception { 
	 	dcmNotificationServiceLog.debug("Inside validateIPID method of RequestHandlerServiceImpl");		
		Collection<Product> productCollection = listProducts.getProduct();
 		Iterator<Product> productIterator = productCollection.iterator();
		while (productIterator.hasNext()) {
			boolean validProductId = productIterator.next().isValid();
			if (!validProductId) {
				dcmNotificationServiceLog.debug("IPID is not in the featureCodeRef table for IPID :: "+productIterator.next().getId());
				return false;
			}
		}
		return true;	
	}
		
	 public Products assignProductIds(Collection<Product> productCollection) throws IOException, Exception{
		 dcmNotificationServiceLog.debug("Inside assignProductIds method of DCMNotificationServiceImpl");
		 Iterator<Product> productIterator = productCollection.iterator();
		 Collection<com.att.tpp.xml.model.Product> productList = new ArrayList<com.att.tpp.xml.model.Product>();
		 Products products = new Products();
		 while (productIterator.hasNext()) {
			 Product lineProduct = productIterator.next();
				String strIPID = lineProduct.getId();
				String strIpid = lineProduct.getIpid();
				String strAction = lineProduct.getAction();
				//String strCategory = productIterator.next().getCategory();
				Collection<Attribute> attributeList = lineProduct.getAttribute();
				// Returning set of productIds for single offeringCode
				ArrayList<String> productIds = getProductIds(strIPID);
				Iterator<String> prodIdsIt = productIds.iterator();
				while(prodIdsIt.hasNext()){
					String productId = prodIdsIt.next();
					Product product = new Product(productId, strIpid, strAction, attributeList);
					productList.add(product);
				}
		 }
		 products.setProduct(productList);
		 return products;
	 }

	 private ArrayList<String> getProductIds(String strIPID) throws Exception{    	 
		   dcmNotificationServiceLog.debug("Offering Code: -----> " + strIPID);
	  	   ArrayList<String> productIds = new ArrayList<String>();
	  	   List<FeatureCodeRef> featureCodeRefList = csiCollectorDao.featureCodeRefDCMList();
	  	   dcmNotificationServiceLog.debug("Featur Code List Size ----> " + featureCodeRefList.size());
	  	   if (featureCodeRefList != null && featureCodeRefList.size() > 0) {
	  		   for (FeatureCodeRef featureCode : featureCodeRefList) {
	  			   if (featureCode.getId().getFeatureCode().equals(strIPID)) {
	  				 dcmNotificationServiceLog.debug("Product ID ------> " + featureCode.getId().getProductId());
	  				   productIds.add(featureCode.getId().getProductId());
	  			   }        		 
	  		   }
	  	   }
	  	   if(productIds.isEmpty()){
	  		   productIds.add("9999");             
	  	   }
	  	   dcmNotificationServiceLog.debug("Get ProductIds -----> " + productIds);
	  	   return productIds;
     }
	 
	 public boolean persistDCMRequest(DcmMessageArchive dcmMessageArchive){
		boolean intInsertMsg = csiCollectorDao.persistDcmMessage(dcmMessageArchive);
		return intInsertMsg;
	 }

}
