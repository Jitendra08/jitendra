/**
 * 
 */
package com.att.tpp.service;

import java.io.IOException;

import com.att.tpp.xml.model.Products;
import com.att.tpp.xml.model.ProvisioningRequestData;

/**
 * @author rg730b
 *
 */
public interface CSICollectorService {
	
	public Boolean validateXML(String inputXML, String xsd) throws IOException, Exception;
	
    public String createTPPProvReqXML(ProvisioningRequestData provisioningRequestData, Products products);
    
    public String createABSProvResXML(ProvisioningRequestData tppProvisioningRequest, Products products, StringBuffer errorMessage);
    
    public String createInvalidXMLABSProvResXML(ProvisioningRequestData tppProvisioningRequest, StringBuffer errorMessage);



}
