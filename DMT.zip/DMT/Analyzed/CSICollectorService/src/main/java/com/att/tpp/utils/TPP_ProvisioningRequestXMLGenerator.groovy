package com.att.tpp.utils

import com.att.tpp.xml.model.*;

import groovy.xml.MarkupBuilder
import groovy.xml.XmlUtil



class TPP_ProvisioningRequestXMLGenerator {

	public TPP_ProvisioningRequestXMLGenerator() {
	}

	def String createProvReqXML(ProvisioningRequestData dcmReq, Products products){
		def dcmReqXML = new StringWriter()
		def xml = new MarkupBuilder(dcmReqXML)
				
		xml.setDoubleQuotes(true)
		xml.mkp.xmlDeclaration(version: "1.0", encoding: "UTF-8")
		//println("vendorName: " + dcmReq.vendorDetails?.vendorName?.toString())
		//println("vendorName: " + dcmReq.vendorDetails?.companyName?.toString())
		//println("orderId: " + dcmReq.vendorDetails?.orderId?.toString())
		
		xml.TPP_ProvisioningRequest("xmlns:xsi":"http://www.w3.org/2001/XMLSchema-instance"){
			Header(
				TransactionId:dcmReq.transactionId,
				ProvisioningCarrier:dcmReq.provisioningCarrier,
				TimeStamp:dcmReq.receivedTimeStamp,
				Atlas_Event_Type:dcmReq.atlasEventType,
				RoutingCarrier:dcmReq.routingCarrier,
			)
			Order(){
				Account(MSISDN:dcmReq.msisdn)
				if(dcmReq.vendorDetails != null)
				{
					buildVendorDetails(xml, dcmReq)
				}
			}
			buildProducts(xml, products)
		}
		
		Node root = new XmlParser().parseText(dcmReqXML.toString())
		cleanNode( root )		
		dcmReqXML = XmlUtil.serialize( root )
		 
		return dcmReqXML.toString()
		
	}
	
	def buildVendorDetails (MarkupBuilder mBuilder, ProvisioningRequestData dcmReq)
	{
		def vendorDetails= dcmReq.getVendorDetails();
		
		mBuilder.VendorDetails()
		{
			VendorName(replaceNull(vendorDetails.vendorName))
			CompanyName(replaceNull(vendorDetails.companyName))
			OrderId(replaceNull(vendorDetails.orderId))
		}
	}
	def buildProducts(MarkupBuilder mBuilder, Products products){
		mBuilder.Products(){
			products.product*.each { prod ->
				//println("ProductId: " + prod.id)
				Product(Category:"3PP", Id:prod.id, IPID:prod.ipid, Action:prod.action){
					prod.attribute*.each{ attrib ->
						Attribute(Name:attrib.name, Value:attrib.value)
					}
				}
			}
		}
	}
	
	//This Method cleans empty Nodes and null values nodes
	boolean cleanNode( Node node ) {
		node.attributes().with { a ->
			a.findAll { !it.value }.each { a.remove( it.key ) }
		}
		node.children().with { kids ->
			kids.findAll { it instanceof Node ? !cleanNode( it ) : false }
				.each { kids.remove( it ) }
		}
		node.attributes() || node.children() || node.text()
	}
	
	//This method will replace Null value with empty string
	def String replaceNull(value){
		def outputValue = value ?: ''
//		log.info("outputValue:"+outputValue)
		return outputValue
	}
}
