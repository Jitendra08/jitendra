package com.att.tpp.xml.model;

public class ChangeData {
	
	private String emailChange;
	private  String nameChange;
	private  String msisdnChange;
	private  String banChange;
	private  String makeChange;
	private  String modelChange;
	private  String imeiChange;
	private  String imsiChange;
	private  String subNumberChange;
	private  String phoneChange;
	private  String addressChange;
	private  String fanChange;
	private  String iccidChange;
	  
	  
	
	
	/**
	 * @param emailChange
	 * @param nameChange
	 * @param msisdnChange
	 * @param banChange
	 * @param makeChange
	 * @param modelChange
	 * @param imeiChange
	 * @param imsiChange
	 * @param subNumberChange
	 * @param phoneChange
	 * @param addressChange
	 * @param fanChange
	 * @param iccidChange
	 */
	public ChangeData(String emailChange, String nameChange,
			String msisdnChange, String banChange, String makeChange,
			String modelChange, String imeiChange, String imsiChange,
			String subNumberChange, String phoneChange, String addressChange,
			String fanChange, String iccidChange) {
		super();
		this.emailChange = emailChange;
		this.nameChange = nameChange;
		this.msisdnChange = msisdnChange;
		this.banChange = banChange;
		this.makeChange = makeChange;
		this.modelChange = modelChange;
		this.imeiChange = imeiChange;
		this.imsiChange = imsiChange;
		this.subNumberChange = subNumberChange;
		this.phoneChange = phoneChange;
		this.addressChange = addressChange;
		this.fanChange = fanChange;
		this.iccidChange = iccidChange;
	}
	  
	/**
	 * @return the emailChange
	 */
	public String getEmailChange() {
		return emailChange;
	}
	/**
	 * @param emailChange the emailChange to set
	 */
	public void setEmailChange(String emailChange) {
		this.emailChange = emailChange;
	}
	/**
	 * @return the nameChange
	 */
	public String getNameChange() {
		return nameChange;
	}
	/**
	 * @param nameChange the nameChange to set
	 */
	public void setNameChange(String nameChange) {
		this.nameChange = nameChange;
	}
	/**
	 * @return the msisdnChange
	 */
	public String getMsisdnChange() {
		return msisdnChange;
	}
	/**
	 * @param msisdnChange the msisdnChange to set
	 */
	public void setMsisdnChange(String msisdnChange) {
		this.msisdnChange = msisdnChange;
	}
	/**
	 * @return the banChange
	 */
	public String getBanChange() {
		return banChange;
	}
	/**
	 * @param banChange the banChange to set
	 */
	public void setBanChange(String banChange) {
		this.banChange = banChange;
	}
	/**
	 * @return the makeChange
	 */
	public String getMakeChange() {
		return makeChange;
	}
	/**
	 * @param makeChange the makeChange to set
	 */
	public void setMakeChange(String makeChange) {
		this.makeChange = makeChange;
	}
	/**
	 * @return the modelChange
	 */
	public String getModelChange() {
		return modelChange;
	}
	/**
	 * @param modelChange the modelChange to set
	 */
	public void setModelChange(String modelChange) {
		this.modelChange = modelChange;
	}
	/**
	 * @return the imeiChange
	 */
	public String getImeiChange() {
		return imeiChange;
	}
	/**
	 * @param imeiChange the imeiChange to set
	 */
	public void setImeiChange(String imeiChange) {
		this.imeiChange = imeiChange;
	}
	/**
	 * @return the imsiChange
	 */
	public String getImsiChange() {
		return imsiChange;
	}
	/**
	 * @param imsiChange the imsiChange to set
	 */
	public void setImsiChange(String imsiChange) {
		this.imsiChange = imsiChange;
	}
	/**
	 * @return the subNumberChange
	 */
	public String getSubNumberChange() {
		return subNumberChange;
	}
	/**
	 * @param subNumberChange the subNumberChange to set
	 */
	public void setSubNumberChange(String subNumberChange) {
		this.subNumberChange = subNumberChange;
	}
	/**
	 * @return the phoneChange
	 */
	public String getPhoneChange() {
		return phoneChange;
	}
	/**
	 * @param phoneChange the phoneChange to set
	 */
	public void setPhoneChange(String phoneChange) {
		this.phoneChange = phoneChange;
	}
	/**
	 * @return the addressChange
	 */
	public String getAddressChange() {
		return addressChange;
	}
	/**
	 * @param addressChange the addressChange to set
	 */
	public void setAddressChange(String addressChange) {
		this.addressChange = addressChange;
	}
	/**
	 * @return the fanChange
	 */
	public String getFanChange() {
		return fanChange;
	}
	/**
	 * @param fanChange the fanChange to set
	 */
	public void setFanChange(String fanChange) {
		this.fanChange = fanChange;
	}
	/**
	 * @return the iccidChange
	 */
	public String getIccidChange() {
		return iccidChange;
	}
	/**
	 * @param iccidChange the iccidChange to set
	 */
	public void setIccidChange(String iccidChange) {
		this.iccidChange = iccidChange;
	}
	
	  
	  
	  
	  

}
