package com.att.tpp.xml.model;

public class Account {



	private String msisdn;
	private String ban;
    private String subscriberNumber;
    private String accountTypeIndicator;
    private String socEffectiveDate;
    private String prevMSISDN;
    private String wirelessServiceId;
    private String banName;
    private String prevBAN;
    private String invoiceId;
    private String eodgroupid;
    
  //OrderStatusNoticeInfo
  	public Account(String msisdn) {
    		this.msisdn = msisdn;
  	}
    
    //Order Notification
	public Account(String msisdn, String ban) {
		super();
		this.msisdn = msisdn;
		this.ban = ban;
	}
    
    //Product Notification
    public Account(String msisdn, String subscriberNumber, String ban,
			String accountTypeIndicator, String socEffectiveDate) {
		super();
		this.msisdn = msisdn;
		this.subscriberNumber = subscriberNumber;
		this.ban = ban;
		this.accountTypeIndicator = accountTypeIndicator;
		this.socEffectiveDate = socEffectiveDate;
	}

	//Subscriber Notification
	public Account(String msisdn, String subscriberNumber, String prevMSISDN,
			String ban, String prevBAN, String socEffectiveDate,
			String accountTypeIndicator, String invoiceId) {
		super();
		this.msisdn = msisdn;
		this.subscriberNumber = subscriberNumber;
		this.prevMSISDN = prevMSISDN;
		this.ban = ban;
		this.prevBAN = prevBAN;
		this.socEffectiveDate = socEffectiveDate;
		this.accountTypeIndicator = accountTypeIndicator;
		this.invoiceId = invoiceId;
	}
	
	//For Account Notification
	/**	 
	 * @param msisdn
	 * @param ban
	 * @param prevBAN
	 * @param invoiceId
	 */
	public Account(String msisdn, String ban, String prevBAN, String invoiceId) {
		super();
		this.msisdn = msisdn;
		this.ban = ban;
		this.prevBAN = prevBAN;
		this.invoiceId = invoiceId;
	}
    
	public Account(String msisdn, String prevMSISDN, String wirelessServiceId,
			String subscriberNumber, String ban, String banName,
			String prevBAN, String accountTypeIndicator,
			String socEffectiveDate, String invoiceId, String eodgroupid) {
		super();
		this.msisdn = msisdn;
		this.prevMSISDN = prevMSISDN;
		this.wirelessServiceId = wirelessServiceId;
		this.subscriberNumber = subscriberNumber;
		this.ban = ban;
		this.banName = banName;
		this.prevBAN = prevBAN;
		this.accountTypeIndicator = accountTypeIndicator;
		this.socEffectiveDate = socEffectiveDate;
		this.invoiceId = invoiceId;
		this.eodgroupid = eodgroupid;
	}
	
	
	
	public String getMsisdn() {
		return msisdn;
	}
	public void setMsisdn(String msisdn) {
		this.msisdn = msisdn;
	}
	public String getPrevMSISDN() {
		return prevMSISDN;
	}
	public void setPrevMSISDN(String prevMSISDN) {
		this.prevMSISDN = prevMSISDN;
	}
	public String getWirelessServiceId() {
		return wirelessServiceId;
	}
	public void setWirelessServiceId(String wirelessServiceId) {
		this.wirelessServiceId = wirelessServiceId;
	}
	public String getSubscriberNumber() {
		return subscriberNumber;
	}
	public void setSubscriberNumber(String subscriberNumber) {
		this.subscriberNumber = subscriberNumber;
	}
	public String getBan() {
		return ban;
	}
	public void setBan(String ban) {
		this.ban = ban;
	}
	public String getBanName() {
		return banName;
	}
	public void setBanName(String banName) {
		this.banName = banName;
	}
	public String getPrevBAN() {
		return prevBAN;
	}
	public void setPrevBAN(String prevBAN) {
		this.prevBAN = prevBAN;
	}
	public String getAccountTypeIndicator() {
		return accountTypeIndicator;
	}
	public void setAccountTypeIndicator(String accountTypeIndicator) {
		this.accountTypeIndicator = accountTypeIndicator;
	}
	public String getSocEffectiveDate() {
		return socEffectiveDate;
	}
	public void setSocEffectiveDate(String socEffectiveDate) {
		this.socEffectiveDate = socEffectiveDate;
	}
	public String getInvoiceId() {
		return invoiceId;
	}
	public void setInvoiceId(String invoiceId) {
		this.invoiceId = invoiceId;
	}
	public String getEodgroupid() {
		return eodgroupid;
	}
	public void setEodgroupid(String eodgroupid) {
		this.eodgroupid = eodgroupid;
	}
        
	
	
}
