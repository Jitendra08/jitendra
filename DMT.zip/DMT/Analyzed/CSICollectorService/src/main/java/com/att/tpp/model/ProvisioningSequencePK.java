package com.att.tpp.model;

import java.io.Serializable;
import javax.persistence.*;

/**
 * The primary key class for the PROVISIONING_SEQUENCE database table.
 * 
 */
@Embeddable
public class ProvisioningSequencePK implements Serializable {
	//default serial version id, required for serializable classes.
	private static final long serialVersionUID = 1L;

	@Column(name="PRODUCT_ID", insertable=false, updatable=false)
	private String productId;

	@Column(name="\"ACTION\"", insertable=false, updatable=false)
	private String action;

	@Column(name="SYSTEM_NAME", insertable=false, updatable=false)
	private String systemName;

	@Column(name="PROVISIONING_CARRIER")
	private String provisioningCarrier;

	public ProvisioningSequencePK() {
	}
	public String getProductId() {
		return this.productId;
	}
	public void setProductId(String productId) {
		this.productId = productId;
	}
	public String getAction() {
		return this.action;
	}
	public void setAction(String action) {
		this.action = action;
	}
	public String getSystemName() {
		return this.systemName;
	}
	public void setSystemName(String systemName) {
		this.systemName = systemName;
	}
	public String getProvisioningCarrier() {
		return this.provisioningCarrier;
	}
	public void setProvisioningCarrier(String provisioningCarrier) {
		this.provisioningCarrier = provisioningCarrier;
	}

	public boolean equals(Object other) {
		if (this == other) {
			return true;
		}
		if (!(other instanceof ProvisioningSequencePK)) {
			return false;
		}
		ProvisioningSequencePK castOther = (ProvisioningSequencePK)other;
		return 
			this.productId.equals(castOther.productId)
			&& this.action.equals(castOther.action)
			&& this.systemName.equals(castOther.systemName)
			&& this.provisioningCarrier.equals(castOther.provisioningCarrier);
	}

	public int hashCode() {
		final int prime = 31;
		int hash = 17;
		hash = hash * prime + this.productId.hashCode();
		hash = hash * prime + this.action.hashCode();
		hash = hash * prime + this.systemName.hashCode();
		hash = hash * prime + this.provisioningCarrier.hashCode();
		
		return hash;
	}
}