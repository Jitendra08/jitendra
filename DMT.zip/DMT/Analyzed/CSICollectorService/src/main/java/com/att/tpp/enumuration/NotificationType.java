package com.att.tpp.enumuration;

public enum NotificationType {
	DCMNotification
}
