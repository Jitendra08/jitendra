package com.att.tpp.jms.sender;

import javax.jms.JMSException;
import javax.jms.Message;
import javax.jms.Queue;
import javax.jms.Session;
import javax.jms.TextMessage;

import org.apache.log4j.Logger;
import org.springframework.jms.core.JmsTemplate;
import org.springframework.jms.core.MessageCreator;
import org.springframework.stereotype.Service;

import com.att.tpp.model.ProcessingResult;

/**
 * The TestMessageSender class uses the injected JMSTemplate to send a message
 * to a specified Queue. In our case we're sending messages to 'TestQueueTwo'
 */
@Service
public class GatewayRequestSender
{
	private JmsTemplate jmsTemplate;
	private Queue gatewayProvisioningRequestQueue;
	private static final Logger gatewayRequestSenderLog = Logger.getLogger(GatewayRequestSender.class);
	private final static String swcTransactionId = "swcTransactionId";

	/**
	 * Sends message using JMS Template.
	 *
	 * @param csiMessage the csiMessage
	 * @throws JMSException the jMS exception
	 */	
	public void sendMessage(Message csiMessage) throws JMSException
	{
		//requestSenderLog.info("About to put message on queue. Queue[" + GatewayProvisioningRequestQueue.toString() + "] Message[" + message_m + "]");
		gatewayRequestSenderLog.info("Sending messaget to Gateway queue. Queue[" + gatewayProvisioningRequestQueue.toString() + "]" + "[CSITransID: " + csiMessage.getStringProperty("csiTransactionId") + "Message[" + csiMessage + "]");
		/* Write the logic to parse the in comming xml before sending to queue */
		jmsTemplate.convertAndSend(gatewayProvisioningRequestQueue, csiMessage);
	}
	
	public void sendMessage(final ProcessingResult processingResult) throws JMSException
	{
		
		gatewayRequestSenderLog.info("Sending TPP_ProvisioningRequest Message From CSICollector Service to GateWay Service");

		jmsTemplate.send(this.gatewayProvisioningRequestQueue, new MessageCreator(){

			@Override
			public Message createMessage(Session session) throws JMSException {
				TextMessage message = session.createTextMessage(processingResult.getTppProvReq().toString());
				message.setStringProperty(swcTransactionId,processingResult.getMessageId());
				return message;
			}
			
		});		
		
	}

	/**
	 * Sets the jms template.
	 *
	 * @param template the jms template
	 */
	
	public void setJmsTemplate(JmsTemplate tmpl)
	{
		this.jmsTemplate = tmpl;
	}

	/**
	 * Sets the test queue.
	 *
	 * @param gatewayProvisioningRequestQueue the new test queue
	 */
	public void setGatewayProvRequestQueue(Queue gatewayProvisioningRequestQueue)
	{
		this.gatewayProvisioningRequestQueue = gatewayProvisioningRequestQueue;
	}
}