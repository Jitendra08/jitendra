/**
 * 
 */
package com.att.tpp.dao;

import java.util.List;

import com.att.tpp.model.DcmMessageArchive;
import com.att.tpp.model.FeatureCodeRef;

/**
 * @author rg730b
 *
 */
public interface CSICollectorDao {
	
	public List<String> productList() throws Exception;
	
	public List<FeatureCodeRef> featureCodeRefDCMList() throws Exception;
	
	boolean persistDcmMessage(DcmMessageArchive dcmMessageArchive);

}
