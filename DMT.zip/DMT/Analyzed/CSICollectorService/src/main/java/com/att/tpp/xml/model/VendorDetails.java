/**
 * 
 */
package com.att.tpp.xml.model;

/**
 * @author rg730b
 *
 */
public class VendorDetails {
	
	private String vendorName;
	private String companyName;
	private String orderId;
	
	public VendorDetails(String vendorName, String companyName, String orderId) {
		super();
		this.vendorName = vendorName;
		this.companyName = companyName;
		this.orderId = orderId;
	}

	public String getVendorName() {
		return vendorName;
	}

	public void setVendorName(String vendorName) {
		this.vendorName = vendorName;
	}

	public String getCompanyName() {
		return companyName;
	}

	public void setCompanyName(String companyName) {
		this.companyName = companyName;
	}

	public String getOrderId() {
		return orderId;
	}

	public void setOrderId(String orderId) {
		this.orderId = orderId;
	}
	
	

}
