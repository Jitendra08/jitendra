/**
 * 
 */
package com.att.tpp.utils

import groovy.util.Node;
import groovy.xml.MarkupBuilder;
import groovy.xml.XmlUtil;

import com.att.tpp.xml.model.ProvisioningRequestData;
import com.att.tpp.xml.model.Products;

/**
 * @author rg730b
 *
 */
class ABS_ProvisioningResponseXMLGenerator {
	
	public ABS_ProvisioningResponseXMLGenerator() {
	}

	def String createABSResXML(ProvisioningRequestData dcmReq, Products products, StringBuffer errorMessage){
		def dcmReqXML = new StringWriter()
		def xml = new MarkupBuilder(dcmReqXML)
		
		//def errorMessage ="";
				
		xml.setDoubleQuotes(true)
		xml.mkp.xmlDeclaration(version: "1.0", encoding: "UTF-8")

		xml.ProvisioningResponse("xmlns:xsi":"http://www.w3.org/2001/XMLSchema-instance"){
			Header(
			TransactionId:dcmReq.transactionId,
			ProvisioningCarrier:dcmReq.provisioningCarrier,
			TimeStamp:dcmReq.receivedTimeStamp,
			RoutingCarrier:dcmReq.routingCarrier,
			){
				Sender(Login:"abs", Password:"abs123")
				TransactionCode(MajorCode:"60000", Description:"Fatal Data Error")
			}
			Order(){
				Account(MSISDN:dcmReq.msisdn)
				buildProducts(xml, dcmReq, products, errorMessage)
			}
		}
		
		Node root = new XmlParser().parseText(dcmReqXML.toString())
		cleanNode( root )
		dcmReqXML = XmlUtil.serialize( root )
		 
		return dcmReqXML.toString()
		
	}
/* Below buildProducts method used for the createABSResXML. Here product details pass through the Products */
	def buildProducts(MarkupBuilder mBuilder, ProvisioningRequestData dcmReq, Products products, StringBuffer errorMessage){
		mBuilder.Products(){
			products.product*.each { prod ->
				Product(Category:"3PP", Id:prod.id, Action:prod.action, MajorCode:"60000", Description:"Fatal Data Error"){
					prod.attribute*.each{ attrib ->
						Attribute(Name:attrib.name, Value:attrib.value)
					}
					TransactionCode(MajorCode:"60000", Description:"Fatal Data Error"){
						TransactionCodeList(ErrorCode:"60010", ErrorMessageText:errorMessage)
					}
				}
			}
		}
	}
	
	def String createInvalidXMLABSResXML(ProvisioningRequestData dcmReq, StringBuffer errorMessage){
		def dcmReqXML = new StringWriter()
		def xml = new MarkupBuilder(dcmReqXML)
		
		//def errorMessage ="";
				
		xml.setDoubleQuotes(true)
		xml.mkp.xmlDeclaration(version: "1.0", encoding: "UTF-8")

		xml.ProvisioningResponse("xmlns:xsi":"http://www.w3.org/2001/XMLSchema-instance"){
			Header(
			TransactionId:dcmReq.transactionId,
			ProvisioningCarrier:dcmReq.provisioningCarrier,
			TimeStamp:dcmReq.receivedTimeStamp,
			RoutingCarrier:dcmReq.routingCarrier,
			){
				Sender(Login:"abs", Password:"abs123")
				TransactionCode(MajorCode:"60000", Description:"Fatal Data Error")
			}
			Order(){
				Account(MSISDN:dcmReq.msisdn)
				buildProducts(xml, dcmReq, errorMessage)
			}
		}
		
		Node root = new XmlParser().parseText(dcmReqXML.toString())
		cleanNode( root )
		dcmReqXML = XmlUtil.serialize( root )
		 
		return dcmReqXML.toString()
		
	}
	/* Below buildProducts method used for the createInvalidXMLABSResXML. Here product details are passed through the ProvisioningRequestData */
	def buildProducts(MarkupBuilder mBuilder, ProvisioningRequestData dcmReq, StringBuffer errorMessage){
		mBuilder.Products(){
			dcmReq.products.product*.each { prod ->
				Product(Category:"3PP", Id:prod.id, Action:prod.action, MajorCode:"60000", Description:"Fatal Data Error"){
					prod.attribute*.each{ attrib ->
						Attribute(Name:attrib.name, Value:attrib.value)
					}
					TransactionCode(MajorCode:"60000", Description:"Fatal Data Error"){
						TransactionCodeList(ErrorCode:"60020", ErrorMessageText:errorMessage)
					}
				}
			}
		}
	}
	
	//This Method cleans empty Nodes and null values nodes
	boolean cleanNode( Node node ) {
		node.attributes().with { a ->
			a.findAll { !it.value }.each { a.remove( it.key ) }
		}
		node.children().with { kids ->
			kids.findAll { it instanceof Node ? !cleanNode( it ) : false }
				.each { kids.remove( it ) }
		}
		node.attributes() || node.children() || node.text()
	}

}
