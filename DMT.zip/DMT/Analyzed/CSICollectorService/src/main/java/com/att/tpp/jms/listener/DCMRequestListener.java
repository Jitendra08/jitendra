
package com.att.tpp.jms.listener;

import java.io.IOException;

import javax.jms.JMSException;
import javax.jms.Message;
import javax.jms.MessageListener;
import javax.jms.TextMessage;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.att.tpp.controller.CSICollectorController;
import com.att.tpp.jms.sender.CSIQueueSender;
import com.att.tpp.jms.sender.GatewayRequestSender;
import com.att.tpp.model.ProcessingResult;

/**
 * Class handles  DCM incoming messages
 *
 */
@Service
public class DCMRequestListener implements MessageListener
{
	@Autowired
	private GatewayRequestSender gatewayRequestSender;
	@Autowired
	private CSIQueueSender csiQueueSender;
	@Autowired
	private CSICollectorController csiCollectorController;

	private static final Logger dcmRequestListenerLog = Logger.getLogger(DCMRequestListener.class);
	/**
	 * Method implements JMS onMessage and acts as the entry
	 * point for messages consumed by Springs DefaultMessageListenerContainer.
	 * When DefaultMessageListenerContainer picks a message from the queue it
	 * invokes this method with the message payload.
	 */
	public void onMessage(Message message)
	{
		dcmRequestListenerLog.info("Received DCM CSI message from queue [" + message +"]");

		/* The message must be of type TextMessage */
		if (message instanceof TextMessage)
		{
			try
			{
				String requestXML = ((TextMessage) message).getText();
				dcmRequestListenerLog.info("About to process DCM CSI message: " + requestXML);
				ProcessingResult processingResult =csiCollectorController.processRequest(requestXML);
				dcmRequestListenerLog.info("MessageId :"+processingResult.getMessageId());
				
				dcmRequestListenerLog.info("isValidRequest :"+processingResult.isValidRequest());
				dcmRequestListenerLog.info("isValidTPPProvReq :"+processingResult.isValidTPPProvReq());
				//dcmRequestListenerLog.info("isValidProductExist :"+processingResult.isValidProductExist());
				//dcmRequestListenerLog.info("getTppProvReq().length() :"+processingResult.getTppProvReq().length());
				
				
				
				
				if (processingResult.isValidRequest() && processingResult.isValidTPPProvReq() && processingResult.isValidProductExist() && processingResult.getTppProvReq().length() > 0) {
					//If request is valid and valid generated tppProvReq send to the gateway main queue.
					dcmRequestListenerLog.info("Valid XML/Valid IPID, so sending to Gateway queue.");
					gatewayRequestSender.sendMessage(processingResult);
				}else if(processingResult.isValidTPPProvReq()){
					
					dcmRequestListenerLog.info("Invalid XML/Invalid IPID, so sending back the transaction to CSI queue : ProvSystemTransId: "+processingResult.getMessageId());
					csiQueueSender.sendMessage(processingResult);
				}else{
					
					dcmRequestListenerLog.info("Invalid Request XML/Invalid ABSResponse XML, so dropping the transaction : ProvSystemTransId: "+processingResult.getMessageId());
				}
			}
			catch (JMSException jmsExc)
			{
				String errMsg = "An error occurred extracting DCM CSI message";
				dcmRequestListenerLog.error(errMsg, jmsExc);
			}catch (IOException e) {
				//e.printStackTrace();
				dcmRequestListenerLog.error("Exception occured in onMessage() :: IOException ::",e); 
			} catch (Exception e) {
				//e.printStackTrace();
				dcmRequestListenerLog.error("Exception occured in onMessage() :: Exception ::",e);
			}
		}
		else
		{
			String errMsg = "DCM CSI Message is not of expected type TextMessage";
			dcmRequestListenerLog.error(errMsg);
			throw new RuntimeException(errMsg);
		}
	}

	/**
	 * Sets the message sender.
	 *
	 * @param gatewayRequestSender the new message sender
	 */
	public void setGatewayRequestSender(GatewayRequestSender gatewayRequestSender)
	{
		this.gatewayRequestSender = gatewayRequestSender;
	}
	
	public void setCsiQueueSender(CSIQueueSender csiQueueSender) {
		this.csiQueueSender = csiQueueSender;
	}
}