package com.att.tpp.xml.model;

public class Order {

	private Account account;
	private VendorDetails vendorDetails;
	private EventTypeInfo eventType;
	private Products products;
	
	
	
	
	/**
	 * @param account
	 * @param products
	 */
	public Order(Account account, Products products) {
		this.account = account;
		this.products = products;
	}

	/* DCM Notification */
    
    /**
	 * @param account
	 * @param event
	 */
	
	public Order(Account account, EventTypeInfo eventType) {
		this.account = account;
		this.eventType = eventType;
	}
	
	

	public Order(Account account, VendorDetails vendorDetails,
			EventTypeInfo eventType, Products products) {
		this.account = account;
		this.vendorDetails = vendorDetails;
		this.eventType = eventType;
		this.products = products;
	}

	/**
	 * @return the account
	 */
	public Account getAccount() {
		return account;
	}
	
	/**
	 * @param account the account to set
	 */
	public void setAccount(Account account) {
		this.account = account;
	}
	
	
	/**
	 * @return the eventType
	 */
	public EventTypeInfo getEventType() {
		return eventType;
	}
	
	/**
	 * @param eventType the eventType to set
	 */
	public void setEventType(EventTypeInfo eventType) {
		this.eventType = eventType;
	}

	/**
	 * @return the products
	 */
	public Products getProducts() {
		return products;
	}

	/**
	 * @param products the products to set
	 */
	public void setProducts(Products products) {
		this.products = products;
	}

	public VendorDetails getVendorDetails() {
		return vendorDetails;
	}

	public void setVendorDetails(VendorDetails vendorDetails) {
		this.vendorDetails = vendorDetails;
	}

}
