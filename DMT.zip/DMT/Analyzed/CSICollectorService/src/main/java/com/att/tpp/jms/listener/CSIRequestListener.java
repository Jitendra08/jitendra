
package com.att.tpp.jms.listener;

import javax.jms.JMSException;
import javax.jms.Message;
import javax.jms.MessageListener;
import javax.jms.TextMessage;

import org.apache.log4j.Logger;
import org.springframework.stereotype.Service;

import com.att.tpp.jms.sender.GatewayRequestSender;

/**
 * Class handles CSI incoming messages
 *
 */
@Service
public class CSIRequestListener implements MessageListener
{

	private GatewayRequestSender gatewayRequestSender;

	private static final Logger csiRequestListenerLog = Logger.getLogger(CSIRequestListener.class);


	/**
	 * Method implements JMS onMessage and acts as the entry
	 * point for messages consumed by Springs DefaultMessageListenerContainer.
	 * When DefaultMessageListenerContainer picks a message from the queue it
	 * invokes this method with the message payload.
	 */
	public void onMessage(Message csiMessage)
	{
		csiRequestListenerLog.debug("Received CSI message from queue [" + csiMessage +"]");

		/* The message must be of type TextMessage */
		if (csiMessage instanceof TextMessage)
		{
			try
			{
				String msgText = ((TextMessage) csiMessage).getText();
				csiRequestListenerLog.debug("About to process CSI message: " + msgText);
								
				/* call message sender to put message onto second queue */
				gatewayRequestSender.sendMessage(csiMessage);

			}
			catch (JMSException jmsExc)
			{
				String errMsg = "An error occurred extracting CSI message";
				csiRequestListenerLog.error(errMsg, jmsExc);
			}
		}
		else
		{
			String errMsg = "CSI Message is not of expected type TextMessage";
			csiRequestListenerLog.error(errMsg);
			throw new RuntimeException(errMsg);
		}
	}

	/**
	 * Sets the message sender.
	 *
	 * @param gatewayRequestSender the new message sender
	 */
	public void setGatewayRequestSender(GatewayRequestSender gatewayRequestSender)
	{
		this.gatewayRequestSender = gatewayRequestSender;
	}
}