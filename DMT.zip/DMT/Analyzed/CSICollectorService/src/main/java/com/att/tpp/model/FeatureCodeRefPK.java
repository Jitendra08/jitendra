package com.att.tpp.model;

import java.io.Serializable;

import javax.persistence.*;

/**
 * The primary key class for the FEATURE_CODE_REF database table.
 * 
 */
@Embeddable
public class FeatureCodeRefPK implements Serializable {
	//default serial version id, required for serializable classes.
	private static final long serialVersionUID = 1L;

	@Column(name="FEATURE_CODE")
	private String featureCode;

	@Column(name="PRODUCT_ID")
	private String productId;
	
	@Column(name="ATTRIBUTE_VALUE")
	private String attributeValue;

	public FeatureCodeRefPK() {
	}
	public String getFeatureCode() {
		return this.featureCode;
	}
	public void setFeatureCode(String featureCode) {
		this.featureCode = featureCode;
	}
	public String getProductId() {
		return this.productId;
	}
	public void setProductId(String productId) {
		this.productId = productId;
	}
	public String getAttributeValue() {
		return attributeValue;
	}
	public void setAttributeValue(String attributeValue) {
		this.attributeValue = attributeValue;
	}
	public boolean equals(Object other) {
		if (this == other) {
			return true;
		}
		if (!(other instanceof FeatureCodeRefPK)) {
			return false;
		}
		FeatureCodeRefPK castOther = (FeatureCodeRefPK)other;
		return 
			this.featureCode.equals(castOther.featureCode)
			&& this.productId.equals(castOther.productId)
			&& this.attributeValue.equals(castOther.attributeValue);
	}

	public int hashCode() {
		final int prime = 31;
		int hash = 17;
		hash = hash * prime + this.featureCode.hashCode();
		hash = hash * prime + this.productId.hashCode();
		hash = hash * prime + this.attributeValue.hashCode();
		
		return hash;
	}
}